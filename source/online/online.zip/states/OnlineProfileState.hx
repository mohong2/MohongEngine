package online.states;

import backend.MusicBeatState;
import backend.ui.PsychUIInputText;
import editors.content.FileDialogHandler;
import flash.net.FileFilter;
import flixel.FlxG;
import flixel.FlxSprite;
import flixel.addons.display.FlxBackdrop;
import flixel.addons.display.FlxGridOverlay;
import flixel.text.FlxText;
import flixel.util.FlxColor;
import lime.system.Clipboard;
import online.client.GameClient;
import online.client.OnlineSession;
import online.client.ProfileStore;
import online.shared.SeiunProtocol;
import online.ui.AvatarSprite;
import online.ui.OnlineLayout;
import online.ui.OnlinePanel;
import online.ui.OnlinePointer;
import online.ui.TextButton;
import online.ui.UIStyle;
#if sys
import sys.FileSystem;
#end

/**
	RECORDS —— 个人信息页 (参照 PsychOnline ProfileBox / ProfileTab 的布局与行为重写):
	- 左: 大头像实时预览 + 昵称输入 + 头像选择网格 (内置/模组角色 + mods/avatars 自定义图片,
	      4 列分页) + "导入本地图片" (png/jpg ≤1MB, 复制到 mods/avatars) + 保存并广播;
	- 右: 本机战绩 (online_records.json, 由结算页写入) + 设备码 (点击复制)。
	保存: ProfileStore.setProfile 落盘; 若处于房间连接中, 广播 MSG_PROFILE_UPDATE
	让大厅铭牌/玩家卡片立即生效 (与 OptionsSubstate 的行为一致)。
	头像模型: 角色名 → 原版角色血条图标 (HealthIcon); "file:<name>" → mods/avatars/<name> 本地图片,
	上传后服务器同步给房间内其他玩家。
**/
class OnlineProfileState extends MusicBeatState
{
	static final GRID_COLS:Int = 4;
	static final GRID_ROWS:Int = 2;
	static final THUMB:Int = 56;
	static final THUMB_GAP:Float = 10;

	var statusText:FlxText;
	var nicknameInput:PsychUIInputText;
	var avatarPreview:FlxSprite = null;

	// 两栏布局 (按屏宽居中 + 屏高钳制, 不假定 1280x720)
	var colL:Float = 190;
	var colR:Float = 660;
	var panelTop:Float = 92;
	var panelH:Float = 470;
	var gridYRef:Float = 260;

	var avatarOptions:Array<String> = [];
	var gridPage:Int = 0;
	var gridThumbs:Array<FlxSprite> = [];
	var gridBorders:Array<FlxSprite> = [];
	var selectedAvatar:String = "";

	var deviceCopyText:FlxText = null;

	var fileDialog:FileDialogHandler;

	override function create()
	{
		super.create();
		ProfileStore.ensureLoaded();
		fileDialog = new FileDialogHandler();
		UIStyle.installInputEscapeGuard();

		var bg:FlxSprite = new FlxSprite().loadGraphic(Paths.image('menuDesat'));
		bg.color = 0xFF12243D;
		bg.screenCenter();
		bg.antialiasing = ClientPrefs.data.globalAntialiasing;
		add(bg);
		var grid:FlxBackdrop = new FlxBackdrop(FlxGridOverlay.createGrid(80, 80, 160, 160, true, 0x22FFFFFF, 0x0));
		grid.velocity.set(30, 30);
		grid.alpha = 0.5;
		add(grid);

		// 两栏按屏宽居中 (原 190/660 只对 1280 宽正确), 面板高按屏高钳制。
		var cols:Array<Float> = OnlineLayout.centeredColumns([440, 430], 30);
		colL = cols[0];
		colR = cols[1];
		panelTop = 92;
		panelH = Math.min(470, FlxG.height - panelTop - 40);

		var title:FlxText = OnlineLayout.makeText(colL, 22, FlxG.width - colL - OnlineLayout.PAD, UIStyle.t('recordsTitle', '个人记录'), 32, 0xFF96C8FF, LEFT);
		add(title);
		var sub:FlxText = OnlineLayout.makeText(colL, 62, FlxG.width - colL - OnlineLayout.PAD, UIStyle.t('profileSubtitle', '头像与昵称修改后点"保存并广播"，房间内立即生效'), 13, OnlineLayout.C_SUB, LEFT);
		add(sub);

		buildIdentityPanel();
		buildRecordsPanel();

		statusText = OnlineLayout.makeText(colL + 20, panelTop + panelH + 12, 440, "", 13, OnlineLayout.C_WARN, LEFT);
		add(statusText);

		FlxG.mouse.visible = true;
	}

	// ── 左: 身份 / 头像 ──────────────────────────────────

	function buildIdentityPanel():Void
	{
		var panel:OnlinePanel = new OnlinePanel(colL, panelTop, 440, panelH, 0xFF0A1220, 0.9, 0.68, 0, 0xFF6FB1FF);
		add(panel);

		var ix:Float = colL + 20;
		var idTitle:FlxText = OnlineLayout.makeText(ix, panelTop + 10, 400, UIStyle.t('recordsIdentity', '身份'), 14, 0xFF96C8FF, LEFT);
		add(idTitle);

		// 大头像预览 (PsychOnline ProfileBox 式: 头像在左, 信息在右)
		var previewBg:FlxSprite = new FlxSprite(ix + 4, panelTop + 38).makeGraphic(104, 104, 0xFF3D4C6E);
		add(previewBg);
		refreshPreview();

		var nickLabel:FlxText = OnlineLayout.makeText(ix + 120, panelTop + 36, 280, UIStyle.t('recordsNickname', '昵称'), 13, OnlineLayout.C_SUB, LEFT);
		add(nickLabel);
		// 昵称框宽度按面板钳制: styleInput 传 maxWidth, 不再被无条件抬到 440 压住右侧战绩面板。
		var nickW:Int = Std.int(Math.min(280, 440 - 120 - OnlineLayout.PAD));
		nicknameInput = new PsychUIInputText(ix + 120, panelTop + 56, nickW, ProfileStore.nickname, 17, UIStyle.inputFontKey());
		UIStyle.styleInput(nicknameInput, nickW);
		nicknameInput.cameras = [FlxG.camera];
		add(nicknameInput);

		var deviceLabel:FlxText = OnlineLayout.makeText(ix + 120, panelTop + 104, 280, UIStyle.t('deviceId', '设备码（唯一身份）'), 13, OnlineLayout.C_SUB, LEFT);
		add(deviceLabel);
		var deviceValue:FlxText = OnlineLayout.makeText(ix + 120, panelTop + 124, 280, ProfileStore.deviceId.substr(0, 12) + "…", 13, OnlineLayout.C_TEXT, LEFT);
		add(deviceValue);

		// ── 头像选择网格 (4 列分页) ──
		var gridLabel:FlxText = OnlineLayout.makeText(ix, panelTop + 152, 400,
			UIStyle.t('profileAvatarGrid', '选择头像') + "  (" + UIStyle.t('profileAvatarHint', '点击选择 · 实时预览') + ")", 13, 0xFF96C8FF, LEFT);
		add(gridLabel);
		buildAvatarGrid();
		// 网格/翻页/保存按面板底往上排, 命中高度补到 ≥40px。
		var gridY:Float = panelTop + 180;
		var btnY:Float = panelTop + panelH - 150;
		var prevBtn:TextButton = new TextButton(ix + 4, btnY, "< " + UIStyle.t('profilePrevPage', '上一页'), function() cycleGridPage(-1), 15);
		add(prevBtn);
		var nextBtn:TextButton = new TextButton(ix + 154, btnY, UIStyle.t('profileNextPage', '下一页') + " >", function() cycleGridPage(1), 15);
		add(nextBtn);
		var importBtn:TextButton = new TextButton(ix + 314, btnY, UIStyle.t('profileImportAvatar', '导入本地图片'), function() pickAvatarImage(), 15);
		add(importBtn);
		OnlineLayout.padTouchAll([prevBtn, nextBtn, importBtn]);

		var saveBtn:TextButton = new TextButton(ix + 4, btnY + OnlineLayout.TOUCH_MIN_H, UIStyle.t('profileSaveBroadcast', '保存并广播'), function() saveAndBroadcast(), 20);
		saveBtn.setFormat(Paths.languageFont(), 20, 0xFFFFD24A, LEFT, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		OnlineLayout.padTouch(saveBtn);
		add(saveBtn);

		var backBtn:TextButton = new TextButton(ix + 220, btnY + OnlineLayout.TOUCH_MIN_H, UIStyle.t('back', '返回'), function()
		{
			MusicBeatState.switchState(new OnlineState());
		}, 18);
		OnlineLayout.padTouch(backBtn);
		add(backBtn);

		gridYRef = gridY;
	}

	function refreshPreview():Void
	{
		if (avatarPreview != null)
		{
			remove(avatarPreview);
			avatarPreview.destroy();
			avatarPreview = null;
		}
		avatarPreview = AvatarSprite.make(selectedAvatar, 96);
		avatarPreview.setPosition(colL + 28, panelTop + 42);
		add(avatarPreview);
	}

	// ── 头像选项与网格 ───────────────────────────────────

	function collectAvatarOptions():Void
	{
		avatarOptions = [];
		// 1) mods/avatars 自定义图片 (PsychOnline 式本地头像图)
		#if sys
		try
		{
			var dir:String = AvatarSprite.AVATAR_DIR;
			if (FileSystem.exists(dir) && FileSystem.isDirectory(dir))
			{
				var files:Array<String> = FileSystem.readDirectory(dir);
				files.sort(function(a:String, b:String):Int return Reflect.compare(a.toLowerCase(), b.toLowerCase()));
				for (f in files)
				{
					var lower:String = f.toLowerCase();
					if (lower.endsWith(".png") || lower.endsWith(".jpg") || lower.endsWith(".jpeg"))
						avatarOptions.push("file:" + f);
				}
			}
		}
		catch (e:Dynamic) {}
		#end
		// 2) 内置/模组角色头像 (与设置页同一扫描, 图标 = 角色 idle 立绘)
		try
		{
			for (e in online.substates.OptionsSubstate.scanModCharacterEntries())
			{
				if (e == null)
					continue;
				var name:String = Std.string(Reflect.field(e, "name"));
				if (name.length > 0 && !avatarOptions.contains(name))
					avatarOptions.push(name);
			}
		}
		catch (e:Dynamic) {}
		if (!avatarOptions.contains("bf"))
			avatarOptions.push("bf");
		if (selectedAvatar.length > 0 && !avatarOptions.contains(selectedAvatar))
			avatarOptions.insert(0, selectedAvatar);
	}

	function buildAvatarGrid():Void
	{
		selectedAvatar = ProfileStore.avatar == null || ProfileStore.avatar.length == 0 ? "bf" : ProfileStore.avatar;
		collectAvatarOptions();
		rebuildGrid();
	}

	function rebuildGrid():Void
	{
		for (t in gridThumbs)
		{
			remove(t);
			t.destroy();
		}
		for (b in gridBorders)
		{
			remove(b);
			b.destroy();
		}
		gridThumbs = [];
		gridBorders = [];

		var perPage:Int = GRID_COLS * GRID_ROWS;
		var maxPage:Int = Std.int(Math.max(0, Math.ceil(avatarOptions.length / perPage) - 1));
		if (gridPage > maxPage)
			gridPage = maxPage;
		if (gridPage < 0)
			gridPage = 0;
		var start:Int = gridPage * perPage;

		for (i in 0...perPage)
		{
			var idx:Int = start + i;
			if (idx >= avatarOptions.length)
				break;
			var col:Int = i % GRID_COLS;
			var row:Int = Std.int(i / GRID_COLS);
			var gx:Float = colL + 24 + col * (THUMB + THUMB_GAP);
			var gy:Float = gridYRef + row * (THUMB + THUMB_GAP);

			var selected:Bool = avatarOptions[idx] == selectedAvatar;
			var border:FlxSprite = new FlxSprite(gx - 2, gy - 2).makeGraphic(THUMB + 4, THUMB + 4, selected ? 0xFFFFD24A : 0xFF3D4C6E);
			add(border);
			gridBorders.push(border);

			// 模组角色头像: 临时切到该角色所在模组目录再加载 (同 Freeplay 图标修法)。
			var savedModDir:String = Paths.currentModDirectory;
			var entry:Dynamic = online.substates.OptionsSubstate.characterEntryByName(avatarOptions[idx]);
			if (entry != null && Reflect.field(entry, "modDir") != null && Std.string(Reflect.field(entry, "modDir")).length > 0)
				Paths.currentModDirectory = Std.string(Reflect.field(entry, "modDir"));
			var thumb:FlxSprite = AvatarSprite.make(avatarOptions[idx], THUMB);
			Paths.currentModDirectory = savedModDir;
			thumb.setPosition(gx, gy);
			thumb.ID = idx;
			add(thumb);
			gridThumbs.push(thumb);
		}
	}

	function cycleGridPage(delta:Int):Void
	{
		var perPage:Int = GRID_COLS * GRID_ROWS;
		var maxPage:Int = Std.int(Math.max(0, Math.ceil(avatarOptions.length / perPage) - 1));
		gridPage = (gridPage + delta + maxPage + 1) % (maxPage + 1);
		rebuildGrid();
	}

	function pickAvatarImage():Void
	{
		fileDialog.open(null,
			UIStyle.t('profileAvatarDialogTitle', '选择头像图片 (png/jpg, ≤1MB)'),
			[new FileFilter('Images', '*.png;*.jpg;*.jpeg'), new FileFilter('All Files', '*.*')],
			function()
			{
				var path:String = fileDialog.path.split('\\').join('/');
				if (path == null || path.length == 0)
					return;
				var imported:String = ProfileStore.importAvatarImage(path);
				if (imported == null)
				{
					statusText.text = UIStyle.t('profileImportFailed', '导入失败: 仅支持 png/jpg, 且不超过 1MB');
					return;
				}
				selectedAvatar = imported;
				collectAvatarOptions();
				gridPage = 0;
				rebuildGrid();
				refreshPreview();
				statusText.text = UIStyle.t('profileImportOk', '头像已导入, 点击"保存并广播"生效');
			});
	}

	function saveAndBroadcast():Void
	{
		ProfileStore.setProfile(StringTools.trim(nicknameInput.text), selectedAvatar);
		refreshPreview();
		if (OnlineSession.active)
		{
			var client:GameClient = GameClient.instance;
			if (client != null && client.socket != null && client.state == online.client.GameClient.ClientState.Ready)
			{
				// 自定义头像: 先把文件分块上传到服务器, 再广播身份, 远端才能拿到真实图片。
				if (ProfileStore.avatar != null && ProfileStore.avatar.indexOf("file:") == 0)
					online.client.AvatarFileClient.upload(ProfileStore.avatar.substr(5));
				client.send(SeiunProtocol.MSG_PROFILE_UPDATE, SeiunProtocol.CHANNEL_ROOM, {
					nickname: ProfileStore.nickname,
					avatar: ProfileStore.avatar,
					skin: ProfileStore.skin
				});
			}
			statusText.text = UIStyle.t('profileSavedBroadcast', '已保存并广播给房间内玩家');
		}
		else
			statusText.text = UIStyle.t('profileSavedLocal', '已保存 (当前不在房间中)');
		FlxG.sound.play(Paths.sound('confirmMenu'), 0.7);
	}

	// ── 右: 战绩 ─────────────────────────────────────────

	function buildRecordsPanel():Void
	{
		var recordsPanel:OnlinePanel = new OnlinePanel(colR, panelTop, 430, panelH, 0xFF0A1220, 0.9, 0.68, 0, 0xFF6FB1FF);
		add(recordsPanel);
		var recordsTitle:FlxText = OnlineLayout.makeText(colR + 20, panelTop + 10, 390, UIStyle.t('recordsStats', '本地战绩'), 14, 0xFF96C8FF, LEFT);
		add(recordsTitle);

		var r:Dynamic = ProfileStore.records;
		var bestAcc:Float = ProfileStore.floatOf(r == null ? 0 : Reflect.field(r, "bestAccuracy"));
		var plays:Int = ProfileStore.intOf(r == null ? 0 : Reflect.field(r, "plays"));
		var asyncPlays:Int = ProfileStore.intOf(r == null ? 0 : Reflect.field(r, "asyncPlays"));
		var wins:Int = ProfileStore.intOf(r == null ? 0 : Reflect.field(r, "wins"));
		var rows:Array<{key:String, label:String}> = [
			{key: 'plays', label: UIStyle.t('recordsPlays', '总对局 (实时)')},
			{key: 'wins', label: UIStyle.t('recordsWins', '实时胜场')},
			{key: 'asyncPlays', label: UIStyle.t('recordsAsyncPlays', '异步对局')},
			{key: 'winRate', label: UIStyle.t('recordsWinRate', '胜率')},
			{key: 'bestScore', label: UIStyle.t('recordsBestScore', '最佳成绩')},
			{key: 'bestAccuracy', label: UIStyle.t('recordsBestAccuracy', '最高准确率')},
			{key: 'fullCombos', label: UIStyle.t('recordsFullCombos', 'FC 次数')},
			{key: 'mvps', label: UIStyle.t('recordsMvps', 'MVP 次数')}
		];
		var y:Float = panelTop + 48;
		for (row in rows)
		{
			var label:FlxText = OnlineLayout.makeText(colR + 30, y, 260, row.label, 15, 0xFFC8DCF5, LEFT);
			add(label);
			var value:String = "";
			if (row.key == 'bestAccuracy')
				value = Highscore.floorDecimal(bestAcc * 100, 2) + "%";
			else if (row.key == 'winRate')
			{
				var total:Int = plays + asyncPlays;
				value = total > 0 ? Highscore.floorDecimal(wins / total * 100, 1) + "%" : "-";
			}
			else
				value = Std.string(ProfileStore.intOf(r == null ? 0 : Reflect.field(r, row.key)));
			var valueText:FlxText = OnlineLayout.makeText(colR + 300, y, 110, value, 15, 0xFFFFEB96, RIGHT);
			add(valueText);
			y += 34;
		}
		var updatedMs:Float = ProfileStore.timestampMs(r == null ? 0 : Reflect.field(r, "updatedAt"));
		if (updatedMs > 0)
		{
			var updated:FlxText = OnlineLayout.makeText(colR + 20, y + 8, 390, UIStyle.t('recordsUpdatedAt', '最近更新: ') + Date.fromTime(updatedMs).toString(), 12, OnlineLayout.C_SUB, LEFT);
			add(updated);
		}

		var deviceCopy:FlxText = OnlineLayout.makeText(colR + 20, panelTop + panelH - 44, 390, UIStyle.t('recordsCopyHint', '按 C 或点击此处复制设备码'), 12, OnlineLayout.C_SUB, LEFT);
		add(deviceCopy);
		deviceCopyText = deviceCopy;
	}

	function copyDeviceId():Void
	{
		Clipboard.text = ProfileStore.deviceId;
		statusText.text = UIStyle.t('deviceCopied', '设备码已复制到剪贴板');
		FlxG.sound.play(Paths.sound('confirmMenu'), 0.6);
	}

	// ── 更新 ─────────────────────────────────────────────

	override function update(elapsed:Float)
	{
		super.update(elapsed);
		if (GameClient.instance != null)
			GameClient.instance.update(elapsed);

		// 头像缩略图点击: tap 语义 (按下一松开, 触屏/鼠标同一套), 命中按 56px 图 + 余量。
		OnlinePointer.poll();
		for (t in gridThumbs)
		{
			if (t == null || !t.visible)
				continue;
			if (OnlinePointer.tapped(t.x, t.y, t.width, t.height, OnlineLayout.TOUCH_MIN_H))
			{
				var idx:Int = t.ID;
				if (idx >= 0 && idx < avatarOptions.length)
				{
					selectedAvatar = avatarOptions[idx];
					refreshPreview();
					rebuildGrid();
					FlxG.sound.play(Paths.sound('scrollMenu'), 0.6);
				}
				break;
			}
		}
		if (deviceCopyText != null && OnlinePointer.tappedOn(deviceCopyText, OnlineLayout.TOUCH_MIN_H))
			copyDeviceId();
		if (FlxG.keys.justPressed.C && !UIStyle.anyInputFocused())
			copyDeviceId();

		if (controls.BACK #if android || FlxG.android.justReleased.BACK #end
			&& !UIStyle.anyInputFocused() && !UIStyle.consumedInputEscape())
		{
			FlxG.sound.play(Paths.sound('cancelMenu'));
			MusicBeatState.switchState(new OnlineState());
		}
	}
}
