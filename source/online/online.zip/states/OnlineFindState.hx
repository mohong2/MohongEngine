package online.states;

import StringTools;
import backend.MusicBeatState;
import backend.ui.PsychUIInputText;
import ClientPrefs;
import flixel.addons.display.FlxBackdrop;
import flixel.addons.display.FlxGridOverlay;
import flixel.FlxG;
import flixel.FlxSprite;
import flixel.text.FlxText;
import flixel.tweens.FlxTween;
import flixel.util.FlxColor;
import online.client.GameClient;
import online.client.LanDiscovery;
import online.client.ProfileStore;
import online.shared.SeiunProtocol;
import online.ui.OnlineLayout;
import online.ui.OnlineMenuList;
import online.ui.OnlinePanel;
import online.ui.TextButton;
import online.ui.UIStyle;

/**
	FIND —— 查找局域网服务器 (独立页, 不再挤在主菜单底部):
	- 自动扫描 (2.5s) + 延迟刷新: 列表只在扫描完成后重建, 选中过程绝不跳行;
	- 固定锚点: ">" 选中标记占独立 22px 列, 行文本 x 恒定, 选中只改色不位移;
	- 服务器地址历史 (点击即连, 与 DEDICATED 页共享 ProfileStore.serverHistory);
	- "加入选中服务器" / "直接输入 IP" / "重新扫描" / "返回"。

	UI 重构 (本轮): 两栏 x 由 OnlineLayout.centeredColumns 计算 (不再写死 190/660);
	两个列表迁到 OnlineMenuList 的行列表形态 —— 固定锚点观感保留, 但拿到 tap 语义
	(按下与松开必须同一行)、≥40px 触屏命中与实测截断; 文本统一 OnlineLayout.makeText;
	按钮命中高度经 OnlineLayout.padTouch 补齐; 面板为扁平 OnlinePanel。
**/
class OnlineFindState extends MusicBeatState
{
	var client:GameClient;
	var discovery:LanDiscovery = new LanDiscovery();
	var statusText:FlxText;

	// 扫描结果
	var lanList:OnlineMenuList;
	var lanListBox:FlxSprite;
	var lanEmpty:FlxText;
	var selLan:Int = 0;

	// 历史
	var historyList:OnlineMenuList;
	var historyListBox:FlxSprite;
	var historyEmpty:FlxText;
	var selHistory:Int = 0;

	// 两栏布局 (按屏宽居中, 不假定 1280)
	var colL:Float = 190;
	var colR:Float = 660;
	static inline var COL_L_W:Float = 440;
	static inline var COL_R_W:Float = 430;
	static inline var ROW_H:Float = 30;
	static inline var MAX_ROWS:Int = 9;

	var scanHint:FlxText;
	var rescanTimer:Float = 0;
	var side:Int = 0; // 0=局域网 1=历史
	var lastLanSig:String = "";
	var lastHintSig:String = "";

	// IP 输入覆盖层
	var overlayDim:FlxSprite;
	var overlayInput:PsychUIInputText;
	var overlayTitle:FlxText;
	var overlayActive:Bool = false;

	override function create()
	{
		super.create();
		UIStyle.installInputEscapeGuard();
		ProfileStore.ensureLoaded();
		client = (GameClient.instance != null) ? GameClient.instance : new GameClient();

		var bg:FlxSprite = new FlxSprite().loadGraphic(Paths.image('menuDesat'));
		bg.color = 0xFF23292E;
		bg.screenCenter();
		bg.antialiasing = ClientPrefs.data.globalAntialiasing;
		add(bg);
		var grid:FlxBackdrop = new FlxBackdrop(FlxGridOverlay.createGrid(80, 80, 160, 160, true, 0x22FFFFFF, 0x0));
		grid.velocity.set(30, 30);
		grid.alpha = 0.5;
		add(grid);

		// 两栏按屏宽居中 (窄屏时贴边 PAD, 不再假定 1280 宽)
		var cols:Array<Float> = OnlineLayout.centeredColumns([COL_L_W, COL_R_W], 30);
		colL = cols[0];
		colR = cols[1];
		var panelTop:Float = 92;
		var panelH:Float = Math.max(240, FlxG.height - panelTop - 200);

		var title:FlxText = OnlineLayout.makeText(colL, 22, FlxG.width - colL - OnlineLayout.PAD,
			UIStyle.t('findTitle', '查找局域网服务器'), 32, 0xFFFFEB96, LEFT);
		add(title);
		var sub:FlxText = OnlineLayout.makeText(colL, 62, FlxG.width - colL - OnlineLayout.PAD,
			UIStyle.t('findSubtitle', '←→ 切换 局域网/历史 · ↑↓ 选择 · 回车 加入选中'), 13, OnlineLayout.C_SUB, LEFT);
		add(sub);

		// ── 左: 局域网扫描结果 ──
		var lanPanel:OnlinePanel = new OnlinePanel(colL, panelTop, COL_L_W, panelH, 0xFF0B1218, 0.9, 0.62, 0, 0xFFFFE38A);
		add(lanPanel);
		var lanTitle:FlxText = OnlineLayout.makeText(colL + 20, panelTop + 10, COL_L_W - 40, UIStyle.t('findLanResults', '局域网扫描结果'), 14, 0xFFFFEB96, LEFT);
		add(lanTitle);
		scanHint = OnlineLayout.makeText(colL + 20, panelTop + 30, COL_L_W - 40, "", 12, OnlineLayout.C_SUB, LEFT);
		add(scanHint);
		lanListBox = new FlxSprite(colL + 14, panelTop + 54).makeGraphic(1, 1, FlxColor.BLACK);
		lanListBox.alpha = 0.35;
		add(lanListBox);
		lanList = new OnlineMenuList(colL + 14, panelTop + 60).asRowList(COL_L_W - 58, 13, ROW_H);
		lanList.onChange = function(i:Int) selLan = i;
		lanList.onAccept = function(i:Int)
		{
			side = 0;
			selLan = i;
			joinSelected();
		};
		add(lanList);

		// ── 右: 地址历史 ──
		var historyPanel:OnlinePanel = new OnlinePanel(colR, panelTop, COL_R_W, panelH, 0xFF0B1218, 0.9, 0.62, 0, 0xFFFFE38A);
		add(historyPanel);
		var historyTitle:FlxText = OnlineLayout.makeText(colR + 20, panelTop + 10, COL_R_W - 40, UIStyle.t('findHistory', '服务器地址历史 (点击即连)'), 14, 0xFFFFEB96, LEFT);
		add(historyTitle);
		historyListBox = new FlxSprite(colR + 14, panelTop + 38).makeGraphic(1, 1, FlxColor.BLACK);
		historyListBox.alpha = 0.35;
		add(historyListBox);
		historyList = new OnlineMenuList(colR + 14, panelTop + 44).asRowList(COL_R_W - 58, 13, ROW_H);
		historyList.onChange = function(i:Int) selHistory = i;
		historyList.onAccept = function(i:Int)
		{
			side = 1;
			selHistory = i;
			joinSelected();
		};
		add(historyList);

		// ── 底部按钮 (两列, 命中高度补到 ≥40px) ──
		var btnY:Float = panelTop + panelH + 12;
		var joinBtn:TextButton = new TextButton(colL + 20, btnY, "< " + UIStyle.t('findJoinSelected', '加入选中服务器') + " >", joinSelected, 18);
		joinBtn.alignment = LEFT;
		add(joinBtn);
		var ipBtn:TextButton = new TextButton(colL + 20, btnY + OnlineLayout.TOUCH_MIN_H, "< " + UIStyle.t('findDirectIp', '直接输入 IP') + " >", openIpOverlay, 16);
		ipBtn.alignment = LEFT;
		add(ipBtn);
		var rescanBtn:TextButton = new TextButton(colR + 20, btnY, "< " + UIStyle.t('findRescan', '重新扫描') + " >", startScan, 18);
		rescanBtn.alignment = LEFT;
		add(rescanBtn);
		var backBtn:TextButton = new TextButton(colR + 20, btnY + OnlineLayout.TOUCH_MIN_H, "< " + UIStyle.t('back', '返回') + " >", doBack, 16);
		backBtn.alignment = LEFT;
		add(backBtn);
		OnlineLayout.padTouchAll([joinBtn, ipBtn, rescanBtn, backBtn]);

		statusText = OnlineLayout.makeText(OnlineLayout.PAD, btnY + OnlineLayout.TOUCH_MIN_H * 2 + 6,
			FlxG.width - OnlineLayout.PAD * 2, "", 14, 0xFFFFDC8C, CENTER);
		add(statusText);

		startScan();
		rebuildLan();
		rebuildHistory();
		syncListFocus();

		if (client.state == online.client.GameClient.ClientState.Ready)
			statusText.text = UIStyle.t('connected', '协议校验通过，已连接：') + client.serverName;
		else if (client.state == online.client.GameClient.ClientState.Failed)
			statusText.text = client.lastError;
		FlxG.mouse.visible = true;
	}

	function startScan():Void
	{
		if (discovery.scanning)
			return;
		discovery.start(2.5);
		scanHint.text = UIStyle.t('discoveryScanning', '扫描中...');
	}

	// ── 局域网列表 (固定锚点) ────────────────────────────

	function rebuildLan():Void
	{
		var entries:Array<OnlineMenuEntry> = [];
		var n:Int = 0;
		for (r in discovery.results)
		{
			if (n >= MAX_ROWS)
				break;
			var type:String = r.dedicated ? UIStyle.t('findDedicated', '[专用服务器]') : UIStyle.t('findEmbedded', '[本机托管]');
			entries.push(new OnlineMenuEntry(r.name + "  " + r.address + ":" + r.port + " " + type));
			n++;
		}
		if (selLan >= entries.length)
			selLan = 0;
		lanList.setEntries(entries);
		lanList.curSelected = selLan;
		lanList.refreshLabels();

		// 空态提示不进列表 (避免"选中空行"), 单独一行文本。
		var emptyMsg:String = discovery.done
			? UIStyle.t('discoveryEmpty', '未发现局域网服务器。可尝试直接输入房主 IP。')
			: UIStyle.t('discoveryScanning', '扫描中...');
		if (lanEmpty == null)
		{
			lanEmpty = OnlineLayout.makeText(lanList.startPosition.x + 22, lanList.startPosition.y, COL_L_W - 58, "", 13, FlxColor.GRAY, LEFT);
			lanEmpty.wordWrap = true;
			add(lanEmpty);
		}
		lanEmpty.visible = entries.length == 0;
		lanEmpty.text = entries.length == 0 ? emptyMsg : "";
		lanListBox.scale.set(COL_L_W - 28, entries.length > 0 ? 10 + entries.length * ROW_H : 44);
		lanListBox.updateHitbox();
	}

	function rebuildHistory():Void
	{
		var entries:Array<OnlineMenuEntry> = [];
		var n:Int = 0;
		for (h in ProfileStore.serverHistory)
		{
			if (n >= MAX_ROWS)
				break;
			var addr:String = Reflect.field(h, "address");
			var name:String = Reflect.field(h, "name");
			entries.push(new OnlineMenuEntry((name != null && name.length > 0 ? name + "  " : "") + addr));
			n++;
		}
		if (selHistory >= entries.length)
			selHistory = 0;
		historyList.setEntries(entries);
		historyList.curSelected = selHistory;
		historyList.refreshLabels();

		if (historyEmpty == null)
		{
			historyEmpty = OnlineLayout.makeText(historyList.startPosition.x + 22, historyList.startPosition.y, COL_R_W - 58, "", 13, FlxColor.GRAY, LEFT);
			add(historyEmpty);
		}
		historyEmpty.visible = entries.length == 0;
		historyEmpty.text = entries.length == 0 ? UIStyle.t('dedicatedNoHistory', '暂无历史记录') : "";
		historyListBox.scale.set(COL_R_W - 28, entries.length > 0 ? 10 + entries.length * ROW_H : 44);
		historyListBox.updateHitbox();
	}

	/** 只有当前侧的列表接收键盘/指针输入 (两列各自的选中互不干扰)。 */
	function syncListFocus():Void
	{
		if (lanList != null)
			lanList.inputEnabled = !overlayActive && side == 0;
		if (historyList != null)
			historyList.inputEnabled = !overlayActive && side == 1;
	}

	function joinSelected():Void
	{
		if (side == 0)
		{
			if (discovery.results.length == 0 || selLan >= discovery.results.length)
			{
				statusText.text = UIStyle.t('findNothingSelected', '没有可加入的服务器，请先扫描或直接输入 IP');
				return;
			}
			var r = discovery.results[selLan];
			connectToAddress(r.address + ":" + r.port);
		}
		else
		{
			if (ProfileStore.serverHistory.length == 0 || selHistory >= ProfileStore.serverHistory.length)
			{
				statusText.text = UIStyle.t('findNothingSelected', '没有可加入的服务器，请先扫描或直接输入 IP');
				return;
			}
			var addr:String = Reflect.field(ProfileStore.serverHistory[selHistory], "address");
			connectToAddress(addr);
		}
	}

	function connectToAddress(addressText:String):Void
	{
		if (client == null)
			return;
		if (client.state == online.client.GameClient.ClientState.Ready)
		{
			var parsed:{host:String, port:Int} = GameClient.parseAddress(addressText);
			if (parsed.host != client.host || parsed.port != client.port)
			{
				client.send(SeiunProtocol.MSG_BYE, SeiunProtocol.CHANNEL_CONTROL, {});
				client.flush();
				client.disconnect(false);
			}
			else
			{
				statusText.text = UIStyle.t('connected', '协议校验通过，已连接：') + client.serverName;
				return;
			}
		}
		statusText.text = UIStyle.t('connecting', '正在连接...');
		ProfileStore.setServerAddress(addressText);
		if (!client.connect(addressText))
			statusText.text = client.lastError;
		else
			statusText.text = UIStyle.t('handshaking', '已连接，正在校验 Seiun 协议...');
	}

	// ── 直接输入 IP 覆盖层 ───────────────────────────────

	function openIpOverlay():Void
	{
		overlayActive = true;
		overlayDim = new FlxSprite().makeGraphic(FlxG.width, FlxG.height, FlxColor.BLACK);
		overlayDim.alpha = 0;
		add(overlayDim);
		FlxTween.tween(overlayDim, {alpha: 0.6}, 0.2);

		// 覆盖层按屏高居中 (原来 250/310 写死只在 720 高正确), 字体统一 languageFont。
		var overlayY:Float = FlxG.height * 0.35;
		overlayTitle = OnlineLayout.makeText(0, overlayY, FlxG.width, UIStyle.t('findDirectIp', '直接输入 IP'), 30, OnlineLayout.C_TEXT, CENTER);
		add(overlayTitle);

		var inputW:Int = Std.int(Math.min(560, FlxG.width - OnlineLayout.PAD * 4));
		overlayInput = new PsychUIInputText(Std.int((FlxG.width - inputW) / 2), overlayY + OnlineLayout.lineHeight(30) + 14,
			inputW, ProfileStore.serverAddress, 22, UIStyle.inputFontKey());
		UIStyle.styleInput(overlayInput, inputW);
		add(overlayInput);
		PsychUIInputText.focusOn = overlayInput;
		syncListFocus();
	}

	function closeIpOverlay():Void
	{
		if (!overlayActive)
			return;
		overlayActive = false;
		if (overlayInput != null)
		{
			if (PsychUIInputText.focusOn == overlayInput)
				PsychUIInputText.focusOn = null;
			remove(overlayInput);
			overlayInput.destroy();
			overlayInput = null;
		}
		if (overlayTitle != null) { remove(overlayTitle); overlayTitle.destroy(); overlayTitle = null; }
		if (overlayDim != null) { remove(overlayDim); overlayDim.destroy(); overlayDim = null; }
		syncListFocus();
	}

	function doBack():Void
	{
		FlxG.sound.play(Paths.sound('cancelMenu'));
		discovery.cancel();
		MusicBeatState.switchState(new OnlineState());
	}

	// ── 更新 ─────────────────────────────────────────────

	override function update(elapsed:Float)
	{
		super.update(elapsed);
		if (client != null)
		{
			client.update(elapsed);
			if (client.state == online.client.GameClient.ClientState.Failed)
				statusText.text = client.lastError;
		}
		discovery.update(elapsed);
		if (discovery.done)
		{
			var hintText:String = discovery.results.length > 0
				? UIStyle.t('findFound', '发现 {n} 个服务器 (8 秒后自动重扫)').replace('{n}', Std.string(discovery.results.length))
				: UIStyle.t('discoveryEmpty', '未发现局域网服务器。可尝试直接输入房主 IP。');
			if (hintText != lastHintSig)
			{
				lastHintSig = hintText;
				scanHint.text = hintText;
			}
			// 列表只在扫描结果变化时重建, 避免每帧销毁/创建对象。
			var lanSigParts:Array<String> = [];
			for (r in discovery.results)
				lanSigParts.push(r.address + ":" + r.port + "|" + r.name);
			var lanSig:String = lanSigParts.join(";");
			if (lanSig != lastLanSig)
			{
				lastLanSig = lanSig;
				rebuildLan();
			}
			rescanTimer += elapsed;
			if (rescanTimer >= 8)
			{
				rescanTimer = 0;
				startScan();
			}
		}
		else
		{
			var scanningText:String = UIStyle.t('discoveryScanning', '扫描中...');
			if (scanningText != lastHintSig)
			{
				lastHintSig = scanningText;
				scanHint.text = scanningText;
			}
		}

		var ev = client.pollEvent();
		while (ev != null)
		{
			switch (ev.type)
			{
				case SeiunProtocol.MSG_WELCOME:
					ProfileStore.addServerHistory(client.host + ":" + client.port, client.serverName);
					statusText.text = UIStyle.t('findConnectedHint', '已连接: ') + client.serverName
						+ " · " + UIStyle.t('findJoinHint', '返回主菜单后可用 JOIN ROOM 输入房间码加入');
					rebuildHistory();
				case SeiunProtocol.MSG_ROOM_LIST_RESULT:
					if (ev.data != null && ev.data.rooms != null)
					{
						var rooms:Array<Dynamic> = cast ev.data.rooms;
						statusText.text = UIStyle.t('connected', '协议校验通过，已连接：') + client.serverName
							+ " · " + (rooms.length == 0
								? UIStyle.t('noRooms', '该服务器当前没有房间，可创建或输入房间码加入。')
								: UIStyle.t('findRoomsFound', '该服务器有 {n} 个房间').replace('{n}', Std.string(rooms.length)));
					}
				case SeiunProtocol.MSG_ERROR:
					statusText.text = UIStyle.errText(ev.data == null ? -1 : Reflect.field(ev.data, "code"), ev.data == null ? client.lastError : Reflect.field(ev.data, "message"));
			}
			ev = client.pollEvent();
		}

		var escCancelledFocus:Bool = UIStyle.consumedInputEscape();

		if (overlayActive)
		{
			if (overlayInput == null)
				return;
			UIStyle.updateFocusOutline(overlayInput);
			if (controls.ACCEPT || FlxG.keys.justPressed.ENTER)
			{
				var text:String = StringTools.trim(overlayInput.text);
				closeIpOverlay();
				if (text.length > 0)
					connectToAddress(text);
			}
			// 输入框聚焦时 BACK 放行: Backspace 是退格不是返回; ESC 第一次只取消聚焦。
			else if (controls.BACK #if android || FlxG.android.justReleased.BACK #end && !UIStyle.anyInputFocused())
				closeIpOverlay();
			return;
		}

		// 左右/TAB 切换焦点栏; ↑↓ 选择与 ACCEPT/点击由当前侧的 OnlineMenuList 处理
		// (行内 tap 语义 + ≥40px 命中都在组件里, 这里不再自己遍历行)。
		if (controls.UI_LEFT_P)
		{
			side = 0;
			FlxG.sound.play(Paths.sound('scrollMenu'), 0.4);
		}
		else if (controls.UI_RIGHT_P)
		{
			side = 1;
			FlxG.sound.play(Paths.sound('scrollMenu'), 0.4);
		}
		else if (FlxG.keys.justPressed.TAB)
			side = side == 0 ? 1 : 0;
		syncListFocus();

		// 当前侧为空时 ACCEPT 仍给出提示 (空列表不会触发组件的 onAccept)。
		if (controls.ACCEPT)
		{
			var emptySide:Bool = (side == 0 && discovery.results.length == 0)
				|| (side == 1 && ProfileStore.serverHistory.length == 0);
			if (emptySide)
				joinSelected();
		}
		if (FlxG.keys.justPressed.R)
			startScan();

		if (controls.BACK #if android || FlxG.android.justReleased.BACK #end && !UIStyle.anyInputFocused() && !escCancelledFocus)
			doBack();
	}

	override function destroy():Void
	{
		discovery.cancel();
		super.destroy();
	}
}
