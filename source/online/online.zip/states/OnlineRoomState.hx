package online.states;

import backend.MusicBeatState;
import flixel.FlxCamera;
import flixel.FlxG;
import flixel.FlxSprite;
import flixel.group.FlxSpriteGroup;
import flixel.group.FlxGroup.FlxTypedGroup;
import flixel.text.FlxText;
import flixel.tweens.FlxEase;
import flixel.tweens.FlxTween;
import flixel.util.FlxColor;
import lime.system.Clipboard;
import online.client.GameClient;
import online.client.ModSyncClient;
import online.client.OnlineSession;
import online.shared.SeiunHash;
import online.shared.SeiunProtocol;
import online.substates.OptionsSubstate;
import online.substates.SongSelectSubstate;
import online.ui.AvatarSprite;
import online.ui.BadgeRow;
import online.ui.CreateRoomCard;
import online.ui.OnlinePanel;
import online.ui.LobbyCharacter;
import online.ui.LobbyChatBox;
import online.ui.LobbyStageBg;
import online.ui.OnlineBigButton;
import online.ui.OnlineLayout;
import online.ui.OnlinePointer;
import online.ui.PlayerCard;
import online.ui.TextButton;
import online.ui.UIStyle;
import Song;
import Song.SwagSong;
import states.LoadingState;
import states.PlayState;

/**
	房间大厅 (PsychOnline RoomState 参考 · 混合版布局重构):
	- 顶栏: 房间名+房间码 (点击复制) | 当前歌曲 (点击选歌) | 开始/门闩状态 | 规则徽标行 (BadgeRow);
	- 左栏: 玩家卡片列表 (PlayerCard: 头像/昵称/房主/准备/观战/ping, 房主点卡两次确认踢出),
	        支持滚轮/拖动滚动, 观战者排在游玩者之后;
	- 右栏: 聊天面板 (LobbyChatBox, 公告/加入离开/模组同步走同一消息流);
	- 中央: 大厅舞台 (真实舞台布景 + 玩家立绘, 镜头按人数拉远);
	- 底栏: 准备/开始/选歌/设置/退出 操作条 (TextButton tap 语义, 命中区 ≥40px)。
	窄屏 (< OnlineLayout.NARROW_W) 降级: 隐藏玩家卡片栏, 聊天沉底全宽。
	协议 / 模组同步 / 对局启动逻辑与原实现一致, 仅 UI 重构。
**/
class OnlineRoomState extends MusicBeatState
{
	/** 大厅舞台专用相机 (叠加在主相机之下, 可缩放拉远)。 */
	public static var camStage:FlxCamera = null;

	var client:GameClient;
	var started:Bool = false;
	var countdownActive:Bool = false;
	var readyState:Bool = false;
	var reportedChartKey:String = "";
	var reportedLocalChartHash:String = "";
	var lastSentManifestSig:String = "";
	/** ROOM_READY 去抖: 内容未变不重发, 内容变化至少间隔 500ms。 */
	static inline var READY_MIN_INTERVAL_MS:Int = 500;
	var lastReadySentAt:Float = 0;
	var lastReadySentKey:String = "";
	var pendingReadyKey:String = "";
	var pendingReadySent:Bool = false;
	var lastPlayerSig:String = "";
	var lastCharSig:String = "";
	var lastBadgeSig:String = "";
	var beatTimer:Float = 0;
	var savedBgColor:FlxColor = 0xFF000000;
	/** HUD 刷新节流: 玩家卡/徽标/站台角色签名每帧拼字符串, 降到 4Hz 减少 GC 压力。 */
	var hudRefreshTimer:Float = 0;

	// 舞台层
	var stageBg:LobbyStageBg;
	var charactersLayer:FlxTypedGroup<LobbyCharacter>;

	// HUD (顶栏)
	var roomTitle:FlxText;
	var songText:FlxText;
	var startStateText:FlxText;
	var badgeRow:BadgeRow;

	// 左栏玩家卡片
	var playersPanel:OnlinePanel;
	var playersTitle:FlxText;
	var playerCards:Array<PlayerCard> = [];
	var railScroll:Float = 0;
	var railMaxScroll:Float = 0;
	var dragTouchId:Int = -1;
	var dragStartY:Float = 0;
	var dragStartScroll:Float = 0;

	// 右栏聊天
	var chatBox:LobbyChatBox;

	// 底部按钮 (实体大按钮, 替代小号文字按钮)
	var readyButton:OnlineBigButton;
	var buttonsRow:Array<OnlineBigButton> = [];
	var curButton:Int = 0;

	// 布局区 (create 时按实际宽高计算, 不假定 1280x720)
	var narrow:Bool = false;
	var railX:Float = 0;
	var railY:Float = 0;
	var railW:Float = 0;
	var railH:Float = 0;
	var cardsX:Float = 0;
	var cardsW:Float = 0;
	var cardsStartY:Float = 0;
	var cardStep:Float = PlayerCard.CARD_H + 8;

	// ── 创建 ─────────────────────────────────────────────

	override function create()
	{
		super.create();
		// 大厅要在 Substate(选歌/设置) 打开期间继续收发网络事件,
		// 否则倒计时/加入离开/同步进度会被搁置到关闭 Substate 才处理。
		persistentUpdate = true;
		UIStyle.installInputEscapeGuard();
		client = GameClient.instance != null ? GameClient.instance : new GameClient();

		setupCameras();

		// 舞台层 (走 camStage, 叠加在主相机之下)
		stageBg = new LobbyStageBg();
		stageBg.cameras = [camStage];
		add(stageBg);

		charactersLayer = new FlxTypedGroup<LobbyCharacter>();
		charactersLayer.cameras = [camStage];
		add(charactersLayer);

		buildHud();
		buildButtons();

		ModSyncClient.reset();
		if (OnlineSession.chart == null)
			ModSyncClient.requestSendLocalManifest(client, null, manifestContextKey(null));
		maybeReportChartHash();
		refreshBadges(true);
		refreshPlayerRows(true);
		rebuildCharacters(true);
		appendChat(UIStyle.t('roomEntered', '已进入房间。输入框点击/TAB 聚焦聊天, ESC 退出房间。'));
		FlxG.mouse.visible = true;
		online.client.CrashReporter.reportPending();
	}

	/** 大厅舞台相机: 主相机保持 HUD (zoom 1), camStage 画布垫底负责舞台与缩放。 */
	function setupCameras():Void
	{
		savedBgColor = FlxG.camera.bgColor;
		camStage = new FlxCamera(0, 0, FlxG.width, FlxG.height);
		camStage.bgColor = 0xFF0B0F1E;
		camStage.scroll.set(200, 250);
		FlxG.cameras.add(camStage, false);
		// 舞台画布垫到最底, 主相机 (HUD/Substate/过渡) 叠加在其上
		try
		{
			FlxG.game.setChildIndex(camStage.flashSprite, 0);
		}
		catch (e:Dynamic) {}
		FlxG.camera.bgColor = 0x00000000;
		FlxG.camera.scroll.set(0, 0);
		FlxG.camera.zoom = 1;
		applyCameraForCount(OnlineSession.players.length, true);
	}

	/** 计算布局区 (混合版: 顶栏 / 左卡片栏 / 右聊天 / 底操作条)。 */
	function computeLayout():Void
	{
		narrow = FlxG.width < OnlineLayout.NARROW_W;
		railX = OnlineLayout.PAD;
		railY = 84;
		var bottomH:Float = OnlineBigButton.BTN_H + 36;
		railW = 250;
		railH = FlxG.height - railY - bottomH;
		cardsX = railX + 8;
		cardsW = railW - 16;
		cardsStartY = railY + 30;
	}

	function buildHud():Void
	{
		computeLayout();

		// 顶栏第 1 行: 左 房间名+房间码 (点击复制) | 右 规则徽标行 (BadgeRow 实测排布)
		roomTitle = OnlineLayout.makeText(OnlineLayout.PAD + 2, 8, 420, "", 20, 0xFFFFEB96);
		roomTitle.textField.wordWrap = false;
		add(roomTitle);

		badgeRow = new BadgeRow(0, 12, FlxG.width - 470, true);
		add(badgeRow);

		// 顶栏第 2/3 行 (居中): 当前歌曲 (点击选歌) + 开始/门闩状态
		songText = OnlineLayout.makeText(0, 34, FlxG.width, "", 18, FlxColor.WHITE, CENTER);
		add(songText);
		startStateText = OnlineLayout.makeText(0, 60, FlxG.width, "", 12, 0xFFBEDCFF, CENTER);
		add(startStateText);

		// 左栏: 玩家卡片 (窄屏隐藏, 人数徽标仍在顶栏)
		playersPanel = new OnlinePanel(railX, railY, railW, railH);
		add(playersPanel);
		playersTitle = OnlineLayout.makeText(railX + 12, railY + 6, railW - 24, "", 14, 0xFFFFEB96);
		add(playersTitle);

		// 右栏: 聊天 (宽屏右侧栏; 窄屏沉底全宽)
		var chatX:Float = narrow ? OnlineLayout.PAD : FlxG.width - 320 - OnlineLayout.PAD;
		var chatY:Float = narrow ? FlxG.height - 300 : railY;
		var chatW:Float = narrow ? FlxG.width - OnlineLayout.PAD * 2 : 320;
		var chatH:Float = narrow ? 200 : railH;
		chatBox = new LobbyChatBox(chatX, chatY, chatW, chatH);
		chatBox.onSend = function(text:String):Void
		{
			sendChatMessage(text);
		};
		add(chatBox);

		if (narrow)
		{
			playersPanel.visible = false;
			playersTitle.visible = false;
		}
	}

	function rebuildButtons():Void
	{
		buildButtons();
	}

	function buildButtons():Void
	{
		// 房间模式/身份可能在房间内被房主实时修改, 重建按钮前先清掉旧行。
		clearButtonsRow();

		// 底部实体大按钮: 准备/开始用强调色, 退出用警示色, 其余普通; 整行水平居中。
		var defs:Array<{text:String, kind:String, tag:String, fn:Void->Void}> = [];
		var selfSpec:Bool = OnlineSession.selfIsSpectator();
		var realtime:Bool = OnlineSession.mode == online.shared.OnlineTypes.OnlineConst.MODE_REALTIME;
		if (realtime && !selfSpec)
			defs.push({text: UIStyle.t('roomReady', '准备'), kind: "primary", tag: "ready", fn: toggleReady});
		if (OnlineSession.isHost)
		{
			defs.push({text: realtime ? UIStyle.t('roomModeBtnRealtime', '模式: 实时对战') : UIStyle.t('roomModeBtnAsync', '模式: 异步排名'),
				kind: "normal", tag: "", fn: toggleRoomMode});
			defs.push({text: UIStyle.t('roomSongBtn', '选歌'), kind: "normal", tag: "", fn: openSongSelect});
			defs.push({text: UIStyle.t('roomOptionsBtn', '设置'), kind: "normal", tag: "", fn: openOptions});
			if (realtime)
				defs.push({text: UIStyle.t('roomStartBtn', '开始'), kind: "primary", tag: "", fn: forceStart});
			else
				defs.push({text: UIStyle.t('roomStartPlayBtn', '开始游玩'), kind: "primary", tag: "", fn: startLocalSong});
		}
		else
		{
			if (!realtime && !selfSpec)
				defs.push({text: UIStyle.t('roomStartPlayBtn', '开始游玩'), kind: "primary", tag: "", fn: startLocalSong});
			defs.push({text: UIStyle.t('roomOptionsBtn', '设置'), kind: "normal", tag: "", fn: openOptions});
		}
		defs.push({text: UIStyle.t('roomLeaveBtn', '退出房间'), kind: "danger", tag: "", fn: leaveRoom});

		var rowY:Float = FlxG.height - OnlineBigButton.BTN_H - 18;
		for (d in defs)
		{
			var btn:OnlineBigButton = new OnlineBigButton(0, rowY, d.text, d.kind, d.fn);
			add(btn);
			buttonsRow.push(btn);
			if (d.tag == "ready")
				readyButton = btn;
		}
		layoutButtonsRow();
		if (buttonsRow.length > 0)
			buttonsRow[0].focused = true;
	}

	/** 底部大按钮行: 实测宽度 + 固定间距, 整行水平居中, 不再挤靠一侧。 */
	function layoutButtonsRow():Void
	{
		if (buttonsRow.length == 0)
			return;
		var gap:Float = 14;
		var total:Float = 0;
		for (b in buttonsRow)
			total += b.width;
		total += gap * (buttonsRow.length - 1);
		var px:Float = (FlxG.width - total) / 2;
		if (px < 8)
			px = 8;
		var rowY:Float = FlxG.height - OnlineBigButton.BTN_H - 18;
		for (b in buttonsRow)
		{
			b.x = px;
			b.y = rowY;
			px += b.width + gap;
		}
	}

	/** 销毁并移除底部按钮行 (房间模式/身份变化时重建)。 */
	function clearButtonsRow():Void
	{
		for (b in buttonsRow)
		{
			if (b != null)
			{
				b.focused = false;
				remove(b);
				b.destroy();
			}
		}
		buttonsRow = [];
		readyButton = null;
		curButton = 0;
	}

	/** 房主把当前房间设置广播给服务器 (与 OptionsSubstate.broadcastRoomSettings 保持一致)。 */
	function broadcastRoomSettings():Void
	{
		if (client == null || client.socket == null || client.state != online.client.GameClient.ClientState.Ready || !OnlineSession.active)
			return;
		var s = OnlineSession.settings;
		var maxPlayers:Int = s != null ? Std.int(s.maxPlayers) : 4;
		var preset:String = ClientPrefs.data.judgementPreset;
		var timings:Array<Int> = (preset == 'Custom')
			? (ClientPrefs.data.judgementTimings != null ? ClientPrefs.data.judgementTimings.copy() : [25, 50, 70, 100])
			: backend.Ratings.returnPreset(preset);
		client.send(SeiunProtocol.MSG_ROOM_SETTINGS, SeiunProtocol.CHANNEL_ROOM, {
			antiCheat: false,
			roomName: s != null ? s.roomName : OnlineSession.roomName,
			password: s != null ? (s.password == null ? "" : s.password) : "",
			mode: OnlineSession.mode,
			allowDuplicateNames: s != null ? s.allowDuplicateNames : true,
			judgementPreset: preset,
			judgementTimings: timings,
			marvelousRatings: ClientPrefs.data.marvelousRatings,
			pausePolicy: OnlineSession.pausePolicy,
			compatibilityMode: backend.CompatEngine.compatMode(),
			compatEngine: ClientPrefs.data.compatEngine,
			stageName: OnlineSession.stageName,
			maxPlayers: maxPlayers,
			teamSize: Std.int(Math.max(1, Std.int(maxPlayers / 2)))
		});
	}

	// ── 聊天 ─────────────────────────────────────────────

	function sendChatMessage(text:String):Void
	{
		if (text == null || text.length == 0)
			return;
		client.send(SeiunProtocol.MSG_ROOM_CHAT, SeiunProtocol.CHANNEL_ROOM, {text: text});
	}

	function appendChat(text:String):Void
	{
		if (chatBox != null)
			chatBox.addLine(text);
	}

	// ── 房间模式 / 准备 / 开始 ──────────────────────────

	/** 房主在房间内直接切换实时/异步 (转谱歌曲强制异步)。 */
	function toggleRoomMode():Void
	{
		if (!OnlineSession.isHost)
		{
			appendChat(UIStyle.t('roomModeHostOnly', '仅房主可以修改房间模式'));
			return;
		}
		if (countdownActive)
		{
			appendChat(UIStyle.t('roomBusyCountdown', '倒计时已开始，本局结束前不能修改房间模式'));
			return;
		}
		if (OnlineSession.chart != null && OnlineSession.chart.chartSource == online.shared.OnlineTypes.OnlineConst.CHART_SOURCE_CONVERTED)
		{
			appendChat(UIStyle.t('roomModeConvertedLock', '当前转谱歌曲强制使用异步排名，不能切换为实时对战。'));
			return;
		}
		var newMode:String = OnlineSession.mode == online.shared.OnlineTypes.OnlineConst.MODE_REALTIME
			? online.shared.OnlineTypes.OnlineConst.MODE_ASYNC
			: online.shared.OnlineTypes.OnlineConst.MODE_REALTIME;
		OnlineSession.mode = newMode;
		if (OnlineSession.settings != null)
			OnlineSession.settings.mode = newMode;
		broadcastRoomSettings();
		appendChat(UIStyle.t('roomModeChanged', '房间模式已切换为 {mode}').replace('{mode}',
			newMode == online.shared.OnlineTypes.OnlineConst.MODE_ASYNC ? UIStyle.t('modeAsync', '异步排名') : UIStyle.t('modeRealtime', '实时对战')));
		rebuildButtons();
	}

	function toggleReady():Void
	{
		if (countdownActive)
		{
			appendChat(UIStyle.t('roomBusyCountdown', '倒计时已开始，请等待对局开始'));
			return;
		}
		readyState = !readyState;
		client.send(SeiunProtocol.MSG_ROOM_READY, SeiunProtocol.CHANNEL_ROOM, {
			ready: readyState,
			chartHash: reportedLocalChartHash
		});
		lastReadySentKey = (readyState ? "1" : "0") + "|" + reportedLocalChartHash;
		lastReadySentAt = Date.now().getTime();
		pendingReadySent = false;
		pendingReadyKey = "";
		updateReadyButton();
	}

	function updateReadyButton():Void
	{
		if (readyButton != null)
		{
			readyButton.setLabel(readyState ? UIStyle.t('roomUnready', '取消准备') : UIStyle.t('roomReady', '准备'));
			layoutButtonsRow();
		}
	}

	function forceStart():Void
	{
		if (countdownActive)
		{
			appendChat(UIStyle.t('roomBusyCountdown', '倒计时已开始'));
			return;
		}
		client.send(SeiunProtocol.MSG_ROOM_FORCE_START, SeiunProtocol.CHANNEL_ROOM, {});
	}

	function openSongSelect():Void
	{
		if (countdownActive)
		{
			appendChat(UIStyle.t('roomBusyCountdown', '倒计时已开始，本局结束前不能修改选歌'));
			return;
		}
		openSubState(new SongSelectSubstate());
	}

	function openOptions():Void
	{
		if (countdownActive)
		{
			appendChat(UIStyle.t('roomBusyCountdown', '倒计时已开始，本局结束前不能修改设置'));
			return;
		}
		openSubState(new OptionsSubstate());
	}

	/** 舞台站位锚点: LobbyStageBg.stagefront 上沿 (y=1180) 减 15px = 前排角色脚底。 */
	static inline var STAGE_FRONT_FEET_Y:Float = 1165;

	// ── 徽标 / 玩家卡片 / 站台角色 (仅签名变化时重建) ─────

	function refreshBadges(force:Bool):Void
	{
		if (badgeRow == null)
			return;
		var s = OnlineSession.settings;
		var chips:Array<{text:String, ?color:FlxColor}> = [];
		var modeLabel:String = OnlineSession.mode == online.shared.OnlineTypes.OnlineConst.MODE_ASYNC
			? UIStyle.t('modeAsync', '异步排名') : UIStyle.t('modeRealtime', '实时对战');
		chips.push({text: UIStyle.t('badgeMode', '模式') + " " + modeLabel, color: OnlineLayout.C_ACCENT});
		if (s != null)
			chips.push({text: UIStyle.t('badgePlayers', '人数') + " " + OnlineSession.players.length + "/" + s.maxPlayers, color: OnlineLayout.C_TEXT});
		if (s != null)
		{
			chips.push({text: UIStyle.t('badgeJudge', '判定') + " " + s.judgementPreset + " " + s.judgementTimings.join("/") + (s.marvelousRatings ? " · M" : ""), color: OnlineLayout.C_SUB});
			// 暂停策略 (非默认时才显示, 减少徽标长度)。
			if (Reflect.hasField(s, "pausePolicy") && s.pausePolicy != null
				&& Std.string(s.pausePolicy) != online.shared.OnlineTypes.OnlineConst.PAUSE_EVERYONE)
				chips.push({text: UIStyle.t('badgePause', '暂停') + " " + CreateRoomCard.pausePolicyLabel(Std.string(s.pausePolicy)), color: OnlineLayout.C_SUB});
		}
		chips.push({text: UIStyle.t('badgeCompat', '兼容') + " " + (OnlineSession.compatEngine == null || OnlineSession.compatEngine.length == 0 ? "Auto" : OnlineSession.compatEngine), color: OnlineLayout.C_SUB});
		chips.push({text: UIStyle.t('badgeStage', '舞台') + " " + (OnlineSession.stageName == null || OnlineSession.stageName.length == 0 ? UIStyle.t('followSong', '跟随歌曲') : OnlineSession.stageName), color: OnlineLayout.C_SUB});
		if (OnlineSession.chart != null && OnlineSession.chart.chartHash != null)
			chips.push({text: UIStyle.t('badgeHash', '哈希') + " " + OnlineSession.chart.chartHash.substr(0, 8), color: OnlineLayout.C_SUB});
		var syncStatus:String = ModSyncClient.statusLine();
		if (syncStatus.length > 0)
			chips.push({text: UIStyle.t('badgeSync', '同步') + " " + syncStatus, color: OnlineLayout.C_INFO});
		var sigParts:Array<String> = [];
		for (c in chips)
			sigParts.push(c.text);
		var sig:String = sigParts.join("|");
		if (!force && sig == lastBadgeSig)
			return;
		lastBadgeSig = sig;
		badgeRow.setChips(chips);

		// 房间名/房间码会随房主改设置变化, 顺带在这里刷新 (测量截断)。
		if (roomTitle != null)
		{
			var chipText:String = "「" + OnlineSession.roomName + "」  " + UIStyle.t('roomCodeLabel', '房间码') + ": " + OnlineSession.roomCode;
			roomTitle.text = OnlineLayout.truncate(roomTitle, chipText, 420);
		}
	}

	function refreshPlayerRows(force:Bool):Void
	{
		if (playersPanel == null || narrow)
			return;
		var sigParts:Array<String> = [];
		for (p in OnlineSession.players)
			sigParts.push(Std.string(p.id) + "|" + (p.isReady == true ? "1" : "0") + "|" + (p.isHost == true ? "1" : "0")
				+ "|" + (p.avatar == null ? "" : Std.string(p.avatar)) + "|" + (p.pingMs == null ? "0" : Std.string(Std.int(p.pingMs)))
				+ "|" + (p.team == null ? "0" : Std.string(p.team)) + "|" + (p.nickname == null ? "" : Std.string(p.nickname)));
		var sig:String = sigParts.join(";");
		if (!force && sig == lastPlayerSig)
			return;
		lastPlayerSig = sig;

		// 玩家卡片列表: 游玩者在先, 观战者在后 (协议层尚无观战字段时全部按游玩者渲染)。
		var players:Array<Dynamic> = OnlineSession.players.copy();
		players.sort(function(a:Dynamic, b:Dynamic):Int {
			var sa:Bool = Reflect.hasField(a, "isSpectator") && a.isSpectator == true;
			var sb:Bool = Reflect.hasField(b, "isSpectator") && b.isSpectator == true;
			if (sa != sb)
				return sa ? 1 : -1;
			return 0;
		});

		for (c in playerCards)
		{
			remove(c);
			c.destroy();
		}
		playerCards = [];
		var specCount:Int = 0;
		for (p in players)
		{
			if (Reflect.hasField(p, "isSpectator") && p.isSpectator == true)
				specCount++;
		}
		playersTitle.text = UIStyle.t('playersTitle', '玩家') + " (" + (players.length - specCount)
			+ (OnlineSession.settings != null ? "/" + OnlineSession.settings.maxPlayers : "")
			+ (specCount > 0 ? " " + UIStyle.t('roomSpectatorShort', '观战') + specCount : "") + ")";

		var cardW:Float = cardsW;
		for (p in players)
		{
			var card:PlayerCard = new PlayerCard(cardW, cardsX, 0);
			card.setPlayer(p);
			card.onKickConfirmed = function(pc:PlayerCard):Void
			{
				kickPlayer(pc.playerId);
			};
			playerCards.push(card);
			add(card);
		}
		var visibleH:Float = railY + railH - 8 - cardsStartY;
		railMaxScroll = Math.max(0, players.length * cardStep - visibleH);
		if (railScroll > railMaxScroll)
			railScroll = railMaxScroll;
		applyRailScroll();
	}

	/** 滚动偏移应用到卡片位置 (越界卡片隐藏, 不裁切相机)。 */
	function applyRailScroll():Void
	{
		var bottomLimit:Float = railY + railH - 6;
		for (i in 0...playerCards.length)
		{
			var card:PlayerCard = playerCards[i];
			var cy:Float = cardsStartY + i * cardStep - railScroll;
			card.y = cy;
			card.visible = cy >= cardsStartY - PlayerCard.CARD_H * 0.5 && cy + PlayerCard.CARD_H <= bottomLimit + PlayerCard.CARD_H * 0.5;
		}
	}

	function kickPlayer(playerId:String):Void
	{
		client.send(SeiunProtocol.MSG_ROOM_KICK, SeiunProtocol.CHANNEL_ROOM, {playerId: playerId});
		appendChat(UIStyle.t('roomKickRequested', '已请求移出玩家。'));
	}

	/** 站台角色: 按人数排布 + 镜头拉远 (仅签名变化时重建)。 */
	function rebuildCharacters(force:Bool):Void
	{
		if (charactersLayer == null)
			return;
		var players = OnlineSession.players;
		var sigParts:Array<String> = [];
		for (p in players)
			sigParts.push(Std.string(p.id) + "|" + (p.skin == null ? "" : Std.string(p.skin))
				+ "|" + (p.isReady == true ? "1" : "0")
				+ "|" + (p.nickname == null ? "" : Std.string(p.nickname))
				+ "|" + (p.avatar == null ? "" : Std.string(p.avatar))
				+ "|" + (p.pingMs == null ? "0" : Std.string(Std.int(p.pingMs))));
		var sig:String = sigParts.join(";");
		if (!force && sig == lastCharSig)
			return;
		lastCharSig = sig;

		UIStyle.clearAndDestroy(charactersLayer);
		var n:Int = players.length;
		applyCameraForCount(n, false);

		var rows:Int = n > 6 ? 2 : 1;
		var perRow:Int = rows == 2 ? Math.ceil(n / 2) : n;
		// 站位全部相对舞台中心与 LobbyStageBg.stagefront 锚点 (原为字面 1280/400/1165/1115;
		// 舞台构图与观感不变, 只是把"为什么是这些数"说清楚)。
		var stageCenterX:Float = FlxG.width / 2;
		var stageFeetY:Float = OnlineRoomState.STAGE_FRONT_FEET_Y; // = LobbyStageBg.stagefront 上沿 - 15
		var stageGapX:Float = 400;
		var spread:Float = Math.max(0, perRow - 1) * stageGapX;
		for (i in 0...n)
		{
			var lc:LobbyCharacter = new LobbyCharacter(players[i]);
			var row:Int = rows == 2 ? (i % 2) : 0;
			var idxInRow:Int = rows == 2 ? Std.int(i / 2) : i;
			var centerX:Float = stageCenterX - spread / 2 + idxInRow * stageGapX;
			// 前排脚底贴 stagefront 上沿, 后排抬高 50px (原 1115 观感保持)。
			var feetY:Float = row == 0 ? stageFeetY : stageFeetY - 50;
			var scale:Float = row == 0 ? 0.92 : 0.85;
			lc.reposition(centerX, feetY, scale);
			if (players[i] != null && Reflect.field(players[i], "isReady") == true)
				lc.setReady(true);
			charactersLayer.add(lc);
		}
	}

	/** 镜头缩放: 人数越多拉得越远。 */
	function applyCameraForCount(count:Int, instant:Bool):Void
	{
		if (camStage == null)
			return;
		var zoom:Float = count <= 1 ? 0.66 : count <= 2 ? 0.6 : count <= 4 ? 0.52 : count <= 6 ? 0.46 : count <= 8 ? 0.42 : 0.38;
		if (instant)
		{
			camStage.zoom = zoom;
			return;
		}
		FlxTween.tween(camStage, {zoom: zoom}, 0.6, {ease: FlxEase.quadOut});
	}

	// ── 更新 ─────────────────────────────────────────────

	override function update(elapsed:Float)
	{
		super.update(elapsed);
		if (client != null)
		{
			client.update(elapsed);
			ModSyncClient.updatePendingManifest(client);
			// 传输停滞 watchdog: 服务器中断/丢帧时 10 秒后自动重试或跳过。
			ModSyncClient.update(client);
			flushPendingReady();
		}
		processEvents();
		if (destroyed)
			return;

		// 选歌范围模组同步完成后重算谱面哈希, 之前缺文件/哈希不一致的玩家
		// 会自动重新上报并恢复可准备状态。
		if (ModSyncClient.consumeRevalidateRequest())
			maybeReportChartHash();

		// 远端自定义头像下载完成后刷新玩家卡片, 让真实头像立即替换 BF 占位。
		if (online.client.AvatarFileClient.consumeRefreshSignal())
			refreshPlayerRows(true);

		// Substate 打开期间: 只处理网络, 不响应大厅按键
		if (subState != null)
			return;

		// 聊天输入框聚焦期间: 大厅快捷键全部让路, Enter 只发送消息, ESC 只取消聚焦。
		var chatFocused:Bool = chatBox != null && chatBox.focused;
		if (chatFocused)
			return;

		// 玩家卡/徽标/站台角色签名计算节流到 4Hz (网络事件到达时会即时 force 刷新)。
		hudRefreshTimer += elapsed;
		if (hudRefreshTimer >= 0.25)
		{
			hudRefreshTimer = 0;
			refreshBadges(false);
			refreshPlayerRows(false);
			rebuildCharacters(false);
		}

		// 站台角色跳舞
		beatTimer += elapsed;
		if (beatTimer >= 0.5)
		{
			beatTimer = 0;
			for (lc in charactersLayer.members)
				if (lc != null)
					lc.dance();
		}

		// 中央信息 (房间码/歌曲/开始状态) 内容变化时更新
		updateCenterTexts();

		// 玩家卡片栏滚动 (滚轮 / 触屏拖动)
		handleRailScroll();

		// 点击房间码复制: tap 语义 (触屏按下-同处松开), 命中高度 ≥40px。
		OnlinePointer.poll();
		if (roomTitle != null && OnlinePointer.tappedOn(roomTitle, OnlineLayout.TOUCH_MIN_H))
		{
			Clipboard.text = OnlineSession.roomCode;
			appendChat(UIStyle.t('roomCodeCopied', '房间码 {code} 已复制到剪贴板。').replace('{code}', OnlineSession.roomCode));
		}
		// 点击歌曲名 → 房主选歌: 旧实现写死鼠标 y 在 [30,58] 的命中带 (触屏完全不响应)。
		// 新实现: 按 songText 实际矩形 + tap 语义 + 40px 命中。
		if (songText != null && OnlinePointer.tapped(songText.x, songText.y, songText.width, OnlineLayout.lineHeight(18)))
		{
			if (OnlineSession.isHost)
				openSongSelect();
			else
				appendChat(UIStyle.t('songSelectHostOnly', '仅房主可以选择歌曲。'));
		}

		// TAB 聚焦聊天
		if (FlxG.keys.justPressed.TAB)
			chatBox.focusInput();

		// 键盘导航底部大按钮
		if (buttonsRow.length > 0)
		{
			if (controls.UI_LEFT_P)
				moveButton(-1);
			else if (controls.UI_RIGHT_P)
				moveButton(1);
			if (controls.ACCEPT)
			{
				FlxG.sound.play(Paths.sound('confirmMenu'), 0.7);
				var btn:OnlineBigButton = buttonsRow[curButton];
				if (btn != null && btn.onClick != null)
					btn.onClick();
			}
		}

		if (controls.BACK #if android || FlxG.android.justReleased.BACK #end && !started && !UIStyle.consumedInputEscape())
		{
			FlxG.sound.play(Paths.sound('cancelMenu'));
			leaveRoom();
		}
	}

	function handleRailScroll():Void
	{
		if (narrow || railMaxScroll <= 0 || playerCards.length == 0)
			return;
		var inRail:Bool = FlxG.mouse.x >= railX && FlxG.mouse.x <= railX + railW && FlxG.mouse.y >= railY;
		if (inRail && FlxG.mouse.wheel != 0)
		{
			railScroll += FlxG.mouse.wheel * 48;
			clampRailScroll();
		}
		#if (android || mobile)
		for (touch in FlxG.touches.list)
		{
			if (touch == null)
				continue;
			var over:Bool = touch.x >= railX && touch.x <= railX + railW && touch.y >= railY;
			if (touch.justPressed && over && dragTouchId < 0)
			{
				dragTouchId = touch.touchPointID;
				dragStartY = touch.y;
				dragStartScroll = railScroll;
			}
			else if (touch.touchPointID == dragTouchId)
			{
				if (touch.justReleased)
					dragTouchId = -1;
				else
				{
					railScroll = dragStartScroll - (touch.y - dragStartY);
					clampRailScroll();
				}
			}
		}
		#end
		applyRailScroll();
	}

	function clampRailScroll():Void
	{
		if (railScroll < 0)
			railScroll = 0;
		if (railScroll > railMaxScroll)
			railScroll = railMaxScroll;
	}

	function moveButton(delta:Int):Void
	{
		buttonsRow[curButton].focused = false;
		curButton = (curButton + delta + buttonsRow.length) % buttonsRow.length;
		buttonsRow[curButton].focused = true;
		FlxG.sound.play(Paths.sound('scrollMenu'), 0.6);
	}

	var lastCenterSig:String = "";

	function updateCenterTexts():Void
	{
		var songPart:String = OnlineSession.chart != null && OnlineSession.chart.songName != null
			? OnlineSession.chart.songName + " [" + OnlineSession.chart.difficulty + "]"
			: UIStyle.t('roomNoSong', '尚未选歌');
		var startPart:String;
		if (OnlineSession.selfIsSpectator())
			startPart = UIStyle.t('roomSpectatorHint', '观战中 · 跟随首个游玩者视角, 不参与对局');
		else if (countdownActive)
			startPart = UIStyle.t('roomCountdownState', '已就绪，倒计时中…服务器将自动开始');
		else if (OnlineSession.mode == online.shared.OnlineTypes.OnlineConst.MODE_REALTIME)
		{
			var readyCount:Int = 0;
			for (p in OnlineSession.players)
				if (p.isReady == true)
					readyCount++;
			startPart = UIStyle.t('roomReadyProgress', '已准备 {a}/{b} · 全部准备且谱面一致后自动开始')
				.replace('{a}', Std.string(readyCount)).replace('{b}', Std.string(OnlineSession.players.length));
		}
		else
			startPart = UIStyle.t('roomAsyncHint', '异步排名模式 · 玩家可自行开始游玩');
		var sig:String = songPart + "|" + startPart;
		if (sig == lastCenterSig)
			return;
		lastCenterSig = sig;
		// 歌名超长测量截断, 绝不压到左右栏。
		var songText2:String = UIStyle.t('roomSong', '当前歌曲: ') + songPart + (OnlineSession.isHost ? "   (" + UIStyle.t('roomClickPick', '点击选歌') + ")" : "");
		songText.text = OnlineLayout.truncate(songText, songText2, FlxG.width - 560);
		startStateText.text = startPart;
	}

	// ── 事件 ─────────────────────────────────────────────

	function processEvents():Void
	{
		if (client == null)
			return;
		if (client.state == online.client.GameClient.ClientState.Failed && !started)
		{
			OnlineSession.clear();
			OnlineSession.recordDisconnect(client.lastError);
			client.disconnect(true);
			MusicBeatState.switchState(new OnlineState());
			return;
		}
		var ev = client.pollEvent();
		while (ev != null)
		{
			switch (ev.type)
			{
				case SeiunProtocol.MSG_ROOM_INFO:
				{
					var oldMode:String = OnlineSession.mode;
					var oldHost:Bool = OnlineSession.isHost;
					OnlineSession.applyRoomInfo(ev.data);
					if (ev.data != null && Reflect.field(ev.data, "status") == online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_LOBBY)
						countdownActive = false;
					for (p in OnlineSession.players)
					{
						if (p.id == OnlineSession.selfId)
						{
							readyState = p.isReady == true;
							updateReadyButton();
							break;
						}
					}
					// 房间模式/身份在房间内可实时修改: 变化时立即重建底部按钮。
					if (oldMode != OnlineSession.mode || oldHost != OnlineSession.isHost)
						rebuildButtons();
					lastCenterSig = "";
					updateCenterTexts();
					maybeReportChartHash();
				}
				case SeiunProtocol.MSG_ROOM_PLAYER_JOIN:
					if (ev.data != null && ev.data.player != null)
						appendChat("+ " + ev.data.player.nickname + " " + UIStyle.t('roomJoined', '加入了房间'));
				case SeiunProtocol.MSG_ROOM_PLAYER_LEAVE:
					if (ev.data != null)
					{
						var reason:String = ev.data.reason == "timeout" ? UIStyle.t('roomLeftTimeout', '连接中断（疑似崩溃）')
							: (ev.data.reason == "kick" ? UIStyle.t('roomLeftKicked', '被移出房间') : UIStyle.t('roomLeft', '退出了房间'));
						appendChat("- " + ev.data.nickname + " " + reason);
					}
				case SeiunProtocol.MSG_ROOM_PLAYER_SKIN:
					// 某玩家更换了对局皮肤: 更新会话玩家列表并提示。
					if (ev.data != null)
					{
						var sid:String = Std.string(Reflect.field(ev.data, "id"));
						var sd:Dynamic = Reflect.field(ev.data, "skinData");
						for (p in OnlineSession.players)
						{
							if (Std.string(Reflect.field(p, "id")) == sid)
							{
								Reflect.setField(p, "skinData", sd);
								Reflect.setField(p, "skin", sd != null && Reflect.field(sd, "char") != null ? Std.string(Reflect.field(sd, "char")) : "");
								break;
							}
						}
						var nick:String = Std.string(Reflect.field(ev.data, "nickname"));
						if (sid != OnlineSession.selfId && nick.length > 0)
							appendChat("* " + StringTools.replace(UIStyle.t('skinUpdateBy', '{0} 更换了皮肤'), "{0}", nick));
					}
				case SeiunProtocol.MSG_ROOM_CHAT:
					if (ev.data != null)
					{
						var chatAvatar:String = ev.data.avatar != null && ev.data.avatar.length > 0 ? "[" + ev.data.avatar + "] " : "";
						appendChat(chatAvatar + ev.data.fromNickname + ": " + ev.data.text);
					}
				case SeiunProtocol.MSG_MOD_MANIFEST_RESULT:
					ModSyncClient.onManifestResult(ev.data, client);
					var syncLine:String = ModSyncClient.statusLine();
					if (syncLine.length > 0)
						appendChat("[" + UIStyle.t('roomModSync', '模组同步') + "] " + syncLine);
					// 同步完成后立刻重算谱面哈希, 之前因缺文件失败的玩家会自动恢复。
					if (!ModSyncClient.syncActive)
						maybeReportChartHash();
				case SeiunProtocol.MSG_MOD_FILE_ACK:
					if (ev.data != null)
					{
						ModSyncClient.onFileAck(ev.data, client);
						if (ev.data.ok == false)
							appendChat("[" + UIStyle.t('roomModSync', '模组同步') + "] " + Std.string(Reflect.field(ev.data, "message")));
						else if (!ModSyncClient.syncActive)
							maybeReportChartHash();
					}
				case SeiunProtocol.MSG_ROOM_ANNOUNCE:
					if (ev.data == null)
						break;
					appendChat("[" + UIStyle.t('roomAnnounce', '公告') + "] " + ev.data.text);
					var noticeText:String = Std.string(ev.data.text);
					if (noticeText.indexOf("房主退出") >= 0 || noticeText.indexOf("房间已关闭") >= 0 || noticeText.indexOf("房主断开") >= 0)
					{
						OnlineSession.clear();
						OnlineSession.recordDisconnect(noticeText);
						if (client != null)
							client.disconnect(true);
						restoreCameras();
						MusicBeatState.switchState(new OnlineState());
						return;
					}
				case SeiunProtocol.MSG_GAME_COUNTDOWN:
					countdownActive = true;
					if (ev.data != null)
						appendChat(UIStyle.t('roomCountdown', '对局倒计时: ') + ev.data.seconds);
				case SeiunProtocol.MSG_GAME_SYNC:
					// 可能仍在切场景: 先存锚点, PlayState 的 startCountdown 在线闸门会消费。
					if (ev.data != null)
						OnlineSession.setPendingRealtimeSync(
							Std.parseFloat(Std.string(Reflect.field(ev.data, "serverNow"))),
							Std.parseFloat(Std.string(Reflect.field(ev.data, "startDelayMs"))));
				case SeiunProtocol.MSG_GAME_START:
					startGame(ev.data);
					return;
				case SeiunProtocol.MSG_ADMIN_RESULT:
					if (ev.data != null)
					{
						var ok:Bool = Reflect.field(ev.data, "ok") == true;
						var msg:String = Reflect.field(ev.data, "message");
						appendChat((ok ? "✓ " : "✗ ") + (msg == null ? "" : Std.string(msg)));
						refreshBadges(true);
						refreshPlayerRows(true);
						rebuildCharacters(true);
					}
				case SeiunProtocol.MSG_ERROR:
					var msg:String = UIStyle.errText(ev.data == null ? -1 : Reflect.field(ev.data, "code"), ev.data == null ? client.lastError : Reflect.field(ev.data, "message"));
					appendChat("[" + UIStyle.t('roomError', '错误') + "] " + msg);
					if (msg != null
						&& (msg.indexOf("移出房间") >= 0 || msg.indexOf("请出服务器") >= 0 || msg.indexOf("封禁") >= 0))
					{
						OnlineSession.recordDisconnect(msg);
						if (client != null)
							client.disconnect(true);
						restoreCameras();
						MusicBeatState.switchState(new OnlineState());
						return;
					}
			}
			ev = client.pollEvent();
		}
	}

	// ── 谱面哈希 / 对局启动 (与原实现一致) ────────────────

	/** 模组清单线程的过期判断键: 换房/换歌都会变化。 */
	function manifestContextKey(chart:online.shared.OnlineTypes.ChartSelection):String
	{
		var song:String = chart == null ? "" : (chart.songName + "|" + chart.difficulty + "|" + chart.chartHash + "|" + (chart.modFolder == null ? "" : chart.modFolder));
		return OnlineSession.roomCode + "|" + song;
	}

	function maybeReportChartHash():Void
	{
		var chart = OnlineSession.chart;
		if (chart == null || chart.songName == null || chart.difficulty == null)
			return;
		var key:String = chart.songName + "|" + chart.difficulty + "|" + chart.chartHash + "|" + (chart.modFolder == null ? "" : chart.modFolder);
		var localHash:String = "";
		try
		{
			var loaded:SwagSong = online.client.OnlineChartUtil.loadChart(chart.songName, chart.difficulty, chart.modFolder);
			localHash = SeiunHash.ofString(haxe.Json.stringify(loaded));
		}
		catch (e:Dynamic)
		{
			localHash = "";
		}
		reportedLocalChartHash = localHash;

		// 换歌时按新选歌刷新"选歌范围"模组清单 (不会全量扫 mods/)。
		// 用 localHash 参与签名: 若客户端之前缺谱面导致清单里没有舞台/角色
		// 依赖, 同步完成后这里会自动补发一次更完整的清单。
		// 签名必须带上房间+选歌上下文: 换房后即使同一首歌, 也要强制重报清单,
		// 否则服务器可能拿着旧房间的 hostManifest/context 做 diff, 出现 0 字节。
		var manifestSig:String = manifestContextKey(chart) + "|" + (localHash.length > 0 ? localHash : "missing");
		if (reportedChartKey != key || lastSentManifestSig != manifestSig)
		{
			reportedChartKey = key;
			lastSentManifestSig = manifestSig;
			ModSyncClient.requestSendLocalManifest(client, chart, manifestContextKey(chart));
		}

		// ROOM_READY 去抖: 服务器收到 READY 会广播完整 ROOM_INFO, 客户端收到
		// ROOM_INFO 又会触发本函数。如果每次都无条件重发 READY 就会形成
		// READY→INFO→READY 放大回环, 选歌/切歌时瞬间把限速桶打爆。
		// 这里只在 ready/本地谱面哈希实际变化时重发, 并施加 500ms 最小间隔。
		var readyKey:String = (readyState ? "1" : "0") + "|" + localHash;
		if (readyKey != lastReadySentKey)
		{
			pendingReadyKey = readyKey;
			pendingReadySent = true;
		}
		flushPendingReady();

		if (localHash != chart.chartHash)
			appendChat(UIStyle.t('roomHashMismatch', '谱面哈希不一致，已上报服务器等待房主同步谱面。'));
	}

	/** 若存在待发的 ROOM_READY 且已过最小间隔, 立即发出。 */
	function flushPendingReady():Void
	{
		if (!pendingReadySent || pendingReadyKey.length == 0)
			return;
		if (client == null || client.socket == null || client.state != online.client.GameClient.ClientState.Ready)
			return;
		var now:Float = Date.now().getTime();
		if (now - lastReadySentAt < READY_MIN_INTERVAL_MS)
			return;
		client.send(SeiunProtocol.MSG_ROOM_READY, SeiunProtocol.CHANNEL_ROOM, {
			ready: readyState,
			chartHash: reportedLocalChartHash
		});
		lastReadySentAt = now;
		lastReadySentKey = pendingReadyKey;
		pendingReadySent = false;
		pendingReadyKey = "";
	}

	function startGame(data:Dynamic):Void
	{
		if (started)
			return;
		if (data == null)
			return;
		started = true;
		countdownActive = false;
		// 观战: 进对局渲染被跟随玩家, 不参与判定/输入/成绩。
		PlayState.seiunSpectate = OnlineSession.selfIsSpectator();
		var song:Dynamic = data.song;
		if (song == null)
			song = OnlineSession.chart;
		if (song == null)
		{
			started = false;
			return;
		}
		OnlineSession.setChart({
			songName: song.songName,
			difficulty: song.difficulty,
			chartHash: song.chartHash,
			chartSource: song.chartSource,
			modFolder: song.modFolder == null ? "" : Std.string(song.modFolder)
		});
		// 实时对战不再按"收到 GAME_START 的本地时间"各自起跑: 进入 PlayState
		// 后先冻结, 等服务器在全部玩家上传时间轴后广播 MSG_GAME_SYNC 统一发令。
		PlayState.startOnTime = 0;
		PlayState.seiunSkipLocalCountdown = false;
		loadPlayState(song);
	}

	function startLocalSong():Void
	{
		// 观战者不单独开始游玩。
		if (OnlineSession.selfIsSpectator())
			return;
		// 实时对战必须由服务器统一倒计时开局, 不允许任何玩家本地单独开始。
		if (OnlineSession.mode == online.shared.OnlineTypes.OnlineConst.MODE_REALTIME)
		{
			appendChat(UIStyle.t('roomRealtimeStartByHost', '实时对战由房主统一开始，请点击准备或等待房主开始。'));
			return;
		}
		if (ModSyncClient.syncActive
			|| !ModSyncClient.manifestResultReceived
			|| ModSyncClient.failedFiles > 0
			|| ModSyncClient.unavailableFiles > 0)
		{
			appendChat(UIStyle.t('roomSyncWait', '模组同步尚未完成，请稍候再开始游玩。'));
			return;
		}
		var chart = OnlineSession.chart;
		if (chart == null)
		{
			appendChat(UIStyle.t('roomPickSongFirst', '请房主先选歌'));
			return;
		}
		if (started)
			return;
		started = true;
		PlayState.startOnTime = 0;
		PlayState.seiunSkipLocalCountdown = false;
		loadPlayState(chart);
	}

	function loadPlayState(song:Dynamic):Void
	{
		try
		{
			var modFolder:String = song.modFolder == null ? "" : Std.string(song.modFolder);
			var loaded:SwagSong = online.client.OnlineChartUtil.loadChart(song.songName, song.difficulty, modFolder);
			var localHash:String = SeiunHash.ofString(haxe.Json.stringify(loaded));
			if (song.chartHash != null && song.chartHash.length > 0 && localHash != song.chartHash)
			{
				appendChat(UIStyle.t('roomHashBlocked', '谱面哈希不一致，禁止开始。请等待房主同步谱面。'));
				if (client != null)
					client.send(SeiunProtocol.MSG_ROOM_CHAT, SeiunProtocol.CHANNEL_ROOM, {text: UIStyle.t('roomHashMismatch', '谱面哈希不一致') + ": " + song.songName});
				started = false;
				PlayState.seiunSkipLocalCountdown = false;
				return;
			}
			PlayState.SONG = loaded;
			PlayState.isStoryMode = false;
			PlayState.replayMode = false;
			PlayState.chartingMode = false;
			var diffName:String = Std.string(song.difficulty);
			if (CoolUtil.difficulties.length < 1)
				CoolUtil.difficulties = CoolUtil.defaultDifficulties.copy();
			var diffIndex:Int = CoolUtil.difficulties.indexOf(diffName);
			if (diffIndex < 0)
			{
				CoolUtil.difficulties.push(diffName);
				diffIndex = CoolUtil.difficulties.length - 1;
			}
			PlayState.storyDifficulty = diffIndex;
			PlayState.seiunOnline = true;
			// 与 Freeplay 一致: 模组歌进入对局后保持该 mod 目录, 供音频/角色/图片解析。
			if (modFolder.length > 0)
				Paths.currentModDirectory = modFolder;
			#if ONLINE_ALLOWED
			// 进对局前刷新皮肤 (实时/异步统一生效)
			online.client.OnlineSession.selfSkin = online.client.ProfileStore.skin == null ? "" : online.client.ProfileStore.skin;
			#end
			// 谱面校验全部通过才拆大厅舞台相机; 失败时仍能回到大厅继续操作。
			started = true;
			restoreCameras();
			LoadingState.loadAndSwitchState(new PlayState());
		}
		catch (e:Dynamic)
		{
			appendChat(UIStyle.t('roomLoadFailed', '加载歌曲失败: ') + Std.string(e));
			started = false;
			PlayState.seiunSkipLocalCountdown = false;
		}
	}

	// ── 退出 / 恢复 ──────────────────────────────────────

	/** 离开大厅: 恢复主相机, 移除舞台相机。 */
	function restoreCameras():Void
	{
		FlxG.camera.zoom = 1;
		FlxG.camera.scroll.set(0, 0);
		FlxG.camera.bgColor = savedBgColor;
		if (camStage != null)
		{
			FlxG.cameras.remove(camStage, true);
			camStage = null;
		}
	}

	function leaveRoom():Void
	{
		if (client != null)
		{
			client.send(SeiunProtocol.MSG_ROOM_LEAVE, SeiunProtocol.CHANNEL_ROOM, {});
			client.flush();
		}
		#if ONLINE_ALLOWED
		if (OnlineSession.isHost)
		{
			if (client != null)
				client.disconnect(false);
			online.server.EmbeddedServerRunner.stop();
		}
		#end
		ModSyncClient.reset();
		PlayState.startOnTime = 0;
		PlayState.seiunSkipLocalCountdown = false;
		PlayState.seiunSpectate = false;
		restoreCameras();
		OnlineSession.clear();
		MusicBeatState.switchState(new OnlineState());
	}

	override function closeSubState():Void
	{
		super.closeSubState();
		rebuildButtons();
		refreshBadges(true);
		refreshPlayerRows(true);
		rebuildCharacters(true);
		maybeReportChartHash();
		lastCenterSig = "";
		updateCenterTexts();
	}

	override function destroy():Void
	{
		restoreCameras();
		super.destroy();
	}
}
