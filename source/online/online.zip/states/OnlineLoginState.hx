package online.states;

import backend.MusicBeatState;
import backend.ui.PsychUIInputText;
import flixel.FlxG;
import flixel.FlxSprite;
import flixel.text.FlxText;
import flixel.util.FlxColor;
import online.client.GameClient;
import online.client.ProfileStore;
import online.shared.SeiunProtocol;
import online.ui.OnlineLayout;
import online.ui.OnlinePanel;
import online.ui.OnlineMenuBg;
import online.ui.TextButton;
import online.ui.UIStyle;

/**
	专用服务器注册/登录 (一体化 + 自动登录)。
	- 连接时 HELLO 自动携带本机保存的会话令牌, 令牌有效则完全免输密码;
	- 令牌过期/首次使用时进入本页: 输一次用户名密码, 登录成功即记住令牌;
	- 登录时账号不存在 → 自动用同一组凭据注册 (一键注册), 密码永不落盘;
	- 服务器地址支持历史记录左右切换。
	局域网内置托管不需要此界面。
**/
class OnlineLoginState extends MusicBeatState
{
	var addressInput:PsychUIInputText;
	var userInput:PsychUIInputText;
	var passInput:PsychUIInputText;
	var statusText:FlxText;
	var client:GameClient;

	/** 登录失败且账号不存在时, 自动用同一组凭据注册一次 (防循环)。 */
	var autoRegisterTried:Bool = false;
	var historyIndex:Int = 0;

	override function create()
	{
		super.create();
		online.ui.UIStyle.installInputEscapeGuard();
		ProfileStore.ensureLoaded();
		client = GameClient.instance != null ? GameClient.instance : new GameClient();

		OnlineMenuBg.attach(this, 0.6);

		// 面板: 宽高都钳到屏幕内 (窄/矮屏不再横向溢出或贴底出屏)。
		var panelW:Float = Math.min(600, FlxG.width - OnlineLayout.PAD * 2);
		var panelX:Float = FlxG.width / 2 - panelW / 2;
		var inputW:Int = Std.int(Math.min(440, panelW - 40));
		var innerX:Float = FlxG.width / 2 - inputW / 2;
		var panelTop:Float = Math.max(16, FlxG.height * 0.08);
		var panelH:Float = Math.min(520, FlxG.height - panelTop - 24);
		var panel:OnlinePanel = new OnlinePanel(panelX, panelTop, panelW, panelH);
		add(panel);

		var title:FlxText = OnlineLayout.makeText(0, 76, FlxG.width, UIStyle.t('loginTitle', '专用服务器账号'), OnlineLayout.FS_TITLE, FlxColor.WHITE, CENTER);
		add(title);

		var tip:FlxText = OnlineLayout.makeText(panelX + 20, 128, panelW - 40,
			UIStyle.t('loginTipIntegrated', '登录成功后本机自动记住登录状态，之后无需再输密码；密码只以哈希保存在服务器。'), 13, OnlineLayout.C_SUB, CENTER);
		add(tip);

		// 地址输入框与历史箭头 ">" 同宽对齐: 输入框宽 = 50 (左箭头区) + 440 (输入区) + 50 (右箭头区)。
		// 左箭头 x = center - 246, 右箭头必须与它对称 (center + 246), 否则压住输入框右半区。
		addressInput = new PsychUIInputText(innerX, 170, inputW, client.host + ":" + client.port, 17, UIStyle.inputFontKey());
		UIStyle.styleInput(addressInput, inputW);
		addressInput.cameras = [FlxG.camera];
		add(addressInput);

		// 服务器历史: 左右切换 (触屏友好, 不做下拉)。
		// 箭头按键在输入框两侧对称 (旧版 ">" 放在 inputW/2+196 处, 压住被 styleInput
		// 拉宽的地址框右半区 —— 2026-08-29 修复)。
		var histPrev:TextButton = new TextButton(0, 170, "<", function() cycleHistory(-1), 18);
		histPrev.color = OnlineLayout.C_ACCENT;
		OnlineLayout.padTouch(histPrev);
		histPrev.x = innerX - 10 - histPrev.width;
		add(histPrev);
		var histNext:TextButton = new TextButton(innerX + inputW + 10, 170, ">", function() cycleHistory(1), 18);
		histNext.color = OnlineLayout.C_ACCENT;
		OnlineLayout.padTouch(histNext);
		add(histNext);

		userInput = new PsychUIInputText(innerX, 222, inputW, ProfileStore.userFor(addressInput.text), 17, UIStyle.inputFontKey());
		UIStyle.styleInput(userInput, inputW);
		userInput.cameras = [FlxG.camera];
		add(userInput);

		passInput = new PsychUIInputText(innerX, 274, inputW, "", 17, UIStyle.inputFontKey());
		UIStyle.styleInput(passInput, inputW);
		passInput.passwordMask = true;
		passInput.cameras = [FlxG.camera];
		add(passInput);

		// 面板内元素从底部往上排: 命中高度统一 ≥40px, 不再写死 370/420/476。
		var stackBottom:Float = panelTop + panelH - 10;
		var btnH:Float = OnlineLayout.TOUCH_MIN_H;
		var btnGap:Float = 4;
		var backY:Float = stackBottom - btnH;
		var loginY:Float = backY - btnH - btnGap;
		var regY:Float = loginY - btnH - btnGap;
		statusText = OnlineLayout.makeText(panelX + 20, regY - OnlineLayout.lineHeight(15) - 12, panelW - 40, "", 15, OnlineLayout.C_WARN, CENTER);
		add(statusText);

		var reg:TextButton = new TextButton(0, regY, UIStyle.t('loginRegister', '注册新账号'), function() doAuth(true), 24);
		reg.centerOnLabel = true;
		add(reg);
		var login:TextButton = new TextButton(0, loginY, UIStyle.t('loginLogin', '登录'), function() doAuth(false), 26);
		login.centerOnLabel = true;
		add(login);
		var back:TextButton = new TextButton(0, backY, UIStyle.t('back', '返回'), function() MusicBeatState.switchState(new OnlineState()), 22);
		back.centerOnLabel = true;
		add(back);
		OnlineLayout.padTouchAll([reg, login, back]);

		FlxG.mouse.visible = true;
	}

	function cycleHistory(delta:Int):Void
	{
		if (ProfileStore.serverHistory.length == 0)
			return;
		historyIndex = (historyIndex + delta + ProfileStore.serverHistory.length) % ProfileStore.serverHistory.length;
		var h:Dynamic = ProfileStore.serverHistory[historyIndex];
		if (h == null)
			return;
		addressInput.text = Std.string(Reflect.field(h, "address"));
		userInput.text = ProfileStore.userFor(addressInput.text);
	}

	function currentAddress():String
	{
		var a:String = StringTools.trim(addressInput.text);
		return a.length > 0 ? a : client.host + ":" + client.port;
	}

	function doAuth(register:Bool):Void
	{
		if (userInput.text.length == 0 || passInput.text.length == 0)
		{
			statusText.text = Language.get('online.loginFillAll', '请填写用户名和密码');
			return;
		}
		pendingAuthDone = false;
		authPending = register;
		if (client.socket == null || client.state != online.client.GameClient.ClientState.Ready)
		{
			statusText.text = UIStyle.t('connecting', '正在连接...');
			if (!client.connect(currentAddress()))
			{
				statusText.text = client.lastError;
				return;
			}
			statusText.text = UIStyle.t('loginWaitingHandshake', '已连接，等待握手后自动认证...');
			authPending = register;
			return;
		}
		client.auth(register, userInput.text, passInput.text);
		statusText.text = register ? UIStyle.t('loginRegistering', '正在注册...') : UIStyle.t('loginLoggingIn', '正在登录...');
	}

	var authPending:Bool = false;
	var pendingAuthDone:Bool = false;

	override function update(elapsed:Float)
	{
		super.update(elapsed);
		client.update(elapsed);
		if (client.state == online.client.GameClient.ClientState.Failed)
			statusText.text = client.lastError;
		var ev = client.pollEvent();
		while (ev != null)
		{
			if (ev.type == SeiunProtocol.MSG_WELCOME)
			{
				if (authPending && !pendingAuthDone)
				{
					pendingAuthDone = true;
					client.auth(authPending, userInput.text, passInput.text);
				}
			}
			else if (ev.type == SeiunProtocol.MSG_AUTH_RESULT)
			{
				if (ev.data != null && ev.data.ok == true)
				{
					client.sessionToken = ev.data.token;
					client.authenticated = true;
					// 一体化登录: 记住令牌, 下次连接本服务器全程免密。
					ProfileStore.rememberAuth(currentAddress(), userInput.text, Std.string(ev.data.token));
					statusText.text = Language.get('online.authOkRemembered', '认证成功，已记住本机登录状态');
					MusicBeatState.switchState(new OnlineState());
					return;
				}
				else
				{
					var code:Int = ev.data == null ? -1 : (Reflect.field(ev.data, "code") == null ? -1 : Reflect.field(ev.data, "code"));
					if (!authPending && code == SeiunProtocol.ERR_USER_NOT_FOUND && !autoRegisterTried
						&& userInput.text.length > 0 && passInput.text.length > 0)
					{
						// 账号不存在: 自动用同一组凭据注册 (一键注册)。
						autoRegisterTried = true;
						statusText.text = Language.get('online.autoRegistering', '该服务器没有此账号，正在为您自动注册...');
						doAuth(true);
					}
					else
						statusText.text = UIStyle.errText(code, ev.data == null ? UIStyle.t('authFailed', '认证失败') : Reflect.field(ev.data, "message"));
				}
			}
			else if (ev.type == SeiunProtocol.MSG_ERROR)
			{
				statusText.text = UIStyle.errText(ev.data == null ? -1 : Reflect.field(ev.data, "code"), ev.data == null ? client.lastError : Reflect.field(ev.data, "message"));
			}
			ev = client.pollEvent();
		}

		// 输入框聚焦时 BACK 放行: Backspace 是退格不是返回; ESC 第一次只取消聚焦。
		if (controls.BACK #if android || FlxG.android.justReleased.BACK #end && !online.ui.UIStyle.anyInputFocused() && !online.ui.UIStyle.consumedInputEscape())
		{
			FlxG.sound.play(Paths.sound('cancelMenu'));
			if (client.state == online.client.GameClient.ClientState.Ready)
			{
				client.send(SeiunProtocol.MSG_BYE, SeiunProtocol.CHANNEL_CONTROL, {});
				client.flush();
				client.disconnect(true);
			}
			else if (client.socket != null)
				client.disconnect(true);
			MusicBeatState.switchState(new OnlineState());
		}
	}
}
