package online.states;

import backend.MusicBeatState;
import backend.ui.PsychUIInputText;
import ClientPrefs;
import flixel.addons.display.FlxBackdrop;
import flixel.addons.display.FlxGridOverlay;
import flixel.FlxG;
import flixel.FlxSprite;
import flixel.text.FlxText;
import flixel.tweens.FlxTween;
import flixel.util.FlxColor;
import online.client.GameClient;
import online.client.OnlineSession;
import online.client.ProfileStore;
import online.shared.SeiunProtocol;
import online.ui.CreateRoomCard;
import online.ui.OnlineLayout;
import online.ui.OnlineMenuList;
import online.ui.OnlinePanel;
import online.ui.TextButton;
import online.ui.UIStyle;

/**
	DEDICATED —— 专用服务器页 (蓝色系, 与 LAN 页明显区分):
	- 左: 服务器地址历史 (点击即连 / 删除记录) + 新地址输入;
	- 右: 服务器名 / 在线房间列表 (选择即加入) / 注册登录入口 / 创建房间 (同一套建房配置, 不启动内置服务器)。

	UI 重构 (本轮): 两栏 x 走 OnlineLayout.centeredColumns (原 190/650 只在 1280 宽正确);
	历史与房间两个列表迁 OnlineMenuList 行列表形态 (固定锚点观感保留 + tap 语义 + ≥40px 命中
	+ 实测截断, 长服务器名/房间名不再溢出); 文本统一 OnlineLayout.makeText; 建房覆盖层按屏幕居中。
**/
class OnlineDedicatedState extends MusicBeatState
{
	var client:GameClient;
	var statusText:FlxText;

	// 历史
	var historyList:OnlineMenuList;
	var historyEmpty:FlxText;
	var historyBox:FlxSprite;
	var selHistory:Int = 0;
	var addressInput:PsychUIInputText;

	// 房间列表
	var roomList:OnlineMenuList;
	var roomEmpty:FlxText;
	var roomListBox:FlxSprite;
	var selRoom:Int = 0;
	var rooms:Array<Dynamic> = [];

	// 两栏布局 (按屏宽居中, 不假定 1280)
	var colL:Float = 190;
	var colR:Float = 650;
	static inline var COL_L_W:Float = 430;
	static inline var COL_R_W:Float = 440;
	static inline var HIST_ROW_H:Float = 36;
	static inline var ROOM_ROW_H:Float = 30;
	static inline var MAX_ROWS:Int = 7;

	// 服务器状态
	var serverNameText:FlxText;
	var serverStateText:FlxText;

	// 建房覆盖层
	var overlayDim:FlxSprite;
	var overlayCard:CreateRoomCard;
	var overlayConfirm:TextButton;
	var overlayCancel:TextButton;
	var overlayActive:Bool = false;

	var side:Int = 0; // 0=历史 1=房间列表
	var ipRefreshTimer:Float = 0;

	override function create()
	{
		super.create();
		UIStyle.installInputEscapeGuard();
		ProfileStore.ensureLoaded();
		client = (GameClient.instance != null) ? GameClient.instance : new GameClient();

		var bg:FlxSprite = new FlxSprite().loadGraphic(Paths.image('menuDesat'));
		bg.color = 0xFF12243D;
		bg.screenCenter();
		bg.antialiasing = ClientPrefs.data.globalAntialiasing;
		add(bg);
		var grid:FlxBackdrop = new FlxBackdrop(FlxGridOverlay.createGrid(80, 80, 160, 160, true, 0x22FFFFFF, 0x0));
		grid.velocity.set(30, 30);
		grid.alpha = 0.5;
		add(grid);

		// 两栏按屏宽居中 (原 190/650 只在 1280 宽正确)
		var cols:Array<Float> = OnlineLayout.centeredColumns([COL_L_W, COL_R_W], 30);
		colL = cols[0];
		colR = cols[1];
		var panelTop:Float = 92;
		var panelH:Float = Math.max(300, FlxG.height - panelTop - 128);

		var title:FlxText = OnlineLayout.makeText(colL, 22, FlxG.width - colL - OnlineLayout.PAD,
			UIStyle.t('dedicatedTitle', '专用服务器'), 32, 0xFF96C8FF, LEFT);
		add(title);
		var sub:FlxText = OnlineLayout.makeText(colL, 62, FlxG.width - colL - OnlineLayout.PAD,
			UIStyle.t('dedicatedSubtitle', '连接远程服务器 · 需要账号的服务器请先注册/登录'), 13, OnlineLayout.C_SUB, LEFT);
		add(sub);

		// ── 左: 地址历史 ──
		var leftPanel:OnlinePanel = new OnlinePanel(colL, panelTop, COL_L_W, panelH, 0xFF0A1220, 0.9, 0.68, 0, 0xFF6FB1FF);
		add(leftPanel);
		var leftTitle:FlxText = OnlineLayout.makeText(colL + 20, panelTop + 10, COL_L_W - 40, UIStyle.t('dedicatedHistory', '服务器地址历史 (点击即连)'), 14, 0xFF96C8FF, LEFT);
		add(leftTitle);

		historyBox = new FlxSprite(colL + 14, panelTop + 36).makeGraphic(1, 1, FlxColor.BLACK);
		historyBox.alpha = 0.35;
		add(historyBox);
		historyList = new OnlineMenuList(colL + 14, panelTop + 42).asRowList(COL_L_W - 60, 13, HIST_ROW_H);
		historyList.colorSelected = 0xFF96C8FF;
		historyList.onChange = function(i:Int) selHistory = i;
		historyList.onAccept = function(i:Int)
		{
			side = 0;
			selHistory = i;
			connectSelected();
		};
		add(historyList);

		// 左栏底部: 新地址输入 + 三个操作按钮 (由面板底部往上排, 不写死 428/492/524/556)
		var leftBtnH:Float = OnlineLayout.TOUCH_MIN_H;
		var loginY:Float = panelTop + panelH - leftBtnH - 8;
		var deleteY:Float = loginY - leftBtnH;
		var connectY:Float = deleteY - leftBtnH;
		var inputY:Float = connectY - 34;
		var addrLabel:FlxText = OnlineLayout.makeText(colL + 20, inputY - 20, COL_L_W - 40, UIStyle.t('dedicatedNewAddress', '新地址 (ws://IP:端口)'), 12, OnlineLayout.C_SUB, LEFT);
		add(addrLabel);
		var addrW:Int = Std.int(COL_L_W - 40);
		addressInput = new PsychUIInputText(colL + 20, inputY, addrW, ProfileStore.serverAddress, 15, UIStyle.inputFontKey());
		UIStyle.styleInput(addressInput, addrW);
		add(addressInput);

		var connectBtn:TextButton = new TextButton(colL + 20, connectY, "< " + UIStyle.t('dedicatedConnect', '连接') + " >", connectSelected, 18);
		connectBtn.desc = UIStyle.t('dedicatedConnectDesc', '连接选中的历史地址或输入的新地址');
		connectBtn.alignment = LEFT;
		connectBtn.color = 0xFF96C8FF;
		add(connectBtn);
		var deleteBtn:TextButton = new TextButton(colL + 20, deleteY, "< " + UIStyle.t('dedicatedDelete', '删除记录') + " >", deleteSelected, 16);
		deleteBtn.alignment = LEFT;
		deleteBtn.color = 0xFFFFAA96;
		add(deleteBtn);
		var loginBtn:TextButton = new TextButton(colL + 20, loginY, "< " + UIStyle.t('loginTitle', '注册 / 登录') + " >", function() openLogin(), 16);
		loginBtn.alignment = LEFT;
		loginBtn.color = 0xFF96C8FF;
		add(loginBtn);

		// ── 右: 服务器信息 + 房间列表 ──
		var rightPanel:OnlinePanel = new OnlinePanel(colR, panelTop, COL_R_W, panelH, 0xFF0A1220, 0.9, 0.68, 0, 0xFF6FB1FF);
		add(rightPanel);
		var rightTitle:FlxText = OnlineLayout.makeText(colR + 20, panelTop + 10, COL_R_W - 40, UIStyle.t('dedicatedServerInfo', '服务器信息'), 14, 0xFF96C8FF, LEFT);
		add(rightTitle);
		serverNameText = OnlineLayout.makeText(colR + 20, panelTop + 34, COL_R_W - 40, "", 13, 0xFFDCEBFF, LEFT);
		add(serverNameText);
		serverStateText = OnlineLayout.makeText(colR + 20, panelTop + 54, COL_R_W - 40, "", 12, OnlineLayout.C_SUB, LEFT);
		add(serverStateText);

		var roomTitle:FlxText = OnlineLayout.makeText(colR + 20, panelTop + 84, COL_R_W - 40, UIStyle.t('dedicatedRooms', '在线房间 (选择后回车加入)'), 13, 0xFF96C8FF, LEFT);
		add(roomTitle);
		roomListBox = new FlxSprite(colR + 14, panelTop + 108).makeGraphic(1, 1, FlxColor.BLACK);
		roomListBox.alpha = 0.35;
		add(roomListBox);
		roomList = new OnlineMenuList(colR + 14, panelTop + 114).asRowList(COL_R_W - 60, 12, ROOM_ROW_H);
		roomList.colorSelected = 0xFF96C8FF;
		roomList.onChange = function(i:Int) selRoom = i;
		roomList.onAccept = function(i:Int)
		{
			side = 1;
			selRoom = i;
			joinSelectedRoom();
		};
		add(roomList);

		var rightBtnH:Float = OnlineLayout.TOUCH_MIN_H;
		var rBackY:Float = panelTop + panelH - rightBtnH - 8;
		var rCreateY:Float = rBackY - rightBtnH;
		var rRefreshY:Float = rCreateY - rightBtnH;
		var refreshBtn:TextButton = new TextButton(colR + 20, rRefreshY, "< " + UIStyle.t('dedicatedRefresh', '刷新房间') + " >", function() requestRoomList(), 16);
		refreshBtn.alignment = LEFT;
		refreshBtn.color = 0xFF96C8FF;
		add(refreshBtn);
		var createBtn:TextButton = new TextButton(colR + 20, rCreateY, "< " + UIStyle.t('dedicatedCreateRoom', '创建房间') + " >", openCreateOverlay, 16);
		createBtn.alignment = LEFT;
		createBtn.color = 0xFF96C8FF;
		add(createBtn);
		var backBtn:TextButton = new TextButton(colR + 20, rBackY, "< " + UIStyle.t('back', '返回') + " >", doBack, 16);
		backBtn.alignment = LEFT;
		add(backBtn);
		OnlineLayout.padTouchAll([connectBtn, deleteBtn, loginBtn, refreshBtn, createBtn, backBtn]);

		statusText = OnlineLayout.makeText(OnlineLayout.PAD, panelTop + panelH + 14, FlxG.width - OnlineLayout.PAD * 2, "", 14, 0xFFFFDC8C, CENTER);
		add(statusText);

		rebuildHistory();
		rebuildRooms();
		refreshServerInfo();
		requestRoomList();
		syncListFocus();

		if (client.state == online.client.GameClient.ClientState.Ready)
			statusText.text = UIStyle.t('connected', '协议校验通过，已连接：') + client.serverName;
		else if (client.state == online.client.GameClient.ClientState.Failed)
			statusText.text = client.lastError;
		FlxG.mouse.visible = true;
	}

	// ── 历史列表 (固定锚点: ">" 独立列, 行文本 x 恒定) ────

	function rebuildHistory():Void
	{
		var entries:Array<OnlineMenuEntry> = [];
		var n:Int = 0;
		for (h in ProfileStore.serverHistory)
		{
			if (n >= MAX_ROWS)
				break;
			var addr:String = Reflect.field(h, "address");
			var name:String = Reflect.field(h, "name");
			entries.push(new OnlineMenuEntry((name != null && name.length > 0 ? name + "  " : "") + addr));
			n++;
		}
		if (selHistory >= entries.length)
			selHistory = 0;
		historyList.setEntries(entries);
		historyList.curSelected = selHistory;
		historyList.refreshLabels();

		historyBox.scale.set(COL_L_W - 28, entries.length > 0 ? 18 + entries.length * HIST_ROW_H : 44);
		historyBox.updateHitbox();
		if (historyEmpty == null)
		{
			historyEmpty = OnlineLayout.makeText(historyList.startPosition.x + 22, historyList.startPosition.y, COL_L_W - 60, "", 13, FlxColor.GRAY, LEFT);
			add(historyEmpty);
		}
		historyEmpty.visible = entries.length == 0;
		historyEmpty.text = entries.length == 0 ? UIStyle.t('dedicatedNoHistory', '暂无历史记录') : "";
	}

	/** 只让当前侧的列表吃键盘/指针输入。 */
	function syncListFocus():Void
	{
		if (historyList != null)
			historyList.inputEnabled = !overlayActive && side == 0;
		if (roomList != null)
			roomList.inputEnabled = !overlayActive && side == 1;
	}

	function connectSelected():Void
	{
		var address:String = "";
		if (ProfileStore.serverHistory.length > 0 && selHistory < ProfileStore.serverHistory.length)
			address = Reflect.field(ProfileStore.serverHistory[selHistory], "address");
		else
			address = addressInput.text;
		if (address == null || address.length == 0)
		{
			statusText.text = UIStyle.t('dedicatedNeedAddress', '请选择历史记录或输入新地址');
			return;
		}
		connectToAddress(address);
	}

	function connectToAddress(addressText:String):Void
	{
		if (client == null)
			return;
		if (client.state == online.client.GameClient.ClientState.Ready)
		{
			var parsed:{host:String, port:Int} = GameClient.parseAddress(addressText);
			if (parsed.host != client.host || parsed.port != client.port)
			{
				client.send(SeiunProtocol.MSG_BYE, SeiunProtocol.CHANNEL_CONTROL, {});
				client.flush();
				client.disconnect(false);
			}
			else
			{
				requestRoomList();
				return;
			}
		}
		statusText.text = UIStyle.t('connecting', '正在连接...');
		ProfileStore.setServerAddress(addressText);
		if (!client.connect(addressText))
			statusText.text = client.lastError;
		else
			statusText.text = UIStyle.t('handshaking', '已连接，正在校验 Seiun 协议...');
	}

	function deleteSelected():Void
	{
		if (ProfileStore.serverHistory.length == 0)
			return;
		var addr:String = Reflect.field(ProfileStore.serverHistory[selHistory], "address");
		ProfileStore.removeServerHistory(addr);
		selHistory = 0;
		rebuildHistory();
		FlxG.sound.play(Paths.sound('cancelMenu'), 0.6);
	}

	// ── 房间列表 ─────────────────────────────────────────

	function requestRoomList():Void
	{
		if (client == null || client.socket == null || client.state != online.client.GameClient.ClientState.Ready)
		{
			statusText.text = UIStyle.t('dedicatedConnectFirst', '请先连接服务器');
			return;
		}
		client.send(SeiunProtocol.MSG_ROOM_LIST, SeiunProtocol.CHANNEL_ROOM, {});
		statusText.text = UIStyle.t('listingRooms', '已连接，请等待房间列表...');
	}

	function rebuildRooms():Void
	{
		var entries:Array<OnlineMenuEntry> = [];
		var n:Int = 0;
		for (r in rooms)
		{
			if (n >= MAX_ROWS)
				break;
			// Reflect 取值兜底: 缺字段时不显示字面 "null"。
			var rn:Dynamic = Reflect.field(r, "roomName");
			var rc:Dynamic = Reflect.field(r, "roomCode");
			var pc:Dynamic = Reflect.field(r, "playerCount");
			var mp:Dynamic = Reflect.field(r, "maxPlayers");
			// 每段都取 String, 避免与数字混合时类型推断打架 (不能写 pc == null ? 0 : Std.string(pc))。
			var line:String = (rn == null ? "?" : Std.string(rn))
				+ (rc == null ? "" : " [" + Std.string(rc) + "]")
				+ " " + (pc == null ? "0" : Std.string(pc))
				+ "/" + (mp == null ? "0" : Std.string(mp))
				+ (Reflect.field(r, "hasPassword") == true ? " [P]" : "");
			entries.push(new OnlineMenuEntry(line));
			n++;
		}
		if (selRoom >= entries.length)
			selRoom = 0;
		roomList.setEntries(entries);
		roomList.curSelected = selRoom;
		roomList.refreshLabels();

		roomListBox.scale.set(COL_R_W - 28, entries.length > 0 ? 14 + entries.length * ROOM_ROW_H : 44);
		roomListBox.updateHitbox();
		if (roomEmpty == null)
		{
			roomEmpty = OnlineLayout.makeText(roomList.startPosition.x + 22, roomList.startPosition.y, COL_R_W - 60, "", 12, FlxColor.GRAY, LEFT);
			roomEmpty.wordWrap = true;
			add(roomEmpty);
		}
		roomEmpty.visible = entries.length == 0;
		roomEmpty.text = entries.length == 0 ? UIStyle.t('noRooms', '该服务器当前没有房间，可创建或输入房间码加入。') : "";
	}

	function joinSelectedRoom():Void
	{
		if (rooms.length == 0 || selRoom >= rooms.length)
			return;
		var code:String = Reflect.field(rooms[selRoom], "roomCode");
		if (code == null || code.length == 0)
			return;
		if (client == null || client.socket == null || client.state != online.client.GameClient.ClientState.Ready)
		{
			statusText.text = UIStyle.t('connectFirst', '请先连接服务器');
			return;
		}
		client.send(SeiunProtocol.MSG_ROOM_JOIN, SeiunProtocol.CHANNEL_ROOM, {roomCode: code, password: ""});
		statusText.text = UIStyle.t('joiningRoom', '正在加入房间...');
	}

	function openLogin():Void
	{
		MusicBeatState.switchState(new OnlineLoginState());
	}

	// ── 建房覆盖层 (同一套配置, 不启动内置服务器) ────────

	var overlayPanel:OnlinePanel = null;
	var overlayTitle:FlxText = null;

	function openCreateOverlay():Void
	{
		if (client == null || client.socket == null || client.state != online.client.GameClient.ClientState.Ready)
		{
			statusText.text = UIStyle.t('connectFirst', '请先连接服务器');
			return;
		}
		overlayActive = true;
		overlayDim = new FlxSprite().makeGraphic(FlxG.width, FlxG.height, FlxColor.BLACK);
		overlayDim.alpha = 0;
		add(overlayDim);
		FlxTween.tween(overlayDim, {alpha: 0.65}, 0.2);

		// 覆盖层按屏幕居中 (原 400/60 只在 1280x720 居中)
		var ovW:Float = Math.min(480, FlxG.width - OnlineLayout.PAD * 2);
		var ovH:Float = Math.min(600, FlxG.height - OnlineLayout.PAD * 2);
		var ovX:Float = (FlxG.width - ovW) / 2;
		var ovY:Float = (FlxG.height - ovH) / 2;
		overlayPanel = new OnlinePanel(ovX, ovY, ovW, ovH, 0xFF0A1220, 0.96, 0.72, 0, 0xFF6FB1FF);
		add(overlayPanel);
		overlayTitle = OnlineLayout.makeText(ovX + 20, ovY + 10, ovW - 40, UIStyle.t('dedicatedCreateTitle', '在专用服务器上创建房间'), 16, 0xFF96C8FF, LEFT);
		add(overlayTitle);

		// 专用服务器建房: 默认房间名 = "昵称的房间" (局域网托管保持默认"局域网房间")。
		var defaultRoomName:String = Language.get('online.defaultRoomNameDedicated', '{name}的房间')
			.replace('{name}', ProfileStore.nickname);
		overlayCard = new CreateRoomCard(ovX + 20, ovY + 40, ovW - 40, defaultRoomName);
		add(overlayCard);

		var ovBtnY:Float = ovY + ovH - OnlineLayout.TOUCH_MIN_H * 2 - 8;
		overlayConfirm = new TextButton(ovX + 20, ovBtnY, "< " + UIStyle.t('createRoom', '创建房间') + " >", function() confirmCreate(), 20);
		overlayConfirm.alignment = LEFT;
		overlayConfirm.color = 0xFF96C8FF;
		add(overlayConfirm);
		overlayCancel = new TextButton(ovX + 20, ovBtnY + OnlineLayout.TOUCH_MIN_H, "< " + UIStyle.t('cancel', '取消') + " >", closeCreateOverlay, 16);
		overlayCancel.alignment = LEFT;
		add(overlayCancel);
		OnlineLayout.padTouchAll([overlayConfirm, overlayCancel]);
		overlayConfirm.focused = true;
		syncListFocus();
	}

	function confirmCreate():Void
	{
		var payload:Dynamic = overlayCard.buildPayload();
		client.send(SeiunProtocol.MSG_ROOM_CREATE, SeiunProtocol.CHANNEL_ROOM, payload);
		statusText.text = UIStyle.t('creatingRoom', '正在创建房间...');
		closeCreateOverlay();
	}

	function closeCreateOverlay():Void
	{
		if (!overlayActive)
			return;
		overlayActive = false;
		if (PsychUIInputText.focusOn != null && overlayCard != null
			&& (PsychUIInputText.focusOn == overlayCard.roomNameInput || PsychUIInputText.focusOn == overlayCard.passwordInput))
			PsychUIInputText.focusOn = null;
		if (overlayDim != null) { remove(overlayDim); overlayDim.destroy(); overlayDim = null; }
		if (overlayPanel != null) { remove(overlayPanel); overlayPanel.destroy(); overlayPanel = null; }
		if (overlayTitle != null) { remove(overlayTitle); overlayTitle.destroy(); overlayTitle = null; }
		if (overlayCard != null) { remove(overlayCard); overlayCard.destroy(); overlayCard = null; }
		if (overlayConfirm != null) { remove(overlayConfirm); overlayConfirm.destroy(); overlayConfirm = null; }
		if (overlayCancel != null) { remove(overlayCancel); overlayCancel.destroy(); overlayCancel = null; }
		syncListFocus();
	}

	// ── 状态刷新 ─────────────────────────────────────────

	function refreshServerInfo():Void
	{
		if (serverNameText != null)
		{
			if (client != null && client.state == online.client.GameClient.ClientState.Ready)
				serverNameText.text = client.serverName;
			else
				serverNameText.text = UIStyle.t('dedicatedNotConnected', '(未连接)');
		}
		if (serverStateText != null)
		{
			if (client != null && client.state == online.client.GameClient.ClientState.Ready)
				serverStateText.text = UIStyle.t('dedicatedOnline', '已连接: ') + client.host + ":" + client.port
					+ (client.dedicated ? " · " + UIStyle.t('dedicatedTag', '专用服务器') : "");
			else
				serverStateText.text = UIStyle.t('dedicatedOffline', '未连接');
		}
	}

	function doBack():Void
	{
		FlxG.sound.play(Paths.sound('cancelMenu'));
		MusicBeatState.switchState(new OnlineState());
	}

	// ── 更新 ─────────────────────────────────────────────

	override function update(elapsed:Float)
	{
		super.update(elapsed);
		if (client != null)
		{
			client.update(elapsed);
			if (client.state == online.client.GameClient.ClientState.Failed)
				statusText.text = client.lastError;
		}
		if (overlayCard != null)
			overlayCard.updateFocus();

		var ev = client.pollEvent();
		while (ev != null)
		{
			switch (ev.type)
			{
				case SeiunProtocol.MSG_WELCOME:
					ProfileStore.addServerHistory(client.host + ":" + client.port, client.serverName);
					statusText.text = UIStyle.t('connected', '协议校验通过，已连接：') + client.serverName;
					refreshServerInfo();
					if (client.authRequired && !client.authenticated)
						statusText.text = UIStyle.t('authRequired', '该专用服务器需要先注册/登录账号。');
					else
						requestRoomList();
				case SeiunProtocol.MSG_ROOM_LIST_RESULT:
					if (ev.data != null && ev.data.rooms != null)
					{
						rooms = cast ev.data.rooms;
						rebuildRooms();
						if (rooms.length == 0)
							statusText.text = UIStyle.t('noRooms', '该服务器当前没有房间，可创建或输入房间码加入。');
					}
				case SeiunProtocol.MSG_ROOM_JOIN_RESULT:
					if (ev.data != null && ev.data.ok == true)
					{
						if (ev.data.room != null)
							OnlineSession.enter(ev.data.room, ev.data.selfId);
						if (ev.data.players != null && Std.isOfType(ev.data.players, Array))
							OnlineSession.players = cast ev.data.players;
						MusicBeatState.switchState(new OnlineRoomState());
						return;
					}
					else
						statusText.text = UIStyle.errText(ev.data == null ? -1 : Reflect.field(ev.data, "code"), ev.data == null ? "加入失败" : Reflect.field(ev.data, "message"));
				case SeiunProtocol.MSG_AUTH_RESULT:
					if (ev.data != null && ev.data.ok == true)
					{
						statusText.text = UIStyle.t('authOk', '登录成功');
						requestRoomList();
					}
					else
						statusText.text = ev.data == null ? UIStyle.t('authFailed', '认证失败') : ev.data.message;
				case SeiunProtocol.MSG_ERROR:
					statusText.text = UIStyle.errText(ev.data == null ? -1 : Reflect.field(ev.data, "code"), ev.data == null ? client.lastError : Reflect.field(ev.data, "message"));
			}
			ev = client.pollEvent();
		}

		var escCancelledFocus:Bool = UIStyle.consumedInputEscape();

		if (overlayActive)
		{
			if (overlayCard == null)
				return;
			var typing:Bool = UIStyle.anyInputFocused();
			if (!typing)
			{
				if (controls.UI_UP_P)
					moveOverlayFocus(-1);
				else if (controls.UI_DOWN_P)
					moveOverlayFocus(1);
				if (controls.ACCEPT)
				{
					FlxG.sound.play(Paths.sound('confirmMenu'), 0.7);
					if (overlayConfirm.focused)
						confirmCreate();
					else if (overlayCancel.focused)
						closeCreateOverlay();
					else
					{
						var handledRow:Bool = false;
						for (r in overlayCard.rows)
							if (r.focused)
							{
								r.onClick();
								handledRow = true;
								break;
							}
						if (!handledRow && overlayCard.rows.length > 0)
							overlayCard.rows[0].onClick();
					}
				}
			}
			// 输入框聚焦时 BACK 放行: Backspace 是退格不是返回; ESC 第一次只取消聚焦。
			if (controls.BACK #if android || FlxG.android.justReleased.BACK #end && !UIStyle.anyInputFocused() && !escCancelledFocus)
				closeCreateOverlay();
			return;
		}

		// 列表导航: 左右/TAB 切栏; ↑↓ 与 ACCEPT/点击由当前侧的 OnlineMenuList 处理
		// (行 tap 语义 + ≥40px 命中在组件内)。
		if (controls.UI_LEFT_P)
		{
			side = 0;
			FlxG.sound.play(Paths.sound('scrollMenu'), 0.4);
		}
		else if (controls.UI_RIGHT_P)
		{
			side = 1;
			FlxG.sound.play(Paths.sound('scrollMenu'), 0.4);
		}
		syncListFocus();
		// 空列表时 ACCEPT 仍要给提示 (组件对空列表不会回调)。
		if (controls.ACCEPT)
		{
			if (side == 0 && ProfileStore.serverHistory.length == 0)
				connectSelected();
			else if (side == 1 && rooms.length == 0)
				joinSelectedRoom();
		}
		if (FlxG.keys.justPressed.D && side == 0)
			deleteSelected();
		if (FlxG.keys.justPressed.R)
			requestRoomList();
		if (FlxG.keys.justPressed.C)
			openCreateOverlay();
		if (FlxG.keys.justPressed.L)
			openLogin();
		if (FlxG.keys.justPressed.TAB)
		{
			side = side == 0 ? 1 : 0;
			syncListFocus();
		}

		if (controls.BACK #if android || FlxG.android.justReleased.BACK #end && !UIStyle.anyInputFocused() && !escCancelledFocus)
			doBack();
	}

	function moveOverlayFocus(delta:Int):Void
	{
		if (overlayCard == null)
			return;
		var chain:Array<TextButton> = [overlayConfirm, overlayCancel];
		for (r in overlayCard.rows)
			chain.push(r);
		var idx:Int = 0;
		for (i in 0...chain.length)
			if (chain[i] != null && chain[i].focused)
			{
				idx = i;
				chain[i].focused = false;
				break;
			}
		idx = (idx + delta + chain.length) % chain.length;
		chain[idx].focused = true;
		FlxG.sound.play(Paths.sound('scrollMenu'), 0.5);
	}
}
