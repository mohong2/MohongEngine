package online.states;

import StringTools;
import backend.MusicBeatState;
import ClientPrefs;
import flixel.addons.display.FlxBackdrop;
import flixel.addons.display.FlxGridOverlay;
import flixel.FlxG;
import flixel.FlxSprite;
import flixel.group.FlxGroup.FlxTypedGroup;
import flixel.text.FlxText;
import flixel.util.FlxColor;
import online.client.CrashReporter;
import online.client.GameClient;
import online.client.OnlineSession;
import online.client.ProfileStore;
import online.server.EmbeddedServerRunner;
import online.shared.SeiunProtocol;
import online.ui.OnlineLayout;
import online.ui.UIStyle;
import openfl.events.KeyboardEvent;
import states.MainMenuState;

/**
	联机主界面 —— PsychOnline 风格菜单:
	menuDesat 灰底 + 网格流光, 居中全大写菜单
	(JOIN ROOM / HOST LAN / DEDICATED / FIND / OPTIONS / RECORDS / BACK),
	选中项 "> X <" + 全宽黑条高亮, 底部描述黑框。
	JOIN ROOM 内联输入房间码/密码; HOST LAN 进局域网托管页;
	DEDICATED 进专用服务器页; FIND 进独立查找页; OPTIONS 打开设置 Substate; RECORDS 进个人记录页。
	加入被拒 ERR_ROOM_FULL 时提供"以观战身份加入"重试 (观战不占游玩席位)。
**/
class OnlineState extends MusicBeatState
{
	var items:FlxTypedGroup<FlxText>;
	var itemsTopY:Float = 0;
	static final itemNames:Array<String> = ["JOIN ROOM", "HOST LAN", "DEDICATED", "FIND", "OPTIONS", "RECORDS", "BACK"];
	/** 菜单项多语言文案 (键与 itemNames 一一对应, 样式保持原版)。 */
	static final itemKeys:Array<String> = ["menuJoin", "menuHostLan", "menuDedicated", "menuFind", "menuOptions", "menuRecords", "menuBack"];
	var itemNameLocalized:Array<String> = [];
	static final itemDescs:Array<String> = [
		"输入房间码加入房间 (房间码 + 密码)",
		"本机托管建房，其他玩家通过 IP 直接加入 (局域网托管页)",
		"连接专用服务器: 地址历史 / 房间列表 / 注册登录",
		"扫描局域网内的 SeiunEngine 服务器",
		"服务器地址 / 昵称 / 头像 / 皮肤 / 默认规则",
		"设备码 / 昵称 / 战绩 / 最佳成绩",
		"退出联机，返回主菜单"
	];

	var selectLine:FlxSprite;
	var descBox:FlxSprite;
	var itemDesc:FlxText;
	var statusText:FlxText;

	static var curSelected:Int = 0;

	var client:GameClient;
	var pendingJoinCode:String = "";
	var pendingJoinPassword:String = "";

	var inputWait:Bool = false;
	var inputMode:Int = 0; // 1=房间码 2=密码
	var inputString:String = "";
	var joinCodeInput:String = "";
	var joinPasswordInput:String = "";
	var justCancelledInput:Bool = false;
	/** 房间已满时的观战重试: 记住上次加入的房间, 确认后以观战身份再加入。 */
	var lastJoinCode:String = "";
	var lastJoinPassword:String = "";
	var awaitSpectate:Bool = false;
	#if android
	/** 安卓没有物理键盘: 房间码/密码改用 PsychUIInputText + 系统软键盘。 */
	var nativeJoinInput:backend.ui.PsychUIInputText = null;
	var nativeJoinDim:FlxSprite = null;
	var nativeJoinTitle:FlxText = null;
	#end

	override function create()
	{
		super.create();
		// 打开"联机设置" Substate 期间也要继续处理网络事件。
		persistentUpdate = true;
		ProfileStore.ensureLoaded();
		client = GameClient.instance != null ? GameClient.instance : new GameClient();

		FlxG.mouse.visible = true;

		var bg:FlxSprite = new FlxSprite().loadGraphic(Paths.image('menuDesat'));
		bg.color = 0xFF2B2B2B;
		bg.updateHitbox();
		bg.screenCenter();
		bg.antialiasing = ClientPrefs.data.globalAntialiasing;
		add(bg);

		var grid:FlxBackdrop = new FlxBackdrop(FlxGridOverlay.createGrid(80, 80, 160, 160, true, 0x33FFFFFF, 0x0));
		grid.velocity.set(30, 30);
		grid.alpha = 0.5;
		add(grid);

		selectLine = new FlxSprite();
		selectLine.makeGraphic(1, 1, FlxColor.BLACK);
		selectLine.alpha = 0.3;
		add(selectLine);

		descBox = new FlxSprite(0, FlxG.height - 125);
		descBox.makeGraphic(1, 1, FlxColor.BLACK);
		descBox.alpha = 0.4;
		add(descBox);

		items = new FlxTypedGroup<FlxText>();
		for (i in 0...itemNames.length)
			itemNameLocalized.push(UIStyle.t(itemKeys[i], itemNames[i]));
		for (i in 0...itemNames.length)
		{
			var text:FlxText = new FlxText(0, 0, 0, itemNameLocalized[i], 34);
			text.ID = i;
			// languageFont: 中文语言包渲染中文菜单项, 英文包回落 vcr, 样式不变。
			text.setFormat(Paths.languageFont(), 34, FlxColor.WHITE, CENTER, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
			items.add(text);
		}
		itemsTopY = (FlxG.height - itemNames.length * 38) / 2;
		for (i in 0...items.length)
			items.members[i].y = itemsTopY + i * 38;
		add(items);

		itemDesc = new FlxText(0, FlxG.height - 170, FlxG.width, "", 22);
		itemDesc.setFormat(Paths.languageFont(), 22, FlxColor.WHITE, CENTER, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		itemDesc.wordWrap = true; // 长描述折行, 不横向溢出
		add(itemDesc);

		// 状态行: 顶部相对定位 + 折行 (原 x=190 只在 1280 宽正确; 房间列表多行文本会下压与菜单重叠)。
		statusText = new FlxText(OnlineLayout.PAD, 96, FlxG.width - OnlineLayout.PAD * 2, "", 18);
		statusText.setFormat(Paths.languageFont(), 18, FlxColor.WHITE, CENTER, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		statusText.wordWrap = true;
		statusText.scrollFactor.set();
		statusText.alpha = 0.85;
		add(statusText);

		FlxG.stage.addEventListener(KeyboardEvent.KEY_DOWN, onKeyDown);
		CrashReporter.reportPending();
		changeSelection(0);

		if (OnlineSession.lastDisconnectMessage.length > 0)
		{
			// 这是"上次会话"的断线提示, 不是当前实时断线, 加前缀避免误导。
			statusText.text = UIStyle.t('lastDisconnectPrefix', '上次连接提示: ') + OnlineSession.lastDisconnectMessage;
			online.shared.OnlineDebug.log("ui", "OnlineState shows lastDisconnect: " + OnlineSession.lastDisconnectMessage);
			OnlineSession.lastDisconnectMessage = "";
		}
		if (client.state == online.client.GameClient.ClientState.Ready)
		{
			statusText.text = UIStyle.t('connected', '协议校验通过，已连接：') + client.serverName;
			requestRoomList();
		}
		else if (client.state == online.client.GameClient.ClientState.Failed)
		{
			statusText.text = client.lastError;
			online.shared.OnlineDebug.log("ui", "OnlineState shows Failed: " + client.lastError);
		}
		online.shared.OnlineDebug.log("ui", "OnlineState.create state=" + Std.string(client.state) + " lastErr=" + client.lastError);
	}

	override function destroy()
	{
		FlxG.stage.removeEventListener(KeyboardEvent.KEY_DOWN, onKeyDown);
		#if android
		destroyNativeJoinInput();
		#end
		super.destroy();
	}

	// ── 菜单 ─────────────────────────────────────────────

	/**
		指针 y → 菜单项索引。菜单行距 38px, 触屏下限 40px, 这里以"行中心 ±20px"判定
		 (相邻行会按各自中心归属, 不改变任何可见样式, 只扩大点击判定)。
	**/
	function hitItemAtY(py:Float):Int
	{
		if (items == null || items.length == 0)
			return -1;
		var halfHit:Float = Math.max(OnlineLayout.TOUCH_MIN_H / 2, 19);
		for (i in 0...items.length)
		{
			var cy:Float = itemsTopY + i * 38 + 19;
			if (py >= cy - halfHit && py <= cy + halfHit)
				return i;
		}
		return -1;
	}

	function getItemName(i:Int):String
	{
		if (inputWait && i == 0)
			return UIStyle.t('joinCode', 'JOIN CODE:') + " " + inputString;
		return itemNameLocalized[i];
	}

	function changeSelection(change:Int = 0)
	{
		curSelected += change;
		if (curSelected < 0)
			curSelected = itemNames.length - 1;
		if (curSelected >= itemNames.length)
			curSelected = 0;

		itemDesc.text = UIStyle.t('menuDesc' + curSelected, itemDescs[curSelected]);
		itemDesc.screenCenter(X);

		descBox.scale.set(FlxG.width - 500, (itemDesc.text.split("\n").length + 2) * itemDesc.size);
		descBox.y = itemDesc.y + descBox.scale.y * 0.5 - itemDesc.size;
		descBox.screenCenter(X);

		selectLine.y = itemsTopY + 19 + curSelected * 38;
		selectLine.scale.set(FlxG.width, 38);
		selectLine.screenCenter(X);

		for (item in items)
		{
			item.text = getItemName(item.ID);
			item.alpha = inputWait ? 0.5 : 0.8;
			if (item.ID == curSelected)
			{
				item.text = "> " + item.text + " <";
				item.alpha = 1;
			}
			item.screenCenter(X);
		}
		if (change != 0)
			FlxG.sound.play(Paths.sound('scrollMenu'), 0.6);
	}

	function activate():Void
	{
		if (inputWait)
		{
			confirmInput();
			return;
		}
		FlxG.sound.play(Paths.sound('confirmMenu'), 0.7);
		switch (curSelected)
		{
			case 0: startJoinInput();
			case 1: MusicBeatState.switchState(new OnlineCreateRoomState());
			case 2: MusicBeatState.switchState(new OnlineDedicatedState());
			case 3: MusicBeatState.switchState(new OnlineFindState());
			case 4: openSubState(new online.substates.OptionsSubstate());
			case 5: MusicBeatState.switchState(new OnlineProfileState());
			case 6: doBack();
		}
	}

	function doBack():Void
	{
		FlxG.sound.play(Paths.sound('cancelMenu'));
		if (client.state == online.client.GameClient.ClientState.Ready)
		{
			client.send(SeiunProtocol.MSG_BYE, SeiunProtocol.CHANNEL_CONTROL, {});
			client.flush();
			client.disconnect(false);
		}
		else if (client.socket != null)
			client.disconnect(true);
		if (EmbeddedServerRunner.running && (OnlineSession.isHost || !OnlineSession.active))
			EmbeddedServerRunner.stop();
		OnlineSession.clear();
		MusicBeatState.switchState(new MainMenuState());
	}

	// ── 内联输入 (房间码 / 密码) ──────────────────────────

	function startJoinInput():Void
	{
		joinCodeInput = "";
		joinPasswordInput = "";
		inputMode = 1;
		inputString = "";
		inputWait = true;
		statusText.text = UIStyle.t('joinCodeHint', '输入房主房间码，回车继续');
		changeSelection(0);
		#if android
		openNativeJoinInput(1);
		#end
	}

	#if android
	function openNativeJoinInput(mode:Int):Void
	{
		destroyNativeJoinInput();
		nativeJoinDim = new FlxSprite().makeGraphic(FlxG.width, FlxG.height, FlxColor.BLACK);
		nativeJoinDim.alpha = 0.55;
		add(nativeJoinDim);

		nativeJoinTitle = new FlxText(0, 252, FlxG.width,
			mode == 1 ? UIStyle.t('joinCodeHint', '输入房主房间码') : UIStyle.t('joinPasswordHint', '输入房间密码 (可留空)'), 26);
		nativeJoinTitle.setFormat(Paths.languageFont(), 26, FlxColor.WHITE, CENTER, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		add(nativeJoinTitle);

		nativeJoinInput = new backend.ui.PsychUIInputText(Std.int(FlxG.width / 2 - 280), 310, 560, "", 22, UIStyle.inputFontKey());
		UIStyle.styleInput(nativeJoinInput);
		nativeJoinInput.maxLength = mode == 1 ? 12 : 32;
		add(nativeJoinInput);
		backend.ui.PsychUIInputText.focusOn = nativeJoinInput;
		backend.SeiunOverlay.showKeyboard();
	}

	function destroyNativeJoinInput():Void
	{
		if (nativeJoinInput != null)
		{
			if (backend.ui.PsychUIInputText.focusOn == nativeJoinInput)
				backend.ui.PsychUIInputText.focusOn = null;
			remove(nativeJoinInput);
			nativeJoinInput.destroy();
			nativeJoinInput = null;
		}
		if (nativeJoinTitle != null) { remove(nativeJoinTitle); nativeJoinTitle.destroy(); nativeJoinTitle = null; }
		if (nativeJoinDim != null) { remove(nativeJoinDim); nativeJoinDim.destroy(); nativeJoinDim = null; }
		backend.SeiunOverlay.dismissKeyboard();
	}

	function updateNativeJoinInput():Bool
	{
		if (nativeJoinInput == null)
			return false;
		if (controls.ACCEPT || FlxG.keys.justPressed.ENTER)
		{
			FlxG.sound.play(Paths.sound('confirmMenu'), 0.7);
			inputString = StringTools.trim(nativeJoinInput.text);
			destroyNativeJoinInput();
			confirmInput();
			return true;
		}
		if ((controls.BACK #if android || FlxG.android.justReleased.BACK #end) && !UIStyle.anyInputFocused())
		{
			FlxG.sound.play(Paths.sound('cancelMenu'));
			destroyNativeJoinInput();
			cancelInput();
			return true;
		}
		return false;
	}
	#end

	function confirmInput():Void
	{
		switch (inputMode)
		{
			case 1:
				joinCodeInput = StringTools.trim(inputString).toUpperCase();
				if (joinCodeInput.length == 0)
				{
					statusText.text = UIStyle.t('roomCodeRequired', '请输入房间码');
					return;
				}
				inputMode = 2;
				inputString = "";
				statusText.text = UIStyle.t('joinPasswordHint', '输入房间密码 (可留空直接回车)');
				changeSelection(0);
				#if android
				openNativeJoinInput(2);
				#end
			case 2:
				joinPasswordInput = inputString;
				inputWait = false;
				inputMode = 0;
				joinByCode(joinCodeInput, joinPasswordInput);
				changeSelection(0);
		}
	}

	function cancelInput():Void
	{
		#if android
		destroyNativeJoinInput();
		#end
		inputWait = false;
		inputMode = 0;
		changeSelection(0);
		statusText.text = UIStyle.t('statusIdle', '尚未连接。可开启局域网、查找服务器或输入房主 IP。');
	}

	function onKeyDown(e:KeyboardEvent):Void
	{
		#if android
		if (nativeJoinInput != null)
			return; // 原生输入框自己处理键盘/IME
		#end
		if (!inputWait)
			return;
		var key:Int = e.keyCode;
		if (key == 8)
		{
			if (inputString.length > 0)
				inputString = inputString.substr(0, inputString.length - 1);
		}
		else if (key == 13)
		{
			FlxG.sound.play(Paths.sound('confirmMenu'), 0.7);
			confirmInput();
		}
		else if (key == 27)
		{
			justCancelledInput = true;
			cancelInput();
		}
		else if (e.charCode > 0)
		{
			if (inputString.length < 64)
			{
				var c:String = String.fromCharCode(e.charCode);
				inputString += (inputMode == 1 && !e.shiftKey) ? c.toUpperCase() : c;
			}
		}
		if (inputWait)
			changeSelection(0);
	}

	// ── 动作 ─────────────────────────────────────────────

	function joinByCode(code:String, password:String, ?spectate:Bool = false):Void
	{
		pendingJoinCode = code;
		pendingJoinPassword = password;
		lastJoinCode = code;
		lastJoinPassword = password;
		awaitSpectate = false;
		if (client.state != online.client.GameClient.ClientState.Ready)
		{
			statusText.text = UIStyle.t('connectFirst', '请先连接服务器，连接后自动加入房间');
			connectToAddress(ProfileStore.serverAddress);
			return;
		}
		client.send(SeiunProtocol.MSG_ROOM_JOIN, SeiunProtocol.CHANNEL_ROOM, {roomCode: pendingJoinCode, password: pendingJoinPassword, spectate: spectate});
		statusText.text = UIStyle.t(spectate ? 'joiningAsSpectator' : 'joiningRoom', spectate ? '正在以观战身份加入房间...' : '正在加入房间...');
		pendingJoinCode = "";
		pendingJoinPassword = "";
	}

	function connectToAddress(addressText:String):Void
	{
		if (client.state == online.client.GameClient.ClientState.Ready)
		{
			var parsed:{host:String, port:Int} = GameClient.parseAddress(addressText);
			if (parsed.host != client.host || parsed.port != client.port)
			{
				client.send(SeiunProtocol.MSG_BYE, SeiunProtocol.CHANNEL_CONTROL, {});
				client.flush();
				client.disconnect(false);
			}
			else
			{
				requestRoomList();
				return;
			}
		}
		statusText.text = UIStyle.t('connecting', '正在连接...');
		ProfileStore.setServerAddress(addressText);
		if (!client.connect(addressText))
			statusText.text = client.lastError;
		else
			statusText.text = UIStyle.t('handshaking', '已连接，正在校验 Seiun 协议...');
	}

	function requestRoomList():Void
	{
		if (client == null || client.socket == null || client.state != online.client.GameClient.ClientState.Ready)
			return;
		client.send(SeiunProtocol.MSG_ROOM_LIST, SeiunProtocol.CHANNEL_ROOM, {});
		statusText.text = UIStyle.t('listingRooms', '已连接，请等待房间列表...');
	}

	// ── 更新与事件 ───────────────────────────────────────

	override function update(elapsed:Float)
	{
		super.update(elapsed);
		if (client != null)
			client.update(elapsed);
		processEvents();

		// Substate (联机设置) 打开期间不响应大厅按键
		if (subState != null)
			return;

		#if android
		if (inputWait && nativeJoinInput != null)
		{
			updateNativeJoinInput();
			return;
		}
		#end

		// 房间已满的观战重试: 回车/确认=以观战身份加入, ESC=取消 (期间菜单输入挂起)。
		if (awaitSpectate)
		{
			if (controls.ACCEPT)
			{
				awaitSpectate = false;
				joinByCode(lastJoinCode, lastJoinPassword, true);
				return;
			}
			if (controls.BACK #if android || FlxG.android.justReleased.BACK #end)
			{
				awaitSpectate = false;
				statusText.text = UIStyle.t('statusIdle', '尚未连接。可开启局域网、查找服务器或输入房主 IP。');
				return;
			}
			return;
		}

		var touchActivated:Bool = false;
		#if (android || mobile)
		// 移动端没有鼠标: 点击菜单项直接选中并激活。
		// 命中区比行距大 (视觉保持原样, 触屏判定扩大到 40px 标准的半行重叠带)。
		for (touch in FlxG.touches.list)
		{
			if (touch == null || !touch.justPressed)
				continue;
			var idx:Int = hitItemAtY(touch.y);
			if (idx < 0)
				continue;
			curSelected = idx;
			changeSelection(0);
			activate();
			touchActivated = true;
		}
		#end

		var mouseInItems:Bool = hitItemAtY(FlxG.mouse.y) >= 0;

		if (FlxG.mouse.justPressed && inputWait)
		{
			if (!FlxG.mouse.overlaps(items.members[curSelected]))
			{
				cancelInput();
				return;
			}
			confirmInput();
			return;
		}

		if (FlxG.mouse.justMoved && !inputWait && mouseInItems)
		{
			var newSel:Int = hitItemAtY(FlxG.mouse.y);
			if (newSel >= 0 && newSel < items.length && newSel != curSelected)
			{
				curSelected = newSel;
				changeSelection(0);
			}
		}

		if (!inputWait)
		{
			if (controls.UI_UP_P)
				changeSelection(-1);
			else if (controls.UI_DOWN_P)
				changeSelection(1);

			if (!touchActivated && (controls.ACCEPT || (FlxG.mouse.justPressed && mouseInItems)))
				activate();
			if (controls.BACK #if android || FlxG.android.justReleased.BACK #end)
			{
				if (justCancelledInput)
					justCancelledInput = false; // ESC 刚取消输入, 这一帧不再触发返回
				else
					doBack();
			}
		}
	}

	function processEvents():Void
	{
		if (client == null)
			return;
		if (client.state == online.client.GameClient.ClientState.Failed && statusText.text != client.lastError)
			statusText.text = client.lastError;

		var ev = client.pollEvent();
		while (ev != null)
		{
			switch (ev.type)
			{
				case SeiunProtocol.MSG_WELCOME:
					ProfileStore.addServerHistory(client.host + ":" + client.port, client.serverName);
					statusText.text = UIStyle.t('connected', '协议校验通过，已连接：') + client.serverName;
					CrashReporter.reportPending();
					if (client.authRequired && !client.authenticated)
					{
						statusText.text = UIStyle.t('authRequired', '该专用服务器需要先注册/登录账号。');
						MusicBeatState.switchState(new OnlineLoginState());
						return;
					}
					else if (pendingJoinCode.length > 0)
					{
						client.send(SeiunProtocol.MSG_ROOM_JOIN, SeiunProtocol.CHANNEL_ROOM, {roomCode: pendingJoinCode, password: pendingJoinPassword});
						statusText.text = UIStyle.t('joiningRoom', '正在加入房间...');
						pendingJoinCode = "";
						pendingJoinPassword = "";
					}
					else
						requestRoomList();
				case SeiunProtocol.MSG_AUTH_RESULT:
					if (ev.data != null && ev.data.ok == true)
					{
						client.sessionToken = ev.data.token;
						client.authenticated = true;
						// 一体化登录: 记住令牌, 下次连接本服务器免密。
						ProfileStore.rememberAuth(client.host + ":" + client.port,
							ev.data.username == null ? "" : Std.string(ev.data.username),
							Std.string(ev.data.token));
						statusText.text = UIStyle.t('authOk', '登录成功');
						requestRoomList();
					}
					else
						statusText.text = UIStyle.errText(ev.data == null ? -1 : Reflect.field(ev.data, "code"), ev.data == null ? UIStyle.t('authFailed', '认证失败') : ev.data.message);
				case SeiunProtocol.MSG_ROOM_LIST_RESULT:
					if (ev.data != null && ev.data.rooms != null)
					{
						var rooms:Array<Dynamic> = cast ev.data.rooms;
						if (rooms.length == 0)
							statusText.text = UIStyle.t('noRooms', '该服务器当前没有房间，可创建或输入房间码加入。');
						else
							statusText.text = UIStyle.t('roomListTitle', '房间列表：') + describeRooms(rooms);
					}
				case SeiunProtocol.MSG_ROOM_JOIN_RESULT:
					if (ev.data != null && ev.data.ok == true)
					{
						enterRoom(ev.data);
						return;
					}
					else
					{
						var errCode:Dynamic = ev.data == null ? -1 : Reflect.field(ev.data, "code");
						if (errCode != null && errCode == SeiunProtocol.ERR_ROOM_FULL && lastJoinCode.length > 0)
						{
							// 满员: 提供一键"以观战身份加入" (不占游玩席位, 上限 8 人)。
							awaitSpectate = true;
							statusText.text = UIStyle.t('spectateOffer', '房间已满。按 回车/确认 以观战身份加入，ESC 取消');
						}
						else
							statusText.text = UIStyle.errText(errCode, ev.data == null ? UIStyle.t('joinFailed', '加入失败') : Reflect.field(ev.data, "message"));
					}
				case SeiunProtocol.MSG_ERROR:
					statusText.text = UIStyle.errText(ev.data == null ? -1 : Reflect.field(ev.data, "code"), ev.data == null ? client.lastError : Reflect.field(ev.data, "message"));
			}
			ev = client.pollEvent();
		}
	}

	function describeRooms(rooms:Array<Dynamic>):String
	{
		var lines:Array<String> = [];
		for (r in rooms)
			lines.push(r.roomName + " [" + r.roomCode + "] " + r.playerCount + "/" + r.maxPlayers + " "
				+ (r.hasPassword == true ? " [P]" : ""));
		return "\n" + lines.join("\n");
	}

	function enterRoom(data:Dynamic):Void
	{
		if (data.room != null)
			OnlineSession.enter(data.room, data.selfId);
		if (data.players != null && Std.isOfType(data.players, Array))
			OnlineSession.players = cast data.players;
		MusicBeatState.switchState(new OnlineRoomState());
	}
}
