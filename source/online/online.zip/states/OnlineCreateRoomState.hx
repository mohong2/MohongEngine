package online.states;

import backend.MusicBeatState;
import backend.Ratings;
import backend.ui.PsychUIInputText;
import ClientPrefs;
import flixel.addons.display.FlxBackdrop;
import flixel.addons.display.FlxGridOverlay;
import flixel.FlxG;
import flixel.FlxSprite;
import flixel.text.FlxText;
import flixel.util.FlxColor;
import online.client.GameClient;
import online.client.OnlineSession;
import online.client.ProfileStore;
import online.server.EmbeddedServerRunner;
import online.server.LanUtil;
import online.shared.SeiunProtocol;
import online.ui.CreateRoomCard;
import online.ui.OnlineLayout;
import online.ui.OnlinePanel;
import online.ui.TextButton;
import online.ui.UIStyle;

/**
	HOST LAN —— 局域网托管页 (参照 PsychOnline HostServerTab 的"极简 + 状态 + 日志"):
	- 顶部大标题 "局域网托管" (绿色系);
	- 服务器状态卡: 运行中/已停止、实际监听端口 (被占自动 +1)、本机 IP、房间码;
	- 日志区: EmbeddedServerRunner.logSink 缓存的最近 50 行直接显示;
	- 建房配置折叠卡: 房间名/密码/模式/人数/判定/兼容/舞台;
	- 主按钮: START SERVER (启动+建房) / STOP (停服+回主菜单)。
**/
class OnlineCreateRoomState extends MusicBeatState
{
	var client:GameClient;
	var statusText:FlxText;

	// 两栏布局 (按屏宽居中)
	var colL:Float = 190;
	var colR:Float = 670;
	var panelTop:Float = 92;

	// 状态卡
	var statusValue:FlxText;
	var portValue:FlxText;
	var ipValue:FlxText;
	var roomCodeValue:FlxText;

	// 日志
	var logText:FlxText;
	var lastLogSig:String = "";

	// 配置卡
	var card:CreateRoomCard;
	var startButton:TextButton;
	var stopButton:TextButton;

	// 焦点链: 主按钮 + 卡片输入/行
	var focusables:Array<Dynamic> = [];
	var curFocus:Int = 0;

	var createRequested:Bool = false;
	var startedEmbeddedHere:Bool = false;
	var initialStatus:String = "";
	var localIps:Array<String> = [];
	var ipRefreshTimer:Float = 0;
	var ipRefreshInterval:Float = 30; // ipconfig 有进程开销, 30 秒才刷一次
	var ipThreadRunning:Bool = false;
	var lastStatusSig:String = "";

	override function create()
	{
		super.create();
		UIStyle.installInputEscapeGuard();
		client = (GameClient.instance != null) ? GameClient.instance : new GameClient();
		Ratings.loadPresets();
		ProfileStore.ensureLoaded();
		// 本机 IP 用后台线程探测 (ipconfig 进程启动不阻塞主线程/不卡界面)。
		refreshIpsAsync();

		// 背景: 灰底 + 网格, 绿色系基调
		var bg:FlxSprite = new FlxSprite().loadGraphic(Paths.image('menuDesat'));
		bg.color = 0xFF14301F;
		bg.screenCenter();
		bg.antialiasing = ClientPrefs.data.globalAntialiasing;
		add(bg);
		var grid:FlxBackdrop = new FlxBackdrop(FlxGridOverlay.createGrid(80, 80, 160, 160, true, 0x22FFFFFF, 0x0));
		grid.velocity.set(30, 30);
		grid.alpha = 0.5;
		add(grid);

		// 两栏按屏宽居中 (原 190/670 只对 1280 宽正确)
		var cols:Array<Float> = OnlineLayout.centeredColumns([450, 430], 30);
		colL = cols[0];
		colR = cols[1];
		panelTop = 92;

		// 标题 (避让左上 FPS)
		var title:FlxText = OnlineLayout.makeText(colL, 22, FlxG.width - colL - OnlineLayout.PAD, UIStyle.t('lanTitle', '局域网托管'), 32, 0xFF96FFB4, LEFT);
		add(title);
		var sub:FlxText = OnlineLayout.makeText(colL, 62, FlxG.width - colL - OnlineLayout.PAD, UIStyle.t('lanSubtitle', '本机托管 · 房主退出即关房 · 端口被占自动 +1'), 13, OnlineLayout.C_SUB, LEFT);
		add(sub);

		// 左列: 状态卡 (5 行) + 日志卡, 高度按屏幕钳制
		var statusH:Float = 218;
		var logH:Float = Math.max(180, FlxG.height - panelTop - statusH - 16 - 64);
		var statusPanel:OnlinePanel = new OnlinePanel(colL, panelTop, 450, statusH, 0xFF0B1710, 0.9, 0.7, 0, 0xFF4ECF7E);
		add(statusPanel);
		makeCardLabel(colL + 20, panelTop + 12, UIStyle.t('lanServerStatus', '服务器状态'));
		statusValue = makeCardValue(colL + 136, panelTop + 12, 296, "—", FlxColor.fromRGB(180, 200, 190));
		makeCardLabel(colL + 20, panelTop + 44, UIStyle.t('lanPort', '监听端口'));
		portValue = makeCardValue(colL + 136, panelTop + 44, 296, "—", FlxColor.fromRGB(180, 200, 190));
		makeCardLabel(colL + 20, panelTop + 76, UIStyle.t('lanLocalIp', '本机 IP'));
		ipValue = makeCardValue(colL + 136, panelTop + 76, 296, "", FlxColor.fromRGB(180, 200, 190));
		makeCardLabel(colL + 20, panelTop + 108, UIStyle.t('lanRoomCode', '房间码'));
		roomCodeValue = makeCardValue(colL + 136, panelTop + 108, 296, "—", FlxColor.fromRGB(180, 200, 190));
		makeCardLabel(colL + 20, panelTop + 140, UIStyle.t('lanServerName', '服务器名'));
		var nameValue:FlxText = makeCardValue(colL + 136, panelTop + 140, 296, "", FlxColor.fromRGB(180, 200, 190));
		if (EmbeddedServerRunner.instance != null)
			nameValue.text = EmbeddedServerRunner.instance.config.serverName;

		// ── 左: 日志区 (最近 50 行缓存, 显示最后 ~19 行) ──
		var logY:Float = panelTop + statusH + 16;
		var logPanel:OnlinePanel = new OnlinePanel(colL, logY, 450, logH, 0xFF0B1218, 0.9, 0.62, 0, 0xFF4ECF7E);
		add(logPanel);
		var logTitle:FlxText = OnlineLayout.makeText(colL + 20, logY + 10, 410, UIStyle.t('lanLogs', '服务器日志'), 13, 0xFF96FFB4, LEFT);
		add(logTitle);
		logText = OnlineLayout.makeText(colL + 20, logY + 32, 410, "", 12, 0xFFD2EBDC, LEFT);
		logText.wordWrap = true; // 长日志行换行而不是横向溢出
		add(logText);

		// ── 右: 建房配置卡 ──
		var configH:Float = logY + logH - panelTop;
		var configPanel:OnlinePanel = new OnlinePanel(colR, panelTop, 430, configH, 0xFF0B1218, 0.9, 0.62, 0, 0xFF4ECF7E);
		add(configPanel);
		var configTitle:FlxText = OnlineLayout.makeText(colR + 20, panelTop + 10, 390, UIStyle.t('lanCreateConfig', '建房配置'), 16, 0xFF96FFB4, LEFT);
		add(configTitle);

		card = new CreateRoomCard(colR + 20, panelTop + 36, 390);
		add(card);

		// 主按钮 (卡片+按钮从配置面板底往上排, 命中 ≥40px)
		var btnY:Float = panelTop + configH - OnlineLayout.TOUCH_MIN_H - 10;
		stopButton = new TextButton(colR + 20, btnY + OnlineLayout.TOUCH_MIN_H, UIStyle.t('lanStop', 'STOP (停服并返回)'), onStop, 20);
		stopButton.desc = UIStyle.t('lanStopDesc', '停止内置服务器并返回联机主菜单');
		stopButton.alignment = LEFT;
		stopButton.color = 0xFFFFAA96;
		add(stopButton);
		startButton = new TextButton(colR + 20, btnY, UIStyle.t('lanStartServer', 'START SERVER'), onStart, 24);
		startButton.desc = UIStyle.t('lanStartServerDesc', '启动内置服务器并创建房间');
		startButton.alignment = LEFT;
		startButton.color = 0xFF96FFB4;
		add(startButton);
		OnlineLayout.padTouchAll([startButton, stopButton]);

		// 状态行 (位于面板之下)
		statusText = OnlineLayout.makeText(OnlineLayout.PAD, logY + logH + 12, FlxG.width - OnlineLayout.PAD * 2, "", 14, 0xFFFFDC8C, CENTER);
		add(statusText);

		// 焦点链: START → STOP → 卡片 (输入框在前, 行在后)
		focusables = [startButton, stopButton];
		for (f in card.focusables)
			focusables.push(f);
		startButton.focused = true;

		refreshStatusCard();
		if (initialStatus.length > 0)
			statusText.text = initialStatus;
		if (client.state == online.client.GameClient.ClientState.Failed || (client.socket == null && client.lastError.length > 0))
			statusText.text = client.lastError;
		FlxG.mouse.visible = true;
	}

	function makeCardLabel(x:Float, y:Float, text:String):FlxText
	{
		var t:FlxText = OnlineLayout.makeText(x, y, 106, text, 13, FlxColor.fromRGB(150, 190, 170), RIGHT);
		add(t);
		return t;
	}

	function makeCardValue(x:Float, y:Float, w:Float, text:String, color:Int):FlxText
	{
		var t:FlxText = OnlineLayout.makeText(x, y, w, text, 13, color, LEFT);
		// 值文本按实测宽度截断 (服务器名/IP 拼接可能很长)。
		t.text = OnlineLayout.truncate(t, text, w);
		add(t);
		return t;
	}

	// ── 状态卡 / 日志刷新 ────────────────────────────────

	/** ipconfig 在后台线程跑, 探测完成后静默更新, 不阻塞主线程。 */
	function refreshIpsAsync():Void
	{
		if (ipThreadRunning)
			return;
		ipThreadRunning = true;
		#if android
		// Android 不依赖 ipconfig/sh 子进程: 进程启动在部分 ROM 上会被
		// 拒绝或卡住, 用 Host.localhost() + 127.0.0.1 兜底即可。
		try
		{
			var h:sys.net.Host = new sys.net.Host(sys.net.Host.localhost());
			var local:String = h.toString();
			if (local != null && local.length > 0 && local != "127.0.0.1")
				localIps = [local, "127.0.0.1"];
			else
				localIps = ["127.0.0.1"];
		}
		catch (e:Dynamic)
		{
			localIps = ["127.0.0.1"];
		}
		ipThreadRunning = false;
		#elseif cpp
		sys.thread.Thread.create(function():Void
		{
			try
			{
				var ips:Array<String> = LanUtil.detectAddresses();
				if (ips.length > 0)
					localIps = ips;
			}
			catch (e:Dynamic) {}
			ipThreadRunning = false;
		});
		#else
		try { localIps = LanUtil.detectAddresses(); } catch (e:Dynamic) {}
		ipThreadRunning = false;
		#end
	}

	function refreshStatusCard():Void
	{
		var running:Bool = EmbeddedServerRunner.running;
		var hasRoom:Bool = OnlineSession.active && OnlineSession.roomCode.length > 0;
		var sig:String = (running ? "1" : "0") + "|" + EmbeddedServerRunner.actualPort + "|" + localIps.join(",") + "|" + (hasRoom ? OnlineSession.roomCode : "");
		if (sig == lastStatusSig)
			return;
		lastStatusSig = sig;
		if (statusValue != null)
		{
			statusValue.text = running
				? "● " + UIStyle.t('lanRunning', '运行中')
				: "○ " + UIStyle.t('lanStopped', '已停止');
			statusValue.color = running ? 0xFF6CF09A : 0xFFC8D0CC;
		}
		if (portValue != null)
			portValue.text = EmbeddedServerRunner.actualPort > 0 ? Std.string(EmbeddedServerRunner.actualPort) : "—";
		if (ipValue != null)
			// 网卡多时单行放不下全部 IP, 只显示最优前 2 个, 其余折叠为 +N (LanUtil 已按网关/私有网段排序)。
			ipValue.text = LanUtil.displayText(localIps, 2);
		if (roomCodeValue != null)
		{
			roomCodeValue.text = hasRoom ? OnlineSession.roomCode : UIStyle.t('lanNoRoom', '未建房');
			roomCodeValue.color = hasRoom ? 0xFFFFE38A : 0xFFC8D0CC;
		}
	}

	function refreshLogs():Void
	{
		var lines:Array<String> = EmbeddedServerRunner.lastLogs();
		var show:Array<String> = lines.length > 19 ? lines.slice(lines.length - 19) : lines;
		var sig:String = show.join("\n");
		if (sig == lastLogSig)
			return;
		lastLogSig = sig;
		logText.text = sig.length == 0 ? UIStyle.t('lanNoLogs', '(暂无日志，点击 START SERVER 启动)') : sig;
	}

	// ── 主按钮 ───────────────────────────────────────────

	function onStart():Void
	{
		FlxG.sound.play(Paths.sound('confirmMenu'), 0.7);
		online.shared.OnlineDebug.log("ui", "LAN onStart running=" + EmbeddedServerRunner.running + " state=" + Std.string(client == null ? "null" : Std.string(client.state)));
		// 已有房间 (本机托管建房成功过): 直接回大厅。
		if (OnlineSession.active && OnlineSession.isHost)
		{
			MusicBeatState.switchState(new OnlineRoomState());
			return;
		}
		if (client == null || client.socket == null || client.state != online.client.GameClient.ClientState.Ready)
		{
			// 内置服务器还没启动/握手: 启动并记住请求, 握手完成后自动建房。
			if (!EmbeddedServerRunner.running)
			{
				startedEmbeddedHere = true;
				if (!EmbeddedServerRunner.start(SeiunProtocol.DEFAULT_PORT))
				{
					statusText.text = UIStyle.t('embeddedFailed', '内置服务器启动失败，请检查 2567-2572 端口是否都被占用。');
					online.shared.OnlineDebug.log("ui", "LAN embedded start FAILED");
					return;
				}
				online.shared.OnlineDebug.log("ui", "LAN embedded started port=" + EmbeddedServerRunner.actualPort);
				client.disconnect(true);
				client.connect("ws://127.0.0.1:" + EmbeddedServerRunner.actualPort);
			}
			createRequested = true;
			statusText.text = UIStyle.t('lanStarting', '内置服务器正在启动/握手中，连接成功后自动创建房间...');
			return;
		}
		sendCreatePayload();
	}

	function sendCreatePayload():Void
	{
		if (client == null || client.socket == null || client.state != online.client.GameClient.ClientState.Ready)
			return;
		createRequested = false;
		var payload:Dynamic = card.buildPayload();
		client.send(SeiunProtocol.MSG_ROOM_CREATE, SeiunProtocol.CHANNEL_ROOM, payload);
		statusText.text = UIStyle.t('creatingRoom', '正在创建房间...');
	}

	function onStop():Void
	{
		FlxG.sound.play(Paths.sound('cancelMenu'));
		if (OnlineSession.isHost)
		{
			if (client != null && client.socket != null)
			{
				client.send(SeiunProtocol.MSG_ROOM_LEAVE, SeiunProtocol.CHANNEL_ROOM, {});
				client.flush();
				client.disconnect(false);
			}
		}
		else if (client != null && client.socket != null)
			client.disconnect(true);
		EmbeddedServerRunner.stop();
		OnlineSession.clear();
		MusicBeatState.switchState(new OnlineState());
	}

	function doBack():Void
	{
		onStop();
	}

	// ── 更新 ─────────────────────────────────────────────

	override function update(elapsed:Float)
	{
		super.update(elapsed);
		if (client != null)
		{
			client.update(elapsed);
			if (client.state == online.client.GameClient.ClientState.Failed)
				statusText.text = client.lastError;
		}
		card.updateFocus();

		// IP 列表 30 秒刷新一次 (后台线程跑 ipconfig, 不卡主线程)
		ipRefreshTimer += elapsed;
		if (ipRefreshTimer >= ipRefreshInterval)
		{
			ipRefreshTimer = 0;
			refreshIpsAsync();
		}

		refreshStatusCard();
		refreshLogs();

		var ev = client.pollEvent();
		while (ev != null)
		{
			if (ev.type == SeiunProtocol.MSG_WELCOME)
			{
				ProfileStore.addServerHistory("ws://127.0.0.1:" + EmbeddedServerRunner.actualPort, "本机托管");
				if (createRequested)
					sendCreatePayload();
				else
					statusText.text = UIStyle.t('lanConnectedReady', '已连接到内置服务器，可点击 START SERVER 创建房间');
			}
			else if (ev.type == SeiunProtocol.MSG_ROOM_JOIN_RESULT)
			{
				if (ev.data != null && ev.data.ok == true)
				{
					if (ev.data.room != null)
						OnlineSession.enter(ev.data.room, ev.data.selfId);
					if (ev.data.players != null && Std.isOfType(ev.data.players, Array))
						OnlineSession.players = cast ev.data.players;
					OnlineSession.isHost = true;
					OnlineSession.dedicated = false;
					MusicBeatState.switchState(new OnlineRoomState());
					return;
				}
				else
					statusText.text = ev.data == null ? UIStyle.t('createFailed', '创建失败') : ev.data.message;
			}
			else if (ev.type == SeiunProtocol.MSG_ERROR)
				statusText.text = UIStyle.errText(ev.data == null ? -1 : Reflect.field(ev.data, "code"), ev.data == null ? client.lastError : Reflect.field(ev.data, "message"));
			ev = client.pollEvent();
		}

		var typing:Bool = UIStyle.anyInputFocused();
		var escCancelledFocus:Bool = UIStyle.consumedInputEscape();
		if (!typing)
		{
			if (controls.UI_UP_P && focusables.length > 0)
			{
				setFocus(curFocus, false);
				curFocus = (curFocus - 1 + focusables.length) % focusables.length;
				setFocus(curFocus, true);
				FlxG.sound.play(Paths.sound('scrollMenu'), 0.6);
			}
			else if (controls.UI_DOWN_P && focusables.length > 0)
			{
				setFocus(curFocus, false);
				curFocus = (curFocus + 1) % focusables.length;
				setFocus(curFocus, true);
				FlxG.sound.play(Paths.sound('scrollMenu'), 0.6);
			}
			if (controls.ACCEPT && focusables.length > 0)
			{
				var f:Dynamic = focusables[curFocus];
				FlxG.sound.play(Paths.sound('confirmMenu'), 0.7);
				if (Std.isOfType(f, TextButton))
					cast(f, TextButton).onClick();
				else if (Std.isOfType(f, PsychUIInputText))
					PsychUIInputText.focusOn = cast f;
			}
		}
		// 输入框聚焦时 BACK 必须放行: Backspace 是退格, 不是返回 (ESC 第一次只取消聚焦)。
		if (controls.BACK #if android || FlxG.android.justReleased.BACK #end && !typing && !escCancelledFocus)
			doBack();
	}

	function setFocus(idx:Int, on:Bool):Void
	{
		if (idx < 0 || idx >= focusables.length)
			return;
		var f:Dynamic = focusables[idx];
		if (Std.isOfType(f, TextButton))
			cast(f, TextButton).focused = on;
	}
}
