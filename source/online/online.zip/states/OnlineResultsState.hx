package online.states;

import backend.MusicBeatState;
import ClientPrefs;
import CoolUtil;
import flixel.FlxG;
import flixel.FlxSprite;
import flixel.group.FlxSpriteGroup;
import flixel.text.FlxText;
import flixel.util.FlxColor;
import Highscore;
import online.client.GameClient;
import online.client.OnlineSession;
import online.client.ProfileStore;
import online.shared.OnlineTypes;
import online.shared.SeiunProtocol;
import online.ui.OnlineLayout;
import online.ui.OnlineMenuBg;
import online.ui.OnlinePanel;
import online.ui.OnlinePointer;
import online.ui.TextButton;
import online.ui.UIStyle;
import Paths;
import Replay;
import Song;
import states.LoadingState;
import states.PlayState;

/**
	联机结算页 (PsychOnline 风格): 判定明细 / FC / 分数 / 准确率 / 回放与保存。
	- 背景与主界面一致 (OnlineMenuBg);
	- 排行支持翻页 (每页 8 行), 玩家过多也能完整浏览;
	- 点击排行行选中玩家, "查看回放" 可观看任意玩家的回放
	  (异步模式向服务器拉取; 实时模式只有本局自己的回放);
	- 异步模式会显示等待其他玩家状态。
**/
class OnlineResultsState extends MusicBeatState
{
	static inline var ROWS_PER_PAGE:Int = 8;

	/** 排行行布局 (refreshRanking 用, create 时按屏宽计算)。 */
	var colRx:Float = 620;
	var rowTopY:Float = 100;
	var rowH:Float = 40;

	var score:Dynamic;
	var client:GameClient;
	var infoText:FlxText;
	var waitText:FlxText;
	var rankingText:FlxText;
	var pageText:FlxText;
	var pagePrevBtn:TextButton;
	var pageNextBtn:TextButton;
	/** 选中玩家的判定明细面板 (PsychOnline Scoreboard 式)。 */
	var detailText:FlxText;

	/** 当前排行数据 (实时 GAME_END results / 异步 ranking)。 */
	var ranking:Array<Dynamic> = [];
	/** 选中行下标 (全局索引, 跨页)。 */
	var selectedIndex:Int = -1;
	var curPage:Int = 0;
	var pageRows:Array<FlxText> = [];

	/** 战绩去重: 同一局 (房间+歌曲+本人完成时间) 只记录一次, 重连/重复排行刷新不重复计数。 */
	var recordedKey:String = "";

	public function new(score:Dynamic)
	{
		super();
		this.score = score;
	}

	override function create()
	{
		super.create();
		client = GameClient.instance != null ? GameClient.instance : new GameClient();

		OnlineMenuBg.attach(this, 0.5);

		var title:FlxText = OnlineLayout.makeText(0, 26, FlxG.width, UIStyle.t('resultsTitle', '联机结算'), 30, OnlineLayout.C_TEXT, CENTER);
		add(title);

		// 两栏按屏宽居中 (原 30/620 只对 1280 宽正确), 高按屏高钳制。
		var cols:Array<Float> = OnlineLayout.centeredColumns([560, 630], 30);
		var colL:Float = cols[0];
		var colR:Float = cols[1];
		var panelTop:Float = 64;
		var panelH:Float = Math.min(470, FlxG.height - panelTop - 150);

		// ── 左: 本局成绩明细 ──
		var panel:OnlinePanel = new OnlinePanel(colL, panelTop, 560, panelH);
		add(panel);

		infoText = OnlineLayout.makeText(colL + 20, panelTop + 16, 520, "", 15, OnlineLayout.C_TEXT, LEFT);
		add(infoText);

		waitText = OnlineLayout.makeText(colL + 20, panelTop + panelH - 40, 520, "", 13, OnlineLayout.C_WARN, LEFT);
		add(waitText);

		// ── 右: 排行 (翻页) ──
		var rankPanel:OnlinePanel = new OnlinePanel(colR, panelTop, 630, panelH);
		add(rankPanel);

		var rankTitle:FlxText = OnlineLayout.makeText(colR + 20, panelTop + 10, 590, UIStyle.t('resultsRanking', '本局排行'), 15, 0xFF96C8FF, LEFT);
		add(rankTitle);

		rankingText = OnlineLayout.makeText(colR + 20, panelTop + 36, 590, "", 13, 0xFFC8F0FF, LEFT);
		add(rankingText);

		pageText = OnlineLayout.makeText(colR + 20, panelTop + panelH - 108, 590, "", 13, 0xFFB4C8E6, CENTER);
		add(pageText);
		colRx = colR;
		rowTopY = panelTop + 42;
		// 行高均分: 面板底到分页文字上方 (panelH-118) 之间, 上限 40 (触屏标准), 下限 32。
		var rowsArea:Float = (panelTop + panelH - 118) - rowTopY;
		rowH = Math.max(32, Math.min(40, rowsArea / ROWS_PER_PAGE));

		// PsychOnline 式判定明细面板: 显示当前选中玩家的判定计数/连击/漏键。
		detailText = OnlineLayout.makeText(colR + 20, panelTop + panelH - 84, 590, "", 13, 0xFFFFE1A0, LEFT);
		add(detailText);

		pagePrevBtn = new TextButton(colR + 20, panelTop + panelH - 52, "< " + UIStyle.t('resultsPrevPage', '上一页') + " >", function()
		{
			flipPage(-1);
		}, 16, 200);
		pagePrevBtn.alignment = LEFT;
		add(pagePrevBtn);
		// 右对齐: 按钮右缘 = 面板右缘 - 20 (x 按 200 宽回推, 不再靠屏幕右缘)。
		pageNextBtn = new TextButton(colR + 630 - 20 - 200, panelTop + panelH - 52, "< " + UIStyle.t('resultsNextPage', '下一页') + " >", function()
		{
			flipPage(1);
		}, 16, 200);
		pageNextBtn.alignment = RIGHT;
		add(pageNextBtn);
		OnlineLayout.padTouchAll([pagePrevBtn, pageNextBtn]);

		// ── 底部按钮 (从屏底往上排, 不再从 556 写字号, 720 高下也不会贴底出屏) ──
		var btnY:Float = Math.min(FlxG.height - OnlineLayout.TOUCH_MIN_H - 12, panelTop + panelH + 14);
		if (OnlineSession.isHost && OnlineSession.mode == online.shared.OnlineTypes.OnlineConst.MODE_ASYNC)
		{
			addButton(btnY, UIStyle.t('resultsFinalize', '提前结算'), function()
			{
				if (client != null)
					client.send(SeiunProtocol.MSG_ASYNC_FINALIZE, SeiunProtocol.CHANNEL_ASYNC, {});
			});
			btnY -= OnlineLayout.TOUCH_MIN_H + 2;
		}
		addButton(btnY, UIStyle.t('resultsViewReplay', '查看回放'), viewReplay);
		btnY -= OnlineLayout.TOUCH_MIN_H + 2;
		addButton(btnY, UIStyle.t('resultsSaveReplay', '保存回放'), saveReplay);
		btnY -= OnlineLayout.TOUCH_MIN_H + 2;
		addButton(btnY, UIStyle.t('resultsBackRoom', '返回房间'), function() MusicBeatState.switchState(new OnlineRoomState()));

		consumePendingRealtime();
		refreshScore();
		refreshRanking();
		FlxG.mouse.visible = true;
	}

	/** 把 PlayState 阶段缓存的实时成绩/最终排名合并进结算页。 */
	function consumePendingRealtime():Void
	{
		if (OnlineSession.mode != online.shared.OnlineTypes.OnlineConst.MODE_REALTIME)
			return;
		if (OnlineSession.pendingRealtimeRanking != null && OnlineSession.pendingRealtimeRanking.length > 0)
		{
			ranking = OnlineSession.pendingRealtimeRanking.copy();
			OnlineSession.pendingRealtimeRanking = [];
			recordFromRanking(ranking);
			return;
		}
		if (OnlineSession.pendingRealtimeResults != null)
		{
			for (deviceId in OnlineSession.pendingRealtimeResults.keys())
			{
				var entry:Dynamic = OnlineSession.pendingRealtimeResults.get(deviceId);
				if (entry == null)
					continue;
				var found:Bool = false;
				for (i in 0...ranking.length)
				{
					if (ranking[i] != null && Reflect.field(ranking[i], "deviceId") == deviceId)
					{
						ranking[i] = entry;
						found = true;
						break;
					}
				}
				if (!found)
					ranking.push(entry);
			}
			OnlineSession.pendingRealtimeResults = new Map<String, Dynamic>();
		}
	}

	function addButton(y:Float, label:String, onClick:Void->Void):Void
	{
		var btn:TextButton = new TextButton(0, y, label, onClick, 24);
		btn.centerOnLabel = true;
		add(btn);
		OnlineLayout.padTouch(btn);
	}

	function intField(r:Dynamic, field:String):Int
	{
		var value:Dynamic = Reflect.field(r, field);
		if (value == null)
			return 0;
		var parsed:Float = Std.parseFloat(Std.string(value));
		return Math.isNaN(parsed) ? 0 : Std.int(parsed);
	}

	function floatField(r:Dynamic, field:String):Float
	{
		var value:Dynamic = Reflect.field(r, field);
		if (value == null)
			return 0;
		var parsed:Float = Std.parseFloat(Std.string(value));
		return Math.isNaN(parsed) ? 0 : parsed;
	}

	function fcBadge(r:Dynamic):String
	{
		var marvelous:Int = intField(r, "marvelous");
		var sick:Int = intField(r, "sick");
		var good:Int = intField(r, "good");
		var bad:Int = intField(r, "bad");
		var shit:Int = intField(r, "shit");
		var misses:Int = intField(r, "misses");
		var total:Int = marvelous + sick + good + bad + shit;
		if (total <= 0)
			return "-";
		if (misses <= 0 && shit == 0 && bad == 0 && good == 0)
			return total > 0 && marvelous == total ? "[MFC]" : "[SFC]";
		if (misses <= 0)
			return "[GFC]";
		if (bad + shit == 0)
			return "[FC]";
		return "[Clear]";
	}

	function asyncStateName(state:String):String
	{
		if (state == online.shared.OnlineTypes.OnlineConst.ASYNC_STATE_PLAYING)
			return UIStyle.t('resultsStatePlaying', '正在游玩');
		if (state == online.shared.OnlineTypes.OnlineConst.ASYNC_STATE_FINISHED)
			return UIStyle.t('resultsStateFinished', '已完成');
		if (state == online.shared.OnlineTypes.OnlineConst.ASYNC_STATE_WAITING)
			return UIStyle.t('resultsStateWaiting', '等待中');
		return UIStyle.t('resultsStateNotStarted', '未开始');
	}

	function refreshScore():Void
	{
		if (score == null)
			return;
		var acc:Float = floatField(score, "accuracy");
		var missCount:Int = intField(score, "misses");
		var marvelousCount:Int = intField(score, "marvelous");
		var sickCount:Int = intField(score, "sick");
		var goodCount:Int = intField(score, "good");
		var badCount:Int = intField(score, "bad");
		var shitCount:Int = intField(score, "shit");
		var totalCount:Int = marvelousCount + sickCount + goodCount + badCount + shitCount;
		var fc:String = "-";
		if (totalCount > 0 && missCount <= 0 && shitCount == 0 && badCount == 0 && goodCount == 0)
			fc = totalCount > 0 && marvelousCount == totalCount ? "MFC" : "SFC";
		else if (totalCount > 0 && missCount <= 0)
			fc = "GFC";
		else if (badCount + shitCount == 0)
			fc = "FC";
		var npsValue:Float = floatField(score, "nps");
		var missTimesRaw:Dynamic = Reflect.field(score, "missTimes");
		var wrongLaneRaw:Dynamic = Reflect.field(score, "wrongLaneHits");
		var missTimesText:String = "";
		var wrongLaneText:String = "";
		if (missTimesRaw != null && Std.isOfType(missTimesRaw, Array))
		{
			var missTimes:Array<Dynamic> = cast missTimesRaw;
			if (missTimes.length > 0)
			{
				var sample:Array<Dynamic> = missTimes.slice(0, 8);
				missTimesText = "\n" + UIStyle.t('resultsMissTimes', '漏键时间点: ') + sample.join(", ") + (missTimes.length > 8 ? " ..." : "");
			}
		}
		if (wrongLaneRaw != null && Std.isOfType(wrongLaneRaw, Array))
		{
			var wrongLaneHits:Array<Dynamic> = cast wrongLaneRaw;
			if (wrongLaneHits.length > 0)
			{
				var sample:Array<Dynamic> = wrongLaneHits.slice(0, 8);
				wrongLaneText = "\n" + UIStyle.t('resultsWrongLane', '错键时间点: ') + sample.join(", ") + (wrongLaneHits.length > 8 ? " ..." : "");
			}
		}
		infoText.text = UIStyle.t('resultsScore', '分数: ') + intField(score, "score")
			+ "\n" + UIStyle.t('resultsAccuracy', '准确率: ') + Highscore.floorDecimal(acc * 100, 2) + "%"
			+ "\n" + UIStyle.t('resultsMaxCombo', '最大连击: ') + intField(score, "maxCombo")
			+ "\n" + UIStyle.t('resultsMisses', '漏键: ') + missCount
			+ "\n" + UIStyle.t('resultsJudgements', '判定: ') + "M " + marvelousCount
			+ " / S " + sickCount
			+ " / G " + goodCount
			+ " / B " + badCount
			+ " / Shit " + shitCount
			+ "\n" + UIStyle.t('resultsFcBadge', 'FC 徽章: ') + fc
			+ "\nNPS: " + Highscore.floorDecimal(npsValue, 2)
			+ missTimesText
			+ wrongLaneText;
		if (OnlineSession.mode == online.shared.OnlineTypes.OnlineConst.MODE_ASYNC)
			waitText.text = UIStyle.t('waitingOthers', '正在等待其他玩家结束...');
	}

	// ── 排行 / 翻页 / 选中 ────────────────────────────────

	function setRanking(list:Array<Dynamic>):Void
	{
		ranking = list == null ? [] : list;
		if (selectedIndex >= ranking.length)
			selectedIndex = -1;
		var totalPages:Int = maxPages();
		if (curPage >= totalPages)
			curPage = totalPages > 0 ? totalPages - 1 : 0;
		refreshRanking();
	}

	function maxPages():Int
	{
		return Std.int(Math.max(1, Math.ceil(ranking.length / ROWS_PER_PAGE)));
	}

	function flipPage(delta:Int):Void
	{
		var totalPages:Int = maxPages();
		curPage = (curPage + delta + totalPages) % totalPages;
		FlxG.sound.play(Paths.sound('scrollMenu'), 0.6);
		refreshRanking();
	}

	function refreshRanking():Void
	{
		if (rankingText == null)
			return;
		// 清理旧行
		for (t in pageRows)
		{
			if (t != null)
			{
				remove(t);
				t.destroy();
			}
		}
		pageRows = [];

		var start:Int = curPage * ROWS_PER_PAGE;
		var end:Int = Std.int(Math.min(ranking.length, start + ROWS_PER_PAGE));
		var lines:Array<String> = [];
		for (i in start...end)
		{
			var r = ranking[i];
			if (r == null)
				continue;
			var avatarText:String = r.avatar != null && r.avatar.length > 0 ? "[" + r.avatar + "] " : "";
			var isMe:Bool = Reflect.field(r, "deviceId") != null && Reflect.field(r, "deviceId") == ProfileStore.deviceId;
			var meTag:String = isMe ? " *" : "";
			var line:String = (i + 1) + ". " + avatarText + r.nickname + meTag
				+ "  " + intField(r, "score")
				+ "  " + Highscore.floorDecimal(floatField(r, "accuracy") * 100, 2) + "%"
				+ "  " + fcBadge(r);
			lines.push(line);

			// 每行一个可点击文本 (选中高亮) —— 位置相对右栏, 行高 ≥40 命中。
			var rowText:FlxText = new FlxText(colRx + 20, rowTopY + (i - start) * rowH, 560, line, 14);
			rowText.setFormat(Paths.languageFont(), 14,
				i == selectedIndex ? FlxColor.fromRGB(255, 235, 120) : FlxColor.fromRGB(200, 240, 255),
				LEFT, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
			if (i == selectedIndex)
				rowText.text = "▶ " + line;
			rowText.ID = i;
			add(rowText);
			pageRows.push(rowText);
		}
		rankingText.text = lines.join("\n");
		rankingText.visible = false; // 行文本替代, 隐藏旧的纯文本
		refreshDetailPanel();
		pageText.text = UIStyle.t('resultsPage', '第 {a}/{b} 页 (共 {n} 人) · 点击玩家行查看其回放')
			.replace('{a}', Std.string(curPage + 1))
			.replace('{b}', Std.string(maxPages()))
			.replace('{n}', Std.string(ranking.length));
	}

	function selectRow(index:Int):Void
	{
		if (index < 0 || index >= ranking.length)
			return;
		selectedIndex = index;
		refreshRanking();
		refreshDetailPanel();
		FlxG.sound.play(Paths.sound('scrollMenu'), 0.6);
	}

	/** 刷新判定明细面板: 展示当前选中玩家 (未选中 = 自己) 的判定计数与统计。 */
	function refreshDetailPanel():Void
	{
		if (detailText == null)
			return;
		var r:Dynamic = selectedEntry();
		if (r == null)
		{
			for (entry in ranking)
				if (entry != null && Reflect.field(entry, "deviceId") == ProfileStore.deviceId)
				{
					r = entry;
					break;
				}
		}
		if (r == null)
		{
			detailText.text = "";
			return;
		}
		var judgements:String = "M " + intField(r, "marvelous")
			+ " / S " + intField(r, "sick")
			+ " / G " + intField(r, "good")
			+ " / B " + intField(r, "bad")
			+ " / Sh " + intField(r, "shit");
		detailText.text = UIStyle.t('scoreboardJudgements', '判定明细') + ": " + judgements
			+ "  " + UIStyle.t('scoreboardCombo', '最大连击') + " " + intField(r, "maxCombo")
			+ "  " + UIStyle.t('scoreboardMisses', '漏键') + " " + intField(r, "misses")
			+ "  " + fcBadge(r);
	}

	/** 当前选中的玩家行 (未选中 = 自己)。 */
	function selectedEntry():Dynamic
	{
		if (selectedIndex >= 0 && selectedIndex < ranking.length)
			return ranking[selectedIndex];
		return null;
	}

	// ── 回放 ──────────────────────────────────────────────

	function replayOfEntry(r:Dynamic):String
	{
		if (r == null)
			return "";
		var json:Dynamic = Reflect.field(r, "replayJson");
		return json == null ? "" : Std.string(json);
	}

	function viewReplay():Void
	{
		if (score == null)
			return;
		var entry:Dynamic = selectedEntry();
		var replayJson:String = "";

		if (entry != null)
		{
			replayJson = replayOfEntry(entry);
			var isMe:Bool = Reflect.field(entry, "deviceId") == null
				|| Reflect.field(entry, "deviceId") == ProfileStore.deviceId;
			if (replayJson.length == 0 && !isMe)
			{
				// 其他玩家: 向服务器按需拉取其回放 (异步/实时都支持, 服务器总会应答)。
				if (client != null && client.state == online.client.GameClient.ClientState.Ready)
				{
					client.send(SeiunProtocol.MSG_ASYNC_REPLAY_FETCH, SeiunProtocol.CHANNEL_ASYNC, {
						deviceId: Reflect.field(entry, "deviceId")
					});
					waitText.text = UIStyle.t('resultsFetchingReplay', '正在获取 {name} 的回放...')
						.replace('{name}', Std.string(Reflect.field(entry, "nickname")));
				}
				else
					waitText.text = UIStyle.t('resultsNoReplayOthers', '该玩家没有可查看的回放数据');
				return;
			}
			// 自己: 排行里没有回放时 (实时模式), 回退到本局本地记录的回放。
			if (replayJson.length == 0 && isMe)
				replayJson = Reflect.field(score, "replayJson");
		}
		else
			replayJson = Reflect.field(score, "replayJson");

		if (replayJson == null || replayJson.length == 0)
		{
			waitText.text = UIStyle.t('resultsNoReplay', '本局没有可查看的回放数据');
			return;
		}
		playReplay(replayJson);
	}

	/** 写入临时回放文件并进入回放模式。修正: 之前 Song.loadFromJson 参数顺序颠倒, 会打开谱面文件。 */
	function playReplay(replayJson:String):Void
	{
		#if sys
		try
		{
			if (!sys.FileSystem.exists("replays"))
				sys.FileSystem.createDirectory("replays");
			var path:String = "replays/online_view_" + Date.now().getTime() + ".json";
			// 联机回放文件必须带 stateRecord (判定手感/尾判/联机标识), 否则回放不会还原房间判定设置。
			sys.io.File.saveContent(path, buildReplayFileJson(replayJson));
			Replay.preparedPath = path;
			PlayState.replayMode = true;
			PlayState.seiunOnline = false;
			PlayState.chartingMode = false;
			PlayState.isStoryMode = false;

			var songName:String = OnlineSession.songName;
			var viewDiff:String = OnlineSession.difficulty;
			if (songName == null || songName.length == 0)
				songName = Std.string(Reflect.field(score, "songName"));
			if (viewDiff == null || viewDiff.length == 0)
				viewDiff = "hard";
			if (CoolUtil.difficulties.length < 1)
				CoolUtil.difficulties = CoolUtil.defaultDifficulties.copy();
			var viewDiffIndex:Int = CoolUtil.difficulties.indexOf(viewDiff);
			if (viewDiffIndex < 0)
			{
				CoolUtil.difficulties.push(viewDiff);
				viewDiffIndex = CoolUtil.difficulties.length - 1;
			}
			PlayState.storyDifficulty = viewDiffIndex;
			// 修正: 第一个参数是 "song-difficulty" JSON 文件名, 第二个是歌曲目录。
			PlayState.SONG = Song.loadFromJson(Highscore.formatSong(songName, viewDiffIndex), songName);
			LoadingState.loadAndSwitchState(new PlayState());
		}
		catch (e:Dynamic)
		{
			waitText.text = UIStyle.t('resultsReplayViewFailed', '回放查看失败: ') + Std.string(e);
		}
		#end
	}

	/**
		把联机回放帧数据包装成完整回放文件 JSON:
		- stateRecord 记录房间判定手感 (窗口/预设/Marvelous/尾判开关/尾判窗口倍率) 与联机标识
		  (isOnline/房间码/房间名/模式), 回放端还原后评分与录制时一致;
		- 老格式/无法解析时原样返回 (回放仍能播, 只是不还原判定手感)。
	**/
	function buildReplayFileJson(replayJson:String):String
	{
		if (replayJson == null || replayJson.length == 0)
			return replayJson;
		try
		{
			var parsed:Dynamic = haxe.Json.parse(replayJson);
			var frames:Dynamic = parsed != null ? Reflect.field(parsed, "frameData") : null;
			if (frames == null && parsed != null && Reflect.hasField(parsed, "frames"))
				frames = Reflect.field(parsed, "frames");
			if (frames == null)
				return replayJson;
			// 优先取房间统一设置 (房主改过 / 已退出房间恢复本地值后仍准确)。
			var s:Dynamic = OnlineSession.settings;
			var timings:Array<Int> = [25, 50, 70, 100];
			if (s != null && s.judgementTimings != null && Std.isOfType(s.judgementTimings, Array))
			{
				var rawTimings:Array<Dynamic> = cast s.judgementTimings;
				if (rawTimings.length >= 4)
					timings = [for (v in rawTimings) Std.int(v)];
			}
			var preset:String = (s != null && s.judgementPreset != null) ? Std.string(s.judgementPreset) : "Custom";
			var marvelousOn:Bool = s != null && s.marvelousRatings == true;
			var stateRecord:Dynamic = {
				songName: OnlineSession.songName == null ? "" : Paths.formatToSongPath(OnlineSession.songName),
				difficulty: 0,
				playDate: Date.now().toString(),
				songLength: 0,
				songSpeed: 1,
				playbackRate: 1,
				healthGain: 1,
				healthLoss: 1,
				cpuControlled: false,
				practiceMode: false,
				instakillOnMiss: false,
				songScore: 0,
				ratingPercent: 0,
				ratingFC: "",
				songHits: 0,
				highestCombo: 0,
				songMisses: 0,
				sicks: 0,
				goods: 0,
				bads: 0,
				shits: 0,
				noteTime: [],
				noteMs: [],
				songSpeedType: "multiplicative",
				sickWindow: timings[1],
				goodWindow: timings[2],
				badWindow: timings[3],
				safeFrames: ClientPrefs.data.safeFrames,
				judgementTimings: timings,
				judgementPreset: preset,
				marvelousRatings: marvelousOn,
				marvelousWindow: timings[0],
				ratingOffset: ClientPrefs.data.ratingOffset,
				guitarHeroSustains: ClientPrefs.data.guitarHeroSustains,
				replayVersion: 2,
				mania: PlayState.mania,
				isOnline: true,
				roomCode: OnlineSession.roomCode,
				roomName: OnlineSession.roomName,
				onlineMode: OnlineSession.mode
			};
			return haxe.Json.stringify({stateRecord: stateRecord, frameData: frames});
		}
		catch (e:Dynamic)
		{
			return replayJson;
		}
	}

	function saveReplay():Void
	{
		if (score == null)
			return;
		var entry:Dynamic = selectedEntry();
		var replayJson:String = entry != null ? replayOfEntry(entry) : "";
		if (replayJson.length == 0)
		{
			// 未选中他人或他人无回放: 保存本局自己的回放。
			if (entry == null
				|| Reflect.field(entry, "deviceId") == null
				|| Reflect.field(entry, "deviceId") == ProfileStore.deviceId)
				replayJson = Reflect.field(score, "replayJson");
		}
		if (replayJson == null || replayJson.length == 0)
		{
			waitText.text = UIStyle.t('resultsNoReplaySave', '本局没有可保存的回放数据');
			return;
		}
		#if sys
		try
		{
			// 联机回放独立目录: 与单机回放物理隔离, 文件内带 isOnline 标识。
			if (!sys.FileSystem.exists("replays"))
				sys.FileSystem.createDirectory("replays");
			if (!sys.FileSystem.exists("replays/online"))
				sys.FileSystem.createDirectory("replays/online");
			var name:String = "replays/online/online_" + Date.now().getTime() + ".json";
			sys.io.File.saveContent(name, buildReplayFileJson(replayJson));
			waitText.text = UIStyle.t('resultsReplaySaved', '联机回放已保存: ') + name;
		}
		catch (e:Dynamic)
		{
			waitText.text = UIStyle.t('resultsReplaySaveFailed', '回放保存失败: ') + Std.string(e);
		}
		#end
	}

	// ── 更新 ─────────────────────────────────────────────

	override function update(elapsed:Float)
	{
		super.update(elapsed);
		if (client != null)
		{
			client.update(elapsed);
			if (client.state == online.client.GameClient.ClientState.Failed)
				waitText.text = client.lastError;
		}
		var ev = client.pollEvent();
		while (ev != null)
		{
			switch (ev.type)
			{
				case SeiunProtocol.MSG_ROOM_INFO:
					OnlineSession.applyRoomInfo(ev.data);
				case SeiunProtocol.MSG_ASYNC_STATUS:
					if (ev.data != null && ev.data.players != null)
					{
						var statusLines:Array<String> = [UIStyle.t('waitingOthers', '正在等待其他玩家结束...')];
						var players:Array<Dynamic> = cast ev.data.players;
						for (p in players)
							statusLines.push(p.nickname + " : " + asyncStateName(Std.string(p.state)));
						waitText.text = statusLines.join("\n");
					}
				case SeiunProtocol.MSG_ASYNC_RANKING:
					if (ev.data != null && ev.data.ranking != null)
					{
						setRanking(cast ev.data.ranking);
						if (ev.data.finalized == true)
						{
							waitText.text = UIStyle.t('asyncFinalized', '房主已提前结算，最终排名已锁定。');
							recordFromRanking(ranking);
						}
					}
				case SeiunProtocol.MSG_GAME_RESULT:
					// 实时对局中有人先打完: 先把其成绩插入/更新到当前排行,
					// 等服务器广播 GAME_END 时再替换为完整最终排名。
					if (ev.data != null && OnlineSession.mode == online.shared.OnlineTypes.OnlineConst.MODE_REALTIME)
					{
						var updated:Array<Dynamic> = ranking.copy();
						var deviceId:String = Reflect.field(ev.data, "deviceId");
						var found:Bool = false;
						for (i in 0...updated.length)
						{
							if (updated[i] != null && Reflect.field(updated[i], "deviceId") == deviceId)
							{
								updated[i] = ev.data;
								found = true;
								break;
							}
						}
						if (!found)
							updated.push(ev.data);
						setRanking(updated);
					}
				case SeiunProtocol.MSG_GAME_END:
					if (ev.data != null && ev.data.results != null)
					{
						setRanking(cast ev.data.results);
						recordFromRanking(ranking);
					}
				case SeiunProtocol.MSG_ASYNC_REPLAY:
					if (ev.data != null)
					{
						var replayJson:String = Reflect.field(ev.data, "replayJson");
						if (replayJson != null && replayJson.length > 0)
							playReplay(replayJson);
						else
							waitText.text = UIStyle.t('resultsNoReplayOthers', '该玩家没有可查看的回放数据');
					}
				case SeiunProtocol.MSG_ROOM_ANNOUNCE:
					if (ev.data == null)
						break;
					var noticeText:String = Std.string(ev.data.text);
					if (noticeText.indexOf("房主退出") >= 0 || noticeText.indexOf("房间已关闭") >= 0 || noticeText.indexOf("房主断开") >= 0)
					{
						OnlineSession.clear();
						OnlineSession.recordDisconnect(noticeText);
						if (client != null)
							client.disconnect(true);
						MusicBeatState.switchState(new OnlineState());
						return;
					}
				case SeiunProtocol.MSG_ERROR:
					if (ev.data != null)
					{
						waitText.text = UIStyle.errText(Reflect.field(ev.data, "code"), Reflect.field(ev.data, "message"));
						var msg:String = ev.data.message == null ? "" : Std.string(ev.data.message);
						if (msg.indexOf("移出房间") >= 0 || msg.indexOf("请出服务器") >= 0 || msg.indexOf("封禁") >= 0)
						{
							OnlineSession.clear();
							OnlineSession.recordDisconnect(msg);
							if (client != null)
								client.disconnect(true);
							MusicBeatState.switchState(new OnlineState());
							return;
						}
					}
			}
			ev = client.pollEvent();
		}

		// 点击/触屏排行行 → 选中 (tap 语义 + ≥40px 命中, 旧版鼠标 justPressed 直触发)。
		OnlinePointer.poll();
		for (t in pageRows)
		{
			if (t == null || !t.visible)
				continue;
			if (OnlinePointer.tapped(t.x, t.y, t.width, t.height, OnlineLayout.TOUCH_MIN_H))
			{
				selectRow(Std.int(t.ID));
				break;
			}
		}

		// 键盘翻页 / 选择
		if (controls.UI_LEFT_P)
			flipPage(-1);
		else if (controls.UI_RIGHT_P)
			flipPage(1);
		if (controls.UI_UP_P)
			selectRow(selectedIndex <= 0 ? (ranking.length - 1) : selectedIndex - 1);
		else if (controls.UI_DOWN_P)
			selectRow(Std.int((selectedIndex + 1) % Math.max(1, ranking.length)));

		if (controls.BACK #if android || FlxG.android.justReleased.BACK #end)
		{
			FlxG.sound.play(Paths.sound('cancelMenu'));
			PlayState.replayMode = false;
			MusicBeatState.switchState(new OnlineRoomState());
		}
	}

	/**
		结算排行到达时写入本地战绩 (实时 GAME_END / 异步最终排名)。
		去重: 同一局 (房间码+歌曲+本人 finishedAt) 只记一次, 重连/重复排行刷新不重复计数。
	**/
	function recordFromRanking(list:Array<Dynamic>):Void
	{
		if (list == null || list.length == 0)
			return;
		online.client.ProfileStore.ensureLoaded();
		var myDevice:String = online.client.ProfileStore.deviceId;
		var myIndex:Int = -1;
		for (i in 0...list.length)
		{
			var r = list[i];
			if (r != null && Reflect.field(r, "deviceId") == myDevice)
			{
				myIndex = i;
				break;
			}
		}
		if (myIndex < 0)
			return;
		var r = list[myIndex];
		var finishedAt:Float = Reflect.field(r, "finishedAt") == null ? 0 : Std.parseFloat(Std.string(Reflect.field(r, "finishedAt")));
		var key:String = OnlineSession.roomCode + "|" + OnlineSession.songName + "|" + myIndex + "|" + finishedAt;
		if (key == recordedKey)
			return;
		recordedKey = key;
		var scoreValue:Int = intField(r, "score");
		var acc:Float = floatField(r, "accuracy");
		var misses:Int = intField(r, "misses");
		var bad:Int = intField(r, "bad");
		var shit:Int = intField(r, "shit");
		var total:Int = intField(r, "marvelous") + intField(r, "sick") + intField(r, "good") + bad + shit;
		var fullCombo:Bool = total > 0 && misses <= 0 && bad + shit == 0;
		var isFirst:Bool = myIndex == 0 && scoreValue > 0;
		// 实时模式: 成绩由客户端上报; 异步模式: asyncPlays。
		var realtime:Bool = OnlineSession.mode == online.shared.OnlineTypes.OnlineConst.MODE_REALTIME;
		online.client.ProfileStore.recordGame(realtime, isFirst, isFirst, scoreValue, acc, fullCombo);
		if (waitText != null)
			waitText.text = UIStyle.t('resultsRecorded', '战绩已记录: ') + online.client.ProfileStore.intOf(online.client.ProfileStore.records.plays)
				+ " " + UIStyle.t('resultsPlaysShort', '局') + " · " + online.client.ProfileStore.intOf(online.client.ProfileStore.records.wins)
				+ " " + UIStyle.t('resultsWinsShort', '胜');
	}
}
