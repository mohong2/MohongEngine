package online.script;

import online.client.GameClient;
import online.client.OnlineSession;
import online.client.ProfileStore;
import online.shared.SeiunProtocol;

/**
	联机脚本 API (客户端 Lua / HScript 共用入口)。
	离线构建下这些函数返回空值或 false, 不会破坏现有脚本。
**/
class OnlineAPI
{
	public static function isOnline():Bool
	{
		#if ONLINE_ALLOWED
		return OnlineSession.active;
		#else
		return false;
		#end
	}

	public static function roomCode():String
	{
		#if ONLINE_ALLOWED
		return OnlineSession.roomCode;
		#else
		return "";
		#end
	}

	public static function roomMode():String
	{
		#if ONLINE_ALLOWED
		return OnlineSession.mode;
		#else
		return "";
		#end
	}

	public static function isHost():Bool
	{
		#if ONLINE_ALLOWED
		return OnlineSession.isHost;
		#else
		return false;
		#end
	}

	/** 反作弊已移除: 恒为 false。 */
	public static function anticheat():Bool
	{
		return false;
	}

	public static function players():Array<Dynamic>
	{
		#if ONLINE_ALLOWED
		return OnlineSession.players;
		#else
		return [];
		#end
	}

	public static function song():String
	{
		#if ONLINE_ALLOWED
		return OnlineSession.songName;
		#else
		return "";
		#end
	}

	public static function difficulty():String
	{
		#if ONLINE_ALLOWED
		return OnlineSession.difficulty;
		#else
		return "";
		#end
	}

	public static function deviceId():String
	{
		#if ONLINE_ALLOWED
		ProfileStore.ensureLoaded();
		return ProfileStore.deviceId;
		#else
		return "";
		#end
	}

	public static function sendChat(text:String):Void
	{
		#if ONLINE_ALLOWED
		var client:GameClient = GameClient.instance;
		if (client != null && OnlineSession.active && text != null && text.length > 0)
			client.send(SeiunProtocol.MSG_ROOM_CHAT, SeiunProtocol.CHANNEL_ROOM, {text: text});
		#end
	}
}
