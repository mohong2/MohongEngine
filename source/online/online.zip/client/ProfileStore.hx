package online.client;

import haxe.Json;

/**
	本地联机身份 (局域网 Minecraft 式 profile):
	- 首次启动生成随机设备码 UUID, 保存在存档目录, 不采集硬件序列号/MAC;
	- 昵称/头像只是显示资料, 身份主键始终是设备码;
	- 崩溃补报标记也写在同一目录。
**/
class ProfileStore
{
	public static var deviceId:String = "";
	public static var nickname:String = "Player";
	public static var avatar:String = "bf";
	/** 对局角色皮肤 (空 = 跟随谱面默认角色; 否则为内置角色名)。 */
	public static var skin:String = "";
	/** 结构化皮肤 (PsychOnline 式: 角色 + 模组目录 + 左右后缀)。null = 跟随谱面。 */
	public static var skinData:online.shared.OnlineTypes.OnlineSkinData = null;
	public static var serverAddress:String = "ws://127.0.0.1:2567";
	public static var profileLoaded:Bool = false;

	/** 连接过的服务器历史 (最近使用置顶, 上限 10)。 */
	public static var serverHistory:Array<Dynamic> = [];
	/** 本地战绩: plays/wins/asyncPlays/bestScore/bestAccuracy/fullCombos/mvps/updatedAt。 */
	public static var records:Dynamic = null;

	public static inline var PROFILE_PATH:String = "seiun_online_profile.json";
	public static inline var CRASH_REPORT_PATH:String = "online_crash_report.json";
	public static inline var RECORDS_PATH:String = "online_records.json";

	public static function ensureLoaded():Void
	{
		if (profileLoaded)
			return;
		profileLoaded = true;
		#if sys
		try
		{
			if (sys.FileSystem.exists(PROFILE_PATH))
			{
				var json:Dynamic = Json.parse(sys.io.File.getContent(PROFILE_PATH));
				if (json != null)
				{
					deviceId = Reflect.field(json, "deviceId");
					nickname = Reflect.field(json, "nickname");
					avatar = Reflect.field(json, "avatar");
					if (Reflect.field(json, "skin") != null)
						skin = Reflect.field(json, "skin");
					if (Reflect.field(json, "skinData") != null)
						skinData = online.shared.OnlineTypes.SkinDataUtil.fromDynamic(Reflect.field(json, "skinData"));
					if (Reflect.field(json, "serverAddress") != null)
						serverAddress = Reflect.field(json, "serverAddress");
					if (Reflect.field(json, "serverHistory") != null && Std.isOfType(Reflect.field(json, "serverHistory"), Array))
						serverHistory = cast Reflect.field(json, "serverHistory");
				}
			}
		}
		catch (e:Dynamic) {}
		loadRecords();
		loadAuths();
		#else
		deviceId = generateDeviceId();
		records = defaultRecords();
		#end
		if (records == null)
			records = defaultRecords();
		normalizeHistory();
		normalizeRecords();

		if (deviceId == null || deviceId.length == 0)
		{
			deviceId = generateDeviceId();
			save();
		}
		if (nickname == null || nickname.length == 0)
			nickname = "Player";
		if (avatar == null || avatar.length == 0)
			avatar = "bf";
		if (skin == null)
			skin = "";
		// 旧版 profile 只有 skin 字符串: 迁移成 skinData (无模组目录/后缀)。
		if (skinData == null && skin != null && skin.length > 0)
			skinData = {char: skin, modDir: "", suffixLeft: "", suffixRight: ""};
	}

	static function defaultRecords():Dynamic
	{
		return {
			plays: 0,
			wins: 0,
			asyncPlays: 0,
			bestScore: 0,
			bestAccuracy: 0,
			fullCombos: 0,
			mvps: 0,
			updatedAt: 0
		};
	}

	static function loadRecords():Void
	{
		#if sys
		try
		{
			if (sys.FileSystem.exists(RECORDS_PATH))
			{
				var json:Dynamic = Json.parse(sys.io.File.getContent(RECORDS_PATH));
				if (json != null)
					records = json;
			}
		}
		catch (e:Dynamic) {}
		#end
	}

	static function normalizeHistory():Void
	{
		var out:Array<Dynamic> = [];
		if (serverHistory != null)
		{
			for (h in serverHistory)
			{
				if (h == null)
					continue;
				var address:String = Reflect.field(h, "address");
				if (address == null || address.length == 0)
					continue;
				out.push({
					address: address,
					name: Reflect.field(h, "name") == null ? "" : Std.string(Reflect.field(h, "name")),
					lastUsedAt: Reflect.field(h, "lastUsedAt") == null ? 0 : Std.parseFloat(Std.string(Reflect.field(h, "lastUsedAt")))
				});
			}
		}
		serverHistory = out;
	}

	/**
		归一化战绩对象: 文件损坏/字段缺失时补全默认值。
		防止"个人记录页无数据/脏数据崩溃" (如 records 是数组/标量/缺字段)。
	**/
	static function normalizeRecords():Void
	{
		if (records == null || Type.typeof(records) != TObject)
		{
			records = defaultRecords();
			return;
		}
		var def:Dynamic = defaultRecords();
		for (f in Reflect.fields(def))
		{
			var v:Dynamic = Reflect.field(records, f);
			if (v == null)
				Reflect.setField(records, f, Reflect.field(def, f));
		}
	}

	public static function save():Void
	{
		#if sys
		try
		{
			var obj:Dynamic = {deviceId: deviceId, nickname: nickname, avatar: avatar, skin: skin, skinData: skinData, serverAddress: serverAddress, serverHistory: serverHistory};
			sys.io.File.saveContent(PROFILE_PATH, Json.stringify(obj));
		}
		catch (e:Dynamic) {}
		#end
	}

	// ── 服务器地址历史 ────────────────────────────────────

	/** 连接成功后记录: 去重, 最近使用置顶, 上限 10。 */
	public static function addServerHistory(address:String, serverName:String):Void
	{
		ensureLoaded();
		if (address == null || address.length == 0)
			return;
		var clean:String = address;
		if (clean.indexOf("ws://") == 0)
			clean = clean.substr(5);
		var out:Array<Dynamic> = [];
		out.push({address: clean, name: serverName == null ? '' : serverName, lastUsedAt: Date.now().getTime()});
		for (h in serverHistory)
		{
			var a:String = Reflect.field(h, "address");
			if (a != null && a == clean)
				continue;
			out.push(h);
		}
		serverHistory = out.length > 10 ? out.slice(0, 10) : out;
		save();
	}

	public static function removeServerHistory(address:String):Void
	{
		ensureLoaded();
		var out:Array<Dynamic> = [];
		for (h in serverHistory)
		{
			var a:String = Reflect.field(h, "address");
			if (a != null && a == address)
				continue;
			out.push(h);
		}
		serverHistory = out;
		save();
	}

	// ── 本地战绩 ──────────────────────────────────────────

	/** 从结算页写入一次战绩 (重连/重复排行刷新由调用方用去重标记防重复计数)。 */
	public static function recordGame(realtime:Bool, won:Bool, mvp:Bool, score:Int, accuracy:Float, fullCombo:Bool):Void
	{
		ensureLoaded();
		normalizeRecords();
		if (realtime)
			records.plays = intOf(records.plays) + 1;
		else
			records.asyncPlays = intOf(records.asyncPlays) + 1;
		if (won)
			records.wins = intOf(records.wins) + 1;
		if (mvp)
			records.mvps = intOf(records.mvps) + 1;
		if (score > intOf(records.bestScore))
			records.bestScore = score;
		var acc:Float = Math.isNaN(accuracy) ? 0 : accuracy;
		var bestAcc:Float = floatOf(records.bestAccuracy);
		if (acc > bestAcc)
			records.bestAccuracy = acc;
		if (fullCombo)
			records.fullCombos = intOf(records.fullCombos) + 1;
		records.updatedAt = Date.now().getTime();
		saveRecords();
	}

	public static function saveRecords():Void
	{
		#if sys
		try
		{
			sys.io.File.saveContent(RECORDS_PATH, Json.stringify(records));
		}
		catch (e:Dynamic) {}
		#end
	}

	public static function intOf(v:Dynamic):Int
	{
		if (v == null)
			return 0;
		// 用 parseFloat 而不是 parseInt: JSON 大数 (如 bestScore) 解析为 Float 时
		// Std.string 可能输出科学计数法, parseInt 会失败返回 0。
		var parsed:Float = Std.parseFloat(Std.string(v));
		if (Math.isNaN(parsed))
			return 0;
		return Std.int(parsed);
	}

	public static function floatOf(v:Dynamic):Float
	{
		if (v == null)
			return 0;
		var parsed:Float = Std.parseFloat(Std.string(v));
		return Math.isNaN(parsed) ? 0 : parsed;
	}

	/** 时间戳统一转为毫秒: 兼容旧版本存的秒级数据; 非法/0 返回 0。 */
	public static function timestampMs(v:Dynamic):Float
	{
		if (v == null)
			return 0;
		var parsed:Float = Std.parseFloat(Std.string(v));
		if (Math.isNaN(parsed) || parsed <= 0)
			return 0;
		if (parsed < 1e12)
			parsed *= 1000.0; // 秒 → 毫秒 (1970 修复: 旧数据可能存的是秒)
		return parsed;
	}

	public static function setServerAddress(address:String):Void
	{
		ensureLoaded();
		if (address != null && address.length > 0)
			serverAddress = address;
		save();
	}

	public static function setProfile(newNickname:String, newAvatar:String):Void
	{
		ensureLoaded();
		if (newNickname != null && newNickname.length > 0)
			nickname = newNickname;
		if (newAvatar != null && newAvatar.length > 0)
			avatar = newAvatar;
		save();
	}

	public static function setSkin(newSkin:String):Void
	{
		ensureLoaded();
		if (newSkin != null && newSkin.length > 0)
			skin = newSkin;
		save();
	}

	/** 设置结构化皮肤 (PsychOnline 式); char 为空 = 跟随谱面并清空旧 skin 字符串。 */
	public static function setSkinData(sd:online.shared.OnlineTypes.OnlineSkinData):Void
	{
		ensureLoaded();
		if (sd == null || sd.char == null || sd.char.length == 0)
		{
			skinData = null;
			skin = "";
		}
		else
		{
			skinData = sd;
			skin = sd.char;
		}
		save();
	}

	// ── 专用服务器登录态 (一体化登录: 令牌持久化, 密码永不落盘) ──

	/** 已登录服务器地址 → {user, token, at}。 */
	public static var serverAuths:Map<String, Dynamic> = new Map<String, Dynamic>();
	public static inline var AUTH_PATH:String = "seiun_online_auth.json";

	/** 记住某个服务器的登录令牌 (登录成功后调用)。 */
	public static function rememberAuth(address:String, username:String, token:String):Void
	{
		if (address == null || address.length == 0 || token == null || token.length == 0)
			return;
		serverAuths.set(normalizeAddress(address), {user: username == null ? "" : username, token: token, at: Date.now().getTime()});
		saveAuths();
	}

	/** 取某个服务器的已保存令牌 (没有返回 null)。 */
	public static function tokenFor(address:String):String
	{
		var a:Dynamic = serverAuths.get(normalizeAddress(address));
		return a == null ? null : Std.string(Reflect.field(a, "token"));
	}

	/** 取某个服务器的已保存用户名 (没有返回空)。 */
	public static function userFor(address:String):String
	{
		var a:Dynamic = serverAuths.get(normalizeAddress(address));
		return a == null ? "" : Std.string(Reflect.field(a, "user"));
	}

	/** 登出: 丢弃某个服务器保存的令牌。 */
	public static function forgetAuth(address:String):Void
	{
		serverAuths.remove(normalizeAddress(address));
		saveAuths();
	}

	static function normalizeAddress(address:String):String
	{
		var s:String = address == null ? "" : StringTools.trim(address);
		s = StringTools.replace(s, "ws://", "");
		s = StringTools.replace(s, "wss://", "");
		return s;
	}

	static function loadAuths():Void
	{
		#if sys
		try
		{
			if (sys.FileSystem.exists(AUTH_PATH))
			{
				var raw:Dynamic = Json.parse(sys.io.File.getContent(AUTH_PATH));
				if (raw != null && Std.isOfType(raw, Array))
				{
					for (entry in (cast raw : Array<Dynamic>))
					{
						if (entry == null)
							continue;
						var addr:String = Reflect.field(entry, "address");
						var token:String = Reflect.field(entry, "token");
						if (addr == null || addr.length == 0 || token == null || token.length == 0)
							continue;
						serverAuths.set(normalizeAddress(addr), {
							user: Reflect.field(entry, "user") == null ? "" : Std.string(Reflect.field(entry, "user")),
							token: token,
							at: Reflect.field(entry, "at") == null ? 0 : Std.parseFloat(Std.string(Reflect.field(entry, "at")))
						});
					}
				}
			}
		}
		catch (e:Dynamic) {}
		#end
	}

	static function saveAuths():Void
	{
		#if sys
		try
		{
			var arr:Array<Dynamic> = [];
			for (addr in serverAuths.keys())
			{
				var a:Dynamic = serverAuths.get(addr);
				arr.push({address: addr, user: Reflect.field(a, "user"), token: Reflect.field(a, "token"), at: Reflect.field(a, "at")});
			}
			sys.io.File.saveContent(AUTH_PATH, Json.stringify(arr));
		}
		catch (e:Dynamic) {}
		#end
	}

	/**
		导入本地图片作为自定义头像: 复制到 mods/avatars/<name>, 返回 "file:<name>"。
		限制: 仅 png/jpg/jpeg, ≤1MB。失败返回 null。
	**/
	public static function importAvatarImage(srcPath:String):String
	{
		#if sys
		try
		{
			var lower:String = srcPath.toLowerCase();
			var ext:String = "";
			if (lower.endsWith(".png")) ext = ".png";
			else if (lower.endsWith(".jpg") || lower.endsWith(".jpeg")) ext = ".jpg";
			else return null;

			var size:Int = sys.FileSystem.stat(srcPath).size;
			if (size <= 0 || size > 1024 * 1024)
				return null;

			if (!sys.FileSystem.exists("mods/avatars"))
				sys.FileSystem.createDirectory("mods/avatars");

			ensureLoaded();
			var name:String = "avatar_" + deviceId.substr(0, 8) + ext;
			sys.io.File.copy(srcPath, "mods/avatars/" + name);
			return "file:" + name;
		}
		catch (e:Dynamic) {}
		#end
		return null;
	}

	static function generateDeviceId():String
	{
		var bytes:haxe.io.Bytes = haxe.io.Bytes.alloc(16);
		for (i in 0...bytes.length)
		{
			var b:Int = Std.random(256);
			bytes.set(i, b);
		}
		var hex:String = bytes.toHex();
		// 标准 UUID v4 排版 (随机即可, 不需要硬件信息)
		return hex.substr(0, 8) + "-" + hex.substr(8, 4) + "-4" + hex.substr(12, 3)
			+ "-a" + hex.substr(16, 3)
			+ "-" + hex.substr(19, 12);
	}

	/** 崩溃信号未送达时写标记, 下次进入联机时补报。 */
	public static function writeCrashReport(roomCode:String, song:String, summary:String):Void
	{
		#if sys
		try
		{
			var obj:Dynamic = {
				at: Date.now().getTime(),
				roomCode: roomCode,
				song: song,
				summary: summary
			};
			sys.io.File.saveContent(CRASH_REPORT_PATH, Json.stringify(obj));
		}
		catch (e:Dynamic) {}
		#end
	}

	public static function readCrashReport():Dynamic
	{
		#if sys
		try
		{
			if (!sys.FileSystem.exists(CRASH_REPORT_PATH))
				return null;
			return Json.parse(sys.io.File.getContent(CRASH_REPORT_PATH));
		}
		catch (e:Dynamic) { return null; }
		#else
		return null;
		#end
	}

	public static function clearCrashReport():Void
	{
		#if sys
		try
		{
			if (sys.FileSystem.exists(CRASH_REPORT_PATH))
				sys.FileSystem.deleteFile(CRASH_REPORT_PATH);
		}
		catch (e:Dynamic) {}
		#end
	}
}
