package online.client;

import haxe.crypto.Base64;
import haxe.io.Bytes;
import haxe.io.BytesBuffer;
import haxe.io.BytesInput;
import online.shared.SeiunProtocol;

/**
	自定义头像文件下载。
	服务器把 mods/avatars/<file> 以现有 CHANNEL_FILE 分块格式发给客户端,
	这里负责接收、组装并写回本地 mods/avatars/。
	头像图片缺失时 AvatarSprite 先回退 BF 图标, 下载完成后通过
	consumeRefreshSignal() 让房间 UI 刷新玩家卡, 自定义头像即可远程生效。
**/
class AvatarFileClient
{
	static inline var PREFIX:String = "avatars/";

	static var activePath:String = "";
	static var activeTransferId:Int = -1;
	static var activeChunkCount:Int = 0;
	static var activeReceived:Array<{index:Int, data:Bytes}> = [];
	static var activeFinished:Bool = false;
	static var requested:Map<String, Bool> = new Map<String, Bool>();
	static var refreshSignal:Bool = false;

	public static function request(fileName:String):Void
	{
		if (fileName == null || fileName.length == 0)
			return;
		if (hasFile(fileName) || requested.exists(fileName))
			return;
		var client:GameClient = GameClient.instance;
		if (client == null || client.state != GameClient.ClientState.Ready)
			return;
		requested.set(fileName, true);
		client.send(SeiunProtocol.MSG_AVATAR_REQUEST, SeiunProtocol.CHANNEL_FILE, {
			file: fileName,
			at: Date.now().getTime()
		});
	}

	/** 把本地自定义头像分块上传到服务器, 使专用服务器也能把该头像分发给其他玩家。 */
	public static function upload(fileName:String):Void
	{
		if (fileName == null || fileName.length == 0)
			return;
		#if sys
		var path:String = "mods/avatars/" + fileName;
		if (!sys.FileSystem.exists(path) || sys.FileSystem.isDirectory(path))
			return;
		var bytes:Bytes = null;
		try
		{
			bytes = sys.io.File.getBytes(path);
		}
		catch (e:Dynamic)
		{
			return;
		}
		if (bytes == null || bytes.length <= 0)
			return;
		var client:GameClient = GameClient.instance;
		if (client == null || client.state != GameClient.ClientState.Ready)
			return;
		var chunkBytes:Int = 32000;
		var count:Int = Std.int(Math.ceil(bytes.length / chunkBytes));
		if (count < 1)
			count = 1;
		for (i in 0...count)
		{
			var off:Int = i * chunkBytes;
			var len:Int = Std.int(Math.min(chunkBytes, bytes.length - off));
			var sub:Bytes = bytes.sub(off, len);
			client.send(SeiunProtocol.MSG_PROFILE_UPDATE, SeiunProtocol.CHANNEL_ROOM, {
				avatarUpload: true,
				avatarFile: fileName,
				avatarChunkIndex: i,
				avatarChunkCount: count,
				avatarData: Base64.encode(sub)
			});
		}
		#end
	}

	public static function hasFile(fileName:String):Bool
	{
		if (fileName == null || fileName.length == 0)
			return false;
		#if sys
		return sys.FileSystem.exists("mods/avatars/" + fileName);
		#else
		return false;
		#end
	}

	/** 尝试处理一个 CHANNEL_FILE 分块; 是头像文件则处理并返回 true, 否则 false。 */
	public static function maybeHandleChunk(payload:Bytes):Bool
	{
		if (payload == null || payload.length < 21)
			return false;
		var input:BytesInput = new BytesInput(payload);
		input.bigEndian = true;
		try
		{
			if (input.readByte() != 0x5A)
				return false;
			var transferId:Int = input.readInt32();
			var pathLen:Int = input.readInt32();
			if (pathLen <= 0 || pathLen > 1024 || 21 + pathLen > payload.length)
				return false;
			var path:String = input.read(pathLen).toString();
			if (path == null || path.indexOf(PREFIX) != 0)
				return false;
			var index:Int = input.readInt32();
			var count:Int = input.readInt32();
			var dataLen:Int = input.readInt32();
			var headerLen:Int = 21 + pathLen;
			if (index < 0 || count <= 0 || dataLen <= 0 || 21 + pathLen > payload.length || headerLen + dataLen > payload.length)
				return false;
			var data:Bytes = payload.sub(headerLen, dataLen);
			input.close();

			if (activeFinished)
			{
				// 正在完成后的迟到分块; 忽略。
				return true;
			}
			if (transferId != activeTransferId)
			{
				if (activeReceived.length > 0)
					return true; // 正在收另一个文件, 丢弃
				activeTransferId = transferId;
				activePath = path;
				activeChunkCount = count;
				activeReceived = [];
			}
			else if (path != activePath)
				return true;
			var already:Bool = false;
			for (c in activeReceived)
				if (c.index == index)
				{
					already = true;
					break;
				}
			if (!already)
				activeReceived.push({index: index, data: data});
			if (activeReceived.length >= activeChunkCount)
				finishActiveFile();
			return true;
		}
		catch (e:Dynamic)
		{
			return false;
		}
	}

	static function finishActiveFile():Void
	{
		if (activeFinished)
			return;
		var seen:Map<Int, Bool> = new Map<Int, Bool>();
		var complete:Bool = true;
		var maxIdx:Int = -1;
		var maxLen:Int = 0;
		for (c in activeReceived)
		{
			if (c.index < 0 || c.index >= activeChunkCount || seen.exists(c.index))
			{
				complete = false;
				break;
			}
			seen.set(c.index, true);
			if (c.index > maxIdx)
			{
				maxIdx = c.index;
				maxLen = c.data.length;
			}
		}
		if (!complete)
			return;
		for (i in 0...activeChunkCount)
			if (!seen.exists(i))
			{
				complete = false;
				break;
			}
		if (!complete)
			return;
		var buf:BytesBuffer = new BytesBuffer();
		var sorted:Array<{index:Int, data:Bytes}> = activeReceived.copy();
		sorted.sort(function(a, b):Int return a.index - b.index);
		for (c in sorted)
			buf.add(c.data);
		var fileBytes:Bytes = buf.getBytes();
		var fileName:String = activePath.substr(PREFIX.length);
		#if sys
		try
		{
			if (!sys.FileSystem.exists("mods/avatars"))
				sys.FileSystem.createDirectory("mods/avatars");
			if (fileBytes.length > 0)
			{
				sys.io.File.saveBytes("mods/avatars/" + fileName, fileBytes);
				refreshSignal = true;
			}
		}
		catch (e:Dynamic) {}
		#end
		activeFinished = true;
		resetState();
	}

	public static function consumeRefreshSignal():Bool
	{
		var v:Bool = refreshSignal;
		refreshSignal = false;
		return v;
	}

	static function resetState():Void
	{
		activePath = "";
		activeTransferId = -1;
		activeChunkCount = 0;
		activeReceived = [];
		activeFinished = false;
	}
}
