package online.client;

import online.shared.OnlineTypes.OnlineSkinData;

/**
	PsychOnline 式皮肤解析与应用 (SeiunEngine 0.6.3 基座适配):
	- 角色存在性检查: mods/<modDir>/characters/<name>.json → preload 同路径;
	- 降级链: char+舞台后缀+侧向后缀 → char+舞台后缀 → char+侧向后缀 → char (再找不到 = 跟随谱面);
	- 舞台后缀沿用 0.6.3 约定 (school → -pixel, mall → -christmas, limo → -car);
	- 创建失败一律回退谱面原角色, 绝不让联机皮肤导致崩溃。
**/
class OnlineSkinUtil
{
	/** 检查角色 JSON 是否存在 (先指定模组目录, 再根模组, 再 preload)。 */
	public static function characterExists(name:String, ?modDir:String):Bool
	{
		if (name == null || name.length == 0)
			return false;
		var found:Bool = false;
		#if MODS_ALLOWED
		var oldDir:String = backend.Mods.currentModDirectory;
		if (modDir != null && modDir.length > 0 && backend.Mods.getModDirectories().contains(modDir))
			backend.Mods.currentModDirectory = modDir;
		try
		{
			var path:String = Paths.modFolders('characters/' + name + '.json');
			if (!sys.FileSystem.exists(path))
				path = Paths.getPreloadPath('characters/' + name + '.json');
			found = sys.FileSystem.exists(path);
		}
		catch (e:Dynamic) {}
		backend.Mods.currentModDirectory = oldDir;
		#else
		try
		{
			found = openfl.Assets.exists(Paths.getPreloadPath('characters/' + name + '.json'));
		}
		catch (e:Dynamic) {}
		#end
		return found;
	}

	/** 当前舞台对应的角色变体后缀 (0.6.3 约定)。 */
	public static function stageSuffix(stage:String):String
	{
		if (stage == null)
			return "";
		return switch (stage)
		{
			case 'school' | 'schoolEvil': '-pixel';
			case 'mall' | 'mallEvil': '-christmas';
			case 'limo': '-car';
			default: '';
		}
	}

	/**
		解析皮肤降级链: 返回第一个实际存在的角色名; 全部缺失返回 null (= 跟随谱面)。
		@param sd 皮肤数据 (null/char 空 → null)
		@param isRightSide 玩家是否在右侧 (BF 侧): 决定用 suffixRight 还是 suffixLeft
	**/
	public static function resolveSkin(sd:OnlineSkinData, isRightSide:Bool, ?stage:String):String
	{
		if (sd == null || sd.char == null || sd.char.length == 0)
			return null;
		var side:String = isRightSide ? (sd.suffixRight == null ? "" : sd.suffixRight) : (sd.suffixLeft == null ? "" : sd.suffixLeft);
		var stageSfx:String = stageSuffix(stage);
		var candidates:Array<String> = [];
		if (stageSfx.length > 0 && side.length > 0)
			candidates.push(sd.char + stageSfx + side);
		if (stageSfx.length > 0)
			candidates.push(sd.char + stageSfx);
		if (side.length > 0)
			candidates.push(sd.char + side);
		candidates.push(sd.char);
		// 先在皮肤的模组目录里找, 找不到再在根模组里找 (同 PsychOnline skinURL 语义)。
		var dirs:Array<String> = [];
		if (sd.modDir != null && sd.modDir.length > 0)
			dirs.push(sd.modDir);
		dirs.push("");
		for (dir in dirs)
			for (candidate in candidates)
				if (characterExists(candidate, dir))
					return candidate;
		return null;
	}

	/** 皮肤实际生效时使用的模组目录 (角色在其模组目录中存在则返回该目录, 否则空)。 */
	public static function resolveModDir(sd:OnlineSkinData, isRightSide:Bool, ?stage:String):String
	{
		if (sd == null || sd.char == null || sd.char.length == 0)
			return "";
		var side:String = isRightSide ? (sd.suffixRight == null ? "" : sd.suffixRight) : (sd.suffixLeft == null ? "" : sd.suffixLeft);
		var stageSfx:String = stageSuffix(stage);
		var candidates:Array<String> = [];
		if (stageSfx.length > 0 && side.length > 0)
			candidates.push(sd.char + stageSfx + side);
		if (stageSfx.length > 0)
			candidates.push(sd.char + stageSfx);
		if (side.length > 0)
			candidates.push(sd.char + side);
		candidates.push(sd.char);
		if (sd.modDir != null && sd.modDir.length > 0)
		{
			for (candidate in candidates)
				if (characterExists(candidate, sd.modDir))
					return sd.modDir;
		}
		for (candidate in candidates)
			if (characterExists(candidate, ""))
				return "";
		return "";
	}

	/** 该玩家是否启用自定义皮肤 (有效 skinData 且解析出了实际角色)。 */
	public static function effectiveSkin(sd:OnlineSkinData, isRightSide:Bool, ?stage:String):String
	{
		return resolveSkin(sd, isRightSide, stage);
	}
}
