package online.client;

/**
	联机崩溃信号 (尽力而为):
	- 若连接仍可用, 非阻塞发送错误摘要 + 房间码 + 歌曲进度;
	- 发送失败绝不阻塞崩溃恢复, 只写 online_crash_report.json 待下次补报。
**/
class CrashReporter
{
	public static var lastAttemptSucceeded:Bool = false;
	public static var lastAttemptMade:Bool = false;

	public static function notifyCrash(summary:String, stackFirstLines:String):Void
	{
		lastAttemptMade = true;
		lastAttemptSucceeded = false;
		if (!OnlineSession.active)
			return;

		var room:String = OnlineSession.roomCode;
		var song:String = OnlineSession.songName + " " + OnlineSession.difficulty;
		var message:String = summary == null ? "unknown error" : summary;
		if (message.length > 180)
			message = message.substr(0, 180);

		var client:GameClient = GameClient.instance;
		if (client != null && client.socket != null)
		{
			try
			{
				if (client.sendCrashSignal(room, song, message))
				{
					lastAttemptSucceeded = true;
					client.disconnect(false);
					return;
				}
			}
			catch (e:Dynamic) {}
		}

		ProfileStore.writeCrashReport(room, song, message);
	}

	public static function reportPending():Void
	{
		var report:Dynamic = ProfileStore.readCrashReport();
		if (report == null)
			return;
		var client:GameClient = GameClient.instance;
		if (client == null || client.socket == null || client.state != online.client.GameClient.ClientState.Ready)
			return;
		try
		{
			if (client.sendCrashSignal(Reflect.field(report, "roomCode"), Reflect.field(report, "song"), Reflect.field(report, "summary")))
				ProfileStore.clearCrashReport();
		}
		catch (e:Dynamic) {}
	}
}
