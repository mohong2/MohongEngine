package online.client;

import StringTools;
import haxe.io.Bytes;
import haxe.io.BytesInput;
import haxe.io.Path;
import online.shared.OnlineTypes.ChartSelection;
import online.shared.OnlineTypes.ModFileInfo;
import online.shared.OnlineTypes.ModManifest;
import online.shared.SeiunHash;
import online.shared.SeiunProtocol;
import Paths;
import Song.SwagSong;

/**
	模组/谱面同步客户端工具。
	- 递归生成文件清单 (路径 + 大小 + SHA-256);
	- 与房主清单比对出缺失/不同文件;
	- 接收方按 256 KiB 分块落盘并整文件校验。
	传输过程由 OnlineRoomState/OnlineState 显示进度, 不卡对局主循环。
**/
class ModSyncClient
{
	#if sys
	/** 选歌范围清单总文件数上限, 防止异常目录把消息/传输队列撑爆。 */
	static inline var MAX_MANIFEST_FILES:Int = 2048;

	static function collect(root:String, relative:String, out:Array<ModFileInfo>, depth:Int, ?maxFiles:Int = 512,
			?seen:Map<String, Bool> = null):Void
	{
		if (depth > 12 || out.length >= maxFiles || out.length >= MAX_MANIFEST_FILES)
			return;
		var dir:String = relative.length == 0 ? root : root + "/" + relative;
		if (!sys.FileSystem.isDirectory(dir))
			return;
		for (name in sys.FileSystem.readDirectory(dir))
		{
			if (out.length >= maxFiles)
				return;
			if (name == "." || name == "..")
				continue;
			var full:String = dir + "/" + name;
			var rel:String = relative.length == 0 ? name : relative + "/" + name;
			if (seen != null && seen.exists(rel))
				continue;
			if (sys.FileSystem.isDirectory(full))
			{
				collect(root, rel, out, depth + 1, maxFiles, seen);
				continue;
			}
			var size:Int = SeiunHash.fileSize(full);
			if (size <= 0 || size > 64 * 1024 * 1024)
				continue;
			var sha:String = SeiunHash.ofFile(full);
			if (sha == null || sha.length == 0)
				continue;
			if (seen != null)
				seen.set(rel, true);
			out.push({path: rel, size: size, sha256: sha});
		}
	}

	public static function diff(local:ModManifest, remote:ModManifest):Array<String>
	{
		var out:Array<String> = [];
		var remoteMap:Map<String, ModFileInfo> = new Map<String, ModFileInfo>();
		for (f in remote.mods)
			remoteMap.set(f.path, f);
		for (f in local.mods)
		{
			var r:ModFileInfo = remoteMap.get(f.path);
			if (r == null || r.sha256 != f.sha256)
				out.push(f.path);
		}
		for (f in remote.mods)
			if (localIndex(local, f.path) < 0)
				out.push(f.path);
		return out;
	}

	static function localIndex(local:ModManifest, path:String):Int
	{
		for (i in 0...local.mods.length)
			if (local.mods[i].path == path)
				return i;
		return -1;
	}

	public static function writeReceivedFile(baseDir:String, relative:String, chunks:Array<{offset:Int, data:haxe.io.Bytes}>, expectedSha:String, expectedSize:Int = -1):Bool
	{
		try
		{
			if (relative == null || chunks == null || chunks.length == 0)
				return false;
			var safePath:String = StringTools.replace(relative, "\\", "/");
			if (safePath.indexOf("..") >= 0)
				return false;
			if (safePath.length == 0 || safePath.substr(0, 1) == "/" || safePath.indexOf(":") >= 0)
				return false;
			var full:String = baseDir + "/" + safePath;
			var dir:String = haxe.io.Path.directory(full);
			if (!sys.FileSystem.exists(dir))
				createDirs(dir);
			var out:sys.io.FileOutput = sys.io.File.write(full, true);
			chunks.sort(function(a, b):Int { return a.offset < b.offset ? -1 : (a.offset > b.offset ? 1 : 0); });
			var written:Int = 0;
			for (c in chunks)
			{
				out.writeBytes(c.data, 0, c.data.length);
				written += c.data.length;
			}
			out.close();
			if (expectedSize > 0 && written != expectedSize)
			{
				try { if (sys.FileSystem.exists(full)) sys.FileSystem.deleteFile(full); } catch (e2:Dynamic) {}
				return false;
			}
			var ok:Bool = SeiunHash.ofFile(full) == expectedSha;
			if (!ok)
			{
				try { if (sys.FileSystem.exists(full)) sys.FileSystem.deleteFile(full); } catch (e2:Dynamic) {}
			}
			return ok;
		}
		catch (e:Dynamic)
		{
			return false;
		}
	}

	static function createDirs(dir:String):Void
	{
		if (dir == null || dir.length == 0 || sys.FileSystem.exists(dir))
			return;
		var parent:String = haxe.io.Path.directory(dir);
		if (parent != dir && parent.length > 0)
			createDirs(parent);
		try { sys.FileSystem.createDirectory(dir); } catch (e:Dynamic) {}
	}

	// ── 接收侧状态 (LAN 快速互传) ──────────────────────────
	public static var syncActive(default, null):Bool = false;
	public static var manifestResultReceived(default, null):Bool = false;
	public static var totalFiles(default, null):Int = 0;
	public static var completedFiles(default, null):Int = 0;
	public static var failedFiles(default, null):Int = 0;
	public static var unavailableFiles(default, null):Int = 0;
	public static var currentFileName(default, null):String = "";
	public static var lastSyncMessage(default, null):String = "";
	public static var lastSyncError(default, null):String = "";
	/** 一轮选歌范围同步结束 (成功/无缺失) 后置为 true, 大厅应重算谱面哈希。 */
	public static var revalidateRequested(default, null):Bool = false;

	static var pendingFiles:Array<Dynamic> = [];
	static var pendingIndex:Int = 0;
	static var activePath:String = "";
	static var activeSha:String = "";
	static var activeRetries:Int = 0;
	static var activeTransferId:Int = -1;
	static var activeChunkCount:Int = 0;
	static var activeReceived:Array<Dynamic> = [];
	static var activeFinished:Bool = false;
	/** 当前文件传输最近一次收到分块/发出请求的时间戳 (停滞超时用)。 */
	static var activeLastActivityAt:Float = 0;
	/** 单个文件传输停滞多少毫秒后重试/跳过。 */
	public static inline var STALL_TIMEOUT_MS:Int = 10000;

	// 异步清单构建: 选歌后只扫描当前歌曲范围, 但在模组/资源很多的设备上
	// 哈希仍然可能耗时, 放到后台线程避免建房/换歌时主线程未响应。
	// 每次换歌/换房都会 generation+1; 旧线程的过期结果直接丢弃, 绝不把
	// 上一首歌的清单发到当前房间。
	static var pendingManifestChart:ChartSelection = null;
	static var pendingManifestContext:String = "";
	static var pendingManifestGeneration:Int = 0;
	static var pendingManifestResult:ModManifest = null;
	static var pendingManifestResultChart:ChartSelection = null;
	static var pendingManifestResultGeneration:Int = -1;
	static var pendingManifestResultContext:String = "";
	static var manifestThreadRunning:Bool = false;
	static var manifestQueued:Bool = false;

	/**
		异步请求发送"当前选歌"范围内的本地模组清单。
		- 未选歌时只发空清单, 房间可立即进入;
		- 选歌后只扫描 `mods/data/<song>`、`mods/songs/<song>` 以及该谱面
		  直接引用的 stage/character 文件, 绝不全量遍历 mods/。
		- 哈希/扫描放到后台线程, 避免模组很多的设备在建房/换歌时卡死。
	**/
	/**
		@param context 房间+选歌签名, 用于丢弃跨房间/跨选歌的过期线程结果。
	**/
	public static function requestSendLocalManifest(client:GameClient, ?chart:ChartSelection, context:String = ""):Void
	{
		if (client == null || client.state != online.client.GameClient.ClientState.Ready)
			return;
		pendingManifestGeneration++;
		pendingManifestContext = context == null ? "" : context;
		if (chart == null)
		{
			// 未选歌: 空清单本来就是 O(1), 直接同步发送, 房间可立即进入。
			pendingManifestChart = null;
			sendLocalManifest(client, null);
			return;
		}
		// 新清单尚未发出前, 先阻止旧清单状态误放行开局。
		manifestResultReceived = false;
		revalidateRequested = false;
		pendingManifestChart = chart;
		manifestQueued = true;
		if (!manifestThreadRunning)
			startManifestThread();
	}

	/** 每帧由大厅调用: 后台清单构建完成后自动发送。 */
	public static function updatePendingManifest(client:GameClient):Void
	{
		if (client == null || client.state != online.client.GameClient.ClientState.Ready)
			return;
		if (!manifestThreadRunning && manifestQueued)
			startManifestThread();
		// 丢弃过期结果 (例如离开房间/换歌后旧线程才完成)。
		if (pendingManifestResult != null
			&& (pendingManifestResultGeneration != pendingManifestGeneration
				|| pendingManifestResultContext != pendingManifestContext
				|| pendingManifestResultChart != pendingManifestChart))
		{
			pendingManifestResult = null;
			pendingManifestResultChart = null;
			pendingManifestResultGeneration = -1;
			pendingManifestResultContext = "";
		}
		if (pendingManifestResult != null
			&& pendingManifestResultGeneration == pendingManifestGeneration
			&& pendingManifestResultChart == pendingManifestChart)
		{
			var manifest:ModManifest = pendingManifestResult;
			pendingManifestResult = null;
			pendingManifestResultChart = null;
			pendingManifestResultGeneration = -1;
			pendingManifestResultContext = "";
			pendingManifestChart = null;
			manifestQueued = false;
			sendManifestNow(client, manifest);
		}
	}

	static function startManifestThread():Void
	{
		manifestThreadRunning = true;
		manifestQueued = false;
		var chart:ChartSelection = pendingManifestChart;
		var generation:Int = pendingManifestGeneration;
		var context:String = pendingManifestContext;
		#if (cpp || android)
		sys.thread.Thread.create(function():Void
		{
			var manifest:ModManifest = emptyManifest();
			try
			{
				manifest = buildChartManifest(chart);
			}
			catch (e:Dynamic)
			{
				lastSyncError = online.shared.OnlineStrings.get('online.modSyncManifestFail', '读取本地模组清单失败: ') + Std.string(e);
			}
			// 只有仍属于当前请求的结果才允许发布; 换歌/换房后的旧结果作废。
			if (generation == pendingManifestGeneration && context == pendingManifestContext)
			{
				pendingManifestResult = manifest;
				pendingManifestResultChart = chart;
				pendingManifestResultGeneration = generation;
				pendingManifestResultContext = context;
			}
			manifestThreadRunning = false;
		});
		#else
		var manifest:ModManifest = emptyManifest();
		try
		{
			manifest = buildChartManifest(chart);
		}
		catch (e:Dynamic)
		{
			lastSyncError = online.shared.OnlineStrings.get('online.modSyncManifestFail', '读取本地模组清单失败: ') + Std.string(e);
		}
		if (generation == pendingManifestGeneration && context == pendingManifestContext)
		{
			pendingManifestResult = manifest;
			pendingManifestResultChart = chart;
			pendingManifestResultGeneration = generation;
			pendingManifestResultContext = context;
		}
		manifestThreadRunning = false;
		#end
	}

	/** 同步发送入口 (空清单/非后台目标/旧调用直接使用)。 */
	public static function sendLocalManifest(client:GameClient, ?chart:ChartSelection):Void
	{
		if (client == null || client.state != online.client.GameClient.ClientState.Ready)
			return;
		var manifest:ModManifest = {mods: [], generatedAt: Date.now().getTime()};
		try
		{
			manifest = (chart == null) ? emptyManifest() : buildChartManifest(chart);
		}
		catch (e:Dynamic)
		{
			lastSyncError = online.shared.OnlineStrings.get('online.modSyncManifestFail', '读取本地模组清单失败: ') + Std.string(e);
		}
		sendManifestNow(client, manifest);
	}

	static function sendManifestNow(client:GameClient, manifest:ModManifest):Void
	{
		if (client == null || client.state != online.client.GameClient.ClientState.Ready)
			return;
		// 换歌/初次进房时作废旧传输, 服务器会为每个新清单重新计算差异。
		resetTransferState();
		pendingFiles = [];
		pendingIndex = 0;
		syncActive = false;
		totalFiles = 0;
		completedFiles = 0;
		failedFiles = 0;
		unavailableFiles = 0;
		currentFileName = "";
		lastSyncError = "";
		manifestResultReceived = false;
		revalidateRequested = false;

		client.send(SeiunProtocol.MSG_MOD_MANIFEST, SeiunProtocol.CHANNEL_FILE, manifest);
		lastSyncMessage = online.shared.OnlineStrings.get('online.modSyncSubmitted', '已提交当前歌曲模组清单: ') + manifest.mods.length + online.shared.OnlineStrings.get('online.modSyncFiles', ' 个文件');
	}

	static function emptyManifest():ModManifest
	{
		return {mods: [], generatedAt: Date.now().getTime()};
	}

	/**
		构建选歌范围的清单。所有 path 都相对于 mods/ (服务器以 mods/ 或
		serverModsDir 为根解析), 只包含当前谱面实际读取的 `data/<songPath>`、
		`songs/<songPath>` 和谱面直接引用的 stage/character 资源。
		谱面位于 `mods/<mod>/data` 时会把 `<mod>/` 前缀带进清单, 绝不回退到
		全量扫描所有 mods。
	**/
	public static function buildChartManifest(chart:ChartSelection):ModManifest
	{
		var manifest:ModManifest = {
			mods: [],
			generatedAt: Date.now().getTime(),
			chartHash: chart == null ? "" : chart.chartHash,
			chartSource: chart == null ? "" : chart.chartSource
		};
		if (chart == null || chart.songName == null || chart.difficulty == null)
			return manifest;

		var songPath:String = Paths.formatToSongPath(chart.songName);
		var seen:Map<String, Bool> = new Map<String, Bool>();
		var prefixes:Array<String> = modPrefixCandidates(chart.modFolder);

		// 谱面数据 + 歌曲音频: 覆盖所有 modFolders 可能命中的位置
		// (当前 mod → 全局 mod → mods 根), 每处只扫描该歌曲的子目录。
		for (prefix in prefixes)
		{
			collectModDir(prefix, "data/" + songPath, manifest.mods, 512, seen);
			collectModDir(prefix, "songs/" + songPath, manifest.mods, 512, seen);
			if (manifest.mods.length >= 2048)
				break;
		}

		// 谱面直接引用的舞台/角色文件也纳入同步, 避免"谱面一致但声库/舞台
		// 不一致"导致的联机表现差异。
		try
		{
			var loaded:Dynamic = loadChartMeta(chart.songName, chart.difficulty, chart.modFolder);
			if (loaded != null)
			{
				var stageName:String = Reflect.field(loaded, "stage");
				if (stageName != null && stageName.length > 0)
				{
					var stagePath:String = "stages/" + Paths.formatToSongPath(stageName);
					for (prefix in prefixes)
					{
						addScopedFile(prefix, stagePath + ".json", manifest.mods, seen);
						collectModDir(prefix, stagePath, manifest.mods, 128, seen);
					}
				}
				var chars:Array<String> = [
					Reflect.field(loaded, "player1"),
					Reflect.field(loaded, "player2"),
					Reflect.field(loaded, "gfVersion")
				];
				for (charName in chars)
				{
					if (charName == null || charName.length == 0)
						continue;
					var charPath:String = Paths.formatToSongPath(charName);
					for (prefix in prefixes)
					{
						addScopedFile(prefix, "characters/" + charPath + ".json", manifest.mods, seen);
						addScopedFile(prefix, "images/characters/" + charPath + ".png", manifest.mods, seen);
						addScopedFile(prefix, "images/characters/" + charPath + ".xml", manifest.mods, seen);
						collectModDir(prefix, "images/characters/" + charPath, manifest.mods, 128, seen);
					}
				}
			}
		}
		catch (e:Dynamic) {}

		return manifest;
	}

	/** Paths.modFolders 的查找顺序: 选歌自带 mod → 当前 mod → 全局 mod → mods 根。 */
	static function modPrefixCandidates(?extraMod:String = ""):Array<String>
	{
		var out:Array<String> = [];
		if (extraMod != null && extraMod.length > 0 && !out.contains(extraMod))
			out.push(extraMod);
		#if MODS_ALLOWED
		if (Paths.currentModDirectory != null && Paths.currentModDirectory.length > 0
			&& !out.contains(Paths.currentModDirectory))
			out.push(Paths.currentModDirectory);
		var globals:Array<String> = Paths.getGlobalMods();
		if (globals != null)
			for (mod in globals.copy())
				if (mod != null && mod.length > 0 && !out.contains(mod))
					out.push(mod);
		#end
		out.push("");
		return out;
	}

	static function collectModDir(prefix:String, relative:String, out:Array<ModFileInfo>, maxFiles:Int, seen:Map<String, Bool>):Void
	{
		if (out.length >= 2048)
			return;
		var rel:String = prefix.length > 0 ? prefix + "/" + relative : relative;
		collect("mods", rel, out, 0, maxFiles, seen);
	}

	/**
		后台线程安全地读取谱面 JSON 元数据 (stage/player1/player2/gfVersion)。
		不经过 OpenFL/Song.loadFromJson, 避免在工作线程触碰 asset cache。
		查找顺序与 Paths.modFolders 一致, 也兼容 assets 内置谱面。
	**/
	static function loadChartMeta(songName:String, diffName:String, ?modFolder:String):Dynamic
	{
		#if sys
		try
		{
			var songPath:String = Paths.formatToSongPath(songName);
			var fileBase:String = OnlineChartUtil.diffFileBase(songPath, diffName);
			for (prefix in modPrefixCandidates(modFolder))
			{
				var c:String = "mods/" + (prefix.length > 0 ? prefix + "/" : "") + "data/" + songPath + "/" + fileBase + ".json";
				if (sys.FileSystem.exists(c) && !sys.FileSystem.isDirectory(c))
					return haxe.Json.parse(sys.io.File.getContent(c));
			}
			var assetCandidates:Array<String> = [
				"assets/preload/data/" + songPath + "/" + fileBase + ".json",
				"assets/data/" + songPath + "/" + fileBase + ".json"
			];
			for (c in assetCandidates)
			{
				if (sys.FileSystem.exists(c) && !sys.FileSystem.isDirectory(c))
					return haxe.Json.parse(sys.io.File.getContent(c));
			}
		}
		catch (e:Dynamic) {}
		#end
		return null;
	}

	static function addScopedFile(prefix:String, relative:String, out:Array<ModFileInfo>, seen:Map<String, Bool>):Void
	{
		if (relative == null || relative.length == 0 || out.length >= 2048)
			return;
		var rel:String = prefix.length > 0 ? prefix + "/" + relative : relative;
		if (seen.exists(rel))
			return;
		var full:String = "mods/" + rel;
		if (!sys.FileSystem.exists(full) || sys.FileSystem.isDirectory(full))
			return;
		var size:Int = SeiunHash.fileSize(full);
		if (size <= 0 || size > 64 * 1024 * 1024)
			return;
		var sha:String = SeiunHash.ofFile(full);
		if (sha == null || sha.length == 0)
			return;
		seen.set(rel, true);
		out.push({path: rel, size: size, sha256: sha});
	}

	/** 处理服务器回传的差异清单, 开始逐个请求缺失文件。 */
	public static function onManifestResult(data:Dynamic, client:GameClient):Void
	{
		resetTransferState();
		if (data == null || data.files == null || !Std.isOfType(data.files, Array))
			return;
		// 服务器判定为过期清单 (上一首歌/上一房间): 不更新任何同步状态,
		// 大厅随后会用当前选歌重新请求清单, 绝不能让旧结果放行开局。
		if (Reflect.field(data, "stale") == true)
		{
			lastSyncMessage = Std.string(Reflect.field(data, "message"));
			lastSyncError = lastSyncMessage;
			return;
		}
		manifestResultReceived = true;
		var files:Array<Dynamic> = cast data.files;
		pendingFiles = [];
		for (f in files)
		{
			if (f != null && Reflect.field(f, "serverCanServe") == true)
				pendingFiles.push(f);
		}
		totalFiles = pendingFiles.length;
		completedFiles = 0;
		failedFiles = 0;
		pendingIndex = 0;
		syncActive = pendingFiles.length > 0;
		var unavailable:Int = files.length - pendingFiles.length;
		unavailableFiles = unavailable;
		if (unavailable > 0)
			lastSyncError = unavailable + online.shared.OnlineStrings.get('online.modSyncUnavailable', ' 个文件无法由服务器直接读取（专用服务器需把模组放入 server/mods）');
		if (!syncActive)
		{
			lastSyncMessage = (files.length == 0 ? online.shared.OnlineStrings.get('online.modSyncAligned', '模组已一致，无需同步') : online.shared.OnlineStrings.get('online.modSyncNothing', '暂无可自动同步的模组文件'));
			revalidateRequested = true;
			return;
		}
		lastSyncMessage = online.shared.OnlineStrings.get('online.modSyncFound', '发现 ') + pendingFiles.length + online.shared.OnlineStrings.get('online.modSyncNeed', ' 个模组文件需要同步');
		requestNextFile(client);
	}

	public static function reset():Void
	{
		resetTransferState();
		syncActive = false;
		manifestResultReceived = false;
		totalFiles = 0;
		completedFiles = 0;
		failedFiles = 0;
		unavailableFiles = 0;
		currentFileName = "";
		lastSyncMessage = "";
		lastSyncError = "";
		pendingFiles = [];
		pendingIndex = 0;
		revalidateRequested = false;
		pendingManifestChart = null;
		pendingManifestContext = "";
		pendingManifestGeneration++;
		pendingManifestResult = null;
		pendingManifestResultChart = null;
		pendingManifestResultGeneration = -1;
		pendingManifestResultContext = "";
		manifestQueued = false;
		// 注意: 不能在这里强制 manifestThreadRunning=false, 否则可能和仍在运行的
		// 后台构建线程并发启动新线程。让旧线程自然结束并清除标志即可。
	}

	/** 大厅每帧读取并清除"同步完成, 请重算谱面哈希"标记。 */
	public static function consumeRevalidateRequest():Bool
	{
		var v:Bool = revalidateRequested;
		revalidateRequested = false;
		return v;
	}

	static function resetTransferState():Void
	{
		activePath = "";
		activeSha = "";
		activeRetries = 0;
		activeTransferId = -1;
		activeChunkCount = 0;
		activeReceived = [];
		activeFinished = false;
		activeLastActivityAt = Date.now().getTime();
	}

	/**
		大厅每帧调用: 传输停滞 watchdog。
		服务器中断/丢 ACK/分块迟迟不到时, 10 秒无任何活动就重试当前文件,
		重试 2 次仍失败则跳过, 绝不让同步流程卡死在某个文件上。
	**/
	public static function update(client:GameClient):Void
	{
		if (!syncActive || activePath.length == 0 || activeFinished)
			return;
		var now:Float = Date.now().getTime();
		if (now - activeLastActivityAt < STALL_TIMEOUT_MS)
			return;
		activeRetries++;
		if (activeRetries >= 2)
		{
			failedFiles++;
			lastSyncError = online.shared.OnlineStrings.get('online.modSyncStallSkip', '传输停滞，已跳过: ') + activePath;
			if (pendingIndex < pendingFiles.length)
				Reflect.setField(pendingFiles[pendingIndex], "failed", true);
			pendingIndex++;
			requestNextFile(client);
		}
		else
		{
			// 重新请求同一个文件 (resetTransferState 会刷新活动时间戳)。
			var f:Dynamic = pendingIndex < pendingFiles.length ? pendingFiles[pendingIndex] : null;
			resetTransferState();
			if (f != null)
			{
				activePath = Std.string(Reflect.field(f, "path"));
				activeSha = Std.string(Reflect.field(f, "sha256"));
				client.send(SeiunProtocol.MSG_MOD_FILE_REQUEST, SeiunProtocol.CHANNEL_FILE,
					{path: activePath, sha256: activeSha, requestedAt: Date.now().getTime()});
			}
			else
			{
				pendingIndex++;
				requestNextFile(client);
			}
		}
	}

	static function requestNextFile(client:GameClient):Void
	{
		if (client == null || client.state != online.client.GameClient.ClientState.Ready)
			return;
		while (pendingIndex < pendingFiles.length)
		{
			var f:Dynamic = pendingFiles[pendingIndex];
			if (Reflect.field(f, "done") == true || Reflect.field(f, "failed") == true)
			{
				pendingIndex++;
				continue;
			}
			resetTransferState();
			activePath = Std.string(Reflect.field(f, "path"));
			activeSha = Std.string(Reflect.field(f, "sha256"));
			currentFileName = activePath;
			lastSyncMessage = online.shared.OnlineStrings.get('online.modSyncSyncing', '正在同步 [') + (pendingIndex + 1) + "/" + pendingFiles.length + "] " + activePath;
			lastSyncError = "";
			activeLastActivityAt = Date.now().getTime();
			client.send(SeiunProtocol.MSG_MOD_FILE_REQUEST, SeiunProtocol.CHANNEL_FILE, {
				path: activePath,
				sha256: activeSha,
				requestedAt: Date.now().getTime()
			});
			return;
		}
		syncActive = false;
		refreshModsAfterSync();
		lastSyncMessage = online.shared.OnlineStrings.get('online.modSyncDone', '模组同步完成: ') + completedFiles + online.shared.OnlineStrings.get('online.modSyncOk', ' 成功')
			+ (failedFiles > 0 ? ", " + failedFiles + online.shared.OnlineStrings.get('online.modSyncFail', ' 失败') : "")
			+ (completedFiles > 0 ? ". " + online.shared.OnlineStrings.get('online.modSyncRefreshed', '已自动刷新模组列表；若个别内容未生效请重启游戏。') : "");
		revalidateRequested = true;
	}

	/**
		同步完成后自动刷新模组列表, 让新接收的模组尽快生效:
		- 重扫 mods/ 目录并更新 modsList.txt (新模组默认启用);
		- 使依赖目录扫描的 UI 缓存失效 (角色扫描等)。
		谱面/音频/角色资源在 Psych 加载模型下按路径即时读取, 无需重启;
		个别被 OpenFL 资产库缓存的内容才需要重启兜底。
	**/
	static function refreshModsAfterSync():Void
	{
		if (completedFiles <= 0)
			return;
		#if MODS_ALLOWED
		try
		{
			backend.Mods.updatedOnState = false;
			backend.Mods.parseList();
		}
		catch (e:Dynamic) {}
		#end
		try
		{
			online.substates.OptionsSubstate.invalidateCharacterCache();
		}
		catch (e:Dynamic) {}
	}

	/** 服务器在文件无法提供/读取失败时直接回 ACK, 客户端要推进或重试。 */
	public static function onFileAck(data:Dynamic, client:GameClient):Void
	{
		if (data == null || activePath.length == 0)
			return;
		if (Reflect.field(data, "ok") == true)
			return; // 成功 ACK 由 finishActiveFile 自己发送, 这里只处理服务器拒绝。
		var path:String = Reflect.field(data, "path");
		if (path != activePath)
			return;
		activeRetries++;
		lastSyncError = Std.string(Reflect.field(data, "message"));
		if (activeRetries >= 2)
		{
			failedFiles++;
			if (pendingIndex < pendingFiles.length)
				Reflect.setField(pendingFiles[pendingIndex], "failed", true);
			pendingIndex++;
			requestNextFile(client);
		}
		else
		{
			var f:Dynamic = pendingIndex < pendingFiles.length ? pendingFiles[pendingIndex] : null;
			resetTransferState();
			if (f != null)
			{
				activePath = Std.string(Reflect.field(f, "path"));
				activeSha = Std.string(Reflect.field(f, "sha256"));
				client.send(SeiunProtocol.MSG_MOD_FILE_REQUEST, SeiunProtocol.CHANNEL_FILE,
					{path: activePath, sha256: activeSha, requestedAt: Date.now().getTime()});
			}
			else
			{
				pendingIndex++;
				requestNextFile(client);
			}
		}
	}

	/** GameClient 收到 CHANNEL_FILE 分块时调用。 */
	public static function receiveChunk(payload:Bytes):Void
	{
		if (activeFinished)
			return;
		try
		{
			var input:BytesInput = new BytesInput(payload);
			input.bigEndian = true;
			if (input.readByte() != 0x5A)
				return;
			var transferId:Int = input.readInt32();
			var pathLen:Int = input.readInt32();
			if (pathLen <= 0 || pathLen > 1024)
				return;
			var path:String = input.read(pathLen).toString();
			var index:Int = input.readInt32();
			var count:Int = input.readInt32();
			var dataLen:Int = input.readInt32();
			var headerLen:Int = 21 + pathLen;
			if (index < 0 || count <= 0 || index >= count || dataLen <= 0)
				return;
			if (headerLen + dataLen > payload.length)
				return;
			var data:Bytes = payload.sub(headerLen, dataLen);
			input.close();

			if (dataLen > SeiunProtocol.FILE_CHUNK_BYTES)
				return;
			if (transferId != activeTransferId)
			{
				// 一个文件只允许一个 transferId; 只有尚未收到任何分块时才能
				// 开始新 transfer, 避免重试旧帧与重试新帧互相污染。
				if (activeReceived.length > 0 || path != activePath)
					return;
				activeTransferId = transferId;
				activeChunkCount = count;
				activeReceived = [];
			}
			if (path != activePath || activeChunkCount != count)
				return;
			var already:Bool = false;
			for (c in activeReceived)
				if (c.index == index)
				{
					already = true;
					break;
				}
			if (!already)
			{
				activeReceived.push({index: index, data: data});
				activeLastActivityAt = Date.now().getTime();
				lastSyncMessage = currentFileName + "  " + Std.int((activeReceived.length / count) * 100) + "%";
			}
			if (activeReceived.length >= count)
				finishActiveFile();
		}
		catch (e:Dynamic)
		{
			lastSyncError = online.shared.OnlineStrings.get('online.modSyncChunkFail', '分块解析失败: ') + Std.string(e);
		}
	}

	static function finishActiveFile():Void
	{
		if (activeFinished)
			return;
		var client:GameClient = GameClient.instance;
		if (client == null)
			return;
		// 传输完整性前置校验: 索引必须正好是 0..count-1 且无重复,
		// 最后一帧的数据长度决定整文件大小。缺帧/重帧走校验失败重试。
		var chunkSize:Int = SeiunProtocol.FILE_CHUNK_BYTES;
		var expectedSize:Int = 0;
		var complete:Bool = true;
		var seen:Map<Int, Bool> = new Map<Int, Bool>();
		var lastIndex:Int = -1;
		var lastLen:Int = 0;
		for (c in activeReceived)
		{
			var idx:Int = Std.int(c.index);
			var len:Int = c.data.length;
			if (idx < 0 || idx >= activeChunkCount || seen.exists(idx))
			{
				complete = false;
				break;
			}
			seen.set(idx, true);
			if (idx > lastIndex)
			{
				lastIndex = idx;
				lastLen = len;
			}
		}
		if (complete)
			for (i in 0...activeChunkCount)
				if (!seen.exists(i))
				{
					complete = false;
					break;
				}
		expectedSize = complete ? lastIndex * chunkSize + lastLen : 0;

		var ok:Bool = false;
		if (complete)
		{
			activeFinished = true;
			var chunks:Array<{offset:Int, data:Bytes}> = [];
			for (c in activeReceived)
			{
				var chunkIndex:Int = Std.int(c.index);
				chunks.push({offset: chunkIndex * chunkSize, data: c.data});
			}
			ok = writeReceivedFile("mods", activePath, chunks, activeSha, expectedSize);
		}
		if (ok)
		{
			completedFiles++;
			if (pendingIndex < pendingFiles.length)
				Reflect.setField(pendingFiles[pendingIndex], "done", true);
			client.send(SeiunProtocol.MSG_MOD_FILE_ACK, SeiunProtocol.CHANNEL_FILE, {
				transferId: activeTransferId,
				path: activePath,
				sha256: activeSha,
				ok: true
			});
			lastSyncMessage = online.shared.OnlineStrings.get('online.modSyncReceived', '已接收并校验 ') + activePath;
		}
		else
		{
			activeRetries++;
			lastSyncError = online.shared.OnlineStrings.get('online.modSyncVerifyFail', '接收校验失败: ') + activePath;
			if (activeRetries >= 2)
			{
				failedFiles++;
				if (pendingIndex < pendingFiles.length)
					Reflect.setField(pendingFiles[pendingIndex], "failed", true);
				client.send(SeiunProtocol.MSG_MOD_FILE_ACK, SeiunProtocol.CHANNEL_FILE, {
					transferId: activeTransferId,
					path: activePath,
					sha256: activeSha,
					ok: false
				});
			}
		}
		if (ok || activeRetries >= 2)
		{
			pendingIndex++;
			requestNextFile(client);
		}
		else
		{
			// 校验失败立即重试同一个文件。
			var f:Dynamic = pendingIndex < pendingFiles.length ? pendingFiles[pendingIndex] : null;
			resetTransferState();
			if (f != null)
			{
				activePath = Std.string(Reflect.field(f, "path"));
				activeSha = Std.string(Reflect.field(f, "sha256"));
				client.send(SeiunProtocol.MSG_MOD_FILE_REQUEST, SeiunProtocol.CHANNEL_FILE,
					{path: activePath, sha256: activeSha, requestedAt: Date.now().getTime()});
			}
			else
			{
				pendingIndex++;
				requestNextFile(client);
			}
		}
	}

	/** 供房间大厅显示同步进度 (本地化)。 */
	public static function statusLine():String
	{
		if (!syncActive)
		{
			if (lastSyncMessage.length > 0
				&& (lastSyncMessage.indexOf(online.shared.OnlineStrings.get('online.modSyncDone', '模组同步完成')) >= 0
					|| lastSyncMessage.indexOf(online.shared.OnlineStrings.get('online.modSyncAligned', '模组已一致')) >= 0
					|| lastSyncMessage.indexOf(online.shared.OnlineStrings.get('online.modSyncNothing', '暂无可自动同步')) >= 0))
				return lastSyncMessage;
			return "";
		}
		var done:Int = completedFiles + failedFiles;
		return online.shared.OnlineStrings.get('online.modSyncProgress', '模组同步 ') + done + "/" + totalFiles + "  "
			+ (currentFileName.length > 0 ? currentFileName + " " : "")
			+ (totalFiles > 0 ? Std.int((done / totalFiles) * 100) + "%" : "");
	}
	#end
}
