﻿package online.client;

import haxe.io.Bytes;
import haxe.io.Error;

typedef DiscoveredServer =
{
	var address:String;
	var port:Int;
	var name:String;
	var dedicated:Bool;
}

/**
	局域网服务器发现:
	- UDP 广播 "SEIUNP01" 探测包, 服务器用同协议魔数回包;
	- 非阻塞轮询, 在 FlxState.update 中调用, 不卡游戏主循环;
	- 广播无效时回退扫描 localhost。
**/
class LanDiscovery
{
	public var results:Array<DiscoveredServer> = [];
	public var scanning(default, null):Bool = false;
	public var done(default, null):Bool = false;
	public var lastError:String = "";

	var socket:sys.net.UdpSocket = null;
	var buf:Bytes;
	var elapsed:Float = 0;
	var timeout:Float = 2.5;

	public function new()
	{
		buf = Bytes.alloc(512);
	}

	public function start(?timeout:Float):Void
	{
		if (timeout != null && timeout > 0)
			this.timeout = timeout;
		results = [];
		done = false;
		lastError = "";
		elapsed = 0;
		#if cpp
		try
		{
			socket = new sys.net.UdpSocket();
			socket.bind(new sys.net.Host("0.0.0.0"), 0);
			socket.setBlocking(false);
			socket.setBroadcast(true);
			var addr:sys.net.Address = new sys.net.Address();
			var host:sys.net.Host = new sys.net.Host("255.255.255.255");
			addr.host = host.ip;
			var payload:Bytes = Bytes.ofString("SEIUNP01-DISCOVER");
			for (probePort in 2567...2573)
			{
				addr.port = probePort;
				socket.sendTo(payload, 0, payload.length, addr);
			}
			scanning = true;
		}
		catch (e:Dynamic)
		{
			lastError = online.shared.OnlineStrings.get('online.clientErrUdp', 'UDP 发现不可用: ') + Std.string(e);
			scanning = false;
			done = true;
			try { if (socket != null) socket.close(); } catch (e2:Dynamic) {}
			socket = null;
		}
		#else
		scanning = false;
		done = true;
		#end
	}

	public function update(elapsedSeconds:Float):Void
	{
		if (!scanning)
			return;
		elapsed += elapsedSeconds;
		#if cpp
		while (true)
		{
			try
			{
				var addr:sys.net.Address = new sys.net.Address();
				var n:Int = socket.readFrom(buf, 0, buf.length, addr);
				if (n <= 0)
					break;
				var text:String = buf.sub(0, n).toString();
				if (text.indexOf("SEIUNP01|") == 0)
				{
					var parts:Array<String> = text.split("|");
					if (parts.length >= 4)
					{
						var address:String = addr.getHost().toString();
						var rawPort:Null<Int> = Std.parseInt(parts[3]);
						var portValue:Int = (rawPort == null || rawPort <= 0) ? 2567 : rawPort;
						var item:DiscoveredServer = {
							address: address,
							port: portValue,
							name: parts[1],
							dedicated: parts[2] == "dedicated"
						};
						if (!containsResult(item))
							results.push(item);
					}
				}
			}
			catch (e:Dynamic)
			{
				if (e == Error.Blocked || Std.string(e).toLowerCase().indexOf("blocked") >= 0)
					break;
				break;
			}
		}
		if (elapsed >= timeout)
		{
			scanning = false;
			done = true;
			try { socket.close(); } catch (e:Dynamic) {}
			socket = null;
		}
		#end
	}

	public function cancel():Void
	{
		scanning = false;
		done = true;
		try { if (socket != null) socket.close(); } catch (e:Dynamic) {}
		socket = null;
	}

	function containsResult(item:DiscoveredServer):Bool
	{
		for (r in results)
			if (r.address == item.address && r.port == item.port)
				return true;
		return false;
	}
}
