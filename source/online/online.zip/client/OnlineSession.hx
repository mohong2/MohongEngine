package online.client;

import online.shared.OnlineTypes;
import online.shared.OnlineTypes.ChartSelection;
import online.shared.OnlineTypes.RoomSettings;
import online.shared.SeiunProtocol;

/**
	当前联机对局上下文。只存放 UI/PlayState 需要的轻量状态,
	不直接依赖 Flixel, 便于在状态间传递。
**/
class OnlineSession
{
	public static var active(default, null):Bool = false;
	public static var roomCode:String = "";
	public static var roomName:String = "";
	public static var mode:String = online.shared.OnlineTypes.OnlineConst.MODE_REALTIME;
	public static var isHost:Bool = false;
	public static var selfId:String = "";
	public static var hostId:String = "";
	/** 反作弊已移除: 恒为 false, 保留字段仅为协议/旧代码兼容。 */
	public static var antiCheat:Bool = false;
	public static var dedicated:Bool = false;
	public static var hostIp:String = "";
	public static var settings:RoomSettings = null;
	public static var chart:ChartSelection = null;
	public static var songName:String = "";
	public static var difficulty:String = "";
	/** 房主指定的房间舞台 (空 = 跟随歌曲)。 */
	public static var stageName:String = "";
	/** 房间统一兼容模式 (CompatEngine 取值, 空 = Auto)。 */
	public static var compatEngine:String = "";
	/** 本机对局角色皮肤。 */
	public static var selfSkin:String = "bf";
	public static var crashNotice:String = "";
	public static var lastDisconnectMessage:String = "";
	/** 最后一次由远端玩家发起的暂停 (对方昵称, 空 = 自己暂停/无人暂停)。 */
	public static var pauseNickname:String = "";
	/** 实时对局暂停策略 (everyone / hostOnly / disabled), 由房主设置并随房间广播。 */
	public static var pausePolicy:String = online.shared.OnlineTypes.OnlineConst.PAUSE_EVERYONE;
	public static var viewingReplay:Bool = false;
	public static var players:Array<Dynamic> = [];
	public static var roomInfo:Dynamic = null;

	/** 本机当前是否以观战身份在房间中 (不占游玩席位)。 */
	public static function selfIsSpectator():Bool
	{
		for (p in players)
		{
			if (p != null && Std.string(p.id) == selfId)
				return Reflect.hasField(p, "isSpectator") && p.isSpectator == true;
		}
		return false;
	}

	/** 客户端每帧产生或收到的输入事件, PlayState 会取出处理。 */
	public static var incomingInputs:Array<Dynamic> = [];
	public static var incomingJudges:Array<Dynamic> = [];

	/** 对局中收到的皮肤变更 (deviceId → skinData), PlayState 渲染层消费。 */
	public static var pendingSkinChanges:Map<String, online.shared.OnlineTypes.OnlineSkinData> = new Map<String, online.shared.OnlineTypes.OnlineSkinData>();

	/** PlayState 仍在对局中时收到的实时成绩/最终排名 (转交给结算页)。 */
	public static var pendingRealtimeResults:Map<String, Dynamic> = new Map<String, Dynamic>();
	public static var pendingRealtimeRanking:Array<Dynamic> = [];

	/**
		实时对局统一起跑锚点。MSG_GAME_SYNC 携带 `serverNow + startDelayMs`,
		客户端换算成自己的 `startOnTime` (距本地开始还剩多少毫秒)。
		值为 -1 表示还没有收到统一起跑信号。
	**/
	public static var pendingRealtimeSyncServerStartMs:Float = -1;

	public static function setPendingRealtimeSync(serverNowMs:Float, startDelayMs:Float):Void
	{
		if (Math.isNaN(serverNowMs) || serverNowMs <= 0)
			return;
		if (Math.isNaN(startDelayMs) || startDelayMs < 0)
			startDelayMs = 0;
		pendingRealtimeSyncServerStartMs = serverNowMs + startDelayMs;
	}

	/** 取出统一起跑信号并换算成本地 startOnTime (毫秒); 没有或已过期返回 -1。 */
	public static function consumePendingRealtimeSync():Float
	{
		if (pendingRealtimeSyncServerStartMs <= 0)
			return -1;
		var target:Float = pendingRealtimeSyncServerStartMs;
		pendingRealtimeSyncServerStartMs = -1;

		var client:GameClient = GameClient.instance;
		var offset:Float = 0;
		if (client != null && client.clock != null)
			offset = client.clock.offsetMs;
		if (Math.isNaN(offset))
			offset = 0;

		// local = server - offset (ClockSync 的 offset 语义是 server - local)
		var targetLocal:Float = target - offset;
		var wait:Float = targetLocal - Date.now().getTime();
		if (wait < 0)
			wait = 0;
		// 服务器时间异常时不要无限等待。
		if (wait > 15000)
			wait = 0;
		return wait;
	}

	public static function enter(roomInfo:Dynamic, selfId:String):Void
	{
		clear();
		active = true;
		roomCode = Reflect.field(roomInfo, "roomCode");
		roomName = Reflect.field(roomInfo, "roomName");
		mode = Reflect.field(roomInfo, "mode");
		antiCheat = false; // 反作弊已移除
		isHost = false;
		hostId = Reflect.field(roomInfo, "hostId");
		OnlineSession.selfId = selfId;
		OnlineSession.roomInfo = roomInfo;
		isHost = (selfId == hostId);
		settings = roomInfo.settings;
		if (settings != null)
		{
			stageName = settings.stageName == null ? "" : Std.string(settings.stageName);
			compatEngine = settings.compatEngine == null ? "" : Std.string(settings.compatEngine);
			pausePolicy = settings.pausePolicy == null ? online.shared.OnlineTypes.OnlineConst.PAUSE_EVERYONE : Std.string(settings.pausePolicy);
		}
		ProfileStore.ensureLoaded();
		selfSkin = ProfileStore.skin == null ? "" : ProfileStore.skin;
		if (roomInfo.chart != null)
			setChart(roomInfo.chart);
		applyConvertedChartMode();
		if (GameClient.instance != null)
			dedicated = GameClient.instance.dedicated;
	}

	/** Malody/osu! 转谱强制异步: 即使旧房间数据瞬时不一致, 本地也立即对齐。 */
	static function applyConvertedChartMode():Void
	{
		if (chart == null || chart.chartSource != online.shared.OnlineTypes.OnlineConst.CHART_SOURCE_CONVERTED)
			return;
		mode = online.shared.OnlineTypes.OnlineConst.MODE_ASYNC;
		if (settings != null)
			settings.mode = online.shared.OnlineTypes.OnlineConst.MODE_ASYNC;
	}

	public static function enterHosted(roomInfo:Dynamic):Void
	{
		enter(roomInfo, Reflect.field(roomInfo, "hostId"));
		isHost = true;
	}

	public static function clear():Void
	{
		active = false;
		roomCode = "";
		roomName = "";
		mode = online.shared.OnlineTypes.OnlineConst.MODE_REALTIME;
		isHost = false;
		selfId = "";
		hostId = "";
		antiCheat = false;
		dedicated = false;
		settings = null;
		chart = null;
		songName = "";
		difficulty = "";
		stageName = "";
		compatEngine = "";
		selfSkin = "bf";
		incomingInputs = [];
		incomingJudges = [];
		pendingSkinChanges = new Map<String, online.shared.OnlineTypes.OnlineSkinData>();
		pendingRealtimeResults = new Map<String, Dynamic>();
		pendingRealtimeRanking = [];
		pendingRealtimeSyncServerStartMs = -1;
		crashNotice = "";
		lastDisconnectMessage = "";
		pauseNickname = "";
		pausePolicy = online.shared.OnlineTypes.OnlineConst.PAUSE_EVERYONE;
		viewingReplay = false;
		players = [];
		roomInfo = null;
	}

	public static function applyRoomInfo(data:Dynamic):Void
	{
		if (data == null)
			return;
		roomInfo = data;
		if (data.room != null)
		{
			var room:Dynamic = data.room;
			roomCode = room.roomCode;
			roomName = room.roomName;
			mode = room.mode;
			antiCheat = false; // 反作弊已移除
			hostId = room.hostId;
			isHost = selfId == hostId;
			settings = room.settings;
			if (settings != null)
			{
				stageName = settings.stageName == null ? "" : Std.string(settings.stageName);
				compatEngine = settings.compatEngine == null ? "" : Std.string(settings.compatEngine);
				pausePolicy = settings.pausePolicy == null ? online.shared.OnlineTypes.OnlineConst.PAUSE_EVERYONE : Std.string(settings.pausePolicy);
			}
			chart = room.chart;
			if (chart != null)
			{
				songName = chart.songName;
				difficulty = chart.difficulty;
			}
			applyConvertedChartMode();
		}
		if (data.players != null && Std.isOfType(data.players, Array))
			players = cast data.players;
	}

	public static function setChart(c:ChartSelection):Void
	{
		chart = c;
		if (c != null)
		{
			songName = c.songName;
			difficulty = c.difficulty;
		}
	}

	public static function sendInput(lane:Int, pressed:Bool, songTime:Float):Void
	{
		var client:GameClient = GameClient.instance;
		if (client == null || !active || mode != online.shared.OnlineTypes.OnlineConst.MODE_REALTIME)
			return;
		client.send(SeiunProtocol.MSG_GAME_INPUT, SeiunProtocol.CHANNEL_GAME, {
			lane: lane,
			pressed: pressed,
			songTime: songTime,
			sentAt: Date.now().getTime()
		});
	}

	public static function sendAsyncStart():Void
	{
		var client:GameClient = GameClient.instance;
		if (client != null && active)
			client.send(SeiunProtocol.MSG_ASYNC_START, SeiunProtocol.CHANNEL_ASYNC, {at: Date.now().getTime()});
	}

	/** 请求更换自己的对局皮肤 (服务器校验后广播 MSG_ROOM_PLAYER_SKIN)。 */
	public static function sendSkinUpdate(sd:online.shared.OnlineTypes.OnlineSkinData):Void
	{
		var client:GameClient = GameClient.instance;
		if (client == null || !active || client.state != GameClient.ClientState.Ready)
			return;
		client.send(SeiunProtocol.MSG_ROOM_SET_SKIN, SeiunProtocol.CHANNEL_ROOM, {skinData: sd});
	}

	/** 起跑门闩: 本机玩家已加载完并按下 空格/回车 确认。 */
	public static function sendStartAck():Void
	{
		var client:GameClient = GameClient.instance;
		if (client == null || !active || client.state != GameClient.ClientState.Ready)
			return;
		client.send(SeiunProtocol.MSG_GAME_START_ACK, SeiunProtocol.CHANNEL_GAME, {at: Date.now().getTime()});
	}

	public static function submitAsyncScore(score:Dynamic):Void
	{
		var client:GameClient = GameClient.instance;
		if (client == null || !active)
			return;
		ProfileStore.ensureLoaded();
		score.deviceId = ProfileStore.deviceId;
		if (chart != null)
			score.chartHash = chart.chartHash;
		client.send(SeiunProtocol.MSG_ASYNC_SUBMIT, SeiunProtocol.CHANNEL_ASYNC, score);
	}

	public static function recordDisconnect(message:String):Void
	{
		lastDisconnectMessage = message;
	}

	/** 本地判定上报 (反作弊已移除, 实时模式始终上报; 带当前分数/实时统计/共享血量供对手 HUD 显示)。 */
	public static function sendLocalJudge(strumTime:Float, lane:Int, rating:String, hitDiff:Float, isSustain:Bool,
		?score:Int = 0, ?misses:Int = 0, ?maxCombo:Int = 0, ?accuracy:Float = 0,
		?ratingName:String = "", ?ratingFC:String = "", ?pingMs:Float = 0, ?health:Float = -1):Void
	{
		var client:GameClient = GameClient.instance;
		if (client == null || !active || mode != online.shared.OnlineTypes.OnlineConst.MODE_REALTIME)
			return;
		// PsychOnline 式共享血量: 每次本地判定把当前 health 一起广播,
		// 服务器转发后对手 HUD/血条与本地保持同一条命。
		var payload:Dynamic = {
			strumTime: strumTime,
			lane: lane,
			rating: rating,
			hitDiff: hitDiff,
			isSustain: isSustain,
			score: score,
			misses: misses,
			maxCombo: maxCombo,
			accuracy: accuracy,
			ratingName: ratingName,
			ratingFC: ratingFC,
			pingMs: pingMs,
			health: health >= 0 && !Math.isNaN(health) ? Math.max(0, Math.min(2, health)) : -1,
			sentAt: Date.now().getTime()
		};
		client.send(SeiunProtocol.MSG_GAME_JUDGE, SeiunProtocol.CHANNEL_GAME, payload);
	}
}
