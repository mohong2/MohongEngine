package online.client;

import StringTools;
import haxe.io.Bytes;
import haxe.io.Error;
import online.shared.ClockSync;
import online.shared.OnlineTypes;
import online.shared.SeiunPacket;
import online.shared.SeiunPacket.InboundPacket;
import online.shared.SeiunPacket.PacketFramer;
import online.shared.SeiunProtocol;

typedef ClientEvent =
{
	var type:Int;
	var channel:Int;
	var data:Dynamic;
}

enum ClientState
{
	Disconnected;
	Connecting;
	Handshaking;
	Ready;
	Failed;
}

/**
	SeiunEngine 客户端网络层。
	- 只连接玩家输入的地址, 默认 127.0.0.1, 绝不内置公共服务器;
	- 自定义二进制 TCP, 与 Psych Online / Colyseus 不兼容;
	- update() 必须在游戏状态中每帧调用, 所有网络处理为非阻塞。
**/
class GameClient
{
	public static var instance(default, null):GameClient = null;

	public var state(default, null):ClientState = Disconnected;
	public var socket:sys.net.Socket = null;
	public var host:String = "127.0.0.1";
	public var port:Int = SeiunProtocol.DEFAULT_PORT;
	public var serverName:String = "";
	public var dedicated:Bool = false;
	public var authRequired:Bool = false;
	public var authenticated:Bool = false;
	public var welcomeReceived:Bool = false;
	public var events:Array<ClientEvent> = [];
	public var lastError:String = "";
	/** 服务器主动下发的错误消息 (如封禁/被踢), 断开后仍保留展示, 不被"连接已断开"覆盖。 */
	public var lastServerError:String = "";
	public var lastServerErrorCode:Int = -1;
	public var clock:ClockSync = new ClockSync();
	public var sessionToken:String = "";

	var framer:PacketFramer;
	var readChunk:Bytes;
	var outQueue:Array<Bytes> = [];
	var outPos:Int = 0;
	var sequence:Int = 0;
	var lastReadAt:Float = 0;
	var lastHeartbeatAt:Float = 0;
	var pingProbes:Array<Dynamic> = [];
	var pingProbeCount:Int = 0;

	public function new()
	{
		instance = this;
		readChunk = Bytes.alloc(64 * 1024);
	}

	public static function parseAddress(address:String):{host:String, port:Int}
	{
		var text:String = address == null ? "" : StringTools.trim(address);
		if (text.length == 0)
			text = "ws://127.0.0.1:2567";
		text = StringTools.replace(text, "ws://", "");
		text = StringTools.replace(text, "wss://", "");
		if (text.indexOf("/") == 0)
			text = text.substr(1);
		var colon:Int = text.lastIndexOf(":");
		if (colon > 0)
		{
			var p:Null<Int> = Std.parseInt(text.substr(colon + 1));
			if (p != null && p > 0)
			{
				var portValue:Int = p == null ? SeiunProtocol.DEFAULT_PORT : p;
				return {host: text.substr(0, colon), port: portValue};
			}
		}
		return {host: text, port: SeiunProtocol.DEFAULT_PORT};
	}

	public function connect(address:String, ?port:Int):Bool
	{
		disconnect(false);
		var parsed:{host:String, port:Int} = parseAddress(address);
		if (port != null && port > 0)
			parsed.port = port;
		host = parsed.host;
		this.port = parsed.port;
		state = Connecting;
		lastError = "";
		lastServerError = "";
		lastServerErrorCode = -1;
		events = [];
		framer = new PacketFramer();
		outQueue = [];
		outPos = 0;
		sequence = 0;

		#if sys
		try
		{
			socket = new sys.net.Socket();
			socket.setTimeout(3.0);
			socket.connect(new sys.net.Host(host), parsed.port);
			socket.setBlocking(false);
			lastReadAt = Date.now().getTime();
			lastHeartbeatAt = lastReadAt;
			state = Handshaking;
			ProfileStore.ensureLoaded();
			// 一体化登录: 该服务器有已保存的令牌就随 HELLO 带上,
			// 服务器校验通过则 WELCOME.authenticated = true, 全程免输密码。
			if (sessionToken == null || sessionToken.length == 0)
				sessionToken = ProfileStore.tokenFor(host + ":" + port);
			send(SeiunProtocol.MSG_HELLO, SeiunProtocol.CHANNEL_CONTROL, {
				protocolVersion: SeiunProtocol.PROTOCOL_VERSION,
				fingerprint: SeiunProtocol.ENGINE_FINGERPRINT,
				deviceId: ProfileStore.deviceId,
				nickname: ProfileStore.nickname,
				avatar: ProfileStore.avatar,
				skin: ProfileStore.skin,
				skinData: ProfileStore.skinData,
				sessionToken: sessionToken,
				clientTime: Date.now().getTime()
			});
			flush();
			return true;
		}
		catch (e:Dynamic)
		{
			lastError = online.shared.OnlineStrings.get('online.clientErrConnect', '连接失败: ') + friendlyError(e);
			state = Failed;
			online.shared.OnlineDebug.log("client", "connect failed -> " + lastError);
			try { if (socket != null) socket.close(); } catch (e2:Dynamic) {}
			socket = null;
			return false;
		}
		#else
		lastError = online.shared.OnlineStrings.get('online.clientErrPlatform', '当前平台未启用联机');
		state = Failed;
		return false;
		#end
	}

	public function disconnect(clearEvents:Bool = true):Void
	{
		state = Disconnected;
		if (clearEvents)
			events = [];
		outQueue = [];
		outPos = 0;
		try { if (socket != null) socket.close(); } catch (e:Dynamic) {}
		socket = null;
	}

	public function update(elapsed:Float):Void
	{
		#if sys
		if (socket == null)
			return;

		if (state == Ready || state == Handshaking)
			pumpRead();

		if (state == Handshaking && (Date.now().getTime() - lastReadAt) > 5000.0)
		{
			// 握手超时: 若服务器已下发过错误 (如封禁/协议拒绝), 保留该消息展示。
			if (lastServerError.length > 0)
				lastError = lastServerError;
			else
				lastError = online.shared.OnlineStrings.get('online.clientErrHandshakeTimeout', '握手超时: 服务器不是 SeiunEngine 或版本不匹配');
			state = Failed;
			online.shared.OnlineDebug.log("client", "handshake timeout -> " + lastError);
			try { if (socket != null) socket.close(); } catch (e:Dynamic) {}
			socket = null;
			return;
		}

		if (state == Ready)
		{
			var now:Float = Date.now().getTime();
			var interval:Float = SeiunProtocol.IDLE_HEARTBEAT_SECONDS * 1000.0;
			if (now - lastHeartbeatAt >= interval)
			{
				lastHeartbeatAt = now;
				// 把时钟探测得到的 RTT 一并上报, 大厅玩家行可显示真实延迟。
				send(SeiunProtocol.MSG_HEARTBEAT, SeiunProtocol.CHANNEL_CONTROL, {
					clientTime: now,
					pingMs: clock.rttMs
				});
			}
			if (now - lastReadAt > 15000.0)
			{
				if (lastServerError.length > 0)
					lastError = lastServerError;
				else
					lastError = online.shared.OnlineStrings.get('online.clientErrTimeout', '连接超时');
				state = Failed;
				online.shared.OnlineDebug.log("client", "read timeout -> " + lastError);
				try { if (socket != null) socket.close(); } catch (e:Dynamic) {}
				socket = null;
			}
		}
		flush();
		#end
	}

	function pumpRead():Void
	{
		if (socket == null)
			return;
		while (true)
		{
			try
			{
				var n:Int = socket.input.readBytes(readChunk, 0, readChunk.length);
				if (n <= 0)
					break;
				lastReadAt = Date.now().getTime();
				var packets:Array<InboundPacket> = framer.push(readChunk, 0, n);
				for (p in packets)
				{
					handlePacket(p);
					if (state == Failed)
						break;
				}
				if (state == Failed)
					return;
			}
			catch (e:Dynamic)
			{
				if (e == Error.Blocked || Std.string(e).toLowerCase().indexOf("blocked") >= 0)
					break;
				// 服务器主动断开: 若已收到过服务器错误 (如封禁/被踢), 优先展示服务器消息。
				if (lastServerError.length > 0)
					lastError = lastServerError;
				else
					lastError = online.shared.OnlineStrings.get('online.clientErrClosed', '连接已断开');
				state = Failed;
				online.shared.OnlineDebug.log("client", "pumpRead error -> " + lastError + " (" + Std.string(e) + ")");
				try { if (socket != null) socket.close(); } catch (e2:Dynamic) {}
				socket = null;
				break;
			}
		}
	}

	public function send(type:Int, channel:Int, obj:Dynamic):Void
	{
		if (socket == null)
			return;
		if (state != Ready && type != SeiunProtocol.MSG_HELLO)
			return;
		if (outQueue.length > 1024)
			return; // 本地发送队列保护, 防止 UI 异常时无限堆积。
		var bytes:Bytes = SeiunPacket.encodeJson(type, channel, nextSequence(), obj);
		outQueue.push(bytes);
	}

	public function sendRaw(type:Int, channel:Int, payload:Bytes):Void
	{
		if (socket == null)
			return;
		if (state != Ready && type != SeiunProtocol.MSG_HELLO)
			return;
		outQueue.push(SeiunPacket.encodeBytes(type, channel, nextSequence(), payload, SeiunProtocol.FLAG_RAW_BYTES));
	}

	function nextSequence():Int
	{
		sequence++;
		if (sequence > 0x7FFFFFFF)
			sequence = 1;
		return sequence;
	}

	public function flush():Bool
	{
		if (socket == null)
			return outQueue.length == 0;
		while (outQueue.length > 0)
		{
			var current:Bytes = outQueue[0];
			var left:Int = current.length - outPos;
			try
			{
				var written:Int = socket.output.writeBytes(current, outPos, left);
				if (written <= 0)
					return false;
				outPos += written;
				if (outPos >= current.length)
				{
					outQueue.shift();
					outPos = 0;
				}
			}
			catch (e:Dynamic)
			{
				return false;
			}
		}
		return true;
	}

	function handlePacket(packet:InboundPacket):Void
	{
		if (packet.type == -1)
		{
			lastError = online.shared.OnlineStrings.get('online.clientErrNotSeiun', '对方不是 SeiunEngine 服务器（协议魔数不符）');
			events.push({type: SeiunProtocol.MSG_ERROR, channel: SeiunProtocol.CHANNEL_CONTROL, data: {code: SeiunProtocol.ERR_BAD_MAGIC, message: lastError}});
			state = Failed;
			return;
		}
		if (packet.type == -2)
		{
			lastError = online.shared.OnlineStrings.get('online.clientErrBadLen', '服务器消息长度非法');
			events.push({type: SeiunProtocol.MSG_ERROR, channel: SeiunProtocol.CHANNEL_CONTROL, data: {code: SeiunProtocol.ERR_BAD_PACKET, message: lastError}});
			state = Failed;
			return;
		}
		var payloadLimit:Int = packet.channel == SeiunProtocol.CHANNEL_ASYNC
			? SeiunProtocol.MAX_SCORE_BYTES : SeiunProtocol.MAX_MESSAGE_BYTES;
		if (packet.channel != SeiunProtocol.CHANNEL_FILE
			&& packet.payload != null
			&& packet.payload.length > payloadLimit)
		{
			lastError = online.shared.OnlineStrings.get('online.clientErrMsgTooBig', '服务器消息超过大小限制');
			events.push({type: SeiunProtocol.MSG_ERROR, channel: SeiunProtocol.CHANNEL_CONTROL, data: {code: SeiunProtocol.ERR_BAD_PACKET, message: lastError}});
			state = Failed;
			return;
		}
		if (packet.channel == SeiunProtocol.CHANNEL_FILE
			&& packet.payload != null
			&& packet.payload.length > SeiunProtocol.MAX_FILE_BYTES + 4096)
		{
			lastError = online.shared.OnlineStrings.get('online.clientErrFileTooBig', '服务器文件消息超过大小限制');
			events.push({type: SeiunProtocol.MSG_ERROR, channel: SeiunProtocol.CHANNEL_CONTROL, data: {code: SeiunProtocol.ERR_BAD_PACKET, message: lastError}});
			state = Failed;
			return;
		}
		if (packet.version != SeiunProtocol.PROTOCOL_VERSION)
		{
			lastError = online.shared.OnlineStrings.get('online.clientErrVersion', '协议版本不匹配: 本地 ') + SeiunProtocol.PROTOCOL_VERSION + online.shared.OnlineStrings.get('online.clientErrVersionServer', '，服务器 ') + packet.version;
			events.push({type: SeiunProtocol.MSG_ERROR, channel: SeiunProtocol.CHANNEL_CONTROL, data: {code: SeiunProtocol.ERR_PROTOCOL_VERSION, message: lastError}});
			state = Failed;
			return;
		}
		if (!SeiunPacket.checkCrc(packet))
		{
			lastError = online.shared.OnlineStrings.get('online.clientErrCrc', '服务器消息校验失败');
			events.push({type: SeiunProtocol.MSG_ERROR, channel: SeiunProtocol.CHANNEL_CONTROL, data: {code: SeiunProtocol.ERR_BAD_PACKET, message: lastError}});
			state = Failed;
			return;
		}
		if (packet.type == SeiunProtocol.MSG_WELCOME && packet.channel == SeiunProtocol.CHANNEL_CONTROL)
		{
			var welcomeData:Dynamic = SeiunPacket.payloadJson(packet);
			if (Reflect.field(welcomeData, "fingerprint") != SeiunProtocol.ENGINE_FINGERPRINT)
			{
				lastError = online.shared.OnlineStrings.get('online.clientErrFingerprint', '服务器指纹不符，不是 SeiunEngine 服务器');
				events.push({type: SeiunProtocol.MSG_ERROR, channel: SeiunProtocol.CHANNEL_CONTROL,
					data: {code: SeiunProtocol.ERR_BAD_FINGERPRINT, message: lastError}});
				state = Failed;
				try { if (socket != null) socket.close(); } catch (e:Dynamic) {}
				socket = null;
				return;
			}
			serverName = Reflect.field(welcomeData, "serverName");
			dedicated = Reflect.field(welcomeData, "dedicated") == true;
			authRequired = Reflect.field(welcomeData, "authRequired") == true;
			authenticated = Reflect.field(welcomeData, "authenticated") == true;
			welcomeReceived = true;
			state = Ready;
			online.shared.OnlineDebug.log("client", "WELCOME ready server=" + serverName + " dedicated=" + dedicated + " authRequired=" + authRequired);
			startClockProbe();
			events.push({type: packet.type, channel: packet.channel, data: welcomeData});
			return;
		}
		if (packet.type == SeiunProtocol.MSG_ERROR && packet.channel == SeiunProtocol.CHANNEL_CONTROL)
		{
			var errorData:Dynamic = SeiunPacket.payloadJson(packet);
			// 记录服务器下发的错误 (封禁/被踢/拒绝等): 断开后 UI 优先展示它,
			// 而不是笼统的"连接已断开"。
			lastServerError = Reflect.field(errorData, "message");
			lastServerErrorCode = Reflect.field(errorData, "code") == null ? -1 : Std.parseInt(Std.string(Reflect.field(errorData, "code")));
			lastError = lastServerError;
			online.shared.OnlineDebug.log("client", "server ERROR code=" + Std.string(Reflect.field(errorData, "code")) + " msg=" + lastError);
			events.push({type: packet.type, channel: packet.channel, data: errorData});
			return;
		}
		if (packet.type == SeiunProtocol.MSG_PONG && packet.channel == SeiunProtocol.CHANNEL_CONTROL)
		{
			var pongData:Dynamic = SeiunPacket.payloadJson(packet);
			var t0:Float = Reflect.field(pongData, "t0");
			var t1:Float = Reflect.field(pongData, "t1");
			var t2:Float = Reflect.field(pongData, "t2");
			clock.addSample(t0, t1, t2, Date.now().getTime());
			if (clock.stable && Math.abs(clock.offsetMs) > SeiunProtocol.MAX_CLOCK_SKEW_MS)
			{
				lastError = online.shared.OnlineStrings.get('online.clientErrClock', '检测到本地时钟与服务器偏差过大');
				events.push({type: SeiunProtocol.MSG_ERROR, channel: SeiunProtocol.CHANNEL_CONTROL, data: {code: SeiunProtocol.ERR_CLOCK_JUMP, message: lastError}});
				state = Failed;
			}
			return;
		}
		if (packet.type == SeiunProtocol.MSG_HEARTBEAT && packet.channel == SeiunProtocol.CHANNEL_CONTROL)
		{
			lastReadAt = Date.now().getTime();
			return;
		}
		if (packet.type == SeiunProtocol.MSG_GAME_RECONNECT_RESULT && packet.channel == SeiunProtocol.CHANNEL_CONTROL)
		{
			events.push({type: packet.type, channel: packet.channel, data: SeiunPacket.payloadJson(packet)});
			return;
		}
		#if sys
		if (packet.channel == SeiunProtocol.CHANNEL_FILE && packet.type == SeiunProtocol.MSG_MOD_FILE_CHUNK)
		{
			// 文件分块是自定义二进制格式, 直接交给接收器, 不做 JSON 解析。
			// 头像文件使用相同分块格式但路径前缀为 avatars/, 由 AvatarFileClient 接收。
			if (!AvatarFileClient.maybeHandleChunk(packet.payload))
				ModSyncClient.receiveChunk(packet.payload);
			return;
		}
		#end
		var data:Dynamic = null;
		try
		{
			data = SeiunPacket.payloadJson(packet);
		}
		catch (e:Dynamic) {}
		events.push({type: packet.type, channel: packet.channel, data: data});
	}

	function startClockProbe():Void
	{
		pingProbeCount = 0;
		for (i in 0...3)
		{
			var t0:Float = Date.now().getTime();
			send(SeiunProtocol.MSG_PING, SeiunProtocol.CHANNEL_CONTROL, {t0: t0, clientTime: t0});
		}
	}

	/** 读取一个事件并返回, 没有事件返回 null。 */
	public function pollEvent():ClientEvent
	{
		if (events.length == 0)
			return null;
		return events.shift();
	}

	/** 拉取所有事件, 供 UI 批量处理。 */
	public function drainEvents():Array<ClientEvent>
	{
		var out:Array<ClientEvent> = events.copy();
		events = [];
		return out;
	}

	public function auth(register:Bool, username:String, password:String):Void
	{
		send(register ? SeiunProtocol.MSG_AUTH_REGISTER : SeiunProtocol.MSG_AUTH_LOGIN,
			SeiunProtocol.CHANNEL_AUTH, {username: username, password: password});
	}

	public function sendCrashSignal(roomCode:String, song:String, summary:String):Bool
	{
		if (socket == null || state != Ready)
			return false;
		send(SeiunProtocol.MSG_CRASH_SIGNAL, SeiunProtocol.CHANNEL_CONTROL, {
			roomCode: roomCode,
			song: song,
			summary: summary,
			at: Date.now().getTime()
		});
		return flush();
	}

	static function friendlyError(e:Dynamic):String
	{
		var text:String = Std.string(e);
		text = StringTools.replace(text, "Failed to connect", online.shared.OnlineStrings.get('online.clientErrCannotConnect', '无法连接服务器'));
		return text;
	}
}
