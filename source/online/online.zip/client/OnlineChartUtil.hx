package online.client;

import CoolUtil;
import Highscore;
import Paths;
import Song;
import Song.SwagSong;

/**
	联机选歌路径工具 —— 与原版 FreeplayState 完全一致的加载方式:
	`songLowercase = Paths.formatToSongPath(songName)` +
	`Highscore.formatSong(songLowercase, curDifficulty)` 得到文件基名,
	`Song.loadFromJson(基名, songLowercase)` 实际加载 (内部拼 `mods/data/<song>/<file>.json`)。
	转换谱面按同一规则写入: `mods/data/<songPath>/<songPath>-<diff>.json`
	(默认难度 = `<songPath>.json`), 保证双端哈希一致、能被 Song.loadFromJson 命中。
**/
class OnlineChartUtil
{
	/** 难度文件基名: 默认难度 = <songPath>, 其余 = <songPath>-<diffPath>。 */
	public static function diffFileBase(songPath:String, diffName:String):String
	{
		var d:String = Paths.formatToSongPath(diffName);
		var def:String = Paths.formatToSongPath(CoolUtil.defaultDifficulty);
		if (d == def)
			return songPath;
		return songPath + "-" + d;
	}

	/** 原版方式加载: 标准难度走 Highscore.formatSong, 自定义难度名走等价扩展。 */
	public static function loadChart(songName:String, diffName:String, ?modFolder:String):SwagSong
	{
		var songPath:String = Paths.formatToSongPath(songName);
		var idx:Int = CoolUtil.difficulties.indexOf(diffName);
		var fileBase:String;
		if (idx >= 0)
			fileBase = Highscore.formatSong(songPath, idx);
		else
			fileBase = diffFileBase(songPath, diffName);
		var prevModDir:String = Paths.currentModDirectory;
		if (modFolder != null && modFolder.length > 0)
			Paths.currentModDirectory = modFolder;
		var result:SwagSong = null;
		try
		{
			result = Song.loadFromJson(fileBase, songPath);
		}
		catch (e:Dynamic)
		{
			if (modFolder != null && modFolder.length > 0)
				Paths.currentModDirectory = prevModDir;
			throw e;
		}
		if (modFolder != null && modFolder.length > 0)
			Paths.currentModDirectory = prevModDir;
		return result;
	}

	/**
		是否为 Malody/osu! 等"导入转换谱": 只看磁盘上原始 JSON 的 format 字段。
		不能用 parseJSON 归一化后的 song.format 判断 —— 归一化会把所有旧格式谱面
		(包括原版谱) 统一盖上 psych_v1_convert, 导致原版谱被误判成转谱、房间被强制异步。
		传入空串 convertTo 跳过归一化, 拿到未加工的 format。
	**/
	public static function isConvertedChart(songName:String, diffName:String, ?modFolder:String):Bool
	{
		var songPath:String = Paths.formatToSongPath(songName);
		var idx:Int = CoolUtil.difficulties.indexOf(diffName);
		var fileBase:String;
		if (idx >= 0)
			fileBase = Highscore.formatSong(songPath, idx);
		else
			fileBase = diffFileBase(songPath, diffName);
		var prevModDir:String = Paths.currentModDirectory;
		if (modFolder != null && modFolder.length > 0)
			Paths.currentModDirectory = modFolder;
		var result:Bool = false;
		try
		{
			var raw:SwagSong = Song.loadFromJson(fileBase, songPath, '');
			result = raw != null && Reflect.field(raw, "format") == "psych_v1_convert";
		}
		catch (e:Dynamic)
		{
			result = false;
		}
		if (modFolder != null && modFolder.length > 0)
			Paths.currentModDirectory = prevModDir;
		return result;
	}

	/** 从 mods/data/<songPath>/ 扫描出的文件名反推难度名 (兼容旧版 `<diff>.json` 布局)。 */
	public static function diffNameFromFile(songPath:String, fileName:String):String
	{
		if (fileName == null || !fileName.endsWith(".json"))
			return fileName;
		var base:String = fileName.substr(0, fileName.length - 5);
		if (base == songPath)
			return CoolUtil.defaultDifficulty;
		var prefix:String = songPath + "-";
		if (base.indexOf(prefix) == 0)
			return base.substr(prefix.length);
		return base;
	}
}
