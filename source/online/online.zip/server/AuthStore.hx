package online.server;

import haxe.Json;
import haxe.crypto.Sha256;
import online.shared.OnlineTypes.OnlineConst;
import online.shared.SeiunProtocol;

/**
	专用服务器账号系统 (重构版):
	- 用户名 + 密码, 密码只存 盐化迭代 SHA-256 (10000 轮), 不存明文;
	- 旧版单轮 SHA-256 哈希自动识别并在下次登录时原地升级;
	- 设备绑定策略可配置:
	    * 宽松 (默认): 密码是唯一凭证, 登录时自动记录/绑定当前设备,
	      换设备/重装游戏也能正常登录 (修复"同账号同密码登录失败"的 bug);
	    * 严格 (strictDeviceBinding=true): 保留旧行为 1 设备 = 1 账号;
	- 限制单 IP 可注册的账号数 (maxAccountsPerIp) 与注册冷却 (registerCooldownSeconds);
	- 登录失败计数 + 临时锁定 (loginFailLockoutCount / loginFailLockoutMinutes), 防爆破;
	- 会话 token 带过期时间 (sessionTtlDays), 持久化到 sessions.json, 重启不踢人;
	- 数据存本地 JSON, 原子写入 + 自动备份, 保存失败会输出日志而不是静默丢数据;
	- 封禁支持 账号/设备/IP, 带原因与过期时间 (until, 0 = 永久)。
**/
typedef StoredDevice =
{
	var deviceId:String;
	var lastSeenAt:Float;
	@:optional var nickname:String;
}

typedef StoredAccount =
{
	var username:String;
	var salt:String;
	var passwordHash:String;
	/** "sha256" (旧单轮) / "sha256x10000" (当前)。缺省视为旧格式, 登录时自动升级。 */
	@:optional var hashAlgo:String;
	var deviceId:String;
	@:optional var devices:Array<StoredDevice>;
	var role:String;
	var banned:Bool;
	@:optional var bannedReason:String;
	@:optional var registerIp:String;
	@:optional var registerAt:Float;
	var createdAt:Float;
	@:optional var lastLoginAt:Float;
	@:optional var lastLoginIp:String;
	@:optional var loginFailures:Int;
	@:optional var lockedUntil:Float;
	@:optional var updatedAt:Float;
}

typedef StoredBan =
{
	var target:String;
	var kind:String;
	var reason:String;
	var at:Float;
	/** 过期时间戳 (毫秒), 0 = 永久。 */
	@:optional var until:Float;
	@:optional var createdBy:String;
	/** true = 封账号时自动连带生成的设备封禁, 解封账号时一并移除。 */
	@:optional var auto:Bool;
}

typedef StoredSession =
{
	var token:String;
	var username:String;
	var createdAt:Float;
	var expiresAt:Float;
	@:optional var ip:String;
}

class AuthStore
{
	public static inline var HASH_ALGO_LEGACY:String = "sha256";
	public static inline var HASH_ALGO_CURRENT:String = "sha256x10000";
	public static inline var HASH_ITERATIONS:Int = 10000;

	public var accounts:Array<StoredAccount> = [];
	public var bans:Array<StoredBan> = [];
	public var whitelist:Array<String> = [];
	public var sessions:Array<StoredSession> = [];

	var path:String;
	var sessionsPath:String;
	var server:SeiunServer;

	public function new(server:SeiunServer)
	{
		this.server = server;
	}

	// ── 初始化 / 持久化 ─────────────────────────────────

	public function init(dataDir:String):Void
	{
		path = dataDir + "/accounts.json";
		sessionsPath = dataDir + "/sessions.json";
		#if sys
		try
		{
			if (sys.FileSystem.exists(path))
			{
				var raw:String = readTextFile(path);
				var json:Dynamic = Json.parse(raw);
				if (json != null)
				{
					if (Reflect.hasField(json, "accounts") && Std.isOfType(Reflect.field(json, "accounts"), Array))
						accounts = cast Reflect.field(json, "accounts");
					if (Reflect.hasField(json, "bans") && Std.isOfType(Reflect.field(json, "bans"), Array))
						bans = cast Reflect.field(json, "bans");
					if (Reflect.hasField(json, "whitelist") && Std.isOfType(Reflect.field(json, "whitelist"), Array))
						whitelist = cast Reflect.field(json, "whitelist");
				}
			}
		}
		catch (e:Dynamic)
		{
			server.log("[auth] accounts.json 读取失败: " + Std.string(e));
		}
		try
		{
			if (sys.FileSystem.exists(sessionsPath))
			{
				var rawS:String = readTextFile(sessionsPath);
				var jsonS:Dynamic = Json.parse(rawS);
				if (jsonS != null && Reflect.hasField(jsonS, "sessions") && Std.isOfType(Reflect.field(jsonS, "sessions"), Array))
					sessions = cast Reflect.field(jsonS, "sessions");
			}
		}
		catch (e:Dynamic)
		{
			server.log("[auth] sessions.json 读取失败: " + Std.string(e));
		}
		#end
		normalizeLoadedData();
		cleanExpiredSessions(Date.now().getTime());
		cleanExpiredBans(Date.now().getTime());
		if (sessions.length > 0)
			saveSessions();
	}

	/**
		读取文本文件并剥离 UTF-8 BOM。
		用记事本编辑过 JSON 的 Windows 用户保存时会带 BOM,
		不剥离会让 Json.parse 直接失败 (账号/配置"全部消失"的经典坑)。
	**/
	public static function readTextFile(path:String):String
	{
		var text:String = sys.io.File.getContent(path);
		if (text != null && text.length > 0 && text.charCodeAt(0) == 0xFEFF)
			text = text.substr(1);
		return text;
	}

	/** 兼容旧数据: 补齐缺失字段, 确保后续逻辑不因脏数据崩溃。 */
	function normalizeLoadedData():Void
	{
		for (a in accounts)
		{
			if (a == null)
				continue;
			if (a.username == null) a.username = "";
			if (a.salt == null) a.salt = makeSalt();
			if (a.passwordHash == null) a.passwordHash = "";
			if (a.role == null || a.role.length == 0) a.role = "player";
			if (a.deviceId == null) a.deviceId = "";
			if (a.devices == null || !Std.isOfType(a.devices, Array))
			{
				a.devices = [];
				if (a.deviceId.length > 0)
					a.devices.push({deviceId: a.deviceId, lastSeenAt: a.lastLoginAt > 0 ? a.lastLoginAt : a.createdAt});
			}
			if (a.loginFailures == null) a.loginFailures = 0;
			if (a.lockedUntil == null) a.lockedUntil = 0;
			a.banned = a.banned == true;
		}
	}

	/**
		原子保存: 先写 .tmp 再改名, 旧文件保留为 .bak。
		任何失败都会输出日志, 不再静默吞掉 (静默失败 = 重启后账号消失, 用户以为登录 bug)。
	**/
	public function save():Void
	{
		#if sys
		try
		{
			var tmp:String = path + ".tmp";
			var obj:Dynamic = {accounts: accounts, bans: bans, whitelist: whitelist};
			sys.io.File.saveContent(tmp, Json.stringify(obj, null, "  "));
			if (sys.FileSystem.exists(path))
			{
				var bak:String = path + ".bak";
				try
				{
					if (sys.FileSystem.exists(bak))
						sys.FileSystem.deleteFile(bak);
					sys.FileSystem.rename(path, bak);
				}
				catch (e:Dynamic) {}
			}
			sys.FileSystem.rename(tmp, path);
		}
		catch (e:Dynamic)
		{
			server.log("[auth] 保存 accounts.json 失败: " + Std.string(e) + " (数据仍在内存中)");
		}
		#end
	}

	public function saveSessions():Void
	{
		#if sys
		try
		{
			var tmp:String = sessionsPath + ".tmp";
			sys.io.File.saveContent(tmp, Json.stringify({sessions: sessions}, null, "  "));
			if (sys.FileSystem.exists(sessionsPath))
			{
				var bak:String = sessionsPath + ".bak";
				try
				{
					if (sys.FileSystem.exists(bak))
						sys.FileSystem.deleteFile(bak);
					sys.FileSystem.rename(sessionsPath, bak);
				}
				catch (e:Dynamic) {}
			}
			sys.FileSystem.rename(tmp, sessionsPath);
		}
		catch (e:Dynamic)
		{
			server.log("[auth] 保存 sessions.json 失败: " + Std.string(e));
		}
		#end
	}

	// ── 密码 / 令牌 ─────────────────────────────────────

	/** 当前算法: 盐化迭代 SHA-256。 */
	public function hashPassword(password:String, salt:String):String
	{
		var h:String = salt + "::seiun::" + password;
		for (i in 0...HASH_ITERATIONS)
			h = Sha256.encode(h);
		return h;
	}

	/** 旧算法 (单轮), 仅用于识别旧账号并升级。 */
	public function legacyHashPassword(password:String, salt:String):String
	{
		return Sha256.encode(salt + "::seiun::" + password);
	}

	public function makeSalt():String
	{
		return randomHex(16);
	}

	public function makeToken():String
	{
		return randomHex(32);
	}

	function randomHex(bytes:Int):String
	{
		var out:String = "";
		for (i in 0...bytes)
		{
			var b:Int = Std.random(256);
			var hi:Int = (b >> 4) & 0xF;
			var lo:Int = b & 0xF;
			out += "0123456789abcdef".charAt(hi) + "0123456789abcdef".charAt(lo);
		}
		return out;
	}

	// ── 注册 ────────────────────────────────────────────

	public function register(username:String, password:String, deviceId:String, ip:String):Dynamic
	{
		var now:Float = Date.now().getTime();
		username = cleanUsername(username);
		if (username.length < 3 || username.length > 24)
			return {ok: false, code: SeiunProtocol.ERR_AUTH_FAILED, message: "用户名长度需为 3-24 个字符"};
		if (password == null || password.length < 6)
			return {ok: false, code: SeiunProtocol.ERR_AUTH_FAILED, message: "密码至少 6 位"};
		if (deviceId == null || deviceId.length == 0)
			return {ok: false, code: SeiunProtocol.ERR_AUTH_FAILED, message: "缺少设备码"};
		if (ip == null)
			ip = "";

		for (a in accounts)
		{
			if (a.username.toLowerCase() == username.toLowerCase())
				return {ok: false, code: SeiunProtocol.ERR_USER_EXISTS, message: "用户名已存在"};
		}

		// 设备唯一性: 仅在严格模式下强制 (1 设备 = 1 账号)。
		if (server.config.strictDeviceBinding)
		{
			for (a in accounts)
				if (a.deviceId == deviceId || hasDevice(a, deviceId))
					return {ok: false, code: SeiunProtocol.ERR_DEVICE_BOUND, message: "此设备已绑定账号 " + a.username};
		}

		// IP 注册限制: 单 IP 账号数上限。
		var maxPerIp:Int = server.config.maxAccountsPerIp;
		if (maxPerIp > 0 && ip.length > 0)
		{
			var count:Int = 0;
			for (a in accounts)
				if (a.registerIp == ip)
					count++;
			if (count >= maxPerIp)
				return {ok: false, code: SeiunProtocol.ERR_TOO_MANY_ACCOUNTS,
					message: "该 IP 已注册 " + count + " 个账号 (上限 " + maxPerIp + ")，请更换网络或联系管理员"};
		}

		// IP 注册冷却。
		var cooldown:Float = server.config.registerCooldownSeconds;
		if (cooldown > 0 && ip.length > 0)
		{
			var lastReg:Float = 0;
			for (a in accounts)
				if (a.registerIp == ip && a.registerAt > lastReg)
					lastReg = a.registerAt;
			if (lastReg > 0 && now - lastReg < cooldown * 1000.0)
			{
				var left:Int = Math.ceil((cooldown * 1000.0 - (now - lastReg)) / 1000.0);
				return {ok: false, code: SeiunProtocol.ERR_REGISTER_COOLDOWN,
					message: "注册太频繁，请 " + left + " 秒后再试"};
			}
		}

		var salt:String = makeSalt();
		var account:StoredAccount = {
			username: username,
			salt: salt,
			passwordHash: hashPassword(password, salt),
			hashAlgo: HASH_ALGO_CURRENT,
			deviceId: deviceId,
			devices: [{deviceId: deviceId, lastSeenAt: now}],
			role: accounts.length == 0 ? "admin" : "player",
			banned: false,
			registerIp: ip,
			registerAt: now,
			createdAt: now,
			lastLoginAt: now,
			lastLoginIp: ip,
			loginFailures: 0,
			lockedUntil: 0
		};
		accounts.push(account);
		save();

		// 直接签发会话, 不再回调 login() —— 旧实现里 register 成功后 login 因
		// 设备绑定检查失败会返回"失败", 造成"账号已创建但提示注册失败"的状态错乱。
		var token:String = makeToken();
		sessions.push({token: token, username: account.username, createdAt: now, expiresAt: now + sessionTtlMs(), ip: ip});
		saveSessions();
		server.log("[auth] 新账号注册: " + username + " (ip=" + ip + ", 第 " + accounts.length + " 个)");
		return {
			ok: true,
			token: token,
			username: account.username,
			role: account.role,
			message: "注册成功"
		};
	}

	// ── 登录 ────────────────────────────────────────────

	public function login(username:String, password:String, deviceId:String, ip:String):Dynamic
	{
		var now:Float = Date.now().getTime();
		username = cleanUsername(username);
		var account:StoredAccount = findAccount(username);
		if (account == null)
			return {ok: false, code: SeiunProtocol.ERR_USER_NOT_FOUND, message: "用户名不存在，请先注册"};
		if (account.banned)
		{
			// 原因与解封时间统一由 banErrorPayload 拼装 (账号封禁记录里存有 reason)。
			var banPayload:Dynamic = banErrorPayload("账号已被封禁", effectiveBanForAccount(account.username), now);
			banPayload.ok = false;
			return banPayload;
		}
		if (account.lockedUntil > now)
		{
			var left:Int = Math.ceil((account.lockedUntil - now) / 1000.0);
			return {ok: false, code: SeiunProtocol.ERR_ACCOUNT_LOCKED, message: "登录失败次数过多，账号已锁定 " + left + " 秒"};
		}

		// 严格模式下校验设备绑定 (旧行为); 宽松模式 (默认) 下密码即凭证。
		if (server.config.strictDeviceBinding)
		{
			if (account.deviceId != deviceId && !hasDevice(account, deviceId))
				return {ok: false, code: SeiunProtocol.ERR_DEVICE_BOUND, message: "账号已绑定其他设备"};
		}

		var passwordOk:Bool = verifyPassword(account, password);
		if (!passwordOk)
		{
			account.loginFailures = (account.loginFailures == null ? 0 : account.loginFailures) + 1;
			var maxFail:Int = server.config.loginFailLockoutCount;
			if (maxFail > 0 && account.loginFailures >= maxFail)
			{
				account.lockedUntil = now + server.config.loginFailLockoutMinutes * 60.0 * 1000.0;
				account.loginFailures = 0;
				account.updatedAt = now;
				save();
				return {ok: false, code: SeiunProtocol.ERR_ACCOUNT_LOCKED,
					message: "连续 " + maxFail + " 次密码错误，账号已锁定 " + server.config.loginFailLockoutMinutes + " 分钟"};
			}
			account.updatedAt = now;
			save();
			var left:Int = maxFail - account.loginFailures;
			return {ok: false, code: SeiunProtocol.ERR_BAD_PASSWORD, message: "密码错误" + (maxFail > 0 ? "（还可尝试 " + left + " 次）" : "")};
		}

		// 密码正确: 清除失败计数与锁定。
		account.loginFailures = 0;
		account.lockedUntil = 0;
		account.lastLoginAt = now;
		account.lastLoginIp = ip == null ? "" : ip;
		account.updatedAt = now;

		// 记录当前设备 (宽松模式自动绑定; 严格模式已在上面通过检查)。
		bindDevice(account, deviceId, now);

		var token:String = makeToken();
		sessions.push({token: token, username: account.username, createdAt: now, expiresAt: now + sessionTtlMs(), ip: ip == null ? "" : ip});
		save();
		saveSessions();
		server.log("[auth] 登录成功: " + account.username + " (ip=" + ip + ")");
		return {
			ok: true,
			token: token,
			username: account.username,
			role: account.role,
			message: "登录成功"
		};
	}

	/** 验证密码, 旧格式哈希自动升级为新格式。 */
	function verifyPassword(account:StoredAccount, password:String):Bool
	{
		if (account == null || account.salt == null || account.passwordHash == null || password == null)
			return false;
		var algo:String = account.hashAlgo == null ? HASH_ALGO_LEGACY : account.hashAlgo;
		if (algo == HASH_ALGO_CURRENT)
			return hashPassword(password, account.salt) == account.passwordHash;
		// 旧单轮格式: 验证通过则原地升级。
		if (legacyHashPassword(password, account.salt) == account.passwordHash)
		{
			account.hashAlgo = HASH_ALGO_CURRENT;
			account.passwordHash = hashPassword(password, account.salt);
			account.updatedAt = Date.now().getTime();
			return true;
		}
		return false;
	}

	function bindDevice(account:StoredAccount, deviceId:String, now:Float):Void
	{
		if (account == null || deviceId == null || deviceId.length == 0)
			return;
		if (account.devices == null)
			account.devices = [];
		for (d in account.devices)
		{
			if (d.deviceId == deviceId)
			{
				d.lastSeenAt = now;
				return;
			}
		}
		account.devices.push({deviceId: deviceId, lastSeenAt: now});
		// 设备数上限: 超出时移除最久未使用的设备。
		var maxDev:Int = server.config.maxDevicesPerAccount;
		if (maxDev > 0 && account.devices.length > maxDev)
		{
			account.devices.sort(function(a:StoredDevice, b:StoredDevice):Int
			{
				return a.lastSeenAt < b.lastSeenAt ? -1 : (a.lastSeenAt > b.lastSeenAt ? 1 : 0);
			});
			while (account.devices.length > maxDev)
				account.devices.shift();
		}
	}

	function hasDevice(account:StoredAccount, deviceId:String):Bool
	{
		if (account == null || account.devices == null)
			return false;
		for (d in account.devices)
			if (d.deviceId == deviceId)
				return true;
		return false;
	}

	function sessionTtlMs():Float
	{
		var days:Int = server.config.sessionTtlDays;
		if (days <= 0)
			days = 7;
		return days * 24.0 * 60.0 * 60.0 * 1000.0;
	}

	// ── 会话 ────────────────────────────────────────────

	public function accountForToken(token:String):StoredAccount
	{
		if (token == null || token.length == 0)
			return null;
		var now:Float = Date.now().getTime();
		var found:StoredSession = null;
		for (s in sessions)
		{
			if (s.token == token)
			{
				if (s.expiresAt > 0 && s.expiresAt < now)
				{
					sessions.remove(s);
					saveSessions();
					return null;
				}
				found = s;
				break;
			}
		}
		if (found == null)
			return null;
		var account:StoredAccount = findAccount(found.username);
		if (account == null)
		{
			sessions.remove(found);
			saveSessions();
			return null;
		}
		return account;
	}

	public function logout(token:String):Void
	{
		if (token == null)
			return;
		for (s in sessions)
			if (s.token == token)
			{
				sessions.remove(s);
				saveSessions();
				return;
			}
	}

	public function cleanExpiredSessions(now:Float):Void
	{
		var keep:Array<StoredSession> = [];
		for (s in sessions)
			if (s.expiresAt <= 0 || s.expiresAt >= now)
				keep.push(s);
		if (keep.length != sessions.length)
		{
			sessions = keep;
			saveSessions();
		}
	}

	// ── 封禁 ────────────────────────────────────────────

	public function isIpBanned(ip:String):Bool
	{
		if (ip == null || ip.length == 0)
			return false;
		var now:Float = Date.now().getTime();
		for (b in bans)
			if (b.kind == "ip" && b.target == ip)
			{
				if (b.until > 0 && b.until < now)
					continue;
				return true;
			}
		return false;
	}

	public function isDeviceBanned(deviceId:String):Bool
	{
		if (deviceId == null || deviceId.length == 0)
			return false;
		var now:Float = Date.now().getTime();
		for (b in bans)
			if (b.kind == "device" && b.target == deviceId)
			{
				if (b.until > 0 && b.until < now)
					continue;
				return true;
			}
		return false;
	}

	/** 返回当前生效的封禁记录 (未过期; 同目标多条时取永久或最晚到期的一条), 无则 null。 */
	public function effectiveBan(kind:String, target:String):StoredBan
	{
		if (target == null || target.length == 0)
			return null;
		var now:Float = Date.now().getTime();
		var best:StoredBan = null;
		for (b in bans)
		{
			if (b.kind != kind || b.target != target)
				continue;
			if (b.until > 0 && b.until < now)
				continue; // 已过期
			if (best == null)
				best = b;
			else if (b.until == 0 || (best.until > 0 && b.until > best.until))
				best = b;
		}
		return best;
	}

	/** 查询账号的生效封禁记录 (按用户名)。 */
	public function effectiveBanForAccount(username:String):StoredBan
	{
		if (username == null)
			return null;
		return effectiveBan("account", username);
	}

	/**
		组装封禁错误载荷: 消息里带封禁原因与解封时间 (客户端直接展示 message 即可),
		同时给出结构化字段 bannedUntil / bannedPermanent 供 UI 定制。
	**/
	public static function banErrorPayload(base:String, ban:StoredBan, now:Float):Dynamic
	{
		var until:Float = (ban == null || ban.until == null || Math.isNaN(ban.until)) ? 0 : ban.until;
		var permanent:Bool = until <= 0;
		var msg:String = base;
		// 封禁原因 (面板/命令填写的 reason)。
		var reason:String = ban == null ? "" : (ban.reason == null ? "" : ban.reason);
		if (reason.length > 0)
		{
			if (reason.length > 80)
				reason = reason.substr(0, 80) + "…";
			msg += "（原因: " + reason + "）";
		}
		if (permanent)
		{
			msg += "（永久）";
		}
		else
		{
			var leftSec:Int = Math.ceil((until - now) / 1000.0);
			if (leftSec > 0)
			{
				var d:Date = Date.fromTime(until);
				var two = function(n:Int):String return (n < 10 ? "0" : "") + n;
				var timeText:String = two(d.getMonth() + 1) + "-" + two(d.getDate()) + " " + two(d.getHours()) + ":" + two(d.getMinutes());
				var leftText:String = leftSec < 60 ? leftSec + " 秒"
					: (leftSec < 3600 ? Std.int(leftSec / 60) + " 分钟"
						: (leftSec < 86400 ? Std.int(leftSec / 3600) + " 小时" : Std.int(leftSec / 86400) + " 天"));
				msg += "，解封时间: " + timeText + "（约 " + leftText + " 后）";
			}
			else
				msg += "（即将解封）";
		}
		return {code: SeiunProtocol.ERR_BANNED, message: msg, bannedUntil: until, bannedPermanent: permanent};
	}

	/** 封禁账号/设备/IP。kind: account | device | ip。until: 毫秒时间戳, 0 = 永久。 */
	public function ban(target:String, kind:String, reason:String, ?until:Float, ?by:String):Void
	{
		if (target == null || target.length == 0)
			return;
		var now:Float = Date.now().getTime();
		if (until == null || Math.isNaN(until) || until <= 0)
			until = 0;
		// 同目标同类型已存在永久/更晚过期封禁时不重复添加。
		if (!addBanRecord(target, kind, reason, until, by, false))
			return;
		if (kind == "account")
		{
			for (a in accounts)
				if (a.username.toLowerCase() == target.toLowerCase())
				{
					a.banned = true;
					a.bannedReason = reason == null ? "" : reason;
					// 账号封禁自动连带封禁其全部绑定设备: 防止换账号/匿名连接绕过。
					if (a.devices != null)
						for (d in a.devices)
							addBanRecord(d.deviceId, "device", reason == null ? "账号 " + a.username + " 被封禁" : reason, until, by, true);
				}
		}
		else if (kind == "device")
		{
			for (a in accounts)
				if (a.deviceId == target || hasDevice(a, target))
				{
					a.banned = true;
					a.bannedReason = reason == null ? "" : reason;
				}
		}
		save();
	}

	/** 添加一条封禁记录 (自动设备封禁与手动封禁共用), 已存在更严记录时跳过。 */
	function addBanRecord(target:String, kind:String, reason:String, until:Float, by:String, auto:Bool):Bool
	{
		if (target == null || target.length == 0)
			return false;
		for (b in bans)
		{
			if (b.kind == kind && b.target == target)
			{
				// 已有永久封禁, 或现有过期时间 >= 新请求 → 不需要再添加。
				if (b.until == 0 || (until > 0 && b.until >= until))
					return false;
			}
		}
		bans.push({target: target, kind: kind, reason: reason == null ? "" : reason, at: Date.now().getTime(), until: until, createdBy: by == null ? "" : by, auto: auto});
		return true;
	}

	/** 解封: 只移除匹配的记录, 只解封对应的账号 (不再误伤同设备/同名的其它账号)。 */
	public function unban(target:String, kind:String):Void
	{
		var keep:Array<StoredBan> = [];
		for (b in bans)
			if (!(b.kind == kind && b.target == target))
				keep.push(b);
		bans = keep;
		if (kind == "account")
		{
			var account:StoredAccount = findAccount(target);
			if (account != null && account.devices != null)
			{
				// 移除封账号时自动生成的设备封禁 (手动封的设备保留)。
				var keep2:Array<StoredBan> = [];
				for (b in bans)
				{
					var isAutoDevice:Bool = b.kind == "device" && b.auto == true;
					var belongs:Bool = false;
					if (isAutoDevice)
						for (d in account.devices)
							if (d.deviceId == b.target)
							{
								belongs = true;
								break;
							}
					if (!belongs)
						keep2.push(b);
				}
				bans = keep2;
			}
			for (a in accounts)
				if (a.username.toLowerCase() == target.toLowerCase())
				{
					a.banned = false;
					a.bannedReason = null;
				}
		}
		else if (kind == "device")
		{
			for (a in accounts)
				if (a.deviceId == target || hasDevice(a, target))
				{
					a.banned = false;
					a.bannedReason = null;
				}
		}
		save();
	}

	public function cleanExpiredBans(now:Float):Void
	{
		var keep:Array<StoredBan> = [];
		for (b in bans)
			if (b.until <= 0 || b.until >= now)
				keep.push(b);
		if (keep.length != bans.length)
		{
			bans = keep;
			save();
		}
	}

	public function bansList():Array<Dynamic>
	{
		var out:Array<Dynamic> = [];
		for (b in bans)
			out.push({target: b.target, kind: b.kind, reason: b.reason, at: b.at, until: b.until == null ? 0 : b.until, createdBy: b.createdBy == null ? "" : b.createdBy, auto: b.auto == true});
		return out;
	}

	// ── 管理接口 ────────────────────────────────────────

	public function findAccount(username:String):StoredAccount
	{
		if (username == null)
			return null;
		var key:String = username.toLowerCase();
		for (a in accounts)
			if (a.username != null && a.username.toLowerCase() == key)
				return a;
		return null;
	}

	/** 返回脱敏账号列表 (供管理面板/命令使用, 不含密码与盐)。 */
	public function accountsList():Array<Dynamic>
	{
		var out:Array<Dynamic> = [];
		for (a in accounts)
			out.push(publicAccount(a));
		return out;
	}

	public function publicAccount(a:StoredAccount):Dynamic
	{
		var devices:Array<Dynamic> = [];
		if (a.devices != null)
			for (d in a.devices)
				devices.push({deviceId: d.deviceId, lastSeenAt: d.lastSeenAt});
		return {
			username: a.username,
			role: a.role,
			banned: a.banned == true,
			bannedReason: a.bannedReason == null ? "" : a.bannedReason,
			registerIp: a.registerIp == null ? "" : a.registerIp,
			registerAt: a.registerAt == null ? 0 : a.registerAt,
			createdAt: a.createdAt,
			lastLoginAt: a.lastLoginAt == null ? 0 : a.lastLoginAt,
			lastLoginIp: a.lastLoginIp == null ? "" : a.lastLoginIp,
			loginFailures: a.loginFailures == null ? 0 : a.loginFailures,
			lockedUntil: a.lockedUntil == null ? 0 : a.lockedUntil,
			devices: devices
		};
	}

	public function setRole(username:String, role:String):Dynamic
	{
		var account:StoredAccount = findAccount(username);
		if (account == null)
			return {ok: false, message: "账号不存在"};
		if (role != "admin" && role != "player")
			return {ok: false, message: "角色只能是 admin 或 player"};
		account.role = role;
		account.updatedAt = Date.now().getTime();
		save();
		return {ok: true, message: "已将 " + account.username + " 设为 " + role};
	}

	public function resetPassword(username:String, newPassword:String):Dynamic
	{
		var account:StoredAccount = findAccount(username);
		if (account == null)
			return {ok: false, message: "账号不存在"};
		if (newPassword == null || newPassword.length < 6)
			return {ok: false, message: "新密码至少 6 位"};
		var now:Float = Date.now().getTime();
		account.salt = makeSalt();
		account.passwordHash = hashPassword(newPassword, account.salt);
		account.hashAlgo = HASH_ALGO_CURRENT;
		account.loginFailures = 0;
		account.lockedUntil = 0;
		account.updatedAt = now;
		// 重置密码后吊销该账号的全部会话, 防旧 token 继续使用。
		var keep:Array<StoredSession> = [];
		for (s in sessions)
			if (s.username.toLowerCase() != account.username.toLowerCase())
				keep.push(s);
		sessions = keep;
		save();
		saveSessions();
		return {ok: true, message: "已重置 " + account.username + " 的密码并注销其全部会话"};
	}

	public function setBanned(username:String, banned:Bool, reason:String):Dynamic
	{
		var account:StoredAccount = findAccount(username);
		if (account == null)
			return {ok: false, message: "账号不存在"};
		account.banned = banned;
		account.bannedReason = banned ? (reason == null ? "" : reason) : null;
		account.updatedAt = Date.now().getTime();
		if (banned)
		{
			// 同步记录一条 account 封禁 (便于面板查看), 避免重复。
			ban(username, "account", reason == null ? "" : reason);
		}
		else
		{
			unban(username, "account");
		}
		save();
		return {ok: true, message: (banned ? "已封禁 " : "已解封 ") + account.username};
	}

	/** 删除账号 (仅管理面板/命令使用, 谨慎操作)。 */
	public function deleteAccount(username:String):Dynamic
	{
		var account:StoredAccount = findAccount(username);
		if (account == null)
			return {ok: false, message: "账号不存在"};
		var keep:Array<StoredAccount> = [];
		for (a in accounts)
			if (a != account)
				keep.push(a);
		accounts = keep;
		var keepS:Array<StoredSession> = [];
		for (s in sessions)
			if (s.username.toLowerCase() != username.toLowerCase())
				keepS.push(s);
		sessions = keepS;
		save();
		saveSessions();
		return {ok: true, message: "已删除账号 " + username};
	}

	public function accountCount():Int
	{
		return accounts.length;
	}

	/** 某 IP 已注册的账号数 (面板/命令展示)。 */
	public function accountCountForIp(ip:String):Int
	{
		if (ip == null || ip.length == 0)
			return 0;
		var n:Int = 0;
		for (a in accounts)
			if (a.registerIp == ip)
				n++;
		return n;
	}

	public static function cleanUsername(value:String):String
	{
		if (value == null)
			return "";
		return StringTools.trim(OnlineConst.sanitizeNickname(value));
	}
}
