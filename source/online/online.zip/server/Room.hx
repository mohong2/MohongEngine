package online.server;

import online.shared.JudgeCore;
import online.shared.OnlineTypes;
import online.shared.OnlineTypes.ChartSelection;
import online.shared.OnlineTypes.JudgeResult;
import online.shared.OnlineTypes.ModManifest;
import online.shared.OnlineTypes.RoomPublicInfo;
import online.shared.OnlineTypes.RoomSettings;
import online.shared.OnlineTypes.ScoreRecord;
import online.shared.SeiunProtocol;

/**
	一个联机房间。所有字段只在服务器网络线程内访问。
**/
class Room
{
	public var roomCode:String;
	public var hostId:String;
	public var settings:RoomSettings;
	public var players:Array<ServerClient> = [];
	/** 观战者: 不占游玩席位, 收到全部房间广播但不参与判定/准备/门闩。 */
	public var spectators:Array<ServerClient> = [];
	/** 观战席位上限。 */
	public static inline var MAX_SPECTATORS:Int = 8;
	public var chart:ChartSelection = null;
	public var status:String = online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_LOBBY;
	public var createdAt:Float;
	public var selectedSongHash:String = "";
	public var asyncScores:Map<String, ScoreRecord> = new Map<String, ScoreRecord>();
	public var asyncStates:Map<String, String> = new Map<String, String>();
	public var asyncStartedAt:Map<String, Float> = new Map<String, Float>();
	public var realtimeResults:Map<String, ScoreRecord> = new Map<String, ScoreRecord>();
	/** 实时模式先上传的回放 (成绩消息前到达), 成绩落地时合并。 */
	public var pendingReplayUploads:Map<String, String> = new Map<String, String>();
	public var authoritativeScores:Map<String, ScoreRecord> = new Map<String, ScoreRecord>();
	public var authoritativeCombo:Map<String, Int> = new Map<String, Int>();
	public var countdownLeft:Float = 0;
	public var lastCountdownSecond:Int = 3;
	/** 倒计时被联机暂停挂起 (有人在 3-2-1 阶段暂停, 恢复前不再计时)。 */
	public var countdownPaused:Bool = false;
	public var gameStartedAt:Float = 0;
	public var finalized:Bool = false;
	public var crashNotices:Array<Dynamic> = [];
	public var noteTimesByLane:Map<Int, Array<Float>> = new Map<Int, Array<Float>>();
	public var chartNoteCount:Int = 0;
	public var judgedNotes:Map<String, Bool> = new Map<String, Bool>();

	/**
		实时统一起跑: 记录哪些真人玩家已把 PlayState 加载完成并上传了谱面时间轴。
		全部到齐后服务器才广播 MSG_GAME_SYNC, 因此慢设备不会带着 stale
		startOnTime 起跑 (PsychOnline 的 playerReady 收尾等价物)。
	**/
	public var gameReadyIds:Map<String, Bool> = new Map<String, Bool>();
	/**
		起跑门闩: 玩家加载完成后倒计时冻结, 本人按下 空格/回车 确认才记录。
		全员确认才广播 MSG_GAME_SYNC (PsychOnline 全员确认起跑)。
	**/
	public var startGateIds:Map<String, Bool> = new Map<String, Bool>();
	public var realtimeSyncServerStartMs:Float = 0;
	public var realtimeSyncBroadcastUntilMs:Float = 0;
	public var lastRealtimeSyncRebroadcastMs:Float = 0;

	public function allRealPlayersUploadedTimeline():Bool
	{
		var anyReal:Bool = false;
		for (p in players)
		{
			anyReal = true;
			if (!gameReadyIds.exists(p.id))
				return false;
		}
		return anyReal;
	}

	/** 起跑门闩判定: 房间内所有真人玩家都已按下确认键。 */
	public function allRealPlayersConfirmedStart():Bool
	{
		var anyReal:Bool = false;
		for (p in players)
		{
			anyReal = true;
			if (!startGateIds.exists(p.id))
				return false;
		}
		return anyReal;
	}

	/** 门闩进度: [已确认数, 真人玩家总数]。 */
	public function startGateProgress():{confirmed:Int, total:Int}
	{
		var confirmed:Int = 0;
		var total:Int = 0;
		for (p in players)
		{
			total++;
			if (startGateIds.exists(p.id))
				confirmed++;
		}
		return {confirmed: confirmed, total: total};
	}

	/** 房主发送的模组清单, 作为房间内模组同步的基准。 */
	public var hostManifest:ModManifest = null;
	public var clientManifests:Map<String, ModManifest> = new Map<String, ModManifest>();
	/** 每个玩家还缺多少个模组文件 (由服务器按 ACK 扣减)。 */
	public var modsMissingCount:Map<String, Int> = new Map<String, Int>();

	public function new(host:ServerClient, settings:RoomSettings)
	{
		this.hostId = host.id;
		this.settings = settings;
		this.createdAt = Date.now().getTime();
		this.roomCode = settings.roomCode;
	}

	public function host():ServerClient
	{
		for (p in players)
			if (p.id == hostId)
				return p;
		return null;
	}

	public function playerById(id:String):ServerClient
	{
		for (p in players)
			if (p.id == id)
				return p;
		return null;
	}

	public function spectatorById(id:String):ServerClient
	{
		for (s in spectators)
			if (s.id == id)
				return s;
		return null;
	}

	/** 观战加入 (不占游玩席位); 已在游玩列表/观战列表则拒绝。 */
	public function addSpectator(client:ServerClient):Bool
	{
		if (playerById(client.id) != null || spectatorById(client.id) != null)
			return false;
		if (spectators.length >= MAX_SPECTATORS)
			return false;
		spectators.push(client);
		client.room = this;
		client.team = -1;
		client.isReady = false;
		return true;
	}

	public function removeSpectator(client:ServerClient):Void
	{
		var keep:Array<ServerClient> = [];
		for (s in spectators)
			if (s.id != client.id)
				keep.push(s);
		spectators = keep;
		if (client.room == this)
			client.room = null;
	}

	public function addPlayer(client:ServerClient, ?ignoreFull:Bool = false):Bool
	{
		if (playerById(client.id) != null)
			return false;
		if (!ignoreFull && players.length >= settings.maxPlayers)
			return false;
		var perTeam:Int = settings.teamSize > 0 ? settings.teamSize : 1;
		client.team = Math.floor(players.length / perTeam) % 2;
		players.push(client);
		client.room = this;
		asyncStates.set(client.id, online.shared.OnlineTypes.OnlineConst.ASYNC_STATE_NOT_STARTED);
		modsMissingCount.set(client.id, 0);
		return true;
	}

	public function removePlayer(client:ServerClient):Void
	{
		var keep:Array<ServerClient> = [];
		for (p in players)
			if (p.id != client.id)
				keep.push(p);
		players = keep;
		clientManifests.remove(client.id);
		modsMissingCount.remove(client.id);
		gameReadyIds.remove(client.id);
		startGateIds.remove(client.id);
		pendingReplayUploads.remove(client.id);
		client.room = null;
	}

	public function isEmpty():Bool
	{
		return players.length == 0;
	}

	public function allReady():Bool
	{
		var anyReal:Bool = false;
		for (p in players)
		{
			anyReal = true;
			if (!p.isReady)
				return false;
		}
		return anyReal;
	}

	public function allHashesMatch():Bool
	{
		if (chart == null || selectedSongHash == null || selectedSongHash.length == 0)
			return false;
		for (p in players)
		{
			if (p.chartHash == null || p.chartHash != selectedSongHash)
				return false;
		}
		return true;
	}

	public function hashMismatchNames():Array<String>
	{
		var out:Array<String> = [];
		for (p in players)
		{
			var hash:String = p.chartHash == null ? "" : p.chartHash;
			if (hash != selectedSongHash)
				out.push(p.displayName() + (hash.length == 0 ? "（未上报谱面哈希）" : "（谱面不一致）"));
		}
		return out;
	}

	public function allReadyAndHashesMatch():Bool
	{
		return allReady() && allHashesMatch();
	}

	public function publicInfo():RoomPublicInfo
	{
		var h:ServerClient = host();
		var publicSettings:RoomSettings = {
			roomName: settings.roomName,
			mode: settings.mode,
			maxPlayers: settings.maxPlayers,
			antiCheat: settings.antiCheat,
			password: "",
			roomCode: settings.roomCode,
			judgementPreset: settings.judgementPreset,
			judgementTimings: settings.judgementTimings,
			marvelousRatings: settings.marvelousRatings,
			pausePolicy: settings.pausePolicy == null ? online.shared.OnlineTypes.OnlineConst.PAUSE_EVERYONE : settings.pausePolicy,
			compatibilityMode: settings.compatibilityMode,
			allowDuplicateNames: settings.allowDuplicateNames,
			teamSize: settings.teamSize,
			stageName: settings.stageName == null ? "" : settings.stageName,
			compatEngine: settings.compatEngine == null ? "" : settings.compatEngine
		};
		var info:RoomPublicInfo = {
			roomCode: roomCode,
			roomName: settings.roomName,
			hostId: hostId,
			hostNickname: h == null ? "" : h.displayName(),
			mode: settings.mode,
			playerCount: players.length,
			maxPlayers: settings.maxPlayers,
			antiCheat: settings.antiCheat,
			hasPassword: settings.password != null && settings.password.length > 0,
			status: status,
			settings: publicSettings
		};
		info.spectatorCount = spectators.length;
		if (chart != null)
			info.chart = chart;
		return info;
	}

	public function playerInfos():Array<Dynamic>
	{
		var out:Array<Dynamic> = [];
		for (p in players)
			out.push(p.publicInfo());
		// 观战者追加在游玩者之后, 带 isSpectator 标记供客户端分组渲染。
		for (s in spectators)
		{
			var info:Dynamic = s.publicInfo();
			Reflect.setField(info, "isSpectator", true);
			out.push(info);
		}
		return out;
	}

	/** 广播给房间内所有人 (游玩者 + 观战者)。 */
	public function broadcast(type:Int, obj:Dynamic, exceptId:String = null, channel:Int = SeiunProtocol.CHANNEL_ROOM):Void
	{
		for (p in players)
		{
			if (exceptId != null && p.id == exceptId)
				continue;
			p.send(type, channel, obj);
		}
		for (s in spectators)
		{
			if (exceptId != null && s.id == exceptId)
				continue;
			s.send(type, channel, obj);
		}
	}

	public function broadcastChat(sender:ServerClient, text:String):Void
	{
		var clean:String = online.shared.OnlineTypes.OnlineConst.sanitizeChat(text);
		var server:SeiunServer = cast sender.server;
		if (server != null && server.scriptHost != null)
			server.scriptHost.call("onChat", [roomCode, sender.displayName(), clean]);
		broadcast(SeiunProtocol.MSG_ROOM_CHAT, {
			fromId: sender.id,
			fromNickname: sender.displayName(),
			avatar: sender.identity.avatar,
			text: clean,
			at: Date.now().getTime()
		});
	}

	public function roomInfoMessage():Void
	{
		broadcast(SeiunProtocol.MSG_ROOM_INFO, roomInfoPayload());
	}

	public function roomInfoPayload():Dynamic
	{
		return {
			room: publicInfo(),
			players: playerInfos(),
			chart: chart,
			status: status,
			finalized: finalized
		};
	}

	public function broadcastAsyncStatus():Void
	{
		var list:Array<Dynamic> = [];
		for (p in players)
		{
			var st:String = asyncStates.get(p.id);
			if (st == null)
				st = online.shared.OnlineTypes.OnlineConst.ASYNC_STATE_NOT_STARTED;
			var obj:Dynamic = {
				deviceId: p.identity.deviceId,
				id: p.id,
				nickname: p.displayName(),
				avatar: p.identity.avatar,
				state: st
			};
			if (asyncScores.exists(p.id))
				obj.score = publicScore(asyncScores.get(p.id));
			list.push(obj);
		}
		broadcast(SeiunProtocol.MSG_ASYNC_STATUS, {players: list, finalized: finalized}, null, SeiunProtocol.CHANNEL_ASYNC);
	}

	public function applyAsyncScore(client:ServerClient, score:ScoreRecord):Void
	{
		score.nickname = client.displayName();
		score.avatar = client.identity.avatar;
		score.finishedAt = Date.now().getTime();
		asyncScores.set(client.id, score);
		asyncStates.set(client.id, online.shared.OnlineTypes.OnlineConst.ASYNC_STATE_FINISHED);
		broadcastAsyncStatus();
	}

	public function rankingPayload():Array<Dynamic>
	{
		var list:Array<Dynamic> = [];
		var seen:Map<String, Bool> = new Map<String, Bool>();
		// 先列已提交成绩 (含已离开房间但成绩保留的玩家)。
		for (id in asyncScores.keys())
		{
			var score:ScoreRecord = asyncScores.get(id);
			if (score != null)
				list.push(publicScore(score));
			seen.set(id, true);
		}
		for (p in players)
		{
			if (seen.exists(p.id))
				continue;
			list.push({
				deviceId: p.identity.deviceId,
				nickname: p.displayName(),
				avatar: p.identity.avatar,
				score: 0,
				accuracy: 0,
				maxCombo: 0,
				misses: 0,
				marvelous: 0,
				sick: 0,
				good: 0,
				bad: 0,
				shit: 0,
				completed: false,
				finishedAt: 0
			});
		}
		list.sort(function(a:Dynamic, b:Dynamic):Int
		{
			var sa:Float = Reflect.field(a, "score");
			var sb:Float = Reflect.field(b, "score");
			if (sa != sb)
				return sb > sa ? 1 : -1;
			var aa:Float = Reflect.field(a, "accuracy");
			var ab:Float = Reflect.field(b, "accuracy");
			if (aa != ab)
				return ab > aa ? 1 : -1;
			var fa:Float = Reflect.field(a, "finishedAt");
			var fb:Float = Reflect.field(b, "finishedAt");
			if (fa != fb)
				return fa < fb ? -1 : 1;
			return 0;
		});
		return list;
	}

	public function applyAuthoritativeJudge(client:ServerClient, judge:JudgeResult):Void
	{
		var score:ScoreRecord = authoritativeScores.get(client.id);
		if (score == null)
		{
			score = {
				deviceId: client.identity.deviceId,
				nickname: client.displayName(),
				avatar: client.identity.avatar,
				score: 0,
				accuracy: 0,
				maxCombo: 0,
				misses: 0,
				marvelous: 0,
				sick: 0,
				good: 0,
				bad: 0,
				shit: 0,
				completed: true,
				finishedAt: Date.now().getTime()
			};
			authoritativeScores.set(client.id, score);
			authoritativeCombo.set(client.id, 0);
		}

		switch (judge.rating)
		{
			case JudgeCore.RATING_MARVELOUS: score.marvelous++;
			case JudgeCore.RATING_SICK: score.sick++;
			case JudgeCore.RATING_GOOD: score.good++;
			case JudgeCore.RATING_BAD: score.bad++;
			case JudgeCore.RATING_SHIT: score.shit++;
			default:
		}

		if (judge.rating == JudgeCore.RATING_SHIT)
		{
			authoritativeCombo.set(client.id, 0);
			score.misses++;
		}
		else
		{
			var combo:Int = authoritativeCombo.get(client.id) + 1;
			authoritativeCombo.set(client.id, combo);
			if (combo > score.maxCombo)
				score.maxCombo = combo;
		}

		var added:Int = JudgeCore.ratingScore(judge.rating);
		score.score += added;
		score.finishedAt = Date.now().getTime();
		score.accuracy = JudgeCore.accuracy(score.marvelous, score.sick, score.good, score.bad, score.shit);
	}

	function publicScore(score:ScoreRecord):Dynamic
	{
		// 注意: 不带 replayJson —— 回放可达数 MB, 混进排行广播会超单帧上限;
		// 结算页按需通过 MSG_ASYNC_REPLAY_FETCH 向服务器拉取单个玩家回放。
		return {
			deviceId: score.deviceId,
			nickname: score.nickname,
			avatar: score.avatar,
			score: score.score,
			accuracy: score.accuracy,
			maxCombo: score.maxCombo,
			misses: score.misses,
			marvelous: score.marvelous,
			sick: score.sick,
			good: score.good,
			bad: score.bad,
			shit: score.shit,
			completed: score.completed,
			finishedAt: score.finishedAt,
			nps: score.nps,
			replayVerified: score.replayVerified
		};
	}

	public function realtimeRanking():Array<ScoreRecord>
	{
		var list:Array<ScoreRecord> = [];
		for (p in players)
		{
			var score:ScoreRecord = realtimeResults.get(p.id);
			if (score != null)
				list.push(score);
			else
				list.push({
					deviceId: p.identity.deviceId,
					nickname: p.displayName(),
					avatar: p.identity.avatar,
					score: 0,
					accuracy: 0,
					maxCombo: 0,
					misses: 0,
					marvelous: 0,
					sick: 0,
					good: 0,
					bad: 0,
					shit: 0,
					completed: false,
					finishedAt: 0
				});
		}
		list.sort(function(a:ScoreRecord, b:ScoreRecord):Int
		{
			if (a.score != b.score)
				return b.score > a.score ? 1 : -1;
			if (a.accuracy != b.accuracy)
				return b.accuracy > a.accuracy ? 1 : -1;
			return a.finishedAt < b.finishedAt ? -1 : 1;
		});
		return list;
	}

	public function authoritativeRanking():Array<ScoreRecord>
	{
		var list:Array<ScoreRecord> = [];
		for (id in authoritativeScores.keys())
		{
			var score:ScoreRecord = authoritativeScores.get(id);
			if (score != null)
				list.push(score);
		}
		for (p in players)
		{
			if (authoritativeScores.exists(p.id))
				continue;
			list.push({
				deviceId: p.identity.deviceId,
				nickname: p.displayName(),
				avatar: p.identity.avatar,
				score: 0,
				accuracy: 0,
				maxCombo: 0,
				misses: 0,
				marvelous: 0,
				sick: 0,
				good: 0,
				bad: 0,
				shit: 0,
				completed: false,
				finishedAt: 0
			});
		}
		list.sort(function(a:ScoreRecord, b:ScoreRecord):Int
		{
			if (a.score != b.score)
				return b.score > a.score ? 1 : -1;
			if (a.accuracy != b.accuracy)
				return b.accuracy > a.accuracy ? 1 : -1;
			return a.finishedAt < b.finishedAt ? -1 : 1;
		});
		return list;
	}

	public function noticeForAll(text:String):Void
	{
		broadcast(SeiunProtocol.MSG_ROOM_ANNOUNCE, {text: text, at: Date.now().getTime()});
	}
}
