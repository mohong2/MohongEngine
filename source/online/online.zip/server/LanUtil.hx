package online.server;

using StringTools;

/**
	打印/获取本机局域网 IPv4 地址。
	优先用系统自带命令解析, 不引入第三方网络库。

	排序策略 (Windows 按 ipconfig 适配器分节):
	1. 有"默认网关"的适配器排最前 —— 那才是真正连上局域网/虚拟网的网卡
	   (VMware/Hyper-V/WSL 等虚拟适配器通常没有网关);
	2. 同一档内按私有网段排序: 192.168.x  >  10.x  >  172.16-31.x  >  其它;
	3. 过滤 APIPA 169.254.x.x (网卡没拿到 DHCP 的地址) 与 127.0.0.1/0.0.0.0。

	本机网卡过多时, 单行 UI 请用 displayText() 折叠, 避免 IP 列表溢出面板。
**/
class LanUtil
{
	public static function detectAddresses():Array<String>
	{
		var out:Array<String> = [];
		#if sys
		// 用运行时系统名而不是 #if windows: 游戏 (lime) 构建会定义 windows, 但专用服务器
		// (server/build.hxml) 和裸 haxe -cpp 不定义, 否则会静默走错分支。
		var isWindows:Bool = Sys.systemName().toLowerCase().indexOf("windows") >= 0;
		if (isWindows)
			detectWindows(out);
		else
			detectUnix(out);
		if (out.length == 0)
		{
			try
			{
				var localHost:sys.net.Host = new sys.net.Host(sys.net.Host.localhost());
				var local:String = localHost.toString();
				if (local != null && local.length > 0 && local != "127.0.0.1")
					out.push(local);
			}
			catch (e:Dynamic) {}
		}
		if (out.length == 0)
			out.push("127.0.0.1");
		#end
		return out;
	}

	/** UI 展示用: 取前 max 条 IP 拼成单行, 超出部分折叠为 " +N", 避免多网卡时溢出。 */
	public static function displayText(ips:Array<String>, max:Int = 2):String
	{
		if (ips == null || ips.length == 0)
			return "127.0.0.1";
		var shown:Array<String> = ips.slice(0, max);
		var extra:Int = ips.length - shown.length;
		var text:String = shown.join("  ");
		if (extra > 0)
			text += "  +" + extra;
		return text;
	}

	static function detectWindows(out:Array<String>):Void
	{
		var text:String = runProcess("ipconfig", []);
		if (text.length == 0)
			return;

		var lines:Array<String> = text.split("\n");
		// 按适配器分节: 节头是顶格且含 "适配器"/"adapter" 的行 (中英文系统通用)。
		var sections:Array<{ips:Array<String>, hasGateway:Bool}> = [];
		var cur:{ips:Array<String>, hasGateway:Bool} = null;
		for (i in 0...lines.length)
		{
			var line:String = lines[i];
			var trimmed:String = line.trim();
			var topLevel:Bool = trimmed.length > 0 && line.charAt(0) != ' ' && line.charAt(0) != '\t';
			if (topLevel && (trimmed.indexOf("适配器") >= 0 || trimmed.toLowerCase().indexOf("adapter") >= 0))
			{
				cur = {ips: [], hasGateway: false};
				sections.push(cur);
				continue;
			}
			if (cur == null)
				continue;

			var low:String = line.toLowerCase();
			var idx:Int = low.indexOf("ipv4");
			if (idx >= 0)
			{
				var rest:String = line.substr(idx + 4);
				var colon:Int = rest.indexOf(":");
				if (colon >= 0)
				{
					var ip:String = rest.substr(colon + 1).trim();
					if (isUsefulIp(ip) && !cur.ips.contains(ip))
						cur.ips.push(ip);
				}
			}
			// 网关值可能在本行 (如 26.0.0.1) 也可能在下一行 (IPv6 网关后另起一行的 IPv4)。
			if (low.indexOf("默认网关") >= 0 || low.indexOf("default gateway") >= 0)
			{
				if (containsUsefulIp(line) || (i + 1 < lines.length && containsUsefulIp(lines[i + 1])))
					cur.hasGateway = true;
			}
		}

		var ranked:Array<{ip:String, score:Int, idx:Int}> = [];
		for (sec in sections)
		{
			for (ip in sec.ips)
				ranked.push({ip: ip, score: (sec.hasGateway ? 0 : 8) + privateRank(ip), idx: ranked.length});
		}
		// Haxe 的 sort 不保证稳定, 用原始序号做平局判定。
		ranked.sort(function(a, b):Int
		{
			if (a.score != b.score)
				return a.score - b.score;
			return a.idx - b.idx;
		});
		for (r in ranked)
		{
			if (!out.contains(r.ip))
				out.push(r.ip);
		}
	}
	static function detectUnix(out:Array<String>):Void
	{
		var text:String = runProcess("sh", ["-c", "hostname -I 2>/dev/null || ifconfig 2>/dev/null"]);
		if (text.length > 0)
		{
			var parts:Array<String> = text.split(" ");
			for (part in parts)
			{
				var ip:String = part.trim();
				if (ip.indexOf("\n") >= 0)
				{
					for (sub in ip.split("\n"))
						if (isUsefulIp(sub.trim()) && !out.contains(sub.trim()))
							out.push(sub.trim());
				}
				else if (isUsefulIp(ip) && !out.contains(ip))
					out.push(ip);
			}
		}
		sortByPrivateRank(out);
	}

	/** 私有网段优先级: 192.168.x 最高, 其次 10.x / 172.16-31.x, 其它 (公网/隧道) 最低。 */
	static function privateRank(ip:String):Int
	{
		var parts:Array<String> = ip.split(".");
		if (parts.length != 4)
			return 9;
		var first:Null<Int> = Std.parseInt(parts[0]);
		var second:Null<Int> = Std.parseInt(parts[1]);
		if (first == 192 && second == 168)
			return 0;
		if (first == 10)
			return 1;
		if (first == 172 && second != null && second >= 16 && second <= 31)
			return 2;
		return 3;
	}

	static function sortByPrivateRank(ips:Array<String>):Void
	{
		var indexed:Array<{ip:String, score:Int, idx:Int}> = [];
		for (i in 0...ips.length)
			indexed.push({ip: ips[i], score: privateRank(ips[i]), idx: i});
		indexed.sort(function(a, b):Int
		{
			if (a.score != b.score)
				return a.score - b.score;
			return a.idx - b.idx;
		});
		ips.resize(0);
		for (r in indexed)
			ips.push(r.ip);
	}

	/** 行内是否包含一个可用的 IPv4 (用于识别网关值是否真实存在)。 */
	static function containsUsefulIp(line:String):Bool
	{
		if (line == null || line.length == 0)
			return false;
		var tokens:Array<String> = line.split(" ");
		for (token in tokens)
		{
			var t:String = token.trim();
			if (isUsefulIp(t))
				return true;
		}
		return false;
	}

	static function isUsefulIp(ip:String):Bool
	{
		if (ip == null || ip.length == 0 || ip == "127.0.0.1" || ip == "0.0.0.0")
			return false;
		if (ip.indexOf(":") >= 0)
			return false;
		var parts:Array<String> = ip.split(".");
		if (parts.length != 4)
			return false;
		for (p in parts)
		{
			if (p.length == 0 || p.length > 3)
				return false;
			for (i in 0...p.length)
			{
				var c:Int = p.charCodeAt(i);
				if (c < 48 || c > 57)
					return false;
			}
		}
		// APIPA 链路本地地址 (没拿到 DHCP 时的 169.254.x.x) 对局域网联机无意义。
		if (parts[0] == "169" && parts[1] == "254")
			return false;
		return true;
	}

	#if sys
	static function runProcess(cmd:String, args:Array<String>):String
	{
		try
		{
			var p:sys.io.Process = new sys.io.Process(cmd, args);
			var text:String = p.stdout.readAll().toString();
			p.close();
			return text;
		}
		catch (e:Dynamic)
		{
			return "";
		}
	}
	#end
}
