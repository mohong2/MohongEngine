package online.server;

import online.shared.OnlineTypes;
import online.shared.OnlineTypes.ChartSelection;
import online.shared.OnlineTypes.RoomPublicInfo;
import online.shared.OnlineTypes.ModManifest;
import online.shared.OnlineTypes.RoomSettings;
import online.shared.OnlineTypes.ScoreRecord;
import online.shared.SeiunProtocol;

/**
	房间列表与建房/加入/退出流程。只在服务器网络线程内访问。
**/
class RoomManager
{
	public var rooms:Array<Room> = [];
	var server:SeiunServer;

	public function new(server:SeiunServer)
	{
		this.server = server;
	}

	public function byCode(code:String):Room
	{
		if (code == null)
			return null;
		var upper:String = code.toUpperCase();
		for (r in rooms)
			if (r.roomCode.toUpperCase() == upper)
				return r;
		return null;
	}

	public function generateCode():String
	{
		var chars:String = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
		var attempt:Int = 0;
		while (attempt < 100)
		{
			var code:String = "";
			for (i in 0...5)
				code += chars.charAt(Std.random(chars.length));
			if (byCode(code) == null)
				return code;
			attempt++;
		}
		var fallback:String = Std.string(Date.now().getTime());
		return fallback.substr(fallback.length - 5);
	}

	public function createRoom(host:ServerClient, requested:RoomSettings):Dynamic
	{
		if (host.room != null)
			return {ok: false, code: SeiunProtocol.ERR_ROOM_FULL, message: "你已经在一个房间中"};
		if (requested.maxPlayers < 1 || requested.maxPlayers > 12)
			return {ok: false, code: SeiunProtocol.ERR_BAD_PACKET, message: "玩家人数需在 1-12 之间"};
		if (requested.teamSize < 1 || requested.teamSize > 6)
			return {ok: false, code: SeiunProtocol.ERR_BAD_PACKET, message: "队伍人数需在 1-6 之间"};

		var settings:RoomSettings = {
			roomName: requested.roomName,
			mode: requested.mode == online.shared.OnlineTypes.OnlineConst.MODE_ASYNC ? online.shared.OnlineTypes.OnlineConst.MODE_ASYNC : online.shared.OnlineTypes.OnlineConst.MODE_REALTIME,
			maxPlayers: requested.maxPlayers,
			antiCheat: requested.antiCheat,
			password: requested.password == null ? "" : requested.password,
			roomCode: generateCode(),
			judgementPreset: requested.judgementPreset,
			judgementTimings: requested.judgementTimings,
			marvelousRatings: requested.marvelousRatings,
			pausePolicy: requested.pausePolicy == null ? online.shared.OnlineTypes.OnlineConst.PAUSE_EVERYONE : requested.pausePolicy,
			compatibilityMode: requested.compatibilityMode,
			allowDuplicateNames: requested.allowDuplicateNames,
			teamSize: requested.teamSize,
			stageName: requested.stageName == null ? "" : requested.stageName,
			compatEngine: requested.compatEngine == null ? "" : requested.compatEngine
		};
		if (settings.judgementTimings == null || settings.judgementTimings.length < 4)
			settings.judgementTimings = [25, 50, 70, 100];

		var room:Room = new Room(host, settings);
		rooms.push(room);
		room.addPlayer(host);
		host.isReady = false;
		host.chartHash = "";
		server.log("room created " + room.roomCode + " by " + host.displayName());
		if (server.scriptHost != null)
			server.scriptHost.call("onRoomCreate", [room.roomCode, room.settings.roomName, host.displayName()]);
		return {ok: true, room: room.publicInfo()};
	}

	public function joinRoom(client:ServerClient, code:String, password:String, ?spectate:Bool = false):Dynamic
	{
		if (client.room != null)
			return {ok: false, code: SeiunProtocol.ERR_ROOM_FULL, message: "你已经在一个房间中"};
		var room:Room = byCode(code);
		if (room == null)
			return {ok: false, code: SeiunProtocol.ERR_ROOM_NOT_FOUND, message: "房间不存在或已关闭"};
		if (room.status != online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_LOBBY)
			return {ok: false, code: SeiunProtocol.ERR_BAD_PACKET, message: "对局进行中，请等待回到大厅后再加入"};
		if (room.settings.password != null && room.settings.password.length > 0
			&& (password == null || password != room.settings.password))
			return {ok: false, code: SeiunProtocol.ERR_ROOM_PASSWORD, message: "房间密码错误"};

		// 观战加入: 不占游玩席位, 不参与准备/门闩/开始; 上限 Room.MAX_SPECTATORS。
		if (spectate)
		{
			if (!room.addSpectator(client))
				return {ok: false, code: SeiunProtocol.ERR_ROOM_FULL, message: "观战席位已满 (上限 " + Room.MAX_SPECTATORS + " 人)"};
			var publicSpec:Dynamic = client.publicInfo();
			Reflect.setField(publicSpec, "isSpectator", true);
			room.broadcast(SeiunProtocol.MSG_ROOM_PLAYER_JOIN, {player: publicSpec}, client.id);
			room.roomInfoMessage();
			server.log(client.displayName() + " joined room " + room.roomCode + " (观战)");
			return {ok: true, room: room.publicInfo(), players: room.playerInfos(), selfId: client.id, hostId: room.hostId};
		}

		if (!room.addPlayer(client))
			return {ok: false, code: SeiunProtocol.ERR_ROOM_FULL, message: "房间已满"};

		client.isReady = false;
		client.chartHash = "";
		if (!room.settings.allowDuplicateNames && client.identity != null)
		{
			for (p in room.players)
				if (p.id != client.id && p.displayName().toLowerCase() == client.displayName().toLowerCase())
				{
					room.removePlayer(client);
					return {ok: false, code: SeiunProtocol.ERR_ROOM_FULL, message: "房主已开启拒绝重名"};
				}
		}

		var publicJoin:Dynamic = client.publicInfo();
		room.broadcast(SeiunProtocol.MSG_ROOM_PLAYER_JOIN, {player: publicJoin}, client.id);
		room.roomInfoMessage();
		server.log(client.displayName() + " joined room " + room.roomCode);
		if (server.scriptHost != null)
			server.scriptHost.call("onPlayerJoin", [room.roomCode, client.displayName(), client.id]);
		return {ok: true, room: room.publicInfo(), players: room.playerInfos(), selfId: client.id, hostId: room.hostId};
	}

	public function leaveRoom(client:ServerClient):Void
	{
		if (client.room == null)
			return;
		client.clearPendingFile();
		var room:Room = client.room;
		// 观战者离开: 只从观战列表移除, 不影响游玩席位与房间状态。
		if (room.spectatorById(client.id) != null)
		{
			room.removeSpectator(client);
			room.broadcast(SeiunProtocol.MSG_ROOM_PLAYER_LEAVE, {
				id: client.id,
				nickname: client.displayName(),
				reason: "bye",
				at: Date.now().getTime()
			});
			room.roomInfoMessage();
			return;
		}
		var wasHost:Bool = room.hostId == client.id;
		room.removePlayer(client);
		room.broadcast(SeiunProtocol.MSG_ROOM_PLAYER_LEAVE, {
			id: client.id,
			nickname: client.displayName(),
			reason: "bye",
			at: Date.now().getTime()
		});
		if (server.scriptHost != null)
			server.scriptHost.call("onPlayerLeave", [room.roomCode, client.displayName(), client.id, "bye"]);
		if (wasHost || room.isEmpty())
		{
			if (wasHost)
				room.noticeForAll("房主退出了房间，房间已关闭");
			closeRoom(room, wasHost ? "房主退出了房间" : "房间已空");
		}
		else
		{
			// 暂停者退出: 解除倒计时挂起, 避免剩余玩家永远卡在"等待恢复"。
			if (room.status == online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_COUNTDOWN && room.countdownPaused)
				room.countdownPaused = false;
			if (room.settings.mode == online.shared.OnlineTypes.OnlineConst.MODE_ASYNC)
				room.broadcast(SeiunProtocol.MSG_ASYNC_RANKING, {ranking: room.rankingPayload(), finalized: room.finalized}, null, SeiunProtocol.CHANNEL_ASYNC);
			server.tryFinalizeRealtime(room);
			server.maybeBroadcastRealtimeSync(room);
			room.roomInfoMessage();
		}
	}

	/** 房主踢人: 移除目标并广播, 目标由调用方先发错误提示。 */
	public function kickPlayer(target:ServerClient, by:ServerClient):Void
	{
		if (target == null || target.room == null)
			return;
		target.clearPendingFile();
		var room:Room = target.room;
		// 观战者被踢: 只移出观战列表, 房间与游玩席位不受影响。
		if (room.spectatorById(target.id) != null)
		{
			room.removeSpectator(target);
			room.broadcast(SeiunProtocol.MSG_ROOM_PLAYER_LEAVE, {
				id: target.id,
				nickname: target.displayName(),
				reason: "kick",
				at: Date.now().getTime()
			});
			room.roomInfoMessage();
			return;
		}
		var wasHost:Bool = room.hostId == target.id;
		room.removePlayer(target);
		room.broadcast(SeiunProtocol.MSG_ROOM_PLAYER_LEAVE, {
			id: target.id,
			nickname: target.displayName(),
			reason: "kick",
			at: Date.now().getTime()
		});
		if (server.scriptHost != null)
			server.scriptHost.call("onPlayerLeave", [room.roomCode, target.displayName(), target.id, "kick"]);
		if (wasHost || room.isEmpty())
		{
			if (wasHost)
				room.noticeForAll("房主被移出，房间已关闭");
			closeRoom(room, "房间已空");
		}
		else
		{
			// 暂停者被移出: 解除倒计时挂起, 避免剩余玩家永远卡在"等待恢复"。
			if (room.status == online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_COUNTDOWN && room.countdownPaused)
				room.countdownPaused = false;
			server.tryFinalizeRealtime(room);
			server.maybeBroadcastRealtimeSync(room);
			room.roomInfoMessage();
		}
		// 先把"你已被移出"的提示冲刷到目标 socket, 再标记关闭, 否则错误消息会被丢弃。
		try { target.flush(); } catch (e:Dynamic) {}
		target.closing = true;
		server.log(target.displayName() + " was kicked by " + (by == null ? "admin" : by.displayName()) + " from room " + room.roomCode);
	}

	public function onClientLeave(client:ServerClient, room:Room, isDisconnect:Bool):Void
	{
		if (room == null)
			return;
		client.clearPendingFile();
		var wasHost:Bool = room.hostId == client.id;
		room.removePlayer(client);
		if (isDisconnect)
		{
			room.broadcast(SeiunProtocol.MSG_ROOM_PLAYER_LEAVE, {
				id: client.id,
				nickname: client.displayName(),
				reason: "timeout",
				at: Date.now().getTime()
			});
			if (server.scriptHost != null)
				server.scriptHost.call("onPlayerLeave", [room.roomCode, client.displayName(), client.id, "timeout"]);
		}
		if (wasHost || room.isEmpty())
		{
			if (wasHost)
				room.noticeForAll("房主断开，房间已关闭");
			closeRoom(room, wasHost ? "房主断开，房间已关闭" : "房间已空");
		}
		else
		{
			// 暂停者断开: 解除倒计时挂起, 避免剩余玩家永远卡在"等待恢复"。
			if (room.status == online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_COUNTDOWN && room.countdownPaused)
				room.countdownPaused = false;
			if (room.settings.mode == online.shared.OnlineTypes.OnlineConst.MODE_ASYNC)
				room.broadcast(SeiunProtocol.MSG_ASYNC_RANKING, {ranking: room.rankingPayload(), finalized: room.finalized}, null, SeiunProtocol.CHANNEL_ASYNC);
			server.tryFinalizeRealtime(room);
			server.maybeBroadcastRealtimeSync(room);
			room.roomInfoMessage();
		}
	}

	public function closeRoom(room:Room, reason:String):Void
	{
		var keep:Array<Room> = [];
		for (r in rooms)
			if (r != room)
				keep.push(r);
		rooms = keep;
		for (p in room.players)
			p.room = null;
		server.log("room closed " + room.roomCode + ": " + reason);
	}

	public function listPublic():Array<RoomPublicInfo>
	{
		var out:Array<RoomPublicInfo> = [];
		for (r in rooms)
			out.push(r.publicInfo());
		return out;
	}

	public function applyChart(room:Room, chart:ChartSelection):Bool
	{
		if (room == null || chart == null)
			return false;
		// Malody/osu! 转谱强制异步排名: 转谱布局/音频在不同设备上差异大,
		// 实时同开容易出现不同步, 统一走"各自游玩后提交排名"。
		var forcedAsync:Bool = chart.chartSource == online.shared.OnlineTypes.OnlineConst.CHART_SOURCE_CONVERTED;
		if (forcedAsync && room.settings.mode != online.shared.OnlineTypes.OnlineConst.MODE_ASYNC)
		{
			room.settings.mode = online.shared.OnlineTypes.OnlineConst.MODE_ASYNC;
			room.noticeForAll("当前歌曲为 Malody/osu! 转谱，房间已强制切换为异步排名模式。");
		}

		room.chart = chart;
		room.selectedSongHash = chart.chartHash;
		room.chartNoteCount = 0;
		room.noteTimesByLane = new Map<Int, Array<Float>>();
		room.asyncScores = new Map<String, ScoreRecord>();
		room.asyncStartedAt = new Map<String, Float>();
		room.realtimeResults = new Map<String, ScoreRecord>();
		room.pendingReplayUploads = new Map<String, String>();
		room.authoritativeScores = new Map<String, ScoreRecord>();
		room.authoritativeCombo = new Map<String, Int>();
		room.judgedNotes = new Map<String, Bool>();
		room.gameReadyIds = new Map<String, Bool>();
		room.realtimeSyncServerStartMs = 0;
		room.realtimeSyncBroadcastUntilMs = 0;
		room.lastRealtimeSyncRebroadcastMs = 0;
		// 选歌范围变了: 旧的全量/上一首歌清单全部作废, 等待各端上报新清单。
		room.hostManifest = null;
		room.clientManifests = new Map<String, ModManifest>();
		for (p in room.players)
		{
			// 选歌变了: 旧歌的文件传输立即作废, 不占用新歌的同步带宽。
			p.clearPendingFile();
			room.asyncStates.set(p.id, online.shared.OnlineTypes.OnlineConst.ASYNC_STATE_NOT_STARTED);
			room.modsMissingCount.set(p.id, 0);
			p.isReady = false;
			// 房主是谱面来源, 直接采信其哈希; 其他玩家通过 ROOM_READY 自动上报本地哈希。
			p.chartHash = (p.id == room.hostId) ? chart.chartHash : "";
		}
		room.finalized = false;
		room.roomInfoMessage();
		return true;
	}

}
