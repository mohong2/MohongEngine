package online.server;

import StringTools;
import online.shared.SeiunProtocol;

/**
	无头专用服务器控制台命令。
	所有命令都在服务器主循环线程外执行, 通过 adminMutex 互斥, 避免跨线程修改房间状态。
	命令: help | list | accounts | kick | ban | unban | mute | announce | broadcast |
	      setpassword (房间密码) | adminpassword (面板口令) | anticheat | maxplayers |
	      admin <用户> on/off | resetpw <用户> <新密码> | ipaccounts <ip> | stop
**/
class ServerConsole
{
	var server:SeiunServer;

	public function new(server:SeiunServer)
	{
		this.server = server;
	}

	public function execute(line:String):String
	{
		#if cpp
		var tw:Float = Date.now().getTime();
		server.adminMutex.acquire();
		var twMs:Float = Date.now().getTime() - tw;
		if (twMs > 200)
			server.log("[console] mutex wait " + Std.int(twMs) + "ms");
		#end
		var result:String = "";
		try
		{
			result = executeUnlocked(line);
		}
		catch (e:Dynamic)
		{
			result = "命令执行出错: " + Std.string(e);
		}
		#if cpp
		server.adminMutex.release();
		#end
		return result;
	}

	function executeUnlocked(line:String):String
	{
		if (line == null)
			return "";
		var trimmed:String = StringTools.trim(line);
		if (trimmed.length == 0)
			return "";
		var parts:Array<String> = trimmed.split(" ");
		var cmd:String = parts[0].toLowerCase();
		var arg:String = parts.length > 1 ? trimmed.substr(cmd.length + 1).trim() : "";

		switch (cmd)
		{
			case "help":
				return "命令: list | accounts | kick <id> | ban <id/ip> | unban <target> [ip/device/account] | announce <text> | broadcast <text> | setpassword <房间密码> | adminpassword <面板口令> | admin <用户> on/off | resetpw <用户> <新密码> | ipaccounts <ip> | maxplayers <n> | stop";
			case "list":
				var out:String = "clients: " + server.clients.length + "\n";
				for (c in server.clients)
					out += "  " + c.id + " " + c.ip + " " + c.displayName() + (c.room == null ? "" : " room=" + c.room.roomCode) + "\n";
				for (r in server.roomManager.rooms)
					out += "room " + r.roomCode + " " + r.settings.roomName + " players=" + r.players.length + "/" + r.settings.maxPlayers + "\n";
				return out;
			case "accounts":
				var list:Array<Dynamic> = server.authStore.accountsList();
				var out2:String = "accounts: " + list.length + "\n";
				for (a in list)
					out2 += "  " + a.username + " role=" + a.role + " banned=" + a.banned
						+ " ip=" + (a.registerIp == null ? "" : a.registerIp)
						+ " lastLogin=" + (a.lastLoginAt == null ? 0 : a.lastLoginAt) + "\n";
				return out2;
			case "kick":
				return kickById(arg);
			case "ban":
				return banTarget(arg);
			case "unban":
				return unbanTarget(arg);
			case "mute":
				return muteById(arg);
			case "announce":
				if (arg.length == 0)
					return "缺少公告文本";
				for (r in server.roomManager.rooms)
					r.noticeForAll(arg);
				server.log("announce: " + arg);
				return "已公告全部房间";
			case "broadcast":
				if (arg.length == 0)
					return "缺少公告文本";
				for (r in server.roomManager.rooms)
					r.noticeForAll(arg);
				server.log("broadcast: " + arg);
				return "已全服公告";
			case "setpassword":
				// 房间密码 (旧命令语义是同时改房间与面板口令, 现在拆开)。
				for (r in server.roomManager.rooms)
					r.settings.password = arg;
				return "房间密码已更新 (面板口令请用 adminpassword 命令)";
			case "adminpassword":
				if (arg.length == 0)
					return "缺少新口令";
				server.config.adminPassword = arg;
				if (server.adminHttp != null)
					server.adminHttp.setPassword(arg);
				server.saveConfig();
				return "面板口令已更新";
			case "anticheat":
				// 反作弊已移除: 命令保留仅为兼容, 始终强制关闭。
				server.config.anticheatDefault = false;
				for (r in server.roomManager.rooms)
				{
					r.settings.antiCheat = false;
					r.roomInfoMessage();
				}
				return "反作弊已移除，始终关闭";
			case "maxplayers":
				var parsed:Null<Int> = Std.parseInt(arg);
				if (parsed == null || parsed < 1 || parsed > 12)
					return "人数需在 1-12 之间";
				var n:Int = parsed;
				server.config.maxPlayersDefault = n;
				for (r in server.roomManager.rooms)
				{
					if (n >= r.players.length)
					{
						r.settings.maxPlayers = n;
						r.roomInfoMessage();
					}
				}
				server.saveConfig();
				return "默认人数已更新为 " + n;
			case "admin":
				// admin <username> on|off
				var parts2:Array<String> = arg.split(" ");
				var username:String = parts2.length > 0 ? parts2[0] : "";
				var enable:Bool = parts2.length < 2 || parts2[1].toLowerCase() != "off";
				if (username.length == 0)
					return "用法: admin <用户名> on|off";
				var result:Dynamic = server.authStore.setRole(username, enable ? "admin" : "player");
				return Std.string(Reflect.field(result, "message"));
			case "resetpw":
				// resetpw <username> <newpassword>
				var sp:Int = arg.indexOf(" ");
				if (sp <= 0)
					return "用法: resetpw <用户名> <新密码>";
				var username2:String = arg.substr(0, sp).trim();
				var newPass:String = arg.substr(sp + 1).trim();
				var result2:Dynamic = server.authStore.resetPassword(username2, newPass);
				return Std.string(Reflect.field(result2, "message"));
			case "ipaccounts":
				if (arg.length == 0)
					return "用法: ipaccounts <ip>";
				var list2:Array<Dynamic> = server.authStore.accountsList();
				var out3:String = "IP " + arg + " 注册的账号:\n";
				var found:Bool = false;
				for (a in list2)
					if (a.registerIp == arg)
					{
						out3 += "  " + a.username + " (" + a.role + (a.banned ? ", 已封禁" : "") + ")\n";
						found = true;
					}
				if (!found)
					out3 += "  (无)\n";
				return out3;
			case "stop":
				server.stopRequested = true;
				return "服务器正在关闭...";
			default:
				return "未知命令: " + cmd + " (输入 help 查看命令)";
		}
	}

	function kickById(arg:String):String
	{
		for (c in server.clients)
			if (c.id == arg || c.displayName() == arg)
			{
				c.sendError(SeiunProtocol.ERR_NOT_AUTHORIZED, "你被管理员请出服务器");
				c.closing = true;
				return "已踢出 " + c.displayName();
			}
		return "玩家不存在";
	}

	function banTarget(arg:String):String
	{
		if (arg.length == 0)
			return "缺少 id/ip";
		for (c in server.clients)
		{
			if (c.id == arg || c.ip == arg || (c.identity != null && c.identity.deviceId == arg) || c.displayName() == arg)
			{
				server.authStore.ban(c.ip, "ip", "console");
				server.authStore.ban(c.identity.deviceId, "device", "console");
				if (c.account != null)
					server.authStore.ban(c.account.username, "account", "console"); // 自动连带封其设备
				var now:Float = Date.now().getTime();
				var banInfo:AuthStore.StoredBan = c.account != null
					? server.authStore.effectiveBanForAccount(c.account.username)
					: server.authStore.effectiveBan("device", c.identity.deviceId);
				c.send(SeiunProtocol.MSG_ERROR, SeiunProtocol.CHANNEL_CONTROL, AuthStore.banErrorPayload("你已被服务器封禁", banInfo, now));
				c.closing = true;
				return "已封禁 " + c.displayName() + " (" + c.ip + ")";
			}
		}
		// 不在线: 按内容自动推断类型 (含 . 视为 IP, 否则视为账号)。
		var kind:String = arg.indexOf(".") >= 0 ? "ip" : "account";
		server.authStore.ban(arg, kind, "console");
		return "已记录封禁 " + arg + " (" + kind + ")";
	}

	function unbanTarget(arg:String):String
	{
		if (arg.length == 0)
			return "缺少目标";
		var parts:Array<String> = arg.split(" ");
		var target:String = parts[0];
		var kind:String = parts.length > 1 ? parts[1].toLowerCase() : "";
		if (kind != "ip" && kind != "device" && kind != "account")
			kind = target.indexOf(".") >= 0 ? "ip" : "account";
		server.authStore.unban(target, kind);
		return "已解封 " + kind + ":" + target;
	}

	function muteById(arg:String):String
	{
		// 房间聊天暂未接入独立 mute 位; 这里先记录并在踢人逻辑中兼容。
		server.log("mute requested: " + arg);
		return "当前版本通过踢出/封禁处理恶意发言";
	}
}
