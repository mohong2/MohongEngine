package online.server;

import haxe.Json;
import online.shared.SeiunProtocol;

/**
	专用服务器/内置托管共用配置。
	内置托管形态不会启动 Web 管理面板。
**/
class ServerConfig
{
	public var port:Int = SeiunProtocol.DEFAULT_PORT;
	public var adminPort:Int = SeiunProtocol.ADMIN_PORT;
	/** Web 面板监听地址 (默认 0.0.0.0; 只本机访问可改 127.0.0.1)。 */
	public var adminBind:String = "0.0.0.0";
	public var adminPassword:String = "seiun";
	public var dataDir:String = "server_data";
	public var dedicated:Bool = false;
	public var maxPlayersDefault:Int = 6;
	/** 反作弊已移除: 该字段保留仅为 UDP 广播/旧命令兼容, 恒为 false。 */
	public var anticheatDefault:Bool = false;
	public var allowAnonymous:Bool = true;
	public var requireEmail:Bool = false;
	public var reconnectWindowSeconds:Float = SeiunProtocol.RECONNECT_WINDOW_SECONDS;
	public var heartbeatTimeoutSeconds:Float = 15.0;
	public var serverName:String = "SeiunEngine LAN Server";
	public var webPanelEnabled:Bool = true;
	public var serverScriptsDir:String = "scripts";
	public var serverModsDir:String = "mods";

	// ── 账号/安全策略 (重构新增) ──────────────────────────
	/** 单 IP 可注册的账号数上限, 0 = 不限。 */
	public var maxAccountsPerIp:Int = 3;
	/** 同一 IP 两次注册的最小间隔 (秒), 0 = 不限。 */
	public var registerCooldownSeconds:Int = 300;
	/** 会话有效期 (天), 到期后需重新登录。 */
	public var sessionTtlDays:Int = 7;
	/** 每账号最多绑定设备数 (宽松模式), 0 = 不限。 */
	public var maxDevicesPerAccount:Int = 5;
	/** true = 旧行为 (1 账号 = 1 设备, 换设备无法登录); false = 密码即凭证, 登录自动绑定设备。 */
	public var strictDeviceBinding:Bool = false;
	/** 连续错误密码达到该次数后锁定账号, 0 = 不锁定。 */
	public var loginFailLockoutCount:Int = 5;
	/** 锁定时长 (分钟)。 */
	public var loginFailLockoutMinutes:Int = 10;

	public function new() {}

	public static function embeddedDefaults():ServerConfig
	{
		var cfg:ServerConfig = new ServerConfig();
		cfg.dedicated = false;
		cfg.webPanelEnabled = false;
		cfg.allowAnonymous = true;
		cfg.dataDir = "seiun_online";
		cfg.serverName = "局域网 · 本机托管";
		return cfg;
	}

	public static function dedicatedDefaults():ServerConfig
	{
		var cfg:ServerConfig = new ServerConfig();
		cfg.dedicated = true;
		cfg.webPanelEnabled = true;
		cfg.allowAnonymous = false;
		cfg.dataDir = "server_data";
		cfg.serverName = "专用服务器";
		return cfg;
	}

	#if sys
	public static function load(path:String, fallback:ServerConfig):ServerConfig
	{
		var cfg:ServerConfig = fallback == null ? dedicatedDefaults() : fallback;
		if (path == null || !sys.FileSystem.exists(path))
			return cfg;
		try
		{
			var raw:String = AuthStore.readTextFile(path);
			var json:Dynamic = Json.parse(raw);
			if (json == null)
				return cfg;
			var fields:Array<String> = Reflect.fields(json);
			for (f in fields)
			{
				var v:Dynamic = Reflect.field(json, f);
				if (v == null)
					continue;
				switch (f)
				{
					case "port": cfg.port = intField(v, cfg.port);
					case "adminPort": cfg.adminPort = intField(v, cfg.adminPort);
					case "adminBind": cfg.adminBind = Std.string(v);
					case "adminPassword": cfg.adminPassword = Std.string(v);
					case "dataDir": cfg.dataDir = Std.string(v);
					case "dedicated": cfg.dedicated = Std.string(v).toLowerCase() == "true";
					case "maxPlayersDefault": cfg.maxPlayersDefault = intField(v, cfg.maxPlayersDefault);
					case "anticheatDefault": cfg.anticheatDefault = Std.string(v).toLowerCase() == "true";
					case "allowAnonymous": cfg.allowAnonymous = Std.string(v).toLowerCase() == "true";
					case "requireEmail": cfg.requireEmail = Std.string(v).toLowerCase() == "true";
					case "reconnectWindowSeconds": cfg.reconnectWindowSeconds = floatField(v, cfg.reconnectWindowSeconds);
					case "heartbeatTimeoutSeconds": cfg.heartbeatTimeoutSeconds = floatField(v, cfg.heartbeatTimeoutSeconds);
					case "serverName": cfg.serverName = Std.string(v);
					case "webPanelEnabled": cfg.webPanelEnabled = Std.string(v).toLowerCase() == "true";
					case "serverScriptsDir": cfg.serverScriptsDir = Std.string(v);
					case "serverModsDir": cfg.serverModsDir = Std.string(v);
					case "maxAccountsPerIp": cfg.maxAccountsPerIp = intField(v, cfg.maxAccountsPerIp);
					case "registerCooldownSeconds": cfg.registerCooldownSeconds = intField(v, cfg.registerCooldownSeconds);
					case "sessionTtlDays": cfg.sessionTtlDays = intField(v, cfg.sessionTtlDays);
					case "maxDevicesPerAccount": cfg.maxDevicesPerAccount = intField(v, cfg.maxDevicesPerAccount);
					case "strictDeviceBinding": cfg.strictDeviceBinding = Std.string(v).toLowerCase() == "true";
					case "loginFailLockoutCount": cfg.loginFailLockoutCount = intField(v, cfg.loginFailLockoutCount);
					case "loginFailLockoutMinutes": cfg.loginFailLockoutMinutes = intField(v, cfg.loginFailLockoutMinutes);
				}
			}
		}
		catch (e:Dynamic) {}
		return cfg;
	}

	public function save(path:String):Void
	{
		var obj:Dynamic = toObject();
		try
		{
			ensureDir(haxe.io.Path.directory(path));
			sys.io.File.saveContent(path, Json.stringify(obj, null, "  "));
		}
		catch (e:Dynamic) {}
	}

	public function toObject():Dynamic
	{
		return {
			port: port,
			adminPort: adminPort,
			adminBind: adminBind,
			adminPassword: adminPassword,
			dataDir: dataDir,
			dedicated: dedicated,
			maxPlayersDefault: maxPlayersDefault,
			anticheatDefault: anticheatDefault,
			allowAnonymous: allowAnonymous,
			requireEmail: requireEmail,
			reconnectWindowSeconds: reconnectWindowSeconds,
			heartbeatTimeoutSeconds: heartbeatTimeoutSeconds,
			serverName: serverName,
			webPanelEnabled: webPanelEnabled,
			serverScriptsDir: serverScriptsDir,
			serverModsDir: serverModsDir,
			maxAccountsPerIp: maxAccountsPerIp,
			registerCooldownSeconds: registerCooldownSeconds,
			sessionTtlDays: sessionTtlDays,
			maxDevicesPerAccount: maxDevicesPerAccount,
			strictDeviceBinding: strictDeviceBinding,
			loginFailLockoutCount: loginFailLockoutCount,
			loginFailLockoutMinutes: loginFailLockoutMinutes
		};
	}

	public function ensureDir(path:String):Void
	{
		if (path == null || path.length == 0)
			return;
		try
		{
			if (!sys.FileSystem.exists(path))
				sys.FileSystem.createDirectory(path);
		}
		catch (e:Dynamic) {}
	}

	// ── 统一落盘锚点 (重构新增): 所有目录相对"配置文件所在目录"解析, 绝不依赖 CWD ──

	/** 相对路径解析到锚点目录; 绝对路径 (含 Windows 盘符) 原样归一化返回。 */
	public static function resolveAgainstAnchor(path:String, anchorDir:String):String
	{
		if (path == null || path.length == 0)
			return path;
		var p:String = StringTools.replace(path, "\\", "/");
		if (haxe.io.Path.isAbsolute(p) || (p.length >= 2 && p.charAt(1) == ":"))
			return haxe.io.Path.normalize(p);
		if (anchorDir == null || anchorDir.length == 0)
			return haxe.io.Path.normalize(p);
		return haxe.io.Path.normalize(anchorDir + "/" + p);
	}

	/**
		统一落盘锚点: 数据/脚本/模组目录相对"已解析配置文件所在目录"解析。
		必须在创建 SeiunServer 之前调用 (HeadlessMain 专用服务器 / 内置托管各自接线)。
		返回锚点目录 (用于启动横幅打印)。
	**/
	public static function applyRuntimeAnchor(cfg:ServerConfig, configPath:String):String
	{
		var anchorDir:String = "";
		try
		{
			var abs:String = sys.FileSystem.absolutePath(configPath == null || configPath.length == 0 ? "server.config.json" : configPath);
			anchorDir = haxe.io.Path.directory(haxe.io.Path.normalize(abs));
		}
		catch (e:Dynamic)
		{
			anchorDir = Sys.getCwd();
		}
		cfg.dataDir = resolveAgainstAnchor(cfg.dataDir, anchorDir);
		// 兼容旧版"相对仓库根"约定: 旧配置里的 "server/scripts" 类路径在锚点本身就是
		// <...>/server 目录时去掉 "server/" 前缀, 避免解析成 <...>/server/server/x。
		cfg.serverScriptsDir = resolveLegacyPrefixed(cfg.serverScriptsDir, anchorDir);
		cfg.serverModsDir = resolveLegacyPrefixed(cfg.serverModsDir, anchorDir);
		return anchorDir;
	}

	static function resolveLegacyPrefixed(path:String, anchorDir:String):String
	{
		if (path == null)
			return path;
		if (StringTools.startsWith(path, "server/"))
		{
			var base:String = haxe.io.Path.withoutDirectory(StringTools.replace(anchorDir, "\\", "/")).toLowerCase();
			if (base == "server")
				return resolveAgainstAnchor(path.substr("server/".length), anchorDir);
		}
		return resolveAgainstAnchor(path, anchorDir);
	}

	static function ensureDirDeep(path:String):Void
	{
		if (path == null || path.length == 0)
			return;
		var norm:String = haxe.io.Path.normalize(path);
		var parent:String = haxe.io.Path.directory(norm);
		if (parent != null && parent.length > 0 && parent != norm && !sys.FileSystem.exists(parent))
			ensureDirDeep(parent);
		if (!sys.FileSystem.exists(norm))
		{
			try { sys.FileSystem.createDirectory(norm); } catch (e:Dynamic) {}
		}
	}

	/**
		把历史散落的服务器数据目录并入统一数据目录 (只搬一次)。
		目标已有同名文件时, 旧文件改名 <name>.imported-<时间戳> 后移入目标目录, 绝不覆盖新数据。
		返回人读日志行。
	**/
	public static function migrateLegacyDataDirs(targetDataDir:String, legacyDirs:Array<String>):Array<String>
	{
		var out:Array<String> = [];
		if (targetDataDir == null || targetDataDir.length == 0 || legacyDirs == null)
			return out;
		var targetNorm:String = haxe.io.Path.normalize(targetDataDir);
		var stamp:String = DateTools.format(Date.now(), "%Y%m%d-%H%M%S");
		for (legacyDir in legacyDirs)
		{
			if (legacyDir == null || legacyDir.length == 0)
				continue;
			var norm:String = haxe.io.Path.normalize(legacyDir);
			if (norm == targetNorm || !sys.FileSystem.exists(norm) || !sys.FileSystem.isDirectory(norm))
				continue;
			var movedAny:Bool = false;
			for (name in ["accounts.json", "sessions.json", "accounts.json.bak", "sessions.json.bak"])
			{
				var src:String = norm + "/" + name;
				if (!sys.FileSystem.exists(src))
					continue;
				var dst:String = targetNorm + "/" + name;
				// 会话文件特殊处理: 目标已有文件时先合并会话而不是直接改名归档,
				// 防止“目标 sessions.json 已被一次空跑创建”导致旧 token 永远进不了新数据目录。
				if (name == "sessions.json" && sys.FileSystem.exists(dst)
					&& mergeSessionsFiles(dst, src))
				{
					try { sys.FileSystem.deleteFile(src); } catch (e2:Dynamic) {}
					movedAny = true;
					out.push("合并会话: " + src + " -> " + dst);
					continue;
				}
				if (sys.FileSystem.exists(dst))
				{
					var base:String = haxe.io.Path.withoutExtension(name);
					var ext:String = haxe.io.Path.extension(name);
					dst = targetNorm + "/" + base + ".imported-" + stamp + "." + ext;
					var k:Int = 1;
					while (sys.FileSystem.exists(dst))
					{
						dst = targetNorm + "/" + base + ".imported-" + stamp + "-" + (k++) + "." + ext;
					}
				}
				try
				{
					ensureDirDeep(targetNorm);
					sys.io.File.copy(src, dst);
					sys.FileSystem.deleteFile(src);
					movedAny = true;
					out.push("迁移: " + src + " -> " + dst);
				}
				catch (e:Dynamic)
				{
					out.push("迁移失败: " + src + " (" + Std.string(e) + ")");
				}
			}
			if (movedAny)
				out.push("旧数据目录已并入统一数据目录: " + norm);
		}
		return out;
	}

	/**
		把旧数据目录里的会话合并进目标 sessions.json (按 token 去重)。
		目标文件不存在/解析失败时返回 false, 走原有“改名归档”逻辑。
	**/
	static function mergeSessionsFiles(dst:String, src:String):Bool
	{
		try
		{
			if (!sys.FileSystem.exists(dst) || !sys.FileSystem.exists(src))
				return false;
			var dstJson:Dynamic = Json.parse(sys.io.File.getContent(dst));
			var srcJson:Dynamic = Json.parse(sys.io.File.getContent(src));
			var dstArr:Array<Dynamic> = dstJson == null || Reflect.field(dstJson, "sessions") == null
				? [] : cast Reflect.field(dstJson, "sessions");
			var srcArr:Array<Dynamic> = srcJson == null || Reflect.field(srcJson, "sessions") == null
				? [] : cast Reflect.field(srcJson, "sessions");
			var existing:Map<String, Bool> = new Map<String, Bool>();
			for (s in dstArr)
				if (s != null && Reflect.field(s, "token") != null)
					existing.set(Std.string(Reflect.field(s, "token")), true);
			var changed:Bool = false;
			for (s in srcArr)
			{
				if (s == null || Reflect.field(s, "token") == null)
					continue;
				var token:String = Std.string(Reflect.field(s, "token"));
				if (existing.exists(token))
					continue;
				dstArr.push(s);
				existing.set(token, true);
				changed = true;
			}
			if (changed)
			{
				sys.io.File.saveContent(dst, Json.stringify({sessions: dstArr}, null, "  "));
				return true;
			}
			return false;
		}
		catch (e:Dynamic)
		{
			return false;
		}
	}

	/** 构建日期 = exe 文件修改时间 (无需编译期注入, 永远与实际产物一致)。 */
	public static function exeBuildTime():String
	{
		try
		{
			var st = sys.FileSystem.stat(Sys.programPath());
			if (st != null)
				return DateTools.format(st.mtime, "%Y-%m-%d %H:%M");
		}
		catch (e:Dynamic) {}
		return "未知";
	}

	static function intField(v:Dynamic, fallback:Int):Int
	{
		var parsed:Null<Int> = Std.parseInt(Std.string(v));
		return parsed == null ? fallback : parsed;
	}

	static function floatField(v:Dynamic, fallback:Float):Float
	{
		var parsed:Float = Std.parseFloat(Std.string(v));
		return Math.isNaN(parsed) ? fallback : parsed;
	}
	#end
}
