package online.server;

import haxe.Json;
import online.shared.SeiunProtocol;

using StringTools;

/**
	本地 Web 管理面板 (重构版)。
	纯 Haxe sys.net.Socket 实现, 无重型框架:
	- 正确解析请求行/请求头/Content-Length body, 支持 JSON 与表单;
	- 登录后签发随机会话 token (Cookie), 不再把明文口令放进 Cookie;
	- 完整 REST API: 状态/玩家/房间/账号/封禁/公告/踢人/配置/日志/停服;
	- 兼容旧 GET /login?password= 与 POST /api/cmd 调用;
	- 面板页面优先读 server/web/admin.html, 失败回退内嵌页。
**/
class AdminHttpServer
{
	var server:SeiunServer;
	var listenSocket:sys.net.Socket = null;
	var running:Bool = false;
	var password:String = "seiun";
	/** 已登录的管理会话: token -> 过期时间。 */
	var adminSessions:Map<String, Float> = new Map<String, Float>();
	static inline var SESSION_TTL_MS:Float = 12 * 60 * 60 * 1000;
	#if cpp
	var thread:sys.thread.Thread = null;
	#end

	public function new(server:SeiunServer)
	{
		this.server = server;
	}

	public function start(port:Int, password:String):Void
	{
		#if cpp
		if (running)
			return;
		this.password = password == null || password.length == 0 ? "seiun" : password;
		var bindAddr:String = server.config.adminBind == null || server.config.adminBind.length == 0 ? "0.0.0.0" : server.config.adminBind;
		listenSocket = new sys.net.Socket();
		listenSocket.bind(new sys.net.Host(bindAddr), port);
		listenSocket.listen(16);
		running = true;
		thread = sys.thread.Thread.create(function():Void
		{
			// 每连接一个处理线程 (上限并发), 避免单个慢请求阻塞整个面板。
			var active:Int = 0;
			var connLock:sys.thread.Mutex = new sys.thread.Mutex();
			while (running)
			{
				try
				{
					listenSocket.setTimeout(0.2);
					var client:sys.net.Socket = listenSocket.accept();
					if (client == null)
						continue;
					connLock.acquire();
					var over:Bool = active >= 8;
					if (!over)
						active++;
					connLock.release();
					if (over)
					{
						try { client.close(); } catch (e:Dynamic) {}
						continue;
					}
					sys.thread.Thread.create(function():Void
					{
						try
						{
							client.setTimeout(5.0);
							handle(client);
						}
						catch (e:Dynamic) {}
						try { client.close(); } catch (e:Dynamic) {}
						connLock.acquire();
						active--;
						connLock.release();
					});
				}
				catch (e:Dynamic) {}
			}
		});
		#end
	}

	public function stop():Void
	{
		running = false;
		try { if (listenSocket != null) listenSocket.close(); } catch (e:Dynamic) {}
		listenSocket = null;
	}

	/** 面板口令变更时同步 (ServerConsole / 面板设置页调用)。 */
	public function setPassword(newPassword:String):Void
	{
		if (newPassword != null && newPassword.length > 0)
			password = newPassword;
	}

	// ── HTTP 基础 ───────────────────────────────────────

	function handle(socket:sys.net.Socket):Void
	{
		try
		{
			var h0:Float = Date.now().getTime();
			// 请求行 + 请求头 (直到空行)。
			var requestLine:String = socket.input.readLine();
			if (requestLine == null || requestLine.length == 0)
				return;
			var headers:Map<String, String> = new Map<String, String>();
			while (true)
			{
				var line:String = socket.input.readLine();
				if (line == null || line.length == 0)
					break;
				var idx:Int = line.indexOf(":");
				if (idx > 0)
					headers.set(line.substr(0, idx).toLowerCase(), line.substr(idx + 1).trim());
			}
			var h1:Float = Date.now().getTime();
			if (h1 - h0 > 300)
				server.log("[admin] request read took " + Std.int(h1 - h0) + "ms");

			var parts:Array<String> = requestLine.split(" ");
			if (parts.length < 2)
				return;
			var method:String = parts[0].toUpperCase();
			var rawPath:String = parts[1];

			// Body: 按 Content-Length 精确读取。
			var body:String = "";
			var contentLength:Int = 0;
			if (headers.exists("content-length"))
			{
				var parsed:Null<Int> = Std.parseInt(headers.get("content-length"));
				contentLength = parsed == null ? 0 : parsed;
			}
			if (contentLength > 0 && contentLength <= 1 << 20)
			{
				var buf:haxe.io.Bytes = haxe.io.Bytes.alloc(contentLength);
				var got:Int = 0;
				while (got < contentLength)
				{
					var n:Int = socket.input.readBytes(buf, got, contentLength - got);
					if (n <= 0)
						break;
					got += n;
				}
				body = buf.toString().substr(0, got);
			}

			var cookie:String = headers.exists("cookie") ? headers.get("cookie") : "";
			var authed:Bool = isAuthed(cookie);

			// ── 登录 (表单 POST 或旧版 GET query) ────────────
			if (pathOf(rawPath) == "/login")
			{
				handleLogin(socket, method, rawPath, body);
				return;
			}
			if (pathOf(rawPath) == "/logout")
			{
				var token:String = sessionTokenFromCookie(cookie);
				if (token != null && adminSessions.exists(token))
					adminSessions.remove(token);
				sendJson(socket, 200, {ok: true, message: "已退出登录"});
				return;
			}

			if (!authed)
			{
				if (pathOf(rawPath) == "/" || pathOf(rawPath) == "/index.html")
					sendResponse(socket, 200, "text/html; charset=utf-8", loginPage(), "");
				else
					sendJson(socket, 401, {ok: false, message: "未登录或会话已过期"});
				return;
			}

			// ── 面板页面 ─────────────────────────────────────
			if (pathOf(rawPath) == "/" || pathOf(rawPath) == "/index.html")
			{
				var page:String = loadPanelFile();
				sendResponse(socket, 200, "text/html; charset=utf-8", page, "");
				return;
			}

			// ── REST API ─────────────────────────────────────
			routeApi(socket, method, rawPath, body);
		}
		catch (e:Dynamic) {}
	}

	function pathOf(rawPath:String):String
	{
		if (rawPath == null)
			return "/";
		var q:Int = rawPath.indexOf("?");
		var p:String = q >= 0 ? rawPath.substr(0, q) : rawPath;
		try { p = StringTools.urlDecode(p); } catch (e:Dynamic) {}
		return p;
	}

	function queryOf(rawPath:String):Map<String, String>
	{
		var out:Map<String, String> = new Map<String, String>();
		if (rawPath == null)
			return out;
		var q:Int = rawPath.indexOf("?");
		if (q < 0)
			return out;
		var query:String = rawPath.substr(q + 1);
		for (part in query.split("&"))
		{
			if (part.length == 0)
				continue;
			var kv:Array<String> = part.split("=");
			var k:String = "";
			var v:String = "";
			try { k = StringTools.urlDecode(kv[0]); } catch (e:Dynamic) {}
			if (kv.length > 1)
				try { v = StringTools.urlDecode(part.substr(kv[0].length + 1)); } catch (e:Dynamic) {}
			out.set(k, v);
		}
		return out;
	}

	/** 解析表单 (application/x-www-form-urlencoded) 或 JSON body。 */
	function parseBody(body:String):Dynamic
	{
		if (body == null || body.length == 0)
			return {};
		if (body.charAt(0) == "{")
		{
			try { return Json.parse(body); } catch (e:Dynamic) {}
		}
		var out:Dynamic = {};
		for (part in body.split("&"))
		{
			if (part.length == 0)
				continue;
			var kv:Array<String> = part.split("=");
			var k:String = "";
			var v:String = "";
			try { k = StringTools.urlDecode(kv[0]); } catch (e:Dynamic) {}
			if (kv.length > 1)
				try { v = StringTools.urlDecode(part.substr(kv[0].length + 1)); } catch (e:Dynamic) {}
			Reflect.setField(out, k, v);
		}
		return out;
	}

	function handleLogin(socket:sys.net.Socket, method:String, rawPath:String, body:String):Void
	{
		var provided:String = "";
		if (method == "POST")
		{
			var data:Dynamic = parseBody(body);
			provided = Reflect.field(data, "password") == null ? "" : Std.string(Reflect.field(data, "password"));
		}
		else
		{
			var q:Map<String, String> = queryOf(rawPath);
			provided = q.exists("password") ? q.get("password") : "";
		}
		if (provided == password)
		{
			var token:String = makeSessionToken();
			adminSessions.set(token, Date.now().getTime() + SESSION_TTL_MS);
			// 登录成功 → 302 跳转面板, 浏览器自动带上 Cookie。
			sendRedirect(socket, "/", "Set-Cookie: seiun_admin=" + token + "; Path=/; HttpOnly; SameSite=Lax\r\n");
		}
		else
		{
			// 失败 → 重新渲染登录页并显示错误。
			sendResponse(socket, 401, "text/html; charset=utf-8", loginPage("口令错误，请重试"), "");
		}
	}

	function isAuthed(cookie:String):Bool
	{
		var token:String = sessionTokenFromCookie(cookie);
		if (token == null)
			return false;
		if (!adminSessions.exists(token))
			return false;
		var expiresAt:Float = adminSessions.get(token);
		if (expiresAt < Date.now().getTime())
		{
			adminSessions.remove(token);
			return false;
		}
		return true;
	}

	function sessionTokenFromCookie(cookie:String):String
	{
		if (cookie == null || cookie.length == 0)
			return null;
		for (part in cookie.split(";"))
		{
			var kv:Array<String> = part.split("=");
			if (kv.length >= 2 && StringTools.trim(kv[0]) == "seiun_admin")
				return StringTools.trim(kv[1]);
		}
		return null;
	}

	function makeSessionToken():String
	{
		var out:String = "";
		for (i in 0...32)
		{
			var b:Int = Std.random(256);
			out += "0123456789abcdef".charAt((b >> 4) & 0xF) + "0123456789abcdef".charAt(b & 0xF);
		}
		return out;
	}

	// ── 路由 ────────────────────────────────────────────

	function routeApi(socket:sys.net.Socket, method:String, rawPath:String, body:String):Void
	{
		var path:String = pathOf(rawPath);
		switch (path)
		{
			case "/api/status":
				withLock(function() sendJson(socket, 200, buildStatus()));
			case "/api/players":
				withLock(function() sendJson(socket, 200, {players: playerList()}));
			case "/api/rooms":
				withLock(function() sendJson(socket, 200, {rooms: roomList()}));
			case "/api/accounts":
				withLock(function() sendJson(socket, 200, {accounts: server.authStore.accountsList(), total: server.authStore.accountCount()}));
			case "/api/bans":
				withLock(function() sendJson(socket, 200, {bans: server.authStore.bansList()}));
			case "/api/logs":
				sendJson(socket, 200, {logs: server.lastLogs()});
			case "/api/config":
				withLock(function() sendJson(socket, 200, server.config.toObject()));
			case "/api/cmd":
				handleLegacyCmd(socket, body);
			case "/api/account/create":
				withLock(function() handleAccountCreate(socket, body));
			case "/api/account/update":
				withLock(function() handleAccountUpdate(socket, body));
			case "/api/account/delete":
				withLock(function() handleAccountDelete(socket, body));
			case "/api/ban":
				withLock(function() handleBan(socket, body));
			case "/api/unban":
				withLock(function() handleUnban(socket, body));
			case "/api/announce":
				withLock(function() handleAnnounce(socket, body));
			case "/api/kick":
				withLock(function() handleKick(socket, body));
			case "/api/room/close":
				withLock(function() handleRoomClose(socket, body));
			case "/api/stop":
				withLock(function()
				{
					server.stopRequested = true;
					sendJson(socket, 200, {ok: true, message: "服务器正在关闭..."});
				});
			case "/api/save":
				withLock(function()
				{
					server.authStore.save();
					server.saveConfig();
					sendJson(socket, 200, {ok: true, message: "已保存数据与配置"});
				});
			case "/api/config/save":
				withLock(function() handleConfigSave(socket, body));
			default:
				sendJson(socket, 404, {ok: false, message: "未知 API: " + path});
		}
	}

	/** 在管理互斥锁内执行 (与网络主循环互斥, 避免跨线程改房间/账号状态)。 */
	function withLock(fn:Void->Void):Void
	{
		#if cpp
		var t0:Float = Date.now().getTime();
		server.adminMutex.acquire();
		var waitMs:Float = Date.now().getTime() - t0;
		if (waitMs > 200)
			server.log("[admin] mutex wait " + Std.int(waitMs) + "ms");
		#end
		try
		{
			fn();
		}
		catch (e:Dynamic)
		{
			// 不能在这里发送响应 (socket 可能已写一半), 静默记录。
			server.log("[admin] api error: " + Std.string(e));
		}
		#if cpp
		server.adminMutex.release();
		#end
	}

	// ── API 实现 ────────────────────────────────────────

	function buildStatus():Dynamic
	{
		var now:Float = Date.now().getTime();
		var uptimeSec:Int = Std.int((now - serverStartTime()) / 1000.0);
		return {
			ok: true,
			serverName: server.config.serverName,
			dedicated: server.config.dedicated,
			version: SeiunProtocol.ENGINE_FINGERPRINT,
			uptimeSeconds: uptimeSec,
			clients: server.clients.length,
			accounts: server.authStore.accountCount(),
			bans: server.authStore.bans.length,
			rooms: roomList(),
			players: playerList(),
			config: server.config.toObject(),
			recentLog: server.lastLogs()
		};
	}

	var bootTime:Float = 0;
	function serverStartTime():Float
	{
		if (bootTime <= 0)
			bootTime = Date.now().getTime();
		return bootTime;
	}

	function roomList():Array<Dynamic>
	{
		var rooms:Array<Dynamic> = [];
		for (r in server.roomManager.rooms)
		{
			rooms.push({
				code: r.roomCode,
				name: r.settings.roomName,
				mode: r.settings.mode,
				status: r.status,
				players: r.players.length,
				maxPlayers: r.settings.maxPlayers,
				hasPassword: r.settings.password != null && r.settings.password.length > 0,
				host: r.hostId,
				chart: r.chart,
				crashes: r.crashNotices == null ? 0 : r.crashNotices.length
			});
		}
		return rooms;
	}

	function playerList():Array<Dynamic>
	{
		var players:Array<Dynamic> = [];
		for (c in server.clients)
		{
			var info:Dynamic = c.publicInfo();
			info.connectedAt = c.connectedAt;
			info.idleMs = Date.now().getTime() - c.lastReadAt;
			info.roomCode = c.room == null ? "" : c.room.roomCode;
			players.push(info);
		}
		return players;
	}

	function handleAccountCreate(socket:sys.net.Socket, body:String):Void
	{
		var data:Dynamic = parseBody(body);
		var username:String = Reflect.field(data, "username") == null ? "" : Std.string(Reflect.field(data, "username"));
		var pass:String = Reflect.field(data, "password") == null ? "" : Std.string(Reflect.field(data, "password"));
		var role:String = Reflect.field(data, "role") == null ? "player" : Std.string(Reflect.field(data, "role"));
		if (username.length < 3 || pass.length < 6)
		{
			sendJson(socket, 200, {ok: false, message: "用户名至少 3 字符, 密码至少 6 位"});
			return;
		}
		// 管理员在面板创建账号: 不经过 IP 限制, 设备码用占位符 (面板创建的账号没有绑定设备)。
		var result:Dynamic = server.authStore.register(username, pass, "admin_" + makeSessionToken(), "127.0.0.1");
		if (result.ok == true && role == "admin")
			server.authStore.setRole(username, "admin");
		sendJson(socket, 200, result);
	}

	function handleAccountUpdate(socket:sys.net.Socket, body:String):Void
	{
		var data:Dynamic = parseBody(body);
		var username:String = Reflect.field(data, "username") == null ? "" : Std.string(Reflect.field(data, "username"));
		if (username.length == 0)
		{
			sendJson(socket, 200, {ok: false, message: "缺少用户名"});
			return;
		}
		if (Reflect.hasField(data, "role"))
		{
			var role:String = Std.string(Reflect.field(data, "role"));
			var r:Dynamic = server.authStore.setRole(username, role);
			if (r.ok != true)
			{
				sendJson(socket, 200, r);
				return;
			}
		}
		if (Reflect.hasField(data, "password"))
		{
			var pw:String = Std.string(Reflect.field(data, "password"));
			if (pw.length > 0)
				server.authStore.resetPassword(username, pw);
		}
		if (Reflect.hasField(data, "banned"))
		{
			var banned:Bool = Reflect.field(data, "banned") == true || Std.string(Reflect.field(data, "banned")).toLowerCase() == "true";
			var reason:String = Reflect.field(data, "reason") == null ? "" : Std.string(Reflect.field(data, "reason"));
			server.authStore.setBanned(username, banned, reason);
		}
		sendJson(socket, 200, {ok: true, message: "账号已更新"});
	}

	function handleAccountDelete(socket:sys.net.Socket, body:String):Void
	{
		var data:Dynamic = parseBody(body);
		var username:String = Reflect.field(data, "username") == null ? "" : Std.string(Reflect.field(data, "username"));
		if (username.length == 0)
		{
			sendJson(socket, 200, {ok: false, message: "缺少用户名"});
			return;
		}
		var result:Dynamic = server.authStore.deleteAccount(username);
		sendJson(socket, 200, result);
	}

	/**
		自动匹配封禁目标类型:
		用户经常把用户名当 IP 填 (如 ban:mohong), 旧逻辑会把它按 IP 记录,
		永远匹配不到真实 IP → 封禁完全无效。这里自动识别并修正:
		- 明确的合法 IP (v4/v6) → ip
		- 在线玩家 (id/昵称) → 有账号封账号, 否则封设备
		- 已注册账号名 → account
		- 形如设备码 (UUID/hex) → device
		返回 {kind, target}; 无法识别返回 null。
	**/
	function inferBan(target:String, kind:String):Dynamic
	{
		if (target == null || target.length == 0)
			return null;
		if (kind == null || kind.length == 0)
			kind = "ip";
		kind = kind.toLowerCase();
		if (kind == "ip")
		{
			if (looksLikeIp(target))
				return {kind: "ip", target: target};
			// kind=ip 但目标不是 IP → 按 在线玩家 → 账号 → 设备码 顺序自动匹配。
			for (c in server.clients)
			{
				if (c.id == target || c.displayName() == target)
				{
					if (c.account != null)
						return {kind: "account", target: c.account.username};
					if (c.identity != null && c.identity.deviceId != null && c.identity.deviceId.length > 0)
						return {kind: "device", target: c.identity.deviceId};
					return null;
				}
			}
			if (server.authStore.findAccount(target) != null)
				return {kind: "account", target: target};
			if (looksLikeDeviceId(target))
				return {kind: "device", target: target};
			return null;
		}
		if (kind == "account" || kind == "device")
			return {kind: kind, target: target};
		return null;
	}

	static function looksLikeIp(target:String):Bool
	{
		if (target == null || target.length == 0 || target.length > 64)
			return false;
		if (target.indexOf(":") >= 0)
			return true; // IPv6
		var parts:Array<String> = target.split(".");
		if (parts.length != 4)
			return false;
		for (p in parts)
		{
			if (p.length == 0 || p.length > 3)
				return false;
			var n:Null<Int> = Std.parseInt(p);
			if (n == null || n < 0 || n > 255)
				return false;
		}
		return true;
	}

	static function looksLikeDeviceId(target:String):Bool
	{
		if (target == null || target.length < 8 || target.length > 80)
			return false;
		for (i in 0...target.length)
		{
			var c:Int = target.charCodeAt(i);
			var ok:Bool = (c >= 48 && c <= 57) || (c >= 97 && c <= 102) || (c >= 65 && c <= 70) || c == 45;
			if (!ok)
				return false;
		}
		return true;
	}

	function handleBan(socket:sys.net.Socket, body:String):Void
	{
		var data:Dynamic = parseBody(body);
		var target:String = Reflect.field(data, "target") == null ? "" : Std.string(Reflect.field(data, "target"));
		var kind:String = Reflect.field(data, "kind") == null ? "ip" : Std.string(Reflect.field(data, "kind"));
		var reason:String = Reflect.field(data, "reason") == null ? "" : Std.string(Reflect.field(data, "reason"));
		var until:Float = 0;
		if (Reflect.hasField(data, "until"))
		{
			var untilVal:Float = Std.parseFloat(Std.string(Reflect.field(data, "until")));
			if (!Math.isNaN(untilVal))
				until = untilVal;
		}
		if (target.length == 0)
		{
			sendJson(socket, 200, {ok: false, message: "缺少封禁目标"});
			return;
		}
		// 自动匹配目标类型 (用户名被当 IP 填时修正为账号/设备)。
		var inferred:Dynamic = inferBan(target, kind);
		if (inferred == null)
		{
			sendJson(socket, 200, {ok: false, message: "无法识别封禁目标: " + target + " (请填 IP 地址、设备码或账号名)"});
			return;
		}
		kind = inferred.kind;
		target = inferred.target;
		server.authStore.ban(target, kind, reason, until, "web panel");
		// 立即断开匹配的在线玩家 (账号/设备/IP; 封账号时其绑定设备也会被自动封禁,
		// 因此匿名连接的客户端同样会被踢出)。
		var kicked:Int = 0;
		var now:Float = Date.now().getTime();
		var banInfo:AuthStore.StoredBan = server.authStore.effectiveBan(kind, target);
		for (c in server.clients)
		{
			var hit:Bool = (kind == "ip" && c.ip == target)
				|| (kind == "device" && c.identity != null && c.identity.deviceId == target)
				|| (kind == "account"
					&& ((c.account != null && c.account.username.toLowerCase() == target.toLowerCase())
						|| (c.identity != null && server.authStore.isDeviceBanned(c.identity.deviceId))));
			if (hit)
			{
				c.send(SeiunProtocol.MSG_ERROR, SeiunProtocol.CHANNEL_CONTROL, AuthStore.banErrorPayload("你已被服务器封禁", banInfo, now));
				c.closing = true;
				kicked++;
			}
		}
		var kindText:String = kind == "ip" ? "IP" : (kind == "device" ? "设备" : "账号");
		sendJson(socket, 200, {
			ok: true,
			message: "已封禁 " + kindText + ": " + target + (until > 0 ? " (到期时间已设置)" : " (永久)") + (kicked > 0 ? "，已断开 " + kicked + " 个在线连接" : ""),
			kind: kind,
			target: target
		});
	}

	function handleUnban(socket:sys.net.Socket, body:String):Void
	{
		var data:Dynamic = parseBody(body);
		var target:String = Reflect.field(data, "target") == null ? "" : Std.string(Reflect.field(data, "target"));
		var kind:String = Reflect.field(data, "kind") == null ? "ip" : Std.string(Reflect.field(data, "kind"));
		if (target.length == 0)
		{
			sendJson(socket, 200, {ok: false, message: "缺少解封目标"});
			return;
		}
		var inferred:Dynamic = inferBan(target, kind);
		if (inferred == null)
		{
			sendJson(socket, 200, {ok: false, message: "无法识别解封目标: " + target});
			return;
		}
		kind = inferred.kind;
		target = inferred.target;
		server.authStore.unban(target, kind);
		var kindText:String = kind == "ip" ? "IP" : (kind == "device" ? "设备" : "账号");
		sendJson(socket, 200, {ok: true, message: "已解封 " + kindText + ": " + target});
	}

	function handleAnnounce(socket:sys.net.Socket, body:String):Void
	{
		var data:Dynamic = parseBody(body);
		var text:String = Reflect.field(data, "text") == null ? "" : Std.string(Reflect.field(data, "text"));
		if (text.length == 0)
		{
			sendJson(socket, 200, {ok: false, message: "缺少公告文本"});
			return;
		}
		for (r in server.roomManager.rooms)
			r.noticeForAll(text);
		server.log("web announce: " + text);
		sendJson(socket, 200, {ok: true, message: "已公告全部房间"});
	}

	function handleKick(socket:sys.net.Socket, body:String):Void
	{
		var data:Dynamic = parseBody(body);
		var id:String = Reflect.field(data, "id") == null ? "" : Std.string(Reflect.field(data, "id"));
		for (c in server.clients)
		{
			if (c.id == id || c.displayName() == id)
			{
				c.sendError(SeiunProtocol.ERR_NOT_AUTHORIZED, "你被管理员请出服务器");
				c.closing = true;
				sendJson(socket, 200, {ok: true, message: "已踢出 " + c.displayName()});
				return;
			}
		}
		sendJson(socket, 200, {ok: false, message: "玩家不存在"});
	}

	function handleRoomClose(socket:sys.net.Socket, body:String):Void
	{
		var data:Dynamic = parseBody(body);
		var code:String = Reflect.field(data, "roomCode") == null ? "" : Std.string(Reflect.field(data, "roomCode"));
		var room:Room = server.roomManager.byCode(code);
		if (room == null)
		{
			sendJson(socket, 200, {ok: false, message: "房间不存在: " + code});
			return;
		}
		for (p in room.players)
		{
			p.sendError(SeiunProtocol.ERR_NOT_AUTHORIZED, "房间已被管理员关闭");
			p.closing = true;
		}
		server.roomManager.closeRoom(room, "管理员关闭");
		sendJson(socket, 200, {ok: true, message: "已关闭房间 " + code});
	}

	function handleConfigSave(socket:sys.net.Socket, body:String):Void
	{
		var data:Dynamic = parseBody(body);
		if (data == null)
		{
			sendJson(socket, 200, {ok: false, message: "参数错误"});
			return;
		}
		var cfg:ServerConfig = server.config;
		var changed:Array<String> = [];
		var setField = function(name:String, value:Dynamic):Void
		{
			if (value == null)
				return;
			switch (name)
			{
				case "port": cfg.port = intOf(value, cfg.port);
				case "adminPort": cfg.adminPort = intOf(value, cfg.adminPort);
				case "adminBind": cfg.adminBind = Std.string(value);
				case "adminPassword":
					var pw:String = Std.string(value);
					if (pw.length > 0)
					{
						cfg.adminPassword = pw;
						setPassword(pw);
					}
				case "dataDir": cfg.dataDir = Std.string(value);
				case "serverName": cfg.serverName = Std.string(value);
				case "maxPlayersDefault": cfg.maxPlayersDefault = intOf(value, cfg.maxPlayersDefault);
				case "allowAnonymous": cfg.allowAnonymous = boolOf(value, cfg.allowAnonymous);
				case "webPanelEnabled": cfg.webPanelEnabled = boolOf(value, cfg.webPanelEnabled);
				case "maxAccountsPerIp": cfg.maxAccountsPerIp = intOf(value, cfg.maxAccountsPerIp);
				case "registerCooldownSeconds": cfg.registerCooldownSeconds = intOf(value, cfg.registerCooldownSeconds);
				case "sessionTtlDays": cfg.sessionTtlDays = intOf(value, cfg.sessionTtlDays);
				case "maxDevicesPerAccount": cfg.maxDevicesPerAccount = intOf(value, cfg.maxDevicesPerAccount);
				case "strictDeviceBinding": cfg.strictDeviceBinding = boolOf(value, cfg.strictDeviceBinding);
				case "loginFailLockoutCount": cfg.loginFailLockoutCount = intOf(value, cfg.loginFailLockoutCount);
				case "loginFailLockoutMinutes": cfg.loginFailLockoutMinutes = intOf(value, cfg.loginFailLockoutMinutes);
				case "heartbeatTimeoutSeconds": cfg.heartbeatTimeoutSeconds = Std.parseFloat(Std.string(value));
				case "reconnectWindowSeconds": cfg.reconnectWindowSeconds = Std.parseFloat(Std.string(value));
				default: return;
			}
			changed.push(name);
		};
		for (f in Reflect.fields(data))
			setField(f, Reflect.field(data, f));
		server.saveConfig();
		var note:String = changed.length == 0 ? "" : "已更新: " + changed.join(", ");
		sendJson(socket, 200, {ok: true, message: note + " (端口/绑定等部分配置需重启生效)"});
	}

	static function intOf(v:Dynamic, fallback:Int):Int
	{
		var parsed:Null<Int> = Std.parseInt(Std.string(v));
		return parsed == null ? fallback : parsed;
	}

	static function boolOf(v:Dynamic, fallback:Bool):Bool
	{
		var text:String = Std.string(v).toLowerCase();
		if (text == "true" || text == "1" || text == "on")
			return true;
		if (text == "false" || text == "0" || text == "off")
			return false;
		return fallback;
	}

	/** 旧面板兼容: POST /api/cmd {command, args}。 */
	function handleLegacyCmd(socket:sys.net.Socket, body:String):Void
	{
		var cmd:Dynamic = null;
		try { cmd = Json.parse(body); } catch (e:Dynamic) {}
		var result:Dynamic = {ok: false, message: "bad command"};
		if (cmd != null)
		{
			var command:String = Reflect.field(cmd, "command");
			var args:Dynamic = Reflect.field(cmd, "args");
			result = executeCommand(command, args);
		}
		sendJson(socket, 200, result);
	}

	function executeCommand(command:String, args:Dynamic):Dynamic
	{
		if (command == null)
			return {ok: false, message: "缺少命令"};
		switch (command)
		{
			case "kick":
				var id:String = args == null ? "" : Std.string(Reflect.field(args, "id"));
				for (c in server.clients)
					if (c.id == id || c.displayName() == id)
					{
						c.sendError(SeiunProtocol.ERR_NOT_AUTHORIZED, "你被管理员请出服务器");
						c.closing = true;
						return {ok: true, message: "已踢出 " + c.displayName()};
					}
				return {ok: false, message: "玩家不存在"};
			case "ban":
				var target:String = args == null ? "" : Std.string(Reflect.field(args, "target"));
				var kind:String = args == null || Reflect.field(args, "kind") == null ? "ip" : Std.string(Reflect.field(args, "kind"));
				var inferred:Dynamic = inferBan(target, kind);
				if (inferred == null)
					return {ok: false, message: "无法识别封禁目标: " + target + " (请填 IP、设备码或账号名)"};
				kind = inferred.kind;
				target = inferred.target;
				server.authStore.ban(target, kind, "web panel", 0, "web panel");
				var now2:Float = Date.now().getTime();
				var banInfo2:AuthStore.StoredBan = server.authStore.effectiveBan(kind, target);
				for (c in server.clients)
				{
					if ((kind == "ip" && c.ip == target)
						|| (kind == "device" && c.identity != null && c.identity.deviceId == target)
						|| (kind == "account"
							&& ((c.account != null && c.account.username.toLowerCase() == target.toLowerCase())
								|| (c.identity != null && server.authStore.isDeviceBanned(c.identity.deviceId)))))
					{
						c.send(SeiunProtocol.MSG_ERROR, SeiunProtocol.CHANNEL_CONTROL, AuthStore.banErrorPayload("你已被服务器封禁", banInfo2, now2));
						c.closing = true;
					}
				}
				return {ok: true, message: "已封禁 " + kind + ":" + target};
			case "unban":
				var target2:String = args == null ? "" : Std.string(Reflect.field(args, "target"));
				var kind2:String = args == null || Reflect.field(args, "kind") == null ? "ip" : Std.string(Reflect.field(args, "kind"));
				var inferred2:Dynamic = inferBan(target2, kind2);
				if (inferred2 == null)
					return {ok: false, message: "无法识别解封目标: " + target2};
				kind2 = inferred2.kind;
				target2 = inferred2.target;
				server.authStore.unban(target2, kind2);
				return {ok: true, message: "已解封 " + kind2 + ":" + target2};
			case "anticheat":
				for (r in server.roomManager.rooms)
				{
					r.settings.antiCheat = false;
					r.roomInfoMessage();
				}
				return {ok: true, message: "反作弊已移除，始终关闭"};
			case "announce":
				var text:String = args == null ? "" : Std.string(Reflect.field(args, "text"));
				if (text.length == 0)
					return {ok: false, message: "缺少公告文本"};
				for (r in server.roomManager.rooms)
					r.noticeForAll(text);
				return {ok: true, message: "已公告"};
			case "setpassword":
				var pw:String = args == null ? "" : Std.string(Reflect.field(args, "password"));
				for (r in server.roomManager.rooms)
					r.settings.password = pw;
				return {ok: true, message: "房间密码已更新"};
			case "adminpassword":
				var pw2:String = args == null ? "" : Std.string(Reflect.field(args, "password"));
				if (pw2.length == 0)
					return {ok: false, message: "缺少 password"};
				server.config.adminPassword = pw2;
				setPassword(pw2);
				server.saveConfig();
				return {ok: true, message: "面板口令已更新"};
			case "stop":
				server.stopRequested = true;
				return {ok: true, message: "服务器将关闭"};
			default:
				return {ok: false, message: "未知命令: " + command};
		}
	}

	// ── 响应 ────────────────────────────────────────────

	function sendJson(socket:sys.net.Socket, code:Int, obj:Dynamic, extraHeader:String = ""):Void
	{
		sendResponse(socket, code, "application/json; charset=utf-8", Json.stringify(obj), extraHeader);
	}

	function sendResponse(socket:sys.net.Socket, code:Int, contentType:String, body:String, extraHeader:String):Void
	{
		var bodyBytes:haxe.io.Bytes = haxe.io.Bytes.ofString(body);
		var head:String = "HTTP/1.0 " + code + " " + statusText(code) + "\r\n"
			+ "Content-Type: " + contentType + "\r\n"
			+ "Content-Length: " + bodyBytes.length + "\r\n"
			+ "Cache-Control: no-store\r\n"
			+ "Connection: close\r\n"
			+ extraHeader + "\r\n";
		socket.output.writeString(head);
		socket.output.writeString(body);
		socket.output.flush();
	}

	static function statusText(code:Int):String
	{
		return switch (code)
		{
			case 200: "OK";
			case 401: "Unauthorized";
			case 404: "Not Found";
			default: "OK";
		}
	}

	/** 从 server/web/admin.html 读取面板页 (允许管理员自定义样式), 失败回退内嵌页。 */
	function loadPanelFile():String
	{
		#if sys
		try
		{
			if (sys.FileSystem.exists("server/web/admin.html"))
				return AuthStore.readTextFile("server/web/admin.html");
		}
		catch (e:Dynamic) {}
		#end
		return panelPage();
	}

	/** 302 跳转 (登录成功等场景)。 */
	function sendRedirect(socket:sys.net.Socket, location:String, extraHeader:String):Void
	{
		var head:String = "HTTP/1.0 302 Found\r\n"
			+ "Location: " + location + "\r\n"
			+ "Content-Length: 0\r\n"
			+ "Cache-Control: no-store\r\n"
			+ "Connection: close\r\n"
			+ extraHeader + "\r\n";
		socket.output.writeString(head);
		socket.output.flush();
	}

	function loginPage(?error:String):String
	{
		var errHtml:String = "";
		if (error != null && error.length > 0)
			errHtml = "<p style='color:#ff5c6c;font-size:13px;margin:0 0 8px'>" + error + "</p>";
		return "<!doctype html><html><head><meta charset='utf-8'><title>SeiunEngine Server</title></head>"
			+ "<body style='font-family:sans-serif;background:#101018;color:#eee;display:flex;align-items:center;justify-content:center;height:100vh;margin:0'>"
			+ "<form method='post' action='/login' style='background:#1a1a28;padding:32px;border-radius:12px;text-align:center'>"
			+ "<h2>SeiunEngine 专用服务器</h2>"
			+ errHtml
			+ "<input name='password' type='password' placeholder='管理口令' autofocus style='display:block;margin:16px auto;padding:8px 12px;width:220px'>"
			+ "<button type='submit' style='padding:8px 24px;cursor:pointer'>登录</button>"
			+ "</form></body></html>";
	}

	function panelPage():String
	{
		return "<!doctype html><html><head><meta charset='utf-8'><title>SeiunEngine Server</title></head>"
			+ "<body style='font-family:sans-serif;background:#101018;color:#eee;padding:20px'>"
			+ "<h1>SeiunEngine 专用服务器</h1>"
			+ "<p>管理面板页面文件缺失 (server/web/admin.html)。请将完整面板文件放到该路径。</p>"
			+ "</body></html>";
	}
}
