package online.server;

import haxe.io.Bytes;
import haxe.io.BytesBuffer;
import haxe.io.BytesOutput;
import haxe.io.Error;
import online.shared.OnlineTypes.PlayerIdentity;
import online.shared.OnlineTypes.PlayerPublicInfo;
import online.shared.OnlineTypes.RoomSettings;
import online.shared.SeiunPacket;
import online.shared.SeiunPacket.InboundPacket;
import online.shared.SeiunPacket.PacketFramer;
import online.shared.SeiunProtocol;

/**
	服务器侧的一条 TCP 连接。
	包含握手状态、限流、发送队列与心跳计时。
**/
class ServerClient
{
	public var id:String;
	public var socket:sys.net.Socket;
	public var ip:String;
	public var connectedAt:Float;
	public var server:SeiunServer;

	public var identity:PlayerIdentity = null;
	public var account:AuthStore.StoredAccount = null;
	public var sessionToken:String = "";
	public var room:Room = null;
	public var isReady:Bool = false;
	public var chartHash:String = "";
	public var team:Int = 0;
	public var handshakeDone:Bool = false;
	public var authenticated:Bool = false;
	public var closing:Bool = false;

	public var lastReadAt:Float = 0;
	public var lastWriteAt:Float = 0;
	public var lastPingAt:Float = 0;
	public var lastClientTime:Float = 0;
	/** 服务器收到上一个客户端时间戳采样时的服务器时刻 (防加速检测用)。 */
	public var lastClientSampleAt:Float = 0;
	public var lastClientJump:Float = 0;
	public var violations:Int = 0;
	public var pingMs:Float = 0;
	public var recentPressTimes:Array<Float> = [];

	var framer:PacketFramer;
	var readChunk:Bytes;
	var outQueue:Array<Bytes> = [];
	var outPos:Int = 0;
	var sequence:Int = 0;
	var rateWindowStart:Float = 0;
	var rateCount:Int = 0;
	var fileRateWindowStart:Float = 0;
	var fileRateCount:Int = 0;
	var rateTypeCounts:Map<Int, Int> = new Map<Int, Int>();
	var rateLimitWarned:Bool = false;
	var rateOverWindowCount:Int = 0;
	var rateWindowWasOver:Bool = false;
	var fileRateLimitWarned:Bool = false;
	/** 当前包因限速被丢弃 (不断连); SeiunServer 处理后清除。 */
	public var rateDropCurrent:Bool = false;

	/**
		模组文件传输: 只保留原文件 Bytes + 已发送分块序号, 每次把"一个"
		分块放进发送队列。64MB 文件也只会占用一份原文件内存, 不会再额外
		复制出一整份分块数组。
	**/
	public var pendingFileData:Bytes = null;
	public var pendingFileChunkIndex:Int = 0;
	public var pendingFileChunkCount:Int = 0;
	public var fileTransferActive:Bool = false;
	/** 当前正在传输/刚完成传输的文件 (ACK 必须匹配此路径才扣减缺失数)。 */
	public var pendingModPath:String = "";
	public var pendingModTransferId:Int = -1;

	public function new(server:SeiunServer, socket:sys.net.Socket)
	{
		this.server = server;
		this.socket = socket;
		this.id = "c" + Std.string(Date.now().getTime()) + "_" + Std.string(Std.random(0x7FFFFFFF));
		this.connectedAt = Date.now().getTime();
		this.lastReadAt = this.connectedAt;
		this.lastWriteAt = this.connectedAt;
		this.framer = new PacketFramer();
		this.readChunk = Bytes.alloc(64 * 1024);
		if (socket != null)
		{
			try
			{
				var peer:{host:sys.net.Host, port:Int} = socket.peer();
				this.ip = peer.host.toString();
			}
			catch (e:Dynamic)
			{
				this.ip = "unknown";
			}
			try
			{
				socket.setBlocking(false);
			}
			catch (e:Dynamic) {}
		}
		else
			this.ip = "local";
	}

	public function displayName():String
	{
		if (identity != null && identity.nickname != null && identity.nickname.length > 0)
			return identity.nickname;
		if (account != null)
			return account.username;
		return id;
	}

	public function publicInfo():PlayerPublicInfo
	{
		var info:PlayerPublicInfo = {
			id: id,
			deviceId: identity == null ? "" : identity.deviceId,
			nickname: displayName(),
			avatar: identity == null ? "" : identity.avatar,
			isHost: room != null && room.hostId == id,
			isReady: isReady,
			team: team,
			pingMs: pingMs
		};
		if (identity != null && identity.skin != null && identity.skin.length > 0)
			info.skin = identity.skin;
		if (identity != null && identity.skinData != null)
			info.skinData = identity.skinData;
		if (account != null)
			info.accountName = account.username;
		if (ip != null)
			info.ip = ip;
		if (connectedAt > 0)
			info.joinedAt = connectedAt;
		return info;
	}

	public function hasPendingWrites():Bool
	{
		return outQueue.length > 0;
	}

	public function send(type:Int, channel:Int, obj:Dynamic, flags:Int = 0):Void
	{
		if (closing)
			return;
		var payload:String = haxe.Json.stringify(obj);
		var limit:Int = (channel == SeiunProtocol.CHANNEL_FILE)
			? SeiunProtocol.MAX_FILE_BYTES
			: (channel == SeiunProtocol.CHANNEL_ASYNC ? SeiunProtocol.MAX_SCORE_BYTES : SeiunProtocol.MAX_MESSAGE_BYTES);
		if (payload.length > limit)
			return;
		if (outQueue.length > 2048)
			return; // 发送队列保护, 避免慢客户端拖垮服务器内存。
		queueBytes(SeiunPacket.encodeString(type, channel, nextSequence(), payload, flags));
	}

	public function sendError(code:Int, message:String, detail:String = ""):Void
	{
		send(SeiunProtocol.MSG_ERROR, SeiunProtocol.CHANNEL_CONTROL, {code: code, message: message, detail: detail});
	}

	public function sendBytes(type:Int, channel:Int, flags:Int, payload:Bytes):Void
	{
		if (closing)
			return;
		queueBytes(SeiunPacket.encodeBytes(type, channel, nextSequence(), payload, flags));
	}

	public function nextSequence():Int
	{
		sequence++;
		if (sequence > 0x7FFFFFFF)
			sequence = 1;
		return sequence;
	}

	public function queueBytes(data:Bytes):Void
	{
		if (data == null || data.length == 0)
			return;
		outQueue.push(data);
		lastWriteAt = Date.now().getTime();
	}

	public function flush():Bool
	{
		if (socket == null)
			return true;
		if (outQueue.length == 0)
			enqueueNextFileChunk();
		while (outQueue.length > 0)
		{
			var current:Bytes = outQueue[0];
			var left:Int = current.length - outPos;
			try
			{
				var written:Int = socket.output.writeBytes(current, outPos, left);
				if (written <= 0)
					return false;
				outPos += written;
				if (outPos >= current.length)
				{
					outQueue.shift();
					outPos = 0;
					if (outQueue.length == 0)
						enqueueNextFileChunk();
				}
				lastWriteAt = Date.now().getTime();
			}
			catch (e:Dynamic)
			{
				if (e == Error.Blocked || Std.string(e).toLowerCase().indexOf("blocked") >= 0)
					return false;
				return false;
			}
		}
		return true;
	}

	public function clearPendingFile():Void
	{
		pendingFileData = null;
		pendingFileChunkIndex = 0;
		pendingFileChunkCount = 0;
		fileTransferActive = false;
		pendingModPath = "";
		pendingModTransferId = -1;
	}

	public function queueFileData(data:Bytes, path:String = "", transferId:Int = -1):Void
	{
		pendingFileData = data;
		pendingFileChunkIndex = 0;
		pendingFileChunkCount = data == null || data.length <= 0 ? 0 : Math.ceil(data.length / SeiunProtocol.FILE_CHUNK_BYTES);
		fileTransferActive = pendingFileChunkCount > 0;
		pendingModPath = path == null ? "" : path;
		pendingModTransferId = transferId;
		enqueueNextFileChunk();
	}

	function enqueueNextFileChunk():Void
	{
		if (pendingFileData == null || pendingFileChunkCount <= 0
			|| pendingFileChunkIndex >= pendingFileChunkCount)
		{
			fileTransferActive = false;
			return;
		}
		var index:Int = pendingFileChunkIndex;
		var chunkSize:Int = SeiunProtocol.FILE_CHUNK_BYTES;
		var pos:Int = index * chunkSize;
		var len:Int = Std.int(Math.min(chunkSize, pendingFileData.length - pos));
		var pathBytes:Bytes = Bytes.ofString(pendingModPath);

		var head:BytesOutput = new BytesOutput();
		head.bigEndian = true;
		head.writeByte(0x5A);
		head.writeInt32(pendingModTransferId);
		head.writeInt32(pathBytes.length);
		head.writeBytes(pathBytes, 0, pathBytes.length);
		head.writeInt32(index);
		head.writeInt32(pendingFileChunkCount);
		head.writeInt32(len);
		var headBytes:Bytes = head.getBytes();
		head.close();

		var buf:BytesBuffer = new BytesBuffer();
		buf.add(headBytes);
		buf.add(pendingFileData.sub(pos, len));
		// 关键: 分块必须再包一层 Seiun 28 字节帧头。旧实现把裸分块直接塞进
		// 发送队列, 客户端 PacketFramer 永远等不到完整帧, 模组传输会静默卡死。
		queueBytes(SeiunPacket.encodeBytes(
			SeiunProtocol.MSG_MOD_FILE_CHUNK,
			SeiunProtocol.CHANNEL_FILE,
			nextSequence(),
			buf.getBytes(),
			SeiunProtocol.FLAG_RAW_BYTES
		));
		pendingFileChunkIndex++;
	}

	public function pumpRead():Bool
	{
		var total:Int = 0;
		while (true)
		{
			try
			{
				var n:Int = socket.input.readBytes(readChunk, 0, readChunk.length);
				if (n <= 0)
					break;
				total += n;
				lastReadAt = Date.now().getTime();
				var packets:Array<InboundPacket> = framer.push(readChunk, 0, n);
				for (p in packets)
					if (!server.handlePacket(this, p))
						return false;
			}
			catch (e:Dynamic)
			{
				if (e == Error.Blocked || Std.string(e).toLowerCase().indexOf("blocked") >= 0)
					break;
				return false;
			}
		}
		return true;
	}

	public function checkRate(type:Int, channel:Int):Bool
	{
		var isFileRate:Bool = channel == SeiunProtocol.CHANNEL_FILE;
		var limit:Int = isFileRate
			? SeiunProtocol.RATE_LIMIT_FILE_MESSAGES
			: SeiunProtocol.RATE_LIMIT_MESSAGES;
		var now:Float = Date.now().getTime();
		var windowStart:Float = isFileRate ? fileRateWindowStart : rateWindowStart;
		var count:Int = isFileRate ? fileRateCount : rateCount;
		if (windowStart <= 0)
		{
			windowStart = now;
			count = 1;
			if (!isFileRate)
			{
				rateTypeCounts = new Map<Int, Int>();
				rateLimitWarned = false;
				rateOverWindowCount = 0;
				rateWindowWasOver = false;
			}
			else
				fileRateLimitWarned = false;
		}
		else if (now - windowStart > SeiunProtocol.RATE_LIMIT_WINDOW_SECONDS * 1000.0)
		{
			windowStart = now;
			count = 1;
			if (!isFileRate)
			{
				rateTypeCounts = new Map<Int, Int>();
				rateLimitWarned = false;
				// 上一个窗口若超限, 保留连续超限计数; 否则清零。
				if (!rateWindowWasOver)
					rateOverWindowCount = 0;
				rateWindowWasOver = false;
			}
			else
				fileRateLimitWarned = false;
		}
		else
		{
			count++;
		}

		if (isFileRate)
		{
			fileRateWindowStart = windowStart;
			fileRateCount = count;
			if (count > limit)
			{
				if (!fileRateLimitWarned)
				{
					fileRateLimitWarned = true;
					server.log("FILE rate limit exceeded by " + displayName()
						+ " (" + count + "/" + limit + " in " + SeiunProtocol.RATE_LIMIT_WINDOW_SECONDS + "s), dropping packet "
						+ typeLabel(type));
				}
				rateDropCurrent = true;
				return true;
			}
			return true;
		}

		rateWindowStart = windowStart;
		rateCount = count;
		if (rateTypeCounts == null)
			rateTypeCounts = new Map<Int, Int>();
		rateTypeCounts.set(type, (rateTypeCounts.exists(type) ? rateTypeCounts.get(type) : 0) + 1);
		if (count > limit)
		{
			if (!rateLimitWarned)
			{
				rateLimitWarned = true;
				rateWindowWasOver = true;
				rateOverWindowCount++;
				var top:String = topRateTypes(6);
				server.log("rate limit exceeded by " + displayName()
					+ " (" + count + "/" + limit + " in " + SeiunProtocol.RATE_LIMIT_WINDOW_SECONDS + "s), dropping; top types: "
					+ top + " (over-window " + rateOverWindowCount + ")");
				if (rateOverWindowCount >= 3)
				{
					sendError(SeiunProtocol.ERR_RATE_LIMIT, "消息发送过快，连接已断开");
					closing = true;
					return false;
				}
			}
			rateDropCurrent = true;
			return true;
		}
		return true;
	}

	function topRateTypes(max:Int):String
	{
		var entries:Array<{t:Int, c:Int}> = [];
		for (k in rateTypeCounts.keys())
			entries.push({t: k, c: rateTypeCounts.get(k)});
		entries.sort(function(a, b):Int { return b.c - a.c; });
		var parts:Array<String> = [];
		for (i in 0...entries.length)
		{
			if (i >= max)
				break;
			parts.push(typeLabel(entries[i].t) + "=" + entries[i].c);
		}
		return parts.length > 0 ? parts.join(", ") : "(none)";
	}

	static function typeLabel(t:Int):String
	{
		switch (t)
		{
			case SeiunProtocol.MSG_HELLO: return "HELLO";
			case SeiunProtocol.MSG_WELCOME: return "WELCOME";
			case SeiunProtocol.MSG_ERROR: return "ERROR";
			case SeiunProtocol.MSG_PING: return "PING";
			case SeiunProtocol.MSG_PONG: return "PONG";
			case SeiunProtocol.MSG_HEARTBEAT: return "HEARTBEAT";
			case SeiunProtocol.MSG_BYE: return "BYE";
			case SeiunProtocol.MSG_CRASH_SIGNAL: return "CRASH_SIGNAL";
			case SeiunProtocol.MSG_AUTH_REGISTER: return "AUTH_REGISTER";
			case SeiunProtocol.MSG_AUTH_LOGIN: return "AUTH_LOGIN";
			case SeiunProtocol.MSG_AUTH_RESULT: return "AUTH_RESULT";
			case SeiunProtocol.MSG_PROFILE_UPDATE: return "PROFILE_UPDATE";
			case SeiunProtocol.MSG_ROOM_LIST: return "ROOM_LIST";
			case SeiunProtocol.MSG_ROOM_LIST_RESULT: return "ROOM_LIST_RESULT";
			case SeiunProtocol.MSG_ROOM_CREATE: return "ROOM_CREATE";
			case SeiunProtocol.MSG_ROOM_JOIN: return "ROOM_JOIN";
			case SeiunProtocol.MSG_ROOM_JOIN_RESULT: return "ROOM_JOIN_RESULT";
			case SeiunProtocol.MSG_ROOM_LEAVE: return "ROOM_LEAVE";
			case SeiunProtocol.MSG_ROOM_INFO: return "ROOM_INFO";
			case SeiunProtocol.MSG_ROOM_PLAYER_JOIN: return "ROOM_PLAYER_JOIN";
			case SeiunProtocol.MSG_ROOM_PLAYER_LEAVE: return "ROOM_PLAYER_LEAVE";
			case SeiunProtocol.MSG_ROOM_READY: return "ROOM_READY";
			case SeiunProtocol.MSG_ROOM_SETTINGS: return "ROOM_SETTINGS";
			case SeiunProtocol.MSG_ROOM_CHAT: return "ROOM_CHAT";
			case SeiunProtocol.MSG_ROOM_ANNOUNCE: return "ROOM_ANNOUNCE";
			case SeiunProtocol.MSG_ROOM_SONG_SELECT: return "ROOM_SONG_SELECT";
			case SeiunProtocol.MSG_ROOM_FORCE_START: return "ROOM_FORCE_START";
			case SeiunProtocol.MSG_ROOM_KICK: return "ROOM_KICK";
			case SeiunProtocol.MSG_ROOM_SET_SKIN: return "ROOM_SET_SKIN";
			case SeiunProtocol.MSG_ROOM_PLAYER_SKIN: return "ROOM_PLAYER_SKIN";
			case SeiunProtocol.MSG_MOD_MANIFEST: return "MOD_MANIFEST";
			case SeiunProtocol.MSG_MOD_MANIFEST_RESULT: return "MOD_MANIFEST_RESULT";
			case SeiunProtocol.MSG_MOD_FILE_REQUEST: return "MOD_FILE_REQUEST";
			case SeiunProtocol.MSG_MOD_FILE_CHUNK: return "MOD_FILE_CHUNK";
			case SeiunProtocol.MSG_MOD_FILE_ACK: return "MOD_FILE_ACK";
			case SeiunProtocol.MSG_CHART_BUNDLE_ANNOUNCE: return "CHART_BUNDLE_ANNOUNCE";
			case SeiunProtocol.MSG_GAME_START: return "GAME_START";
			case SeiunProtocol.MSG_GAME_COUNTDOWN: return "GAME_COUNTDOWN";
			case SeiunProtocol.MSG_GAME_INPUT: return "GAME_INPUT";
			case SeiunProtocol.MSG_GAME_JUDGE: return "GAME_JUDGE";
			case SeiunProtocol.MSG_GAME_HEALTH: return "GAME_HEALTH";
			case SeiunProtocol.MSG_GAME_PAUSE: return "GAME_PAUSE";
			case SeiunProtocol.MSG_GAME_RESUME: return "GAME_RESUME";
			case SeiunProtocol.MSG_GAME_END: return "GAME_END";
			case SeiunProtocol.MSG_GAME_RESULT: return "GAME_RESULT";
			case SeiunProtocol.MSG_GAME_RECONNECT: return "GAME_RECONNECT";
			case SeiunProtocol.MSG_GAME_RECONNECT_RESULT: return "GAME_RECONNECT_RESULT";
			case SeiunProtocol.MSG_GAME_SYNC: return "GAME_SYNC";
			case SeiunProtocol.MSG_GAME_START_ACK: return "GAME_START_ACK";
			case SeiunProtocol.MSG_ASYNC_START: return "ASYNC_START";
			case SeiunProtocol.MSG_ASYNC_STATUS: return "ASYNC_STATUS";
			case SeiunProtocol.MSG_ASYNC_SUBMIT: return "ASYNC_SUBMIT";
			case SeiunProtocol.MSG_ASYNC_RANKING: return "ASYNC_RANKING";
			case SeiunProtocol.MSG_ASYNC_FINALIZE: return "ASYNC_FINALIZE";
			case SeiunProtocol.MSG_ASYNC_REPLAY_VERIFY: return "ASYNC_REPLAY_VERIFY";
			case SeiunProtocol.MSG_ASYNC_REPLAY_FETCH: return "ASYNC_REPLAY_FETCH";
			case SeiunProtocol.MSG_ASYNC_REPLAY: return "ASYNC_REPLAY";
			case SeiunProtocol.MSG_ASYNC_REPLAY_UPLOAD: return "ASYNC_REPLAY_UPLOAD";
			case SeiunProtocol.MSG_ADMIN_COMMAND: return "ADMIN_COMMAND";
			case SeiunProtocol.MSG_ADMIN_RESULT: return "ADMIN_RESULT";
			default: return "0x" + StringTools.hex(t);
		}
	}

	public function markViolation(reason:String):Void
	{
		violations++;
		server.log("violation by " + displayName() + ": " + reason);
		// 阈值 5 (每局开始清零): 偶发的偏谱按键 (人类手误) 不该踢人, 连续大量违规才断连。
		if (violations >= 5)
		{
			sendError(SeiunProtocol.ERR_BAD_PACKET, "协议违规次数过多，连接已断开");
			closing = true;
		}
	}

	public function close():Void
	{
		closing = true;
		try
		{
			if (room != null)
			{
				var leaveRoom:Room = room;
				room = null;
				server.roomManager.onClientLeave(this, leaveRoom, true);
			}
		}
		catch (e:Dynamic) {}
		if (socket != null)
		{
			// 先冲刷发送队列 (如"你已被封禁"等错误消息), 再关闭 socket,
			// 否则客户端只会看到裸断开, 不知道发生了什么。
			try { flush(); } catch (e:Dynamic) {}
			try { socket.close(); } catch (e:Dynamic) {}
		}
	}

	public function handshakeAged(now:Float):Bool
	{
		return !handshakeDone && (now - connectedAt) > SeiunProtocol.HELLO_TIMEOUT_SECONDS * 1000.0;
	}

	public function heartbeatTimedOut(now:Float, timeoutSeconds:Float):Bool
	{
		return handshakeDone && (now - lastReadAt) > timeoutSeconds * 1000.0;
	}
}
