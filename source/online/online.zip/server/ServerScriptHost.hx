package online.server;

import hscript.iris.Iris;
import hscript.iris.IrisConfig;

/**
	服务端 HScript (hscript-iris) 钩子系统。
	- 脚本是服主可信代码, 放在 server/scripts/ 或 mods/server/;
	- 默认屏蔽文件/网络/进程等危险 import;
	- 钩子: onInit, onRoomCreate, onPlayerJoin, onPlayerLeave, onInput,
	  onJudge, onChat, onModSync, onGameStart, onGameEnd。
	- Lua 服务端脚本仅原生 cpp 构建可选接入; Node 目标不支持。
**/
class ServerScriptHost
{
	public var scripts:Array<ServerScript> = [];

	public function new(server:SeiunServer)
	{
		loadDirectory(server.config.serverScriptsDir);
		loadDirectory("mods/server");
		for (s in scripts)
		{
			s.iris.set("server", server);
			s.iris.set("api", new ServerScriptApi(server));
			try { s.iris.execute(); } catch (e:Dynamic) {}
		}
		call("onInit", []);
	}

	function loadDirectory(path:String):Void
	{
		#if sys
		if (path == null || path.length == 0 || !sys.FileSystem.exists(path) || !sys.FileSystem.isDirectory(path))
			return;
		try
		{
			for (file in sys.FileSystem.readDirectory(path))
			{
				if (!file.endsWith(".hx") && !file.endsWith(".hscript"))
					continue;
				var full:String = path + "/" + file;
				try
				{
					var src:String = sys.io.File.getContent(full);
					var iris:Iris = new Iris(src, new IrisConfig(full, false, true, [
						"sys.io.File", "sys.io.Process", "sys.net.Socket", "sys.net.UdpSocket", "haxe.Http"
					]));
					scripts.push({name: full, iris: iris});
				}
				catch (e:Dynamic) {}
			}
		}
		catch (e:Dynamic) {}
		#end
	}

	public function call(name:String, args:Array<Dynamic>):Void
	{
		for (s in scripts)
		{
			try
			{
				// hscript-iris 没有 get() 方法; 用 exists() 判断钩子是否存在。
				if (s.iris.exists(name))
					s.iris.call(name, args);
			}
			catch (e:Dynamic) {}
		}
	}
}

typedef ServerScript =
{
	var name:String;
	var iris:Iris;
}

/** 受限服务端脚本 API。 */
class ServerScriptApi
{
	var server:SeiunServer;

	public function new(server:SeiunServer)
	{
		this.server = server;
	}

	public function log(text:String):Void
	{
		server.log("[script] " + text);
	}

	public function rooms():Array<Dynamic>
	{
		var out:Array<Dynamic> = [];
		for (r in server.roomManager.rooms)
			out.push({code: r.roomCode, name: r.settings.roomName, players: r.players.length, mode: r.settings.mode});
		return out;
	}

	public function announce(text:String):Void
	{
		for (r in server.roomManager.rooms)
			r.noticeForAll(text);
	}

	public function setRoomPassword(code:String, password:String):Bool
	{
		var r:Room = server.roomManager.byCode(code);
		if (r == null)
			return false;
		r.settings.password = password == null ? "" : password;
		r.roomInfoMessage();
		return true;
	}

	public function setRoomAnticheat(code:String, enabled:Bool):Bool
	{
		// 反作弊已移除: 脚本调用也强制关闭。
		var r:Room = server.roomManager.byCode(code);
		if (r == null)
			return false;
		r.settings.antiCheat = false;
		r.roomInfoMessage();
		return true;
	}
}
