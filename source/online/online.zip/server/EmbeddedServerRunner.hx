package online.server;

import online.shared.SeiunProtocol;

/**
	Minecraft 式局域网托管入口: 在游戏进程内启动内置服务器。
	服务器跑在独立 cpp 线程, 游戏通过 127.0.0.1 连接, 不阻塞渲染线程。
**/
class EmbeddedServerRunner
{
	public static var instance:SeiunServer = null;
	public static var actualPort:Int = 0;
	public static var running(default, null):Bool = false;

	/** 内置服务器日志缓存 (最近 50 行), LAN 托管页直接显示。 */
	static var logBuffer:Array<String> = [];

	#if (cpp || android)
	static var thread:sys.thread.Thread = null;
	static var generation:Int = 0;
	#end

	public static function lastLogs():Array<String>
	{
		return logBuffer.copy();
	}

	public static function clearLogs():Void
	{
		logBuffer = [];
	}

	/** 内置托管日志缓存写入 (实例创建前的迁移日志也走这里)。 */
	static function pushLog(text:String):Void
	{
		logBuffer.push(text);
		while (logBuffer.length > 50)
			logBuffer.shift();
	}

	public static function start(?port:Int):Bool
	{
		if (running)
			return true;

		var cfg:ServerConfig = ServerConfig.embeddedDefaults();
		#if sys
		// 内置托管数据统一落 applicationStorageDirectory/seiun_online (绝不依赖 CWD);
		// 首次运行把历史散落在游戏目录的 seiun_online 并入一次。
		try
		{
			var target:String = haxe.io.Path.normalize(lime.system.System.applicationStorageDirectory + "/seiun_online");
			cfg.dataDir = target;
			for (line in ServerConfig.migrateLegacyDataDirs(target, [Sys.getCwd() + "/seiun_online"]))
				pushLog("[迁移] " + line);
		}
		catch (e:Dynamic) {}
		#end
		var attemptPort:Int = port == null || port <= 0 ? SeiunProtocol.DEFAULT_PORT : port;
		var started:Bool = false;

		for (attempt in 0...6)
		{
			cfg.port = attemptPort + attempt;
			instance = new SeiunServer(cfg);
			instance.logSink = function(text:String):Void
			{
				logBuffer.push(text);
				while (logBuffer.length > 50)
					logBuffer.shift();
				#if sys
				try { Sys.println(text); } catch (e:Dynamic) {}
				#end
			};
			if (instance.start())
			{
				started = true;
				actualPort = cfg.port;
				break;
			}
			instance = null;
		}

		if (!started)
		{
			actualPort = 0;
			return false;
		}

		#if (cpp || android)
		var server:SeiunServer = instance;
		generation++;
		var gen:Int = generation;
		thread = sys.thread.Thread.create(function():Void
		{
			try
			{
				server.runForever();
			}
			catch (e:Dynamic)
			{
				server.log("embedded server thread error: " + Std.string(e));
				server.shutdown();
			}
			// 只有"当前代"的线程才能清状态: stop() 后立刻 start() 时,
			// 旧线程收尾绝不能把新服务器的 running/instance 清掉。
			if (EmbeddedServerRunner.generation == gen)
			{
				EmbeddedServerRunner.running = false;
				if (EmbeddedServerRunner.instance == server)
					EmbeddedServerRunner.instance = null;
				EmbeddedServerRunner.actualPort = 0;
			}
		});
		#else
		// 非 cpp 目标不启动后台服务器, 由 UI 提示不支持。
		instance.stopRequested = true;
		instance.shutdown();
		instance = null;
		actualPort = 0;
		return false;
		#end
		running = true;
		return true;
	}

	public static function stop():Void
	{
		#if (cpp || android)
		generation++;
		#end
		if (instance != null)
			instance.stopRequested = true;
		running = false;
		actualPort = 0;
		#if (cpp || android)
		thread = null;
		#end
	}
}
