package online.server;

import online.shared.JudgeCore;
import online.shared.OnlineTypes.ScoreRecord;
import online.shared.SeiunProtocol;

/**
	服务器端假人 (debug bot) 对局模拟器。
	目标: 让假人"像真人一样"游玩 ——
	- 实时模式: 按谱面时间轴模拟按键 (MSG_GAME_INPUT) 与判定 (MSG_GAME_JUDGE, 带累计分数),
	  其他玩家的对手 strum 会亮起、右上角 HUD 会实时显示假人分数, 与真人体验一致;
	- 对局结束/异步提交时生成完整成绩, 出现在结算排行里。
	反作弊已移除, 假人不参与任何服务器权威判定, 分数只是本地累计展示。
**/
class BotSim
{
	/** 命中率 (0.70 ~ 0.97, 每人固定, 模拟不同水平)。 */
	public var skill:Float;
	/** 每个 lane 已处理的 note 下标。 */
	public var laneCursor:Map<Int, Int> = new Map<Int, Int>();
	public var done:Bool = false;

	public var score:Int = 0;
	public var combo:Int = 0;
	public var maxCombo:Int = 0;
	public var misses:Int = 0;
	public var marvelous:Int = 0;
	public var sick:Int = 0;
	public var good:Int = 0;
	public var bad:Int = 0;
	public var shit:Int = 0;
	public var finishedAt:Float = 0;

	public function new(?skillValue:Float)
	{
		skill = skillValue == null ? 0.78 + Std.random(20) / 100.0 : skillValue;
	}

	public static function make(room:Room, bot:ServerClient):BotSim
	{
		var sim:BotSim = new BotSim();
		if (room.noteTimesByLane != null)
		{
			for (lane in room.noteTimesByLane.keys())
				sim.laneCursor.set(lane, 0);
		}
		return sim;
	}

	/** 每 tick 调用: 处理所有"该按了"的 note, 广播输入与判定。 */
	public function update(room:Room, bot:ServerClient, now:Float):Void
	{
		if (done || room == null || bot == null)
			return;
		var elapsed:Float = now - room.gameStartedAt;
		if (elapsed < 0 || room.noteTimesByLane == null)
			return;

		var timings:Array<Int> = room.settings == null ? null : room.settings.judgementTimings;
		if (timings == null || timings.length < 4)
			timings = [25, 50, 70, 100];
		var marvelousEnabled:Bool = room.settings != null && room.settings.marvelousRatings;
		// 判定窗口略放宽, 模拟"人类延迟", 也让 HUD 分数逐步上涨而不是一次性跳完。
		var badWindow:Float = timings[3] + 40;

		var anyLeft:Bool = false;
		for (lane in room.noteTimesByLane.keys())
		{
			var notes:Array<Float> = room.noteTimesByLane.get(lane);
			if (notes == null || notes.length == 0)
				continue;
			var cursor:Int = laneCursor.exists(lane) ? laneCursor.get(lane) : 0;
			var processed:Int = 0;
			while (cursor < notes.length && processed < 8)
			{
				var noteTime:Float = notes[cursor];
				// note 时间已到 (留 100ms 容差, 避免 tick 粒度漏键)
				if (noteTime > elapsed + 100.0)
					break;
				processNote(room, bot, lane, noteTime, timings, marvelousEnabled, badWindow, now);
				cursor++;
				processed++;
			}
			laneCursor.set(lane, cursor);
			if (cursor < notes.length)
				anyLeft = true;
		}

		if (!anyLeft && room.chartNoteCount > 0)
		{
			done = true;
			finishedAt = now;
			finalize(room, bot);
		}
	}

	function processNote(room:Room, bot:ServerClient, lane:Int, noteTime:Float,
		timings:Array<Int>, marvelousEnabled:Bool, badWindow:Float, now:Float):Void
	{
		// 按下 (对手 strum 亮起)
		room.broadcast(SeiunProtocol.MSG_GAME_INPUT, {
			id: bot.id,
			deviceId: bot.identity == null ? "" : bot.identity.deviceId,
			nickname: bot.displayName(),
			lane: lane,
			pressed: true,
			songTime: noteTime,
			serverTime: now
		}, bot.id, SeiunProtocol.CHANNEL_GAME);

		var hit:Bool = (Std.random(1000) / 1000.0) < skill;
		var rating:String;
		var hitDiff:Float;
		if (hit)
		{
			hitDiff = Std.random(Std.int(badWindow * 2)) - badWindow;
			rating = JudgeCore.ratingFor(hitDiff, timings, marvelousEnabled);
			switch (rating)
			{
				case JudgeCore.RATING_MARVELOUS: marvelous++;
				case JudgeCore.RATING_SICK: sick++;
				case JudgeCore.RATING_GOOD: good++;
				case JudgeCore.RATING_BAD: bad++;
				default: shit++;
			}
			if (rating == JudgeCore.RATING_SHIT)
			{
				combo = 0;
				misses++;
			}
			else
			{
				combo++;
				if (combo > maxCombo)
					maxCombo = combo;
			}
			score += JudgeCore.ratingScore(rating);
		}
		else
		{
			// 漏键: 分数不加, 连击清零
			rating = JudgeCore.RATING_SHIT;
			hitDiff = badWindow + 1 + Std.random(60);
			shit++;
			combo = 0;
			misses++;
		}

		// 判定广播带累计分数 → 其他玩家右上 HUD 实时显示假人分数
		room.broadcast(SeiunProtocol.MSG_GAME_JUDGE, {
			deviceId: bot.identity == null ? "" : bot.identity.deviceId,
			strumTime: noteTime,
			lane: lane,
			rating: rating,
			hitDiff: hitDiff,
			isSustain: false,
			score: score,
			sentAt: now
		}, bot.id, SeiunProtocol.CHANNEL_GAME);
	}

	/** 打完最后一颗 note 后把假人成绩写入实时结果表, 结算排行即可见。 */
	function finalize(room:Room, bot:ServerClient):Void
	{
		var rec:ScoreRecord = toScoreRecord(room, bot);
		room.realtimeResults.set(bot.id, rec);
		room.asyncStates.set(bot.id, online.shared.OnlineTypes.OnlineConst.ASYNC_STATE_FINISHED);
	}

	public function toScoreRecord(room:Room, bot:ServerClient):ScoreRecord
	{
		return {
			deviceId: bot.identity == null ? "" : bot.identity.deviceId,
			nickname: bot.displayName(),
			avatar: bot.identity == null ? "bf" : bot.identity.avatar,
			score: score,
			accuracy: JudgeCore.accuracy(marvelous, sick, good, bad, shit),
			maxCombo: maxCombo,
			misses: misses,
			marvelous: marvelous,
			sick: sick,
			good: good,
			bad: bad,
			shit: shit,
			completed: true,
			finishedAt: finishedAt > 0 ? finishedAt : Date.now().getTime(),
			nps: 0
		};
	}

	/**
		异步模式假人成绩: 按谱面 note 数估算一局完整成绩。
		同一假人+同一谱面结果尽量稳定, 避免每次刷新排行分数乱跳。
	**/
	public static function asyncScore(room:Room, bot:ServerClient, seed:Int):ScoreRecord
	{
		var total:Int = room.chartNoteCount > 0 ? room.chartNoteCount : (200 + seed % 220);
		var marvelousEnabled:Bool = room.settings != null && room.settings.marvelousRatings;
		// 用固定 seed 生成"确定性随机", 同一局内结果不变
		var rnd:Int = seed;
		function next(max:Int):Int
		{
			rnd = Std.int(Math.abs(rnd * 1103515245 + 12345)) % 1000000007;
			return rnd % max;
		}
		var acc:Float = 0.86 + (next(14) / 100.0); // 0.86 ~ 0.99
		var misses:Int = Std.int((1 - acc) * total * 0.4);
		var shit:Int = misses;
		var good:Int = Std.int(total * (0.005 + next(20) / 1000.0));
		var bad:Int = Std.int(total * (0.002 + next(15) / 1000.0));
		var rest:Int = total - shit - good - bad;
		if (rest < 0)
			rest = 0;
		var marvelous:Int = marvelousEnabled ? Std.int(rest * (0.15 + next(20) / 100.0)) : 0;
		var sick:Int = rest - marvelous;
		if (sick < 0)
			sick = 0;
		var score:Int = marvelous * 400 + sick * 350 + good * 200 + bad * 50 + shit * -150;
		var maxCombo:Int = Std.int(Math.max(0, (total - shit) * (0.45 + next(30) / 100.0)));
		return {
			deviceId: bot.identity == null ? "" : bot.identity.deviceId,
			nickname: bot.displayName(),
			avatar: bot.identity == null ? "bf" : bot.identity.avatar,
			score: score < 0 ? 0 : score,
			accuracy: JudgeCore.accuracy(marvelous, sick, good, bad, shit),
			maxCombo: maxCombo,
			misses: misses,
			marvelous: marvelous,
			sick: sick,
			good: good,
			bad: bad,
			shit: shit,
			completed: true,
			finishedAt: Date.now().getTime(),
			nps: 0
		};
	}
}
