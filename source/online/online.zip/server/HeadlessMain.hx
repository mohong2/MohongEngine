package online.server;

import online.shared.SeiunProtocol;

/**
	无头专用服务器入口。
	同一份 Haxe 源码, 通过 server/build.hxml 编译为 Windows C++ exe,
	不带 Flixel/OpenFL 画面。

	启动参数:
	  --config <path>        配置文件路径 (默认 server/server.config.json)
	  --port <n>             游戏 TCP 端口
	  --adminport <n>        Web 管理面板端口
	  --admin-bind <ip>      面板监听地址 (默认 0.0.0.0; 只本机访问可用 127.0.0.1)
	  --password <pw>        面板口令 (写入内存, 同时会写回配置文件)
	  --name <name>          服务器名称
	  --datadir <dir>        数据目录 (账号/封禁/会话; 相对路径按配置文件所在目录解析, 默认 server_data)
	  --webpanel on|off      是否启动 Web 管理面板
	  --scripts <dir>        server scripts 目录
	  --maxplayers <n>       默认房间人数 (1-12)
	  --headless             强制专用服务器模式
**/
class HeadlessMain
{
	public static function main():Void
	{
		#if sys
		var cfg:ServerConfig = ServerConfig.dedicatedDefaults();
		var configPath:String = "server/server.config.json";
		var args:Array<String> = Sys.args();
		var configExplicit:Bool = false;

		// 第一遍只取 --config: 其余参数在配置文件加载之后再覆盖, 保证命令行优先级最高。
		var i:Int = 0;
		while (i < args.length)
		{
			if (args[i] == "--config" && i + 1 < args.length)
			{
				configPath = args[i + 1];
				configExplicit = true;
			}
			i++;
		}

		// 默认配置统一锚定仓库根 server/server.config.json:
		// 即使用户直接从 server/build/cpp 双击 exe, 也不会误用 build 目录里的旧配置
		// (旧配置会把数据目录锚到 build 旁的空 server_data, 导致会话/账号看似“丢失”)。
		if (!configExplicit)
		{
			try
			{
				var exeDir:String = haxe.io.Path.directory(Sys.programPath());
				var preferred:String = haxe.io.Path.normalize(exeDir + "/../../server.config.json");
				if (sys.FileSystem.exists(preferred))
					configPath = preferred;
			}
			catch (e:Dynamic) {}
		}
		if (!sys.FileSystem.exists(configPath))
		{
			try
			{
				var exeDir:String = haxe.io.Path.directory(Sys.programPath());
				var fallback:String = haxe.io.Path.normalize(exeDir + "/../../server.config.json");
				if (sys.FileSystem.exists(fallback))
					configPath = fallback;
			}
			catch (e:Dynamic) {}
		}
		// 配置路径转绝对: 此后 save/面板写回都不再依赖 CWD。
		try { configPath = sys.FileSystem.absolutePath(configPath); } catch (e:Dynamic) {}

		cfg = ServerConfig.load(configPath, cfg);
		applyCliOverrides(cfg, args);

		// 配置文件不存在时生成默认配置, 方便管理员直接编辑。
		if (!sys.FileSystem.exists(configPath))
		{
			try
			{
				cfg.save(configPath);
				Sys.println("已生成默认配置文件: " + configPath + " (可编辑后重启生效)");
			}
			catch (e:Dynamic) {}
		}

		// 统一落盘锚点: 数据/脚本/模组目录相对配置文件所在目录解析 (绝不依赖 CWD),
		// 并把历史散落的数据目录 (仓库根 server_data / build 目录 server_data) 并入一次。
		var anchorDir:String = ServerConfig.applyRuntimeAnchor(cfg, configPath);
		var legacyDirs:Array<String> = [];
		try
		{
			legacyDirs.push(Sys.getCwd() + "/server_data");
			var exeDir:String = haxe.io.Path.directory(Sys.programPath());
			legacyDirs.push(exeDir + "/server_data");
			legacyDirs.push(haxe.io.Path.normalize(exeDir + "/../../server_data"));
		}
		catch (e:Dynamic) {}
		for (line in ServerConfig.migrateLegacyDataDirs(cfg.dataDir, legacyDirs))
			Sys.println("[迁移] " + line);

		Sys.println("SeiunEngine dedicated server");
		Sys.println("协议版本: " + SeiunProtocol.PROTOCOL_VERSION + " · 指纹: " + SeiunProtocol.ENGINE_FINGERPRINT + " · 构建于: " + ServerConfig.exeBuildTime());
		Sys.println("配置文件: " + configPath);
		Sys.println("数据目录: " + cfg.dataDir);
		Sys.println("脚本目录: " + cfg.serverScriptsDir + " · 模组目录: " + cfg.serverModsDir);
		Sys.println("以上目录均相对配置文件所在目录解析 (锚点: " + anchorDir + "), 与启动位置无关。");
		var server:SeiunServer = new SeiunServer(cfg);
		server.configPath = configPath;
		if (!server.start())
		{
			Sys.println("服务器启动失败：请查看上方的端口占用提示 (netstat -ano | findstr :" + cfg.port + ")。");
			Sys.exit(1);
		}

		Sys.println("SeiunEngine dedicated server ready.");
		Sys.println("游戏端口: " + cfg.port + " (局域网玩家填: ws://<本机IP>:" + cfg.port + ")");
		if (cfg.webPanelEnabled)
			Sys.println("Web 面板: http://" + (cfg.adminBind == "0.0.0.0" ? "127.0.0.1" : cfg.adminBind) + ":" + cfg.adminPort + "  登录口令见 " + configPath + " 的 adminPassword");
		Sys.println("Commands: help | list | accounts | kick <id> | ban <id/ip> | unban <target> [kind] | announce <text> | broadcast <text> | setpassword <pw> | adminpassword <pw> | admin <user> on/off | resetpw <user> <pw> | ipaccounts <ip> | maxplayers <n> | stop");
		#if cpp
		var console:ServerConsole = new ServerConsole(server);
		sys.thread.Thread.create(function():Void
		{
			try
			{
				while (!server.stopRequested)
				{
					var line:String = Sys.stdin().readLine();
					if (line == null)
						break;
					var result:String = console.execute(line);
					if (result.length > 0)
						Sys.println(result);
					if (server.stopRequested)
						break;
				}
			}
			catch (e:Dynamic) {}
		});
		#end
		server.runForever();
		Sys.println("server stopped.");
	#else
		trace("Headless server requires a sys target (cpp recommended).");
	#end
	}

	/** 命令行覆盖 (在配置文件加载之后应用, 优先级最高)。--config 已在第一遍处理。 */
	#if sys
	static function applyCliOverrides(cfg:ServerConfig, args:Array<String>):Void
	{
		var webPanel:Null<Bool> = null;
		var i:Int = 0;
		while (i < args.length)
		{
			var a:String = args[i];
			if (a == "--config" && i + 1 < args.length)
			{
				i += 2;
				continue;
			}
			else if (a == "--port" && i + 1 < args.length)
			{
				var p:Null<Int> = Std.parseInt(args[i + 1]);
				if (p != null && p > 0)
					cfg.port = p;
			}
			else if (a == "--adminport" && i + 1 < args.length)
			{
				var p:Null<Int> = Std.parseInt(args[i + 1]);
				if (p != null && p > 0)
					cfg.adminPort = p;
			}
			else if (a == "--admin-bind" && i + 1 < args.length)
				cfg.adminBind = args[i + 1];
			else if (a == "--password" && i + 1 < args.length)
				cfg.adminPassword = args[i + 1];
			else if (a == "--name" && i + 1 < args.length)
				cfg.serverName = args[i + 1];
			else if (a == "--datadir" && i + 1 < args.length)
				cfg.dataDir = args[i + 1];
			else if (a == "--webpanel" && i + 1 < args.length)
			{
				var v:String = args[i + 1].toLowerCase();
				webPanel = v == "on" || v == "true" || v == "1";
			}
			else if (a == "--scripts" && i + 1 < args.length)
				cfg.serverScriptsDir = args[i + 1];
			else if (a == "--maxplayers" && i + 1 < args.length)
			{
				var n:Null<Int> = Std.parseInt(args[i + 1]);
				if (n != null && n >= 1 && n <= 12)
					cfg.maxPlayersDefault = n;
			}
			else if (a == "--anticheat" && i + 1 < args.length)
				cfg.anticheatDefault = false; // 反作弊已移除, 参数仅为兼容, 恒为关闭
			else if (a == "--headless")
				cfg.dedicated = true;
			i++;
		}
		if (webPanel != null)
			cfg.webPanelEnabled = webPanel;
	}
	#end
}
