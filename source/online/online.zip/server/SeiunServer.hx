package online.server;

import StringTools;
import haxe.io.Bytes;
import haxe.io.BytesBuffer;
import haxe.io.BytesOutput;
import haxe.io.Error;
import online.shared.OnlineTypes.ModFileInfo;
import online.shared.OnlineTypes.ModManifest;
import online.shared.OnlineTypes;
import online.shared.OnlineTypes.ChartSelection;
import online.shared.OnlineTypes.PlayerIdentity;
import online.shared.OnlineTypes.RoomSettings;
import online.shared.OnlineTypes.ScoreRecord;
import online.shared.SeiunPacket;
import online.shared.SeiunPacket.InboundPacket;
import online.shared.SeiunProtocol;

/**
	SeiunEngine TCP 服务器核心。
	纯 Haxe + sys.net.Socket, 同时用于:
	- 游戏内内置服务器 (Minecraft 式, 后台线程);
	- 无头专用服务器 exe。
**/
class SeiunServer
{
	public var config:ServerConfig;
	public var roomManager:RoomManager;
	public var authStore:AuthStore;
	public var scriptHost:ServerScriptHost = null;
	public var clients:Array<ServerClient> = [];
	public var running:Bool = false;
	public var stopRequested:Bool = false;
	public var logSink:String->Void = null;
	/** 当前配置文件路径 (HeadlessMain 设置), 供管理面板/控制台保存配置。 */
	public var configPath:String = "server/server.config.json";

	var listenSocket:sys.net.Socket = null;
	var udpSocket:sys.net.UdpSocket = null;
	/** Web 管理面板 (仅专用服务器形态启动)。 */
	public var adminHttp:AdminHttpServer = null;
	/** 客户端上传中的自定义头像分块 (client.id -> {file, chunks, count, startedAt})。 */
	var avatarUploads:Map<String, Dynamic> = new Map<String, Dynamic>();
	var lastTick:Float = 0;
	var lastHeartbeat:Float = 0;
	var lastBanCleanup:Float = 0;
	var reconnectSeats:Array<Dynamic> = [];
	var logs:Array<String> = [];
	var nextFileTransferId:Int = 1;
	#if cpp
	/** 控制台/Web 管理命令与网络主循环互斥, 避免跨线程改房间状态。 */
	public var adminMutex:sys.thread.Mutex = new sys.thread.Mutex();
	#end

	public function new(config:ServerConfig)
	{
		this.config = config == null ? ServerConfig.dedicatedDefaults() : config;
		this.roomManager = new RoomManager(this);
		this.authStore = new AuthStore(this);
	}

	public function log(text:String):Void
	{
		logs.push(text);
		if (logs.length > 300)
			logs.shift();
		if (logSink != null)
		{
			logSink(text);
			return;
		}
		#if sys
		try { Sys.println(text); } catch (e:Dynamic) {}
		#end
	}

	public function lastLogs():Array<String>
	{
		return logs.copy();
	}

	static function asInt(value:Dynamic, fallback:Int):Int
	{
		var parsed:Null<Int> = Std.parseInt(Std.string(value));
		return parsed == null ? fallback : parsed;
	}

	static function asFloat(value:Dynamic, fallback:Float):Float
	{
		var parsed:Float = Std.parseFloat(Std.string(value));
		return Math.isNaN(parsed) ? fallback : parsed;
	}

	static function parseTimings(value:Dynamic):Array<Int>
	{
		if (value == null || !Std.isOfType(value, Array))
			return null;
		var raw:Array<Dynamic> = cast value;
		var out:Array<Int> = [];
		for (v in raw)
		{
			// 窗口只接受 0~500ms 的合理值, 异常值按 25 兜底 (防改包/手滑把判定改废)。
			var t:Int = asInt(v, 25);
			out.push(t < 0 ? 0 : (t > 500 ? 500 : t));
		}
		return out.length >= 4 ? out : null;
	}

	/** 舞台名只允许字母数字下划线连字符空格, 空串表示跟随歌曲。 */
	static function sanitizeStageName(value:Dynamic):String
	{
		if (value == null)
			return "";
		var text:String = StringTools.trim(Std.string(value));
		if (text.length > 0 && !~/^[a-zA-Z0-9_\- ]+$/.match(text))
			return "";
		return text.length > 32 ? "" : text;
	}

	/** 兼容模式白名单: 只接受 backend.CompatEngine 的合法取值, 否则回退 Auto。 */
	static function sanitizeCompatEngine(value:Dynamic):String
	{
		if (value == null)
			return "";
		var text:String = StringTools.trim(Std.string(value));
		for (v in ["Auto", "0.6.3", "0.7.3", "1.0.4"])
			if (text == v)
				return v;
		return "";
	}

	/** 暂停策略白名单: everyone / hostOnly / disabled, 非法值回退 everyone。 */
	static function sanitizePausePolicy(value:Dynamic):String
	{
		if (value == null)
			return online.shared.OnlineTypes.OnlineConst.PAUSE_EVERYONE;
		var text:String = StringTools.trim(Std.string(value));
		if (text == online.shared.OnlineTypes.OnlineConst.PAUSE_HOST_ONLY
			|| text == online.shared.OnlineTypes.OnlineConst.PAUSE_DISABLED
			|| text == online.shared.OnlineTypes.OnlineConst.PAUSE_EVERYONE)
			return text;
		return online.shared.OnlineTypes.OnlineConst.PAUSE_EVERYONE;
	}

	public function start(?port:Int):Bool
	{
		if (running)
			return false;
		try
		{
			if (port != null && port > 0)
				config.port = port;

			#if sys
			config.ensureDir(config.dataDir);
			log("数据目录: " + config.dataDir);
			#end
			authStore.init(config.dataDir);
			try
			{
				scriptHost = new ServerScriptHost(this);
			}
			catch (e:Dynamic)
			{
				log("server scripts failed to load: " + Std.string(e));
				scriptHost = null;
			}

			var host:sys.net.Host = new sys.net.Host("0.0.0.0");
			listenSocket = new sys.net.Socket();
			listenSocket.bind(host, config.port);
			listenSocket.listen(64);
			listenSocket.setBlocking(false);

			try
			{
				udpSocket = new sys.net.UdpSocket();
				udpSocket.bind(host, config.port);
				udpSocket.setBlocking(false);
			}
			catch (e:Dynamic)
			{
				log("UDP discovery disabled: " + Std.string(e));
				udpSocket = null;
			}

			running = true;
			lastTick = Date.now().getTime();
			lastHeartbeat = lastTick;
			log("SeiunEngine server listening on 0.0.0.0:" + config.port);
			for (addr in LanUtil.detectAddresses())
				log("LAN address: " + addr + ":" + config.port);

			if (config.dedicated && config.webPanelEnabled)
			{
				try
				{
					adminHttp = new AdminHttpServer(this);
					adminHttp.start(config.adminPort, config.adminPassword);
					log("Admin web panel: http://127.0.0.1:" + config.adminPort);
				}
				catch (e:Dynamic)
				{
					var adminErr:String = Std.string(e).toLowerCase();
					if (adminErr.indexOf("bind") >= 0 || adminErr.indexOf("address in use") >= 0)
						log("Web 面板端口 " + config.adminPort + " 被占用！可用 --port 换端口, 或 netstat -ano | findstr :" + config.adminPort + " 查看占用进程。");
					else
						log("Admin web panel failed to start: " + Std.string(e));
				}
			}
			return true;
		}
		catch (e:Dynamic)
		{
			var errText:String = Std.string(e).toLowerCase();
			if (errText.indexOf("bind") >= 0 || errText.indexOf("address in use") >= 0 || errText.indexOf("wsa") >= 0)
			{
				log("端口 " + config.port + " 已被占用！");
				log("处理办法: 结束占用进程后重试, 或换端口启动。");
				log("  netstat -ano | findstr :" + config.port + "   ← 查看占用进程 PID");
				log("  taskkill /PID <PID> /F                          ← 结束占用进程");
				log("  专用服务器换端口: server\\start_server.bat --port 2577   (同时需改 client 地址)");
			}
			else
				log("Failed to start server: " + Std.string(e));
			try { if (listenSocket != null) listenSocket.close(); } catch (e2:Dynamic) {}
			listenSocket = null;
			running = false;
			return false;
		}
	}

	public function runForever():Void
	{
		if (!running)
		{
			if (!start())
				return;
		}
		while (running && !stopRequested)
			runOnce(0.1);
		shutdown();
	}

	/**
		主循环单步:
		1. 无锁阶段: select/sleep 等待事件 (阻塞点不持锁, 避免 CRITICAL_SECTION 饥饿,
		   之前锁在 select 期间被占 100ms、释放后立即重取, 管理线程几乎抢不到锁 → 面板卡 1-4 秒);
		2. 持锁阶段: 只处理就绪事件与 tick 任务 (毫秒级)。
	**/
	public function runOnce(timeout:Float = 0.05):Void
	{
		#if cpp
		var pendingRead:Array<sys.net.Socket> = [];
		var pendingWrite:Array<sys.net.Socket> = [];
		#else
		var pendingRead:Array<sys.net.Socket> = null;
		var pendingWrite:Array<sys.net.Socket> = null;
		#end
		if (running)
		{
			// ── 无锁等待阶段 ──────────────────────────────
			var readList:Array<sys.net.Socket> = [];
			var writeList:Array<sys.net.Socket> = [];
			if (udpSocket != null)
				readList.push(udpSocket);
			for (c in clients)
			{
				readList.push(c.socket);
				if (c.hasPendingWrites())
					writeList.push(c.socket);
			}
			if (readList.length > 0 || writeList.length > 0)
			{
				try
				{
					var result:{read:Array<sys.net.Socket>, write:Array<sys.net.Socket>, others:Array<sys.net.Socket>} =
						sys.net.Socket.select(readList, writeList, [], timeout);
					pendingRead = result.read;
					pendingWrite = result.write;
				}
				catch (e:Dynamic) {}
			}
			else
			{
				#if sys
				Sys.sleep(timeout);
				#end
			}
		}

		// ── 持锁处理阶段 ─────────────────────────────────
		#if cpp
		var tw:Float = Date.now().getTime();
		adminMutex.acquire();
		var twMs:Float = Date.now().getTime() - tw;
		if (twMs > 200)
			log("[tick] main loop mutex wait " + Std.int(twMs) + "ms");
		#end
		try
		{
			runOnceLocked(pendingRead, pendingWrite);
		}
		catch (e:Dynamic)
		{
			log("runOnce error: " + Std.string(e));
		}
		#if cpp
		adminMutex.release();
		#end
	}

	function runOnceLocked(pendingRead:Array<sys.net.Socket>, pendingWrite:Array<sys.net.Socket>):Void
	{
		if (!running)
			return;
		var now:Float = Date.now().getTime();

		acceptPending();

		for (s in pendingRead)
		{
			if (udpSocket != null && s == udpSocket)
			{
				handleUdpBeacon();
				continue;
			}
			var c:ServerClient = clientForSocket(s);
			if (c != null && !c.pumpRead())
				c.close();
		}
		for (s in pendingWrite)
		{
			var c:ServerClient = clientForSocket(s);
			if (c != null)
				c.flush();
		}

		updateClients(now);
		cleanupClients(now);
		checkAsyncTimeouts(now);
		updateRoomCountdowns(now);
		updateRealtimeSyncTimeouts(now);
		updateRealtimeSyncRebroadcasts(now);
		// 定期清理已过期的封禁记录, 避免列表堆积过期项。
		if (now - lastBanCleanup >= 60000.0)
		{
			lastBanCleanup = now;
			try { authStore.cleanExpiredBans(now); } catch (e:Dynamic) {}
		}
	}

	function acceptPending():Void
	{
		if (listenSocket == null)
			return;
		while (true)
		{
			try
			{
				var sock:sys.net.Socket = listenSocket.accept();
				if (sock == null)
					break;
				var client:ServerClient = new ServerClient(this, sock);
				clients.push(client);
				log("connection from " + client.ip);
			}
			catch (e:Dynamic)
			{
				if (e == Error.Blocked || Std.string(e).toLowerCase().indexOf("blocked") >= 0)
					break;
				break;
			}
		}
	}

	function handleUdpBeacon():Void
	{
		if (udpSocket == null)
			return;
		var buf:Bytes = Bytes.alloc(128);
		var addr:sys.net.Address = new sys.net.Address();
		try
		{
			var n:Int = udpSocket.readFrom(buf, 0, buf.length, addr);
			if (n >= 8)
			{
				var text:String = buf.sub(0, n).toString();
				if (text.indexOf("SEIUNP01") == 0)
				{
					var safeName:String = StringTools.replace(config.serverName, "|", "/");
					var answer:String = "SEIUNP01|" + safeName + "|" + (config.dedicated ? "dedicated" : "embedded") + "|" + config.port + "|" + config.anticheatDefault;
					var payload:Bytes = Bytes.ofString(answer);
					udpSocket.sendTo(payload, 0, payload.length, addr);
				}
			}
		}
		catch (e:Dynamic) {}
	}

	function clientForSocket(s:sys.net.Socket):ServerClient
	{
		for (c in clients)
			if (c.socket == s)
				return c;
		return null;
	}

	function updateClients(now:Float):Void
	{
		if (now - lastHeartbeat >= 1000.0)
		{
			lastHeartbeat = now;
			for (c in clients)
			{
				if (!c.handshakeDone)
					continue;
				// 每秒无条件向客户端发一次心跳: 客户端靠它刷新读超时。
				// 绝不能改成"只在客户端安静时发"——那样双方都在等对方先说话,
				// 客户端 15 秒读超时必然触发, 大厅静默时连接会无故断开。
				c.send(SeiunProtocol.MSG_HEARTBEAT, SeiunProtocol.CHANNEL_CONTROL, {serverTime: now});
			}
		}
	}

	function cleanupClients(now:Float):Void
	{
		var liveSeats:Array<Dynamic> = [];
		for (seat in reconnectSeats)
		{
			var seatAt:Float = asFloat(Reflect.field(seat, "at"), 0);
			if (now - seatAt <= config.reconnectWindowSeconds * 1000.0)
				liveSeats.push(seat);
		}
		reconnectSeats = liveSeats;

		var keep:Array<ServerClient> = [];
		for (c in clients)
		{
			// 对局进行中/加载中的客户端给双倍心跳宽限:
			// 慢设备 (尤其安卓) 加载大模组/大谱面时客户端主线程忙, 心跳会迟到;
			// 15 秒硬超时会把正常加载误判成"疑似崩溃"踢出房间。
			var graceMultiplier:Float = 1.0;
			if (c.handshakeDone && c.room != null
				&& (c.room.status == online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_PLAYING
					|| c.room.status == online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_COUNTDOWN))
				graceMultiplier = 2.0;
			var timeoutSeconds:Float = config.heartbeatTimeoutSeconds * graceMultiplier;
			var timedOut:Bool = c.heartbeatTimedOut(now, timeoutSeconds);
			var timeout:Bool = c.handshakeAged(now) || timedOut || c.closing;
			if (timeout)
			{
				if (c.handshakeDone && c.room != null && timedOut)
				{
					saveReconnectSeat(c);
					if (c.room != null)
						c.room.noticeForAll(c.displayName() + " 的连接中断（疑似崩溃）");
				}
				avatarUploads.remove(c.id);
				c.close();
			}
			else
				keep.push(c);
		}
		clients = keep;
	}

	function saveReconnectSeat(c:ServerClient):Void
	{
		if (c == null || c.room == null || c.identity == null)
			return;
		var seat:Dynamic = {
			deviceId: c.identity.deviceId,
			roomCode: c.room.roomCode,
			nickname: c.displayName(),
			avatar: c.identity.avatar,
			at: Date.now().getTime(),
			team: c.team,
			ready: c.isReady
		};
		reconnectSeats.push(seat);
	}

	function checkAsyncTimeouts(now:Float):Void
	{
		for (r in roomManager.rooms)
		{
			if (r.settings.mode != online.shared.OnlineTypes.OnlineConst.MODE_ASYNC)
				continue;
			for (p in r.players)
			{
				var st:String = r.asyncStates.get(p.id);
				if (st == online.shared.OnlineTypes.OnlineConst.ASYNC_STATE_PLAYING)
				{
					var score:ScoreRecord = r.asyncScores.get(p.id);
					var recordedStart:Float = r.asyncStartedAt.exists(p.id) ? r.asyncStartedAt.get(p.id) : 0;
					var startAt:Float = score == null ? (recordedStart > 0 ? recordedStart : p.lastReadAt) : score.finishedAt;
					if (now - startAt > 10.0 * 60.0 * 1000.0)
					{
						r.asyncStates.set(p.id, online.shared.OnlineTypes.OnlineConst.ASYNC_STATE_FINISHED);
						r.noticeForAll(p.displayName() + " 长时间无响应，已标记为未完成");
						r.broadcastAsyncStatus();
					}
				}
			}
		}
	}

	function updateRoomCountdowns(now:Float):Void
	{
		for (r in roomManager.rooms)
		{
			// 倒计时被暂停 (有人在对局开始前暂停) 时挂起计时。
			if (r.status == online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_COUNTDOWN && r.countdownLeft > 0 && !r.countdownPaused)
			{
				// 同一毫秒内 now-lastTick 可能为负, 钳制为 0, 避免倒计时"回弹"多报一个数。
				var dt:Float = Math.max(0, (now - lastTick) / 1000.0);
				r.countdownLeft -= dt;
				var second:Int = Math.ceil(r.countdownLeft);
				if (second != r.lastCountdownSecond && second > 0)
				{
					r.lastCountdownSecond = second;
					r.broadcast(SeiunProtocol.MSG_GAME_COUNTDOWN, {seconds: second, song: r.chart}, null, SeiunProtocol.CHANNEL_GAME);
				}
				if (r.countdownLeft <= 0)
				{
					r.status = online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_PLAYING;
					r.gameStartedAt = now;
					r.broadcast(SeiunProtocol.MSG_GAME_START, {song: r.chart, startedAt: now}, null, SeiunProtocol.CHANNEL_GAME);
					if (scriptHost != null)
						scriptHost.call("onGameStart", [r.roomCode]);
				}
			}
		}
		lastTick = now;
	}

	/**
		实时统一起跑兜底: 起跑门闩开启后, 若有玩家一直不按确认 (挂机/掉线),
		60 秒后强制发令, 避免全房间无限等待; 正常情况下全员几秒内就会确认。
	**/
	function updateRealtimeSyncTimeouts(now:Float):Void
	{
		for (room in roomManager.rooms)
		{
			if (room.settings.mode != online.shared.OnlineTypes.OnlineConst.MODE_REALTIME)
				continue;
			if (room.status != online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_PLAYING)
				continue;
			if (room.realtimeSyncServerStartMs > 0)
				continue;
			if (room.gameStartedAt <= 0 || now - room.gameStartedAt < 60000)
				continue;
			maybeBroadcastRealtimeSync(room, true);
		}
	}

	/**
		MSG_GAME_SYNC 重发窗口: 统一发令帧没有 ACK, 弱网丢帧时客户端会一直
		卡在等待界面。发令后的 12 秒内每 1 秒重发一次, 客户端按相同服务器
		锚点幂等处理, 不会重复开局。
	**/
	function updateRealtimeSyncRebroadcasts(now:Float):Void
	{
		for (room in roomManager.rooms)
		{
			if (room.settings.mode != online.shared.OnlineTypes.OnlineConst.MODE_REALTIME)
				continue;
			if (room.realtimeSyncServerStartMs <= 0 || room.realtimeSyncBroadcastUntilMs <= 0)
				continue;
			if (now >= room.realtimeSyncBroadcastUntilMs)
			{
				room.realtimeSyncBroadcastUntilMs = 0;
				continue;
			}
			if (room.status != online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_PLAYING)
				continue;
			if (room.lastRealtimeSyncRebroadcastMs > 0 && now - room.lastRealtimeSyncRebroadcastMs < 1000)
				continue;
			room.lastRealtimeSyncRebroadcastMs = now;
			var serverNow:Float = room.realtimeSyncServerStartMs;
			var already:Float = now - serverNow;
			if (already < -2000 || already > 15000)
				continue;
			// 每秒重发一次; 用 serverNow 与原始 delay 让锚点保持一致。
			var delay:Float = Math.max(0, serverNow - now);
			room.broadcast(SeiunProtocol.MSG_GAME_SYNC, {
				serverNow: now,
				startDelayMs: delay,
				startedAt: room.gameStartedAt
			}, null, SeiunProtocol.CHANNEL_GAME);
		}
	}

	/**
		实时对局收尾: 所有玩家都已提交成绩后才广播 GAME_END。
		与 PsychOnline 一致, 房主先打完不会提前把其他人的成绩截断;
		异步排名则完全走 MSG_ASYNC_RANKING, 不经过这里。
	**/
	public function tryFinalizeRealtime(room:Room):Void
	{
		if (room == null || room.settings.mode != online.shared.OnlineTypes.OnlineConst.MODE_REALTIME)
			return;
		if (room.status != online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_PLAYING)
			return;
		var anyPlayer:Bool = false;
		for (p in room.players)
		{
			anyPlayer = true;
			if (!room.realtimeResults.exists(p.id))
				return;
		}
		if (!anyPlayer)
			return;

		room.gameReadyIds = new Map<String, Bool>();
		room.startGateIds = new Map<String, Bool>();
		room.realtimeSyncServerStartMs = 0;
		room.realtimeSyncBroadcastUntilMs = 0;
		room.lastRealtimeSyncRebroadcastMs = 0;
		room.broadcast(SeiunProtocol.MSG_GAME_END, {results: room.realtimeRanking()}, null, SeiunProtocol.CHANNEL_GAME);
		if (scriptHost != null)
			scriptHost.call("onGameEnd", [room.roomCode]);
		room.status = online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_LOBBY;
		for (p in room.players)
			p.isReady = false;
		room.roomInfoMessage();
	}

	public function handlePacket(client:ServerClient, packet:InboundPacket):Bool
	{
		if (packet == null)
			return false;
		if (packet.type == -1)
		{
			client.sendError(SeiunProtocol.ERR_BAD_MAGIC, "不是 SeiunEngine 客户端，连接被拒绝");
			client.closing = true;
			return false;
		}
		if (packet.type == -2)
		{
			client.sendError(SeiunProtocol.ERR_BAD_PACKET, "消息长度非法");
			client.closing = true;
			return false;
		}
		if (packet.version != SeiunProtocol.PROTOCOL_VERSION)
		{
			client.sendError(SeiunProtocol.ERR_PROTOCOL_VERSION, "协议版本不匹配：服务器 " + SeiunProtocol.PROTOCOL_VERSION + "，客户端 " + packet.version);
			client.closing = true;
			return false;
		}
		if (!client.checkRate(packet.type, packet.channel))
			return false;
		// 非致命限速超限: 丢弃当前包但保持连接, 不触发断连。
		if (client.rateDropCurrent)
		{
			client.rateDropCurrent = false;
			return true;
		}
		var payloadLimit:Int = packet.channel == SeiunProtocol.CHANNEL_ASYNC
			? SeiunProtocol.MAX_SCORE_BYTES : SeiunProtocol.MAX_MESSAGE_BYTES;
		if (packet.payload.length > payloadLimit && packet.channel != SeiunProtocol.CHANNEL_FILE)
		{
			client.markViolation("oversized message");
			return true;
		}
		if (!SeiunPacket.checkCrc(packet))
		{
			client.markViolation("crc mismatch");
			return true;
		}

		var obj:Dynamic = null;
		try
		{
			if (packet.type != SeiunProtocol.MSG_HELLO && packet.channel != SeiunProtocol.CHANNEL_FILE)
				obj = SeiunPacket.payloadJson(packet);
		}
		catch (e:Dynamic)
		{
			client.markViolation("invalid json");
			return true;
		}

		if (!client.handshakeDone)
		{
			if (packet.type == SeiunProtocol.MSG_HELLO)
				return handleHello(client, packet);
			client.sendError(SeiunProtocol.ERR_AUTH_REQUIRED, "请先发送 HELLO 握手");
			return true;
		}

		switch (packet.channel)
		{
			case SeiunProtocol.CHANNEL_AUTH:
				return handleAuth(client, packet.type, obj);
			case SeiunProtocol.CHANNEL_ROOM:
				return handleRoom(client, packet.type, obj);
			case SeiunProtocol.CHANNEL_GAME:
				return handleGame(client, packet.type, obj);
			case SeiunProtocol.CHANNEL_ASYNC:
				return handleAsync(client, packet.type, obj);
			case SeiunProtocol.CHANNEL_ADMIN:
				return handleAdmin(client, packet.type, obj);
			case SeiunProtocol.CHANNEL_CONTROL:
				return handleControl(client, packet.type, obj);
			case SeiunProtocol.CHANNEL_FILE:
				return handleFile(client, packet.type, packet);
			default:
				client.markViolation("unknown channel " + packet.channel);
		}
		return true;
	}

	function handleHello(client:ServerClient, packet:InboundPacket):Bool
	{
		var hello:Dynamic = null;
		try
		{
			hello = SeiunPacket.payloadJson(packet);
		}
		catch (e:Dynamic) {}

		if (hello == null)
		{
			client.sendError(SeiunProtocol.ERR_BAD_PACKET, "HELLO 内容非法");
			client.closing = true;
			return false;
		}

		var fingerprint:String = Reflect.field(hello, "fingerprint");
		var versionValue:Null<Int> = Std.parseInt(Std.string(Reflect.field(hello, "protocolVersion")));
		var version:Int = versionValue == null ? -1 : versionValue;
		if (version != SeiunProtocol.PROTOCOL_VERSION)
		{
			client.sendError(SeiunProtocol.ERR_PROTOCOL_VERSION, "协议版本不匹配：服务器 " + SeiunProtocol.PROTOCOL_VERSION + "，客户端 " + version);
			client.closing = true;
			return false;
		}
		if (fingerprint != SeiunProtocol.ENGINE_FINGERPRINT)
		{
			client.sendError(SeiunProtocol.ERR_BAD_FINGERPRINT, "客户端指纹不符，不是 SeiunEngine");
			client.closing = true;
			return false;
		}

		var deviceId:String = Reflect.field(hello, "deviceId");
		var nickname:String = Reflect.field(hello, "nickname");
		var avatar:String = Reflect.field(hello, "avatar");
		var skin:String = Reflect.field(hello, "skin");
		var skinData:online.shared.OnlineTypes.OnlineSkinData = online.shared.OnlineTypes.SkinDataUtil.fromDynamic(Reflect.field(hello, "skinData"));
		if (deviceId == null || deviceId.length == 0)
			deviceId = client.id;
		if (deviceId.length > 80)
			deviceId = deviceId.substr(0, 80);

		var cleanAvatar:String = avatar == null ? "" : StringTools.trim(Std.string(avatar));
		if (cleanAvatar.length > 120)
			cleanAvatar = cleanAvatar.substr(0, 120);
		// 皮肤可为空 = 跟随谱面
		var cleanSkin:String = sanitizeStageName(skin);
		// 旧客户端只带 skin 字符串时, 从它推导一个无模组目录/后缀的 skinData。
		if (skinData == null && cleanSkin.length > 0)
			skinData = {char: cleanSkin, modDir: "", suffixLeft: "", suffixRight: ""};
		client.identity = {
			deviceId: deviceId,
			nickname: online.shared.OnlineTypes.OnlineConst.sanitizeNickname(nickname),
			avatar: cleanAvatar,
			skin: cleanSkin
		};
		if (skinData != null)
			client.identity.skinData = skinData;

		var token:String = Reflect.field(hello, "sessionToken");
		var sessionAccount:AuthStore.StoredAccount = null;
		if (token != null && token.length > 0)
		{
			var account:AuthStore.StoredAccount = authStore.accountForToken(token);
			if (account != null && !account.banned)
			{
				client.account = account;
				client.sessionToken = token;
				client.identity.accountName = account.username;
				client.identity.sessionToken = token;
			}
			else if (account != null && account.banned)
				sessionAccount = account; // 带 token 但账号已被封禁: 稍后直接拒绝
		}

		// 封禁检查: 优先 IP/设备, 其次带 token 的被封账号。
		var now:Float = Date.now().getTime();
		if (authStore.isIpBanned(client.ip) || authStore.isDeviceBanned(client.identity.deviceId))
		{
			var ban:AuthStore.StoredBan = null;
			if (authStore.isIpBanned(client.ip))
				ban = authStore.effectiveBan("ip", client.ip);
			else
				ban = authStore.effectiveBan("device", client.identity.deviceId);
			client.send(SeiunProtocol.MSG_ERROR, SeiunProtocol.CHANNEL_CONTROL, AuthStore.banErrorPayload("你已被服务器封禁", ban, now));
			client.closing = true;
			return false;
		}
		if (sessionAccount != null)
		{
			client.send(SeiunProtocol.MSG_ERROR, SeiunProtocol.CHANNEL_CONTROL,
				AuthStore.banErrorPayload("你的账号已被封禁", authStore.effectiveBanForAccount(sessionAccount.username), now));
			client.closing = true;
			return false;
		}

		client.authenticated = config.allowAnonymous || client.account != null;
		client.handshakeDone = true;
		client.send(SeiunProtocol.MSG_WELCOME, SeiunProtocol.CHANNEL_CONTROL, {
			serverName: config.serverName,
			dedicated: config.dedicated,
			protocolVersion: SeiunProtocol.PROTOCOL_VERSION,
			fingerprint: SeiunProtocol.ENGINE_FINGERPRINT,
			authRequired: !config.allowAnonymous,
			authenticated: client.authenticated,
			serverTime: Date.now().getTime(),
			reconnectWindowSeconds: config.reconnectWindowSeconds
		});
		return true;
	}

	function handleAuth(client:ServerClient, type:Int, obj:Dynamic):Bool
	{
		if (obj == null)
			return true;
		var username:String = Reflect.field(obj, "username");
		var password:String = Reflect.field(obj, "password");
		var deviceId:String = client.identity == null ? "" : client.identity.deviceId;
		var ip:String = client.ip;
		var result:Dynamic = null;
		if (type == SeiunProtocol.MSG_AUTH_REGISTER)
			result = authStore.register(username, password, deviceId, ip);
		else if (type == SeiunProtocol.MSG_AUTH_LOGIN)
			result = authStore.login(username, password, deviceId, ip);
		else if (type == SeiunProtocol.MSG_AUTH_RESULT)
			return true;
		else
			return true;

		if (result != null && result.ok == true)
		{
			var account:AuthStore.StoredAccount = authStore.accountForToken(result.token);
			if (account != null)
			{
				client.account = account;
				client.sessionToken = result.token;
				client.authenticated = true;
				client.identity.accountName = account.username;
				client.identity.sessionToken = result.token;
			}
		}
		client.send(SeiunProtocol.MSG_AUTH_RESULT, SeiunProtocol.CHANNEL_AUTH, result);
		return true;
	}

	/**
		记录客户端上报的本地时间戳并做防加速检测 (LAN 尽力而为)。
		判定规则:
		- 时间明显倒退 (超过 MAX_CLOCK_JUMP_MS): 异常, 断开;
		- 客户端时间推进远超真实流逝时间 (超过 elapsed + 1 秒容差): 疑似加速作弊, 断开。
		注意: 心跳间隔本身 (空闲 5s / 对局 1s) 就是正常的时间差,
		绝不能把"两次心跳的时间戳差值"当跳变, 否则所有连接都会被误杀。
	**/
	function recordClientTime(client:ServerClient, reported:Float, now:Float):Bool
	{
		if (reported <= 0 || Math.isNaN(reported))
			return true; // 无有效时间戳, 不记录也不判定
		if (client.lastClientTime > 0)
		{
			var delta:Float = reported - client.lastClientTime;
			var elapsed:Float = now - client.lastClientSampleAt;
			var backwards:Bool = delta < -SeiunProtocol.MAX_CLOCK_JUMP_MS;
			var runaway:Bool = elapsed >= 0 && delta > elapsed + 1000.0;
			if (backwards || runaway)
			{
				client.lastClientJump = delta;
				client.sendError(SeiunProtocol.ERR_CLOCK_JUMP, "检测到本地时钟异常，连接已断开");
				client.closing = true;
				return false;
			}
		}
		client.lastClientTime = reported;
		client.lastClientSampleAt = now;
		return true;
	}

	function handleControl(client:ServerClient, type:Int, obj:Dynamic):Bool
	{
		switch (type)
		{
			case SeiunProtocol.MSG_PING:
				if (obj == null)
					return true;
				var t0:Float = asFloat(Reflect.field(obj, "t0"), Date.now().getTime());
				var t1:Float = Date.now().getTime();
				if (!recordClientTime(client, asFloat(Reflect.field(obj, "clientTime"), t0), t1))
					return false;
				client.send(SeiunProtocol.MSG_PONG, SeiunProtocol.CHANNEL_CONTROL, {t0: t0, t1: t1, t2: Date.now().getTime()});
			case SeiunProtocol.MSG_HEARTBEAT:
				if (obj == null)
					return true;
				var now:Float = Date.now().getTime();
				client.lastReadAt = now;
				var ok:Bool = recordClientTime(client, asFloat(Reflect.field(obj, "clientTime"), now), now);
				if (!ok)
					return false;
				// 客户端每 5s 上报一次 RTT, 变化明显时刷新房间玩家行延迟显示。
				var reportedPing:Float = asFloat(Reflect.field(obj, "pingMs"), -1);
				if (reportedPing >= 0 && Math.abs(reportedPing - client.pingMs) >= 20)
				{
					client.pingMs = reportedPing;
					if (client.room != null)
						client.room.roomInfoMessage();
				}
				return true;
			case SeiunProtocol.MSG_BYE:
				if (client.room != null)
				{
					var leaving:Room = client.room;
					roomManager.leaveRoom(client);
					leaving.noticeForAll(client.displayName() + " 退出了房间");
				}
				client.closing = true;
				return false;
			case SeiunProtocol.MSG_CRASH_SIGNAL:
				handleCrashSignal(client, obj);
			case SeiunProtocol.MSG_GAME_RECONNECT:
				handleReconnect(client, obj);
		}
		return true;
	}

	function handleCrashSignal(client:ServerClient, obj:Dynamic):Void
	{
		if (obj == null)
			return;
		var summary:String = Reflect.field(obj, "summary");
		var roomCode:String = Reflect.field(obj, "roomCode");
		if (summary == null)
			summary = "";
		var target:Room = client.room;
		if (target == null && roomCode != null)
			target = roomManager.byCode(roomCode);
		if (target == null)
			return;
		if (client.identity == null)
			return;
		target.crashNotices.push({deviceId: client.identity.deviceId, nickname: client.displayName(), at: Date.now().getTime(), summary: summary});
		target.noticeForAll(client.displayName() + " 上次对局崩溃了" + (summary.length > 0 ? "（" + summary + "）" : ""));
		if (client.room != null)
			saveReconnectSeat(client);
	}

	function handleReconnect(client:ServerClient, obj:Dynamic):Void
	{
		if (obj == null)
			return;
		var roomCode:String = Reflect.field(obj, "roomCode");
		var deviceId:String = client.identity == null ? "" : client.identity.deviceId;
		var room:Room = roomManager.byCode(roomCode);
		var seat:Dynamic = null;
		var now:Float = Date.now().getTime();
		for (s in reconnectSeats)
		{
			if (s.deviceId == deviceId && s.roomCode == roomCode
				&& now - asFloat(Reflect.field(s, "at"), 0) <= config.reconnectWindowSeconds * 1000.0)
			{
				seat = s;
				break;
			}
		}
		var ok:Bool = false;
		if (room != null && seat != null && room.addPlayer(client, true))
		{
			client.team = asInt(Reflect.field(seat, "team"), 0);
			client.isReady = Reflect.field(seat, "ready") == true;
			Reflect.setField(seat, "at", 0);
			ok = true;
			room.noticeForAll(client.displayName() + " 重新连接了");
			room.roomInfoMessage();
		}
		client.send(SeiunProtocol.MSG_GAME_RECONNECT_RESULT, SeiunProtocol.CHANNEL_CONTROL, {ok: ok, message: ok ? "重连成功" : "重连失败：席位已过期或房间已关闭"});
	}

	function handleRoom(client:ServerClient, type:Int, obj:Dynamic):Bool
	{
		if (!ensureAuthorized(client))
			return true;
		switch (type)
		{
			case SeiunProtocol.MSG_ROOM_LIST:
				client.send(SeiunProtocol.MSG_ROOM_LIST_RESULT, SeiunProtocol.CHANNEL_ROOM, {rooms: roomManager.listPublic()});
			case SeiunProtocol.MSG_ROOM_CREATE:
				if (obj == null)
					return true;
				var requested:RoomSettings = castRoomSettings(obj);
				var res:Dynamic = roomManager.createRoom(client, requested);
				if (res.ok == true)
				{
					var created:Room = roomManager.byCode(res.room.roomCode);
					if (created != null)
						created.roomInfoMessage();
					client.send(SeiunProtocol.MSG_ROOM_JOIN_RESULT, SeiunProtocol.CHANNEL_ROOM, {
						ok: true,
						room: res.room,
						players: created == null ? [] : created.playerInfos(),
						selfId: client.id,
						hostId: client.id
					});
				}
				else
					client.send(SeiunProtocol.MSG_ROOM_JOIN_RESULT, SeiunProtocol.CHANNEL_ROOM, res);
			case SeiunProtocol.MSG_ROOM_JOIN:
				if (obj == null)
					return true;
				var code:String = Reflect.field(obj, "roomCode");
				var password:String = Reflect.field(obj, "password");
				var spectate:Bool = Reflect.field(obj, "spectate") == true;
				var res:Dynamic = roomManager.joinRoom(client, code, password, spectate);
				client.send(SeiunProtocol.MSG_ROOM_JOIN_RESULT, SeiunProtocol.CHANNEL_ROOM, res);
			case SeiunProtocol.MSG_ROOM_LEAVE:
				roomManager.leaveRoom(client);
				case SeiunProtocol.MSG_ROOM_KICK:
					// 房主踢人 (游玩者/观战者均可): 目标收到明确错误提示后断开, 其余玩家看到"被移出房间"。
					if (client.room != null && client.room.hostId == client.id && obj != null)
					{
						var targetId:String = Reflect.field(obj, "playerId") == null ? "" : Std.string(Reflect.field(obj, "playerId"));
						if (targetId.length > 0 && targetId != client.id)
						{
							var kicked:Bool = false;
							for (p in client.room.players)
							{
								if (p.id == targetId)
								{
									p.send(SeiunProtocol.MSG_ERROR, SeiunProtocol.CHANNEL_ROOM,
										{code: SeiunProtocol.ERR_NOT_AUTHORIZED, message: "你已被房主移出房间"});
									roomManager.kickPlayer(p, client);
									kicked = true;
									break;
								}
							}
							if (!kicked)
							{
								var sp:ServerClient = client.room.spectatorById(targetId);
								if (sp != null)
								{
									sp.send(SeiunProtocol.MSG_ERROR, SeiunProtocol.CHANNEL_ROOM,
										{code: SeiunProtocol.ERR_NOT_AUTHORIZED, message: "你已被房主移出房间"});
									roomManager.kickPlayer(sp, client);
								}
							}
						}
					}
			case SeiunProtocol.MSG_PROFILE_UPDATE:
				// 自定义头像上传是分块序列, 先完成文件再走普通资料更新, 避免身份先广播而文件还没到。
				if (obj != null && Reflect.field(obj, "avatarUpload") == true)
				{
					handleAvatarUpload(client, obj);
				}
				// 房间内即时更新身份 (昵称/头像/皮肤), 大厅角色/玩家行随之刷新。
				else if (client.identity != null && obj != null)
				{
					if (Reflect.hasField(obj, "nickname"))
						client.identity.nickname = online.shared.OnlineTypes.OnlineConst.sanitizeNickname(Reflect.field(obj, "nickname"));
					if (Reflect.hasField(obj, "avatar"))
					{
						var cleanAvatar:String = Reflect.field(obj, "avatar") == null ? "" : StringTools.trim(Std.string(Reflect.field(obj, "avatar")));
						if (cleanAvatar.length > 120)
							cleanAvatar = cleanAvatar.substr(0, 120);
						client.identity.avatar = cleanAvatar;
					}
					if (Reflect.hasField(obj, "skin"))
						client.identity.skin = sanitizeStageName(Reflect.field(obj, "skin"));
					if (client.room != null)
					{
						client.room.roomInfoMessage();
						client.room.noticeForAll(client.displayName() + " 更新了资料");
					}
				}
			case SeiunProtocol.MSG_ROOM_READY:
				if (client.room != null && obj != null)
				{
					if (client.room.settings.mode != online.shared.OnlineTypes.OnlineConst.MODE_REALTIME
						|| client.room.status != online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_LOBBY)
						return true;
					client.isReady = Reflect.field(obj, "ready") == true;
					if (Reflect.field(obj, "chartHash") != null)
					{
						client.chartHash = Std.string(Reflect.field(obj, "chartHash"));
						if (client.chartHash.length > 128)
							client.chartHash = client.chartHash.substr(0, 128);
					}
					client.room.roomInfoMessage();
					if (client.room.allReadyAndHashesMatch() && roomModsReady(client.room))
						startRealtimeCountdown(client.room);
					else if (client.room.allReady() && !roomModsReady(client.room))
						client.room.noticeForAll("模组同步尚未完成，已阻止自动开局。");
					else if (client.room.allReady())
						client.room.noticeForAll("有玩家的谱面哈希不一致，已阻止开局：" + client.room.hashMismatchNames().join("、"));
				}
			case SeiunProtocol.MSG_ROOM_CHAT:
				if (client.room != null && obj != null)
				{
					var text:String = Reflect.field(obj, "text");
					if (text != null && text.length > 0)
						client.room.broadcastChat(client, text);
				}
			case SeiunProtocol.MSG_ROOM_SONG_SELECT:
				if (client.room != null && client.room.hostId == client.id
					&& client.room.status == online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_LOBBY && obj != null)
				{
					var songName:String = Reflect.field(obj, "songName");
					var difficulty:String = Reflect.field(obj, "difficulty");
					if (songName == null || songName.length == 0 || difficulty == null || difficulty.length == 0)
						return true;
					var chart:ChartSelection = {
						songName: Reflect.field(obj, "songName"),
						difficulty: Reflect.field(obj, "difficulty"),
						chartHash: Reflect.field(obj, "chartHash"),
						chartSource: Reflect.field(obj, "chartSource")
					};
					if (Reflect.hasField(obj, "convertedBundle"))
						chart.convertedBundle = Reflect.field(obj, "convertedBundle");
					if (Reflect.hasField(obj, "songLengthMs"))
						chart.songLengthMs = Reflect.field(obj, "songLengthMs");
					if (Reflect.hasField(obj, "modFolder") && Reflect.field(obj, "modFolder") != null)
					{
						var mf:String = Std.string(Reflect.field(obj, "modFolder"));
						if (mf.length <= 128)
							chart.modFolder = mf;
					}
					roomManager.applyChart(client.room, chart);
				}
			case SeiunProtocol.MSG_ROOM_SETTINGS:
				updateRoomSettings(client, obj);
			case SeiunProtocol.MSG_ROOM_FORCE_START:
				if (client.room != null && client.room.hostId == client.id
					&& client.room.settings.mode == online.shared.OnlineTypes.OnlineConst.MODE_REALTIME
					&& client.room.status == online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_LOBBY)
					startRealtimeCountdown(client.room);
			case SeiunProtocol.MSG_ROOM_SET_SKIN:
				handleSetSkin(client, obj);
		}
		return true;
	}

	/**
		玩家请求换肤: 更新身份并广播给房间所有人 (PsychOnline setSkin 等价物)。
		未在房间时只更新身份, 下次进房生效。
	**/
	function handleSetSkin(client:ServerClient, obj:Dynamic):Void
	{
		var sd:online.shared.OnlineTypes.OnlineSkinData = online.shared.OnlineTypes.SkinDataUtil.fromDynamic(Reflect.field(obj, "skinData"));
		if (sd != null)
		{
			client.identity.skinData = sd;
			client.identity.skin = sd.char;
		}
		else
		{
			// 空 = 跟随谱面
			client.identity.skinData = null;
			client.identity.skin = "";
		}
		if (client.room != null)
		{
			client.room.broadcast(SeiunProtocol.MSG_ROOM_PLAYER_SKIN, {
				id: client.id,
				skinData: client.identity.skinData
			}, null, SeiunProtocol.CHANNEL_ROOM);
		}
	}

	function ensureAuthorized(client:ServerClient):Bool
	{
		if (client.authenticated)
			return true;
		client.sendError(SeiunProtocol.ERR_AUTH_REQUIRED, "专用服务器需要先注册/登录账号");
		return false;
	}

	function castRoomSettings(obj:Dynamic):RoomSettings
	{
		var settings:RoomSettings = {
			roomName: online.shared.OnlineTypes.OnlineConst.sanitizeRoomName(Reflect.field(obj, "roomName")),
			mode: Reflect.field(obj, "mode"),
			maxPlayers: asInt(Reflect.field(obj, "maxPlayers"), 0),
			// 反作弊已移除: 永远为 false, 保留字段仅为协议兼容。
			antiCheat: false,
			password: Reflect.field(obj, "password") == null ? "" : Std.string(Reflect.field(obj, "password")),
			roomCode: "",
			judgementPreset: Reflect.field(obj, "judgementPreset"),
			judgementTimings: parseTimings(Reflect.field(obj, "judgementTimings")),
			marvelousRatings: Reflect.field(obj, "marvelousRatings") == true,
			pausePolicy: sanitizePausePolicy(Reflect.field(obj, "pausePolicy")),
			compatibilityMode: Reflect.field(obj, "compatibilityMode") == true,
			allowDuplicateNames: Reflect.field(obj, "allowDuplicateNames") != false,
			teamSize: asInt(Reflect.field(obj, "teamSize"), 1),
			stageName: sanitizeStageName(Reflect.field(obj, "stageName")),
			compatEngine: sanitizeCompatEngine(Reflect.field(obj, "compatEngine"))
		};
		if (settings.maxPlayers < 1)
			settings.maxPlayers = config.maxPlayersDefault;
		if (settings.teamSize < 1)
			settings.teamSize = 1;
		if (settings.judgementTimings == null || settings.judgementTimings.length < 4)
			settings.judgementTimings = [25, 50, 70, 100];
		if (settings.judgementPreset == null || settings.judgementPreset.length == 0)
			settings.judgementPreset = "Leather Engine";
		return settings;
	}

	function updateRoomSettings(client:ServerClient, obj:Dynamic):Void
	{
		if (client.room == null || client.room.hostId != client.id || obj == null || client.room.status != online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_LOBBY)
			return;
		var r:Room = client.room;
		if (Reflect.hasField(obj, "roomName"))
			r.settings.roomName = online.shared.OnlineTypes.OnlineConst.sanitizeRoomName(Reflect.field(obj, "roomName"));
		if (Reflect.hasField(obj, "password"))
			r.settings.password = Std.string(Reflect.field(obj, "password"));
		// 反作弊已移除: 忽略客户端设置, 强制关闭。
		if (Reflect.hasField(obj, "mode"))
		{
			var newMode:String = Std.string(Reflect.field(obj, "mode"));
			// Malody/osu! 转谱只能异步排名: 房主切实时时服务器直接拒绝并保持异步。
			if (r.chart != null && r.chart.chartSource == online.shared.OnlineTypes.OnlineConst.CHART_SOURCE_CONVERTED
				&& newMode == online.shared.OnlineTypes.OnlineConst.MODE_REALTIME)
			{
				r.settings.mode = online.shared.OnlineTypes.OnlineConst.MODE_ASYNC;
				r.noticeForAll("当前转谱歌曲强制使用异步排名，不能切换为实时对战。");
			}
			else if (newMode == online.shared.OnlineTypes.OnlineConst.MODE_ASYNC || newMode == online.shared.OnlineTypes.OnlineConst.MODE_REALTIME)
			{
				r.settings.mode = newMode;
				r.asyncStartedAt = new Map<String, Float>();
				r.asyncScores = new Map<String, ScoreRecord>();
				r.realtimeResults = new Map<String, ScoreRecord>();
				r.pendingReplayUploads = new Map<String, String>();
				r.authoritativeScores = new Map<String, ScoreRecord>();
				r.authoritativeCombo = new Map<String, Int>();
				r.judgedNotes = new Map<String, Bool>();
				r.gameReadyIds = new Map<String, Bool>();
				r.startGateIds = new Map<String, Bool>();
				r.realtimeSyncServerStartMs = 0;
				r.realtimeSyncBroadcastUntilMs = 0;
				r.lastRealtimeSyncRebroadcastMs = 0;
				r.finalized = false;
				for (p in r.players)
				{
					p.isReady = false;
					r.asyncStates.set(p.id, online.shared.OnlineTypes.OnlineConst.ASYNC_STATE_NOT_STARTED);
				}
			}
		}
		if (Reflect.hasField(obj, "maxPlayers"))
		{
			var newMax:Int = asInt(Reflect.field(obj, "maxPlayers"), r.settings.maxPlayers);
			if (newMax >= r.players.length && newMax >= 1 && newMax <= 12)
				r.settings.maxPlayers = newMax;
		}
		if (Reflect.hasField(obj, "teamSize"))
		{
			var newTeam:Int = asInt(Reflect.field(obj, "teamSize"), r.settings.teamSize);
			if (newTeam >= 1 && newTeam <= 6)
			{
				r.settings.teamSize = newTeam;
				for (i in 0...r.players.length)
					r.players[i].team = Math.floor(i / newTeam) % 2;
			}
		}
		if (Reflect.hasField(obj, "judgementPreset"))
			r.settings.judgementPreset = Std.string(Reflect.field(obj, "judgementPreset"));
		if (Reflect.hasField(obj, "judgementTimings"))
		{
			var parsedTimings:Array<Int> = parseTimings(Reflect.field(obj, "judgementTimings"));
			if (parsedTimings != null)
				r.settings.judgementTimings = parsedTimings;
		}
		if (Reflect.hasField(obj, "marvelousRatings"))
			r.settings.marvelousRatings = Reflect.field(obj, "marvelousRatings") == true;
		if (Reflect.hasField(obj, "pausePolicy"))
			r.settings.pausePolicy = sanitizePausePolicy(Reflect.field(obj, "pausePolicy"));
		if (Reflect.hasField(obj, "compatibilityMode"))
			r.settings.compatibilityMode = Reflect.field(obj, "compatibilityMode") == true;
		if (Reflect.hasField(obj, "allowDuplicateNames"))
			r.settings.allowDuplicateNames = Reflect.field(obj, "allowDuplicateNames") == true;
		if (Reflect.hasField(obj, "stageName"))
			r.settings.stageName = sanitizeStageName(Reflect.field(obj, "stageName"));
		if (Reflect.hasField(obj, "compatEngine"))
			r.settings.compatEngine = sanitizeCompatEngine(Reflect.field(obj, "compatEngine"));
		r.roomInfoMessage();
	}

	function roomModsReady(room:Room):Bool
	{
		if (room == null)
			return false;
		// 单人实时局: 没有第二个玩家需要补齐文件, 模组同步条件应视为已满足,
		// 否则房主在清单还没提交/扫描完成前点“开始”会被“模组同步未完成”永久挡住。
		if (room.players.length <= 1)
			return true;
		if (room.hostManifest == null)
			return false;
		for (p in room.players)
		{
			if (!room.clientManifests.exists(p.id))
				return false;
			var left:Int = room.modsMissingCount.exists(p.id) ? room.modsMissingCount.get(p.id) : 0;
			if (left > 0)
				return false;
		}
		return true;
	}

	function startRealtimeCountdown(room:Room):Void
	{
		if (room == null || room.chart == null)
		{
			room.noticeForAll("请房主先选择歌曲");
			return;
		}
		// 已在倒计时中: 重复 ready/强制开始不再重置倒计时。
		if (room.status == online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_COUNTDOWN)
			return;
		if (!room.allHashesMatch())
		{
			room.noticeForAll("有玩家的谱面哈希不一致，已阻止开局：" + room.hashMismatchNames().join("、"));
			return;
		}
		if (!roomModsReady(room))
		{
			room.noticeForAll("模组同步尚未完成，已阻止开局。请等待房间大厅显示同步完成。");
			return;
		}
		room.status = online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_COUNTDOWN;
		room.countdownLeft = 3.0;
		room.lastCountdownSecond = 3;
		room.countdownPaused = false;
		// 每局开始清零上一局的计数/判定状态。
		room.authoritativeScores = new Map<String, ScoreRecord>();
		room.authoritativeCombo = new Map<String, Int>();
		room.judgedNotes = new Map<String, Bool>();
		room.realtimeResults = new Map<String, ScoreRecord>();
		room.pendingReplayUploads = new Map<String, String>();
		room.gameReadyIds = new Map<String, Bool>();
		room.startGateIds = new Map<String, Bool>();
		room.realtimeSyncServerStartMs = 0;
		room.realtimeSyncBroadcastUntilMs = 0;
		room.lastRealtimeSyncRebroadcastMs = 0;
		room.broadcast(SeiunProtocol.MSG_GAME_COUNTDOWN, {seconds: 3, song: room.chart}, null, SeiunProtocol.CHANNEL_GAME);
		lastTick = Date.now().getTime();
	}

	function handleGame(client:ServerClient, type:Int, obj:Dynamic):Bool
	{
		if (client.room == null)
			return true;
		var room:Room = client.room;
		// 倒计时阶段也放行暂停/恢复: 玩家可能在 3-2-1 倒计时里暂停,
		// 暂停期间服务器挂起倒计时, 恢复后继续, 保证"暂停时全员都停"。
		var isPauseResume:Bool = (type == SeiunProtocol.MSG_GAME_PAUSE || type == SeiunProtocol.MSG_GAME_RESUME);
		if (type != SeiunProtocol.MSG_GAME_START && room.status != online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_PLAYING)
		{
			if (!isPauseResume || room.status != online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_COUNTDOWN)
				return true;
		}
		switch (type)
		{
			case SeiunProtocol.MSG_GAME_START:
				// 房主可发送完整 chartNotes 供服务器做输入校验。
				if (room.hostId == client.id && obj != null)
				{
					var chartNotes:Dynamic = Reflect.field(obj, "chartNotes");
					if (chartNotes != null && Std.isOfType(chartNotes, Array))
					{
						room.noteTimesByLane = chartNotesToMap(cast chartNotes);
						room.chartNoteCount = (cast chartNotes : Array<Dynamic>).length;
					}
				}
			case SeiunProtocol.MSG_GAME_INPUT:
				handleGameInput(client, obj);
			case SeiunProtocol.MSG_GAME_START_ACK:
				// 起跑门闩: 玩家加载完并按下 空格/回车。全员确认后才广播统一起跑帧。
				if (room.settings.mode == online.shared.OnlineTypes.OnlineConst.MODE_REALTIME
					&& room.status == online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_PLAYING
					&& room.realtimeSyncServerStartMs <= 0)
				{
					room.startGateIds.set(client.id, true);
					// 广播门闩进度给其他玩家, 供等待文本显示 X/Y。
					var prog = room.startGateProgress();
					room.broadcast(SeiunProtocol.MSG_GAME_START_ACK, {
						id: client.id,
						nickname: client.displayName(),
						confirmed: prog.confirmed,
						total: prog.total
					}, client.id, SeiunProtocol.CHANNEL_GAME);
					// 单人实时局: 唯一玩家确认后没有“其他人”可等, 直接 force 发令,
					// 避免 allRealPlayersConfirmedStart 在异常状态下卡住等待。
					if (room.players.length <= 1)
						maybeBroadcastRealtimeSync(room, true);
					else if (room.allRealPlayersConfirmedStart())
						maybeBroadcastRealtimeSync(room, true);
					else
						maybeBroadcastRealtimeSync(room);
				}
			case SeiunProtocol.MSG_GAME_PAUSE, SeiunProtocol.MSG_GAME_RESUME:
				if (room.settings.mode == online.shared.OnlineTypes.OnlineConst.MODE_REALTIME)
				{
					// 暂停策略 (房主设置, 服务器权威执行):
					// - disabled: 禁止暂停相关, 直接丢弃;
					// - hostOnly: 只有房主的暂停/恢复消息有效 (非房主消息直接丢弃)。
					var pp:String = room.settings.pausePolicy == null
						? online.shared.OnlineTypes.OnlineConst.PAUSE_EVERYONE : room.settings.pausePolicy;
					if (pp == online.shared.OnlineTypes.OnlineConst.PAUSE_DISABLED)
						return true;
					if (pp == online.shared.OnlineTypes.OnlineConst.PAUSE_HOST_ONLY && client.id != room.hostId)
						return true;
					// 倒计时中的暂停: 挂起服务器倒计时, 恢复时继续 (全员同步冻结)。
					if (room.status == online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_COUNTDOWN)
					{
						if (type == SeiunProtocol.MSG_GAME_PAUSE)
							room.countdownPaused = true;
						else
							room.countdownPaused = false;
						if (room.countdownPaused)
							lastTick = Date.now().getTime();
					}
					room.broadcast(type, {
						id: client.id,
						nickname: client.displayName(),
						at: Date.now().getTime()
					}, client.id, SeiunProtocol.CHANNEL_GAME);
				}
			case SeiunProtocol.MSG_GAME_JUDGE:
				if (room.settings.mode != online.shared.OnlineTypes.OnlineConst.MODE_REALTIME)
					return true;
				if (obj != null)
				{
					obj.deviceId = client.identity.deviceId;
					obj.nickname = client.displayName();
					room.broadcast(SeiunProtocol.MSG_GAME_JUDGE, obj, client.id, SeiunProtocol.CHANNEL_GAME);
				}
			case SeiunProtocol.MSG_GAME_RESULT:
				if (room.settings.mode != online.shared.OnlineTypes.OnlineConst.MODE_REALTIME)
					return true;
				if (obj != null)
				{
					var score:ScoreRecord = castScore(obj, client);
					if (room.pendingReplayUploads.exists(client.id))
					{
						score.replayJson = room.pendingReplayUploads.get(client.id);
						room.pendingReplayUploads.remove(client.id);
					}
					room.realtimeResults.set(client.id, score);
					room.broadcast(SeiunProtocol.MSG_GAME_RESULT, score, client.id, SeiunProtocol.CHANNEL_GAME);
					// PsychOnline 式收尾: 等所有真人玩家都提交成绩后才出最终排名。
					tryFinalizeRealtime(room);
				}
			case SeiunProtocol.MSG_GAME_END:
				// 兼容旧客户端: 不再由房主单方面立即结束, 统一等待所有真人成绩到齐。
				if (room.hostId == client.id && room.settings.mode == online.shared.OnlineTypes.OnlineConst.MODE_REALTIME)
					tryFinalizeRealtime(room);
		}
		return true;
	}

	function chartNotesToMap(raw:Array<Dynamic>):Map<Int, Array<Float>>
	{
		var map:Map<Int, Array<Float>> = new Map<Int, Array<Float>>();
		for (note in raw)
		{
			if (note == null)
				continue;
			var lane:Int = asInt(Reflect.field(note, "lane"), -1);
			var time:Float = asFloat(Reflect.field(note, "timeMs"), 0);
			var length:Float = asFloat(Reflect.field(note, "lengthMs"), 0);
			if (lane < 0 || length > 0)
				continue; // 长条分段只用于异步回放计数, 不参与 tap 判定。
			if (!map.exists(lane))
				map.set(lane, []);
			map.get(lane).push(time);
		}
		for (k in map.keys())
			map.get(k).sort(function(a:Float, b:Float):Int { return a < b ? -1 : (a > b ? 1 : 0); });
		return map;
	}

	function handleGameInput(client:ServerClient, obj:Dynamic):Void
	{
		if (obj == null || client.room == null)
			return;
		var room:Room = client.room;
		if (room.settings.mode != online.shared.OnlineTypes.OnlineConst.MODE_REALTIME)
			return;
		if (room.status != online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_PLAYING)
			return;
		var lane:Int = asInt(Reflect.field(obj, "lane"), -1);
		var pressed:Bool = Reflect.field(obj, "pressed") == true;
		var songTime:Float = asFloat(Reflect.field(obj, "songTime"), 0);
		if (lane < 0 || lane > 18)
			return;
		// 反作弊已移除: 服务器只做输入转发, 判定由客户端本地完成并广播。
		var broadcast:Dynamic = {
			id: client.id,
			deviceId: client.identity.deviceId,
			nickname: client.displayName(),
			lane: lane,
			pressed: pressed,
			songTime: songTime,
			serverTime: Date.now().getTime()
		};
		room.broadcast(SeiunProtocol.MSG_GAME_INPUT, broadcast, client.id, SeiunProtocol.CHANNEL_GAME);
		if (scriptHost != null)
			scriptHost.call("onInput", [room.roomCode, client.displayName(), lane, pressed, songTime]);
	}

	function castScore(obj:Dynamic, client:ServerClient):ScoreRecord
	{
		var score:ScoreRecord = {
			deviceId: client.identity.deviceId,
			nickname: client.displayName(),
			avatar: client.identity.avatar,
			score: asInt(Reflect.field(obj, "score"), 0),
			accuracy: asFloat(Reflect.field(obj, "accuracy"), 0),
			maxCombo: asInt(Reflect.field(obj, "maxCombo"), 0),
			misses: asInt(Reflect.field(obj, "misses"), 0),
			marvelous: asInt(Reflect.field(obj, "marvelous"), 0),
			sick: asInt(Reflect.field(obj, "sick"), 0),
			good: asInt(Reflect.field(obj, "good"), 0),
			bad: asInt(Reflect.field(obj, "bad"), 0),
			shit: asInt(Reflect.field(obj, "shit"), 0),
			completed: Reflect.field(obj, "completed") != false,
			finishedAt: Date.now().getTime()
		};
		if (Reflect.hasField(obj, "nps"))
			score.nps = asFloat(Reflect.field(obj, "nps"), 0);
		if (Reflect.hasField(obj, "missTimes") && Std.isOfType(Reflect.field(obj, "missTimes"), Array))
			score.missTimes = cast Reflect.field(obj, "missTimes");
		if (Reflect.hasField(obj, "wrongLaneHits") && Std.isOfType(Reflect.field(obj, "wrongLaneHits"), Array))
			score.wrongLaneHits = cast Reflect.field(obj, "wrongLaneHits");
		if (Reflect.hasField(obj, "replayJson"))
			score.replayJson = Reflect.field(obj, "replayJson");
		return score;
	}

	function handleAsync(client:ServerClient, type:Int, obj:Dynamic):Bool
	{
		if (client.room == null)
			return true;
		var room:Room = client.room;
		switch (type)
		{
			case SeiunProtocol.MSG_ASYNC_START:
				if (room.finalized)
					return true;
				if (room.chart == null)
				{
					room.noticeForAll("请房主先选择歌曲");
					return true;
				}
				if (!roomModsReady(room))
				{
					room.noticeForAll("模组同步尚未完成，暂不能开始游玩");
					return true;
				}
				room.asyncStates.set(client.id, online.shared.OnlineTypes.OnlineConst.ASYNC_STATE_PLAYING);
				room.asyncStartedAt.set(client.id, Date.now().getTime());
				room.broadcastAsyncStatus();
			case SeiunProtocol.MSG_ASYNC_SUBMIT:
				if (obj == null)
					return true;
				if (room.finalized)
				{
					room.noticeForAll(client.displayName() + " 在结算后提交成绩，已忽略");
					return true;
				}
				if (room.selectedSongHash != null && room.selectedSongHash.length > 0
					&& Reflect.field(obj, "chartHash") != null
					&& Reflect.field(obj, "chartHash") != room.selectedSongHash)
				{
					room.noticeForAll(client.displayName() + " 提交的歌曲与当前房间不一致，成绩已忽略");
					return true;
				}
				var score:ScoreRecord = castScore(obj, client);
				// 反作弊已移除: 成绩一律接受, 不再校验回放。
				score.replayVerified = null;
				room.applyAsyncScore(client, score);
				room.broadcast(SeiunProtocol.MSG_ASYNC_RANKING, {ranking: room.rankingPayload(), finalized: room.finalized}, null, SeiunProtocol.CHANNEL_ASYNC);
			case SeiunProtocol.MSG_ASYNC_FINALIZE:
				if (room.hostId == client.id)
				{
					room.finalized = true;
					room.broadcast(SeiunProtocol.MSG_ASYNC_RANKING, {ranking: room.rankingPayload(), finalized: true}, null, SeiunProtocol.CHANNEL_ASYNC);
					room.broadcastAsyncStatus();
				}
			case SeiunProtocol.MSG_ASYNC_REPLAY_UPLOAD:
				// 实时模式: 玩家结束后上传本局回放, 供结算页查看其他玩家的回放。
				if (obj == null)
					return true;
				var replayJson:String = Reflect.field(obj, "replayJson");
				if (replayJson == null)
					return true;
				if (replayJson.length > SeiunProtocol.MAX_SCORE_BYTES)
					replayJson = "";
				if (room.realtimeResults.exists(client.id))
				{
					var rec:ScoreRecord = room.realtimeResults.get(client.id);
					if (rec != null)
					{
						rec.replayJson = replayJson;
						room.realtimeResults.set(client.id, rec);
					}
				}
				else
				{
					// 回放先于成绩到达: 暂存, 成绩落地时合并。
					room.pendingReplayUploads.set(client.id, replayJson);
				}
			case SeiunProtocol.MSG_ASYNC_REPLAY_FETCH:
				if (obj == null)
					return true;
				var targetDevice:String = Reflect.field(obj, "deviceId");
				if (targetDevice == null || targetDevice.length == 0)
					return true;
				var found:String = null;
				var foundNick:String = "";
				for (id in room.asyncScores.keys())
				{
					var s:ScoreRecord = room.asyncScores.get(id);
					if (s == null || s.deviceId != targetDevice)
						continue;
					found = s.replayJson == null ? "" : s.replayJson;
					foundNick = s.nickname;
					break;
				}
				if (found == null)
				{
					for (id in room.realtimeResults.keys())
					{
						var s:ScoreRecord = room.realtimeResults.get(id);
						if (s == null || s.deviceId != targetDevice)
							continue;
						found = s.replayJson == null ? "" : s.replayJson;
						foundNick = s.nickname;
						break;
					}
				}
				if (found == null)
					found = "";
				client.send(SeiunProtocol.MSG_ASYNC_REPLAY, SeiunProtocol.CHANNEL_ASYNC, {
					deviceId: targetDevice,
					nickname: foundNick,
					replayJson: found
				});
		}
		return true;
	}

	function handleAdmin(client:ServerClient, type:Int, obj:Dynamic):Bool
	{
		if (type != SeiunProtocol.MSG_ADMIN_COMMAND || obj == null)
			return true;
		var command:String = Reflect.field(obj, "command");
		var isHost:Bool = client.room != null && client.room.hostId == client.id;
		var isServerAdmin:Bool = config.dedicated && client.account != null && client.account.role == "admin";
		if (!isHost && !isServerAdmin)
		{
			client.sendError(SeiunProtocol.ERR_NOT_AUTHORIZED, "普通玩家不能使用管理命令");
			return true;
		}
		var result:Dynamic = runAdminCommand(client, command, Reflect.field(obj, "args"));
		client.send(SeiunProtocol.MSG_ADMIN_RESULT, SeiunProtocol.CHANNEL_ADMIN, result);
		return true;
	}

	public function runAdminCommand(issuer:ServerClient, command:String, args:Dynamic):Dynamic
	{
		if (command == null)
			return {ok: false, message: "缺少命令"};
		var room:Room = issuer.room;
		// 服务器级管理命令 (账号/封禁/公告全服/停服) 只允许 admin 角色。
		var isServerAdmin:Bool = config.dedicated && issuer.account != null && issuer.account.role == "admin";
		switch (command)
		{
			case "kick":
				var targetId:String = args == null ? "" : Std.string(Reflect.field(args, "id"));
				if (room != null && targetId.length > 0)
				{
					var target:ServerClient = room.playerById(targetId);
					if (target == null)
						target = room.spectatorById(targetId); // 观战者也可被请出
					if (target != null && target != issuer)
					{
						target.sendError(SeiunProtocol.ERR_NOT_AUTHORIZED, "你被房主请出了房间");
						roomManager.leaveRoom(target);
						room.noticeForAll(target.displayName() + " 被房主请出房间");
						target.closing = true;
						return {ok: true, message: "已踢出"};
					}
				}
				return {ok: false, message: "目标不存在"};
			case "announce":
				if (room != null && args != null)
				{
					var text:String = Std.string(Reflect.field(args, "text"));
					room.noticeForAll(text);
					return {ok: true, message: "已公告"};
				}
				return {ok: false, message: "缺少文本"};
			case "anticheat":
				if (room != null)
				{
					room.settings.antiCheat = false;
					room.roomInfoMessage();
					return {ok: true, message: "反作弊已移除，始终关闭"};
				}
				return {ok: false, message: "缺少参数"};
			case "setpassword":
				if (room != null && args != null)
				{
					room.settings.password = Std.string(Reflect.field(args, "password"));
					room.roomInfoMessage();
					return {ok: true, message: "房间密码已更新"};
				}
				return {ok: false, message: "缺少参数"};
			// ── 服务器级管理 (仅 admin 角色) ─────────────────
			case "accounts":
				if (!isServerAdmin)
					return {ok: false, message: "需要管理员权限"};
				var list:Array<Dynamic> = authStore.accountsList();
				return {ok: true, accounts: list, total: list.length};
			case "ban":
				if (!isServerAdmin)
					return {ok: false, message: "需要管理员权限"};
				var target:String = args == null ? "" : Std.string(Reflect.field(args, "target"));
				var kind:String = args == null || Reflect.field(args, "kind") == null ? "ip" : Std.string(Reflect.field(args, "kind"));
				if (kind == null || kind.length == 0)
					kind = "ip";
				if (target.length == 0)
					return {ok: false, message: "缺少目标"};
				authStore.ban(target, kind, "in-game admin", 0, issuer.displayName());
				// 立即断开匹配的在线玩家。
				var banNow:Float = Date.now().getTime();
				var banInfo:AuthStore.StoredBan = authStore.effectiveBan(kind, target);
				for (c in clients)
				{
					if ((kind == "ip" && c.ip == target)
						|| (kind == "device" && c.identity != null && c.identity.deviceId == target)
						|| (kind == "account" && c.account != null && c.account.username.toLowerCase() == target.toLowerCase()))
					{
						c.send(SeiunProtocol.MSG_ERROR, SeiunProtocol.CHANNEL_CONTROL, AuthStore.banErrorPayload("你已被服务器封禁", banInfo, banNow));
						c.closing = true;
					}
				}
				return {ok: true, message: "已封禁 " + kind + ":" + target};
			case "unban":
				if (!isServerAdmin)
					return {ok: false, message: "需要管理员权限"};
				var target2:String = args == null ? "" : Std.string(Reflect.field(args, "target"));
				var kind2:String = args == null || Reflect.field(args, "kind") == null ? "ip" : Std.string(Reflect.field(args, "kind"));
				if (kind2 == null || kind2.length == 0)
					kind2 = "ip";
				if (target2.length == 0)
					return {ok: false, message: "缺少目标"};
				authStore.unban(target2, kind2);
				return {ok: true, message: "已解封 " + kind2 + ":" + target2};
			case "admin":
				if (!isServerAdmin)
					return {ok: false, message: "需要管理员权限"};
				var targetUser:String = args == null ? "" : Std.string(Reflect.field(args, "username"));
				var enable:Bool = args == null ? true : Reflect.field(args, "enabled") != false;
				if (targetUser.length == 0)
					return {ok: false, message: "缺少用户名"};
				return authStore.setRole(targetUser, enable ? "admin" : "player");
			case "resetpw":
				if (!isServerAdmin)
					return {ok: false, message: "需要管理员权限"};
				var targetUser2:String = args == null ? "" : Std.string(Reflect.field(args, "username"));
				var newPass:String = args == null ? "" : Std.string(Reflect.field(args, "password"));
				if (targetUser2.length == 0 || newPass.length == 0)
					return {ok: false, message: "用法: resetpw <用户名> <新密码>"};
				return authStore.resetPassword(targetUser2, newPass);
			case "broadcast":
				if (!isServerAdmin)
					return {ok: false, message: "需要管理员权限"};
				var text2:String = args == null ? "" : Std.string(Reflect.field(args, "text"));
				if (text2.length == 0)
					return {ok: false, message: "缺少文本"};
				for (r in roomManager.rooms)
					r.noticeForAll(text2);
				return {ok: true, message: "已全服公告"};
			case "stop":
				if (!isServerAdmin)
					return {ok: false, message: "需要管理员权限"};
				stopRequested = true;
				return {ok: true, message: "服务器将关闭"};
			default:
				return {ok: false, message: "未知命令"};
		}
	}

	function handleFile(client:ServerClient, type:Int, packet:InboundPacket):Bool
	{
		if (packet.payload.length > SeiunProtocol.MAX_FILE_BYTES + 4096)
		{
			client.markViolation("file chunk too large");
			return true;
		}
		switch (type)
		{
			case SeiunProtocol.MSG_MOD_MANIFEST:
				handleModManifest(client, packet);
			case SeiunProtocol.MSG_MOD_FILE_REQUEST:
				handleModFileRequest(client, packet);
			case SeiunProtocol.MSG_MOD_FILE_ACK:
				handleModFileAck(client, packet);
			case SeiunProtocol.MSG_GAME_START:
				handleChartTimeline(client, packet);
			case SeiunProtocol.MSG_AVATAR_REQUEST:
				handleAvatarRequest(client, packet);
			default:
				client.send(SeiunProtocol.MSG_ERROR, SeiunProtocol.CHANNEL_FILE,
					{code: SeiunProtocol.ERR_BAD_PACKET, message: "未知的文件同步消息"});
		}
		return true;
	}

	function handleChartTimeline(client:ServerClient, packet:InboundPacket):Void
	{
		if (client.room == null)
			return;
		var room:Room = client.room;
		// 异步模式无需统一起跑; 各打各的, 时间轴消息直接忽略。
		if (room.settings.mode != online.shared.OnlineTypes.OnlineConst.MODE_REALTIME)
			return;
		var raw:Dynamic = null;
		try
		{
			raw = haxe.Json.parse(packet.payload.toString());
		}
		catch (e:Dynamic)
		{
			client.markViolation("invalid chart timeline");
			return;
		}
		var songData:Dynamic = raw == null ? null : Reflect.field(raw, "song");
		var reportedHash:String = songData == null ? null : Reflect.field(songData, "chartHash");
		if (room.selectedSongHash != null && room.selectedSongHash.length > 0
			&& (reportedHash == null || reportedHash != room.selectedSongHash))
		{
			client.markViolation("chart timeline hash mismatch");
			return;
		}
		// 只有房主的时间轴用于输入校验; 每个真人玩家上传时间轴 = "我加载完了"。
		if (room.hostId == client.id)
		{
			var chartNotes:Dynamic = raw == null ? null : Reflect.field(raw, "chartNotes");
			if (chartNotes != null && Std.isOfType(chartNotes, Array))
			{
				room.noteTimesByLane = chartNotesToMap(cast chartNotes);
				room.chartNoteCount = (cast chartNotes : Array<Dynamic>).length;
			}
		}
		room.gameReadyIds.set(client.id, true);
		// 单人实时局: 唯一玩家时间轴到达即视为“已确认”, 直接 force 发统一起跑帧,
		// 不依赖 START_ACK 回包。这样即使 ACK 丢失/门闩状态异常, 单人也不会卡在等待。
		if (room.players.length <= 1)
		{
			room.startGateIds.set(client.id, true);
			var soloProg = room.startGateProgress();
			room.broadcast(SeiunProtocol.MSG_GAME_START_ACK, {
				id: client.id,
				nickname: client.displayName(),
				confirmed: soloProg.confirmed,
				total: soloProg.total
			}, client.id, SeiunProtocol.CHANNEL_GAME);
			maybeBroadcastRealtimeSync(room, true);
		}
		else
			maybeBroadcastRealtimeSync(room);
	}

	/**
		所有真人玩家都完成加载后发统一起跑帧。
		房主单人也走这里: 单人实时局不用等假想对手。
		@param force 超时兜底: 有玩家已经加载但另一个迟迟未上报时也发令,
		            慢玩家会在信号到达后立即起跑, 而不是让全房无限等待。

		修复: “准备”不再是手动起跑门闩。只要真人玩家全部上传完谱面时间轴
		(= 已经加载完成), 就立即广播 MSG_GAME_SYNC 自动开始, 不再等各自按
		空格/回车确认, 也不依赖 60 秒超时。
	**/
	public function maybeBroadcastRealtimeSync(room:Room, ?force:Bool = false):Void
	{
		if (room == null || room.settings.mode != online.shared.OnlineTypes.OnlineConst.MODE_REALTIME)
			return;
		if (room.status != online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_PLAYING)
			return;
		if (room.realtimeSyncServerStartMs > 0)
			return;
		var allUploaded:Bool = room.allRealPlayersUploadedTimeline();
		var anyConfirmed:Bool = false;
		for (p in room.players)
			if (room.startGateIds.exists(p.id))
			{
				anyConfirmed = true;
				break;
			}
		// 自动开始: 全员上传完时间轴即可；旧的手动门闩仅作为兼容保留。
		if (!allUploaded && !anyConfirmed)
			return;
		// 超时兜底: force 且至少有人确认过才发令；全员已上传则无条件放行。
		if (!force && !allUploaded && !room.allRealPlayersConfirmedStart())
			return;

		var now:Float = Date.now().getTime();
		var delay:Float = 1200; // 给音频/渲染留一点余量, 所有端在这个服务器时刻同时起跑。
		room.realtimeSyncServerStartMs = now + delay;
		room.realtimeSyncBroadcastUntilMs = now + 12000;
		room.lastRealtimeSyncRebroadcastMs = 0;
		room.broadcast(SeiunProtocol.MSG_GAME_SYNC, {
			serverNow: now,
			startDelayMs: delay,
			startedAt: room.gameStartedAt
		}, null, SeiunProtocol.CHANNEL_GAME);
		serverLog("realtime sync broadcast room " + room.roomCode + " at server " + Std.int(room.realtimeSyncServerStartMs));
	}

	function handleModManifest(client:ServerClient, packet:InboundPacket):Void
	{
		if (client.room == null)
			return;
		var raw:Dynamic = null;
		try
		{
			raw = haxe.Json.parse(packet.payload.toString());
		}
		catch (e:Dynamic)
		{
			client.markViolation("invalid mod manifest json");
			return;
		}
		var manifest:ModManifest = sanitizeModManifest(raw);
		var room:Room = client.room;
		// 旧选歌的迟到清单一律作废: 如果清单带了 chartHash 却与当前选歌不一致,
		// 说明它是上一首歌的扫描结果, 用它对齐模组会误放行/误阻塞开局。
		if (room.chart != null && room.selectedSongHash != null && room.selectedSongHash.length > 0
			&& manifest.chartHash != null && manifest.chartHash.length > 0
			&& manifest.chartHash != room.selectedSongHash)
		{
			client.send(SeiunProtocol.MSG_MOD_MANIFEST_RESULT, SeiunProtocol.CHANNEL_FILE, {
				files: [], totalBytes: 0, stale: true,
				message: "模组清单对应的歌曲已变化，已忽略；请等待房间信息刷新后自动重发。"
			});
			return;
		}
		room.clientManifests.set(client.id, manifest);
		if (room.hostId == client.id)
		{
			room.hostManifest = manifest;
			room.modsMissingCount.set(client.id, 0);
			room.noticeForAll("房主已提交模组清单：" + manifest.mods.length + " 个文件");
			syncModsForClient(client, room);
		}
		for (p in room.players)
		{
			if (p.id != room.hostId && room.clientManifests.exists(p.id))
				syncModsForClient(p, room);
		}
		if (room.status == online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_LOBBY
			&& room.settings.mode == online.shared.OnlineTypes.OnlineConst.MODE_REALTIME
			&& room.allReadyAndHashesMatch() && roomModsReady(room))
			startRealtimeCountdown(room);
		if (scriptHost != null)
			scriptHost.call("onModSync", [room.roomCode, client.displayName(), "manifest", manifest.mods.length]);
	}

	function sanitizeModManifest(raw:Dynamic):ModManifest
	{
		var manifest:ModManifest = {mods: [], generatedAt: Date.now().getTime()};
		if (raw == null)
			return manifest;
		var rawHash:Dynamic = Reflect.field(raw, "chartHash");
		if (rawHash != null && Std.string(rawHash).length > 0 && Std.string(rawHash).length <= 128)
			manifest.chartHash = Std.string(rawHash);
		var rawSource:Dynamic = Reflect.field(raw, "chartSource");
		if (rawSource != null && Std.string(rawSource).length > 0 && Std.string(rawSource).length <= 32)
			manifest.chartSource = Std.string(rawSource);
		var rawMods:Dynamic = Reflect.field(raw, "mods");
		if (rawMods == null || !Std.isOfType(rawMods, Array))
			return manifest;
		var arr:Array<Dynamic> = cast rawMods;
		for (entry in arr)
		{
			if (entry == null || !Reflect.isObject(entry))
				continue;
			if (manifest.mods.length >= 2000)
				break;
			var path:String = normalizeModPath(Reflect.field(entry, "path"));
			if (path == null || path.length == 0)
				continue;
			var size:Int = asInt(Reflect.field(entry, "size"), 0);
			if (size <= 0 || size > SeiunProtocol.MAX_FILE_BYTES)
				continue;
			var sha:String = Reflect.field(entry, "sha256");
			if (sha == null || sha.length != 64)
				continue;
			var info:ModFileInfo = {
				path: path,
				size: size,
				sha256: sha
			};
			if (Reflect.hasField(entry, "version") && Reflect.field(entry, "version") != null)
				info.version = Std.string(Reflect.field(entry, "version"));
			if (Reflect.hasField(entry, "modId") && Reflect.field(entry, "modId") != null)
				info.modId = Std.string(Reflect.field(entry, "modId"));
			manifest.mods.push(info);
		}
		return manifest;
	}

	function normalizeModPath(value:Dynamic):String
	{
		if (value == null)
			return null;
		var path:String = StringTools.replace(Std.string(value), "\\", "/");
		path = StringTools.trim(path);
		if (path.length == 0 || path.length > 1024)
			return null;
		if (path.substr(0, 1) == "/" || path.indexOf(":") >= 0)
			return null;
		var parts:Array<String> = path.split("/");
		var clean:Array<String> = [];
		for (part in parts)
		{
			if (part == ".." || part == "." || part.length == 0)
				return null;
			clean.push(part);
		}
		return clean.join("/");
	}

	function syncModsForClient(client:ServerClient, room:Room):Void
	{
		if (room.hostManifest == null)
		{
			serverLog("mod sync for " + client.displayName() + ": NO HOST MANIFEST (skip diff)");
			return;
		}
		var local:ModManifest = room.clientManifests.get(client.id);
		if (local == null)
		{
			serverLog("mod sync for " + client.displayName() + ": NO LOCAL MANIFEST (skip diff)");
			return;
		}
		var missing:Array<ModFileInfo> = missingModFiles(room.hostManifest, local);
		room.modsMissingCount.set(client.id, missing.length);
		var files:Array<Dynamic> = [];
		// Float 防止大模组合计溢出 32 位 Int; 客户端只用文件列表, 该值仅展示。
		var totalBytes:Float = 0;
		for (f in missing)
		{
			totalBytes += f.size;
			files.push({
				path: f.path,
				size: f.size,
				sha256: f.sha256,
				serverCanServe: canServeModFile(f.path)
			});
		}
		client.send(SeiunProtocol.MSG_MOD_MANIFEST_RESULT, SeiunProtocol.CHANNEL_FILE, {
			files: files,
			totalBytes: totalBytes,
			hostDeviceId: room.hostId
		});
		if (missing.length == 0)
		{
			serverLog("mod sync for " + client.displayName() + ": 0 file(s), 0 bytes (no-missing diff) host="
				+ room.hostManifest.mods.length + " local=" + local.mods.length
				+ " hostHash=" + (room.hostManifest.chartHash == null ? "" : room.hostManifest.chartHash)
				+ " localHash=" + (local.chartHash == null ? "" : local.chartHash)
				+ " selectedHash=" + (room.selectedSongHash == null ? "" : room.selectedSongHash)
				+ " | " + modDiffFacts(room.hostManifest, local));
		}
		else
			serverLog("mod sync for " + client.displayName() + ": " + missing.length + " file(s), " + totalBytes + " bytes");
	}

	function modDiffFacts(host:ModManifest, local:ModManifest):String
	{
		var localMap:Map<String, ModFileInfo> = new Map<String, ModFileInfo>();
		for (f in local.mods)
			localMap.set(f.path, f);
		var hostMap:Map<String, ModFileInfo> = new Map<String, ModFileInfo>();
		for (f in host.mods)
			hostMap.set(f.path, f);
		var hostOnly:Array<String> = [];
		var localOnly:Array<String> = [];
		var hashDiff:Int = 0;
		for (f in host.mods)
		{
			var own:ModFileInfo = localMap.get(f.path);
			if (own == null)
				hostOnly.push(f.path);
			else if (own.sha256 != f.sha256)
				hashDiff++;
		}
		for (f in local.mods)
			if (!hostMap.exists(f.path))
				localOnly.push(f.path);
		var cap:Array<String> = [];
		for (i in 0...hostOnly.length)
		{
			if (i >= 6) { cap.push("..."); break; }
			cap.push(hostOnly[i]);
		}
		var cap2:Array<String> = [];
		for (i in 0...localOnly.length)
		{
			if (i >= 6) { cap2.push("..."); break; }
			cap2.push(localOnly[i]);
		}
		return "pathMatch=" + (host.mods.length - hostOnly.length - hashDiff)
			+ " hashDiff=" + hashDiff
			+ " hostOnly(" + hostOnly.length + ")=" + cap.join(", ")
			+ " localOnly(" + localOnly.length + ")=" + cap2.join(", ");
	}

	function missingModFiles(host:ModManifest, local:ModManifest):Array<ModFileInfo>
	{
		var out:Array<ModFileInfo> = [];
		if (host == null || local == null)
			return out;
		var localMap:Map<String, ModFileInfo> = new Map<String, ModFileInfo>();
		for (f in local.mods)
			localMap.set(f.path, f);
		for (f in host.mods)
		{
			var own:ModFileInfo = localMap.get(f.path);
			if (own == null || own.sha256 != f.sha256)
				out.push(f);
		}
		return out;
	}

	function canServeModFile(relative:String):Bool
	{
		var full:String = resolveModFile(relative);
		if (full == null)
			return false;
		try
		{
			return sys.FileSystem.exists(full)
				&& !sys.FileSystem.isDirectory(full)
				&& sys.FileSystem.stat(full).size <= SeiunProtocol.MAX_FILE_BYTES;
		}
		catch (e:Dynamic)
		{
			return false;
		}
	}

	function resolveModFile(relative:String):String
	{
		var safe:String = normalizeModPath(relative);
		if (safe == null)
			return null;
		var roots:Array<String> = ["mods"];
		if (config.serverModsDir != null && config.serverModsDir.length > 0 && config.serverModsDir != "mods")
			roots.push(config.serverModsDir);
		for (root in roots)
		{
			var full:String = root + "/" + safe;
			if (sys.FileSystem.exists(full) && !sys.FileSystem.isDirectory(full))
				return full;
		}
		return null;
	}

	function handleModFileRequest(client:ServerClient, packet:InboundPacket):Void
	{
		if (client.room == null)
			return;
		var raw:Dynamic = null;
		try
		{
			raw = haxe.Json.parse(packet.payload.toString());
		}
		catch (e:Dynamic)
		{
			client.markViolation("invalid mod file request");
			return;
		}
		var path:String = normalizeModPath(Reflect.field(raw, "path"));
		if (path == null)
		{
			client.markViolation("invalid mod path");
			return;
		}
		if (client.fileTransferActive)
		{
			client.send(SeiunProtocol.MSG_MOD_FILE_ACK, SeiunProtocol.CHANNEL_FILE, {path: path, ok: false, message: "上一个文件仍在传输"});
			return;
		}
		var room:Room = client.room;
		if (room.hostManifest == null || findManifestFile(room.hostManifest, path) == null)
		{
			client.send(SeiunProtocol.MSG_MOD_FILE_ACK, SeiunProtocol.CHANNEL_FILE, {path: path, ok: false, message: "该文件不在房主模组清单中"});
			return;
		}
		var full:String = resolveModFile(path);
		if (full == null)
		{
			client.send(SeiunProtocol.MSG_MOD_FILE_ACK, SeiunProtocol.CHANNEL_FILE, {path: path, ok: false, message: "服务器无法直接读取该模组文件"});
			return;
		}
		try
		{
			if (sys.FileSystem.stat(full).size > SeiunProtocol.MAX_FILE_BYTES)
			{
				client.send(SeiunProtocol.MSG_MOD_FILE_ACK, SeiunProtocol.CHANNEL_FILE, {path: path, ok: false, message: "模组文件超过大小限制"});
				return;
			}
			var data:Bytes = sys.io.File.getBytes(full);
			if (data.length <= 0)
			{
				client.send(SeiunProtocol.MSG_MOD_FILE_ACK, SeiunProtocol.CHANNEL_FILE, {path: path, ok: false, message: "空文件无法同步"});
				return;
			}
			var transferId:Int = nextFileTransferId++;
			if (nextFileTransferId > 0x3FFFFFFF)
				nextFileTransferId = 1;
			client.clearPendingFile();
			client.queueFileData(data, path, transferId);
			serverLog("serving mod file " + path + " (" + data.length + " bytes, "
				+ client.pendingFileChunkCount + " chunks) to " + client.displayName());
		}
		catch (e:Dynamic)
		{
			client.send(SeiunProtocol.MSG_MOD_FILE_ACK, SeiunProtocol.CHANNEL_FILE, {path: path, ok: false, message: "读取文件失败: " + Std.string(e)});
		}
	}

	/**
		自定义头像文件服务: 客户端请求 mods/avatars/<file> 时, 服务器直接把本地文件
		按现有 CHANNEL_FILE 分块格式发给客户端。这样房主/嵌入式服务器上传的自定义
		头像可以被同房间其他玩家下载, 不会只在房主机器上显示、远端显示空白。
		专用服务器如需跨机器上传, 可在此基础上扩展客户端→服务器上传。
	**/
	function handleAvatarRequest(client:ServerClient, packet:InboundPacket):Void
	{
		var raw:Dynamic = null;
		try
		{
			raw = haxe.Json.parse(packet.payload.toString());
		}
		catch (e:Dynamic)
		{
			client.markViolation("invalid avatar request");
			return;
		}
		var fileName:String = normalizeModPath(Reflect.field(raw, "file"));
		if (fileName == null || fileName.indexOf("/") >= 0 || fileName.indexOf("\\") >= 0 || fileName.length == 0)
			return;
		if (client.fileTransferActive)
			return; // 已有文件在传, 静默忽略; 客户端拿到后会在需要时重试。
		var full:String = "mods/avatars/" + fileName;
		#if sys
		try
		{
			if (!sys.FileSystem.exists(full) || sys.FileSystem.isDirectory(full))
				return;
			var size:Int = sys.FileSystem.stat(full).size;
			if (size <= 0 || size > SeiunProtocol.MAX_FILE_BYTES)
				return;
			var data:Bytes = sys.io.File.getBytes(full);
			if (data.length <= 0)
				return;
			var transferId:Int = nextFileTransferId++;
			if (nextFileTransferId > 0x3FFFFFFF)
				nextFileTransferId = 1;
			client.clearPendingFile();
			client.queueFileData(data, "avatars/" + fileName, transferId);
			serverLog("serving avatar " + fileName + " (" + data.length + " bytes) to " + client.displayName());
		}
		catch (e:Dynamic) {}
		#end
	}

	/**
		接收客户端上传的自定义头像分块 (通过 MSG_PROFILE_UPDATE + avatarUpload 标记)。
		全部到齐后写入服务器本地 mods/avatars/, 之后 handleAvatarRequest 才能把该文件
		分发给房间内其他玩家。默认 32KB/chunk, 1MB 头像约 32 条消息。
	**/
	function handleAvatarUpload(client:ServerClient, obj:Dynamic):Void
	{
		var fileName:String = normalizeModPath(Reflect.field(obj, "avatarFile"));
		if (fileName == null || fileName.length == 0 || fileName.length > 120 || fileName.indexOf("/") >= 0 || fileName.indexOf("\\") >= 0)
			return;
		var idx:Int = asInt(Reflect.field(obj, "avatarChunkIndex"), -1);
		var count:Int = asInt(Reflect.field(obj, "avatarChunkCount"), 0);
		var dataB64:Dynamic = Reflect.field(obj, "avatarData");
		if (idx < 0 || count <= 0 || count > 128 || dataB64 == null)
			return;
		var bytes:Bytes = null;
		try
		{
			bytes = haxe.crypto.Base64.decode(StringTools.trim(Std.string(dataB64)));
		}
		catch (e:Dynamic)
		{
			return;
		}
		if (bytes == null || bytes.length <= 0 || bytes.length > SeiunProtocol.MAX_MESSAGE_BYTES)
			return;
		var upload:Dynamic = avatarUploads.get(client.id);
		if (upload != null && Std.string(Reflect.field(upload, "file")) != fileName)
		{
			avatarUploads.remove(client.id);
			upload = null;
		}
		if (upload == null)
		{
			upload = {file: fileName, chunks: new Map<Int, Bytes>(), count: count, startedAt: Date.now().getTime()};
			avatarUploads.set(client.id, upload);
		}
		var chunks:Map<Int, Bytes> = cast Reflect.field(upload, "chunks");
		chunks.set(idx, bytes);
		var chunkCount:Int = 0;
		for (k in chunks.keys())
			chunkCount++;
		if (chunkCount < count)
			return;
		for (i in 0...count)
			if (!chunks.exists(i))
				return;
		var buf:BytesBuffer = new BytesBuffer();
		for (i in 0...count)
			buf.add(chunks.get(i));
		var data:Bytes = buf.getBytes();
		#if sys
		try
		{
			if (!sys.FileSystem.exists("mods/avatars"))
				sys.FileSystem.createDirectory("mods/avatars");
			sys.io.File.saveBytes("mods/avatars/" + fileName, data);
			serverLog("received avatar " + fileName + " from " + client.displayName() + " (" + data.length + " bytes)");
		}
		catch (e:Dynamic) {}
		#end
		avatarUploads.remove(client.id);
	}

	function findManifestFile(manifest:ModManifest, path:String):ModFileInfo
	{
		if (manifest == null)
			return null;
		for (f in manifest.mods)
			if (f.path == path)
				return f;
		return null;
	}

	function handleModFileAck(client:ServerClient, packet:InboundPacket):Void
	{
		if (client.room == null)
			return;
		var raw:Dynamic = null;
		try
		{
			raw = haxe.Json.parse(packet.payload.toString());
		}
		catch (e:Dynamic) {}
		if (raw == null)
			return;
		var path:String = normalizeModPath(Reflect.field(raw, "path"));
		var ok:Bool = Reflect.field(raw, "ok") == true;
		// 传输逻辑修正: 只有与服务器当前正在传输的文件匹配的成功 ACK 才扣减
		// 缺失计数, 防止旧谱面的迟到 ACK / 任意路径 ACK 让房间误判"同步完成"。
		if (ok && path != null && path == client.pendingModPath && client.room != null)
		{
			var left:Int = client.room.modsMissingCount.exists(client.id) ? client.room.modsMissingCount.get(client.id) : 0;
			if (left > 0)
				client.room.modsMissingCount.set(client.id, left - 1);
			client.clearPendingFile();
			var room:Room = client.room;
			if (room.status == online.shared.OnlineTypes.OnlineConst.ROOM_STATUS_LOBBY
				&& room.settings.mode == online.shared.OnlineTypes.OnlineConst.MODE_REALTIME
				&& room.allReadyAndHashesMatch() && roomModsReady(room))
				startRealtimeCountdown(room);
		}
		serverLog("mod sync ack from " + client.displayName() + ": " + path + " " + (ok ? "ok" : "failed"));
		if (client.room != null)
		{
			client.room.noticeForAll(client.displayName() + (ok ? " 完成了模组文件同步：" : " 模组文件同步失败：") + path);
			if (scriptHost != null)
				scriptHost.call("onModSync", [client.room.roomCode, client.displayName(), ok ? "complete" : "failed", path]);
		}
	}

	function serverLog(text:String):Void
	{
		log(text);
	}

	/** 保存当前配置到配置文件 (供管理面板/控制台调用)。 */
	public function saveConfig():Void
	{
		#if sys
		try
		{
			config.save(configPath);
		}
		catch (e:Dynamic)
		{
			log("[config] 保存配置失败: " + Std.string(e));
		}
		#end
	}

	public function shutdown():Void
	{
		running = false;
		try
		{
			// 关服前落盘账号/会话/配置, 防止停机丢失数据。
			authStore.save();
			authStore.saveSessions();
			saveConfig();
		}
		catch (e:Dynamic) {}
		try
		{
			for (r in roomManager.rooms)
				r.noticeForAll("房主退出，房间已关闭");
		}
		catch (e:Dynamic) {}
		for (c in clients)
		{
			try { c.sendError(SeiunProtocol.ERR_SERVER_SHUTTING_DOWN, "服务器正在关闭"); } catch (e:Dynamic) {}
			try { c.flush(); } catch (e:Dynamic) {}
			try { c.socket.close(); } catch (e:Dynamic) {}
		}
		clients = [];
		try { if (listenSocket != null) listenSocket.close(); } catch (e:Dynamic) {}
		try { if (udpSocket != null) udpSocket.close(); } catch (e:Dynamic) {}
		udpSocket = null;
		if (adminHttp != null)
			adminHttp.stop();
		log("server stopped");
	}
}
