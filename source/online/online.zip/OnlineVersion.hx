package online;

import online.shared.SeiunProtocol;

/**
	联机功能版本常量。
**/
class OnlineVersion
{
	public static inline var FEATURE_VERSION:String = "0.1alpha";
	public static inline var PROTOCOL_VERSION:Int = SeiunProtocol.PROTOCOL_VERSION;

	public static function displayString():String
	{
		return "Seiun Online v" + FEATURE_VERSION + " / protocol " + PROTOCOL_VERSION;
	}
}
