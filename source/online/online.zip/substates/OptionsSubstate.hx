package online.substates;

import backend.CompatEngine;
import backend.MusicBeatSubstate;
import backend.Ratings;
import backend.ui.PsychUIInputText;
import CheckboxThingie;
import ClientPrefs;
import editors.content.FileDialogHandler;
import flash.net.FileFilter;
import flixel.addons.display.FlxBackdrop;
import flixel.addons.display.FlxGridOverlay;
import flixel.FlxG;
import flixel.FlxSprite;
import flixel.group.FlxGroup.FlxTypedGroup;
import flixel.math.FlxMath;
import flixel.text.FlxText;
import flixel.tweens.FlxEase;
import flixel.tweens.FlxTween;
import flixel.util.FlxColor;
import FlxTextMenuItem.FlxTextAttached;
import lime.system.Clipboard;
import online.client.GameClient;
import online.client.OnlineSession;
import online.client.ProfileStore;
import online.shared.SeiunProtocol;
import online.ui.AvatarSprite;
import online.ui.OnlineLayout;
import online.ui.OnlinePointer;
import online.ui.CreateRoomCard;
import online.ui.UIStyle;
import options.Option;
#if sys
import sys.FileSystem;
#end

/**
	联机设置 Substate —— 原版 OptionsState 界面逐像素复刻:
	menuDesat 蓝底 + 网格背景 + 左侧分类列表 (50px optionsfont + "> <" 选择器),
	进入分类后是 OptionsState 设置页 (FlxTextMenuItem 选项行 + 附加值/勾选框 +
	底部描述黑框)。网络/身份/默认规则三个联机分类, 房主在房间内改默认规则即时广播。
**/
class OptionsSubstate extends MusicBeatSubstate
{
	static final MODE_CATEGORY:Int = 0;
	static final MODE_SETTINGS:Int = 1;

	var currentMode:Int = MODE_CATEGORY;
	var currentPage:String = "";
	var transitioning:Bool = false;

	// 分类视图
	var catIds:Array<String> = ['network', 'identity', 'rules'];
	var catNames:Array<String> = [UIStyle.t('catNetwork', '网络'), UIStyle.t('catIdentity', '身份'), UIStyle.t('catRules', '默认规则')];
	var curSelected:Int = 0;
	var catGrid:FlxBackdrop;
	var catGrpOptions:FlxTypedGroup<FlxText>;
	var catSelectorLeft:FlxText;
	var catSelectorRight:FlxText;
	var scrollOffset:Float = 0;
	var targetScrollOffset:Float = 0;
	static final itemSpacing:Float = 105;
	static final baseY:Float = 120;

	// 设置视图
	var setGrpOptions:FlxTypedGroup<FlxTextMenuItem>;
	var setGrpTexts:FlxTypedGroup<FlxTextAttached>;
	var setCheckboxGroup:FlxTypedGroup<CheckboxThingie>;
	var setOptionsArray:Array<Option> = [];
	var setCurSelected:Int = 0;
	var setCurOption:Option = null;
	var setDescBox:FlxSprite;
	var setDescText:FlxText;
	var setTitleText:FlxTextMenuItem;

	var bg:FlxSprite;
	var avatarPreview:FlxSprite = null;
	var inRoomHost:Bool = false;
	var pendingAvatar:String = "";
	var pendingSkin:String = "";

	// 输入覆盖层 (服务器地址 / 昵称)
	var overlayDim:FlxSprite = null;
	var overlayInput:PsychUIInputText = null;
	var overlayTitle:FlxText = null;
	var overlayCallback:String->Void = null;

	var fileDialog:FileDialogHandler;
	var holdTime:Float = 0;
	var holdValue:Float = 0;

	override function create()
	{
		super.create();
		UIStyle.installInputEscapeGuard();
		ProfileStore.ensureLoaded();
		Ratings.loadPresets();
		fileDialog = new FileDialogHandler();
		inRoomHost = OnlineSession.active && OnlineSession.isHost;
		pendingAvatar = ProfileStore.avatar;
		pendingSkin = ProfileStore.skin;
		FlxG.mouse.visible = true;

		// OptionsState 同款背景
		bg = new FlxSprite().loadGraphic(Paths.image('menuDesat'));
		bg.color = 0xFF17719B;
		bg.screenCenter();
		bg.antialiasing = ClientPrefs.data.globalAntialiasing;
		add(bg);

		buildCategoryView();
		FlxTween.tween(bg, {alpha: 1}, 0.35, {ease: FlxEase.quadOut});
	}

	// ══════════════ 分类视图 (OptionsState 同款) ══════════════

	function buildCategoryView():Void
	{
		currentMode = MODE_CATEGORY;
		currentPage = "";

		catGrid = new FlxBackdrop(FlxGridOverlay.createGrid(80, 80, 160, 160, true, 0x33FFFFFF, 0x0));
		catGrid.velocity.set(40, 40);
		catGrid.alpha = 0;
		add(catGrid);
		FlxTween.tween(catGrid, {alpha: 0.55}, 0.35, {ease: FlxEase.quadOut});

		catGrpOptions = new FlxTypedGroup<FlxText>();
		add(catGrpOptions);
		for (i in 0...catIds.length)
		{
			var txt:FlxText = new FlxText(150, 0, 0, catNames[i], 32);
			txt.setFormat(Paths.optionsfont(), 50, FlxColor.WHITE, LEFT, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
			txt.borderSize = 2.5;
			txt.ID = i;
			catGrpOptions.add(txt);
		}

		catSelectorLeft = new FlxText(0, 0, 0, ">", 32);
		catSelectorLeft.setFormat(Paths.optionsfont(), 50, FlxColor.WHITE, LEFT, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		catSelectorLeft.borderSize = 2.5;
		add(catSelectorLeft);

		catSelectorRight = new FlxText(0, 0, 0, "<", 32);
		catSelectorRight.setFormat(Paths.optionsfont(), 50, FlxColor.WHITE, LEFT, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		catSelectorRight.borderSize = 2.5;
		add(catSelectorRight);

		targetScrollOffset = -(curSelected * itemSpacing);
		scrollOffset = targetScrollOffset;
		changeCategorySelection(0, false);
	}

	function updateCategoryView(elapsed:Float):Void
	{
		scrollOffset = FlxMath.lerp(scrollOffset, targetScrollOffset, CoolUtil.boundTo(elapsed * 12, 0, 1));

		for (i in 0...catGrpOptions.length)
		{
			var item:FlxText = catGrpOptions.members[i];
			if (item == null)
				continue;
			var screenY:Float = baseY + i * itemSpacing + scrollOffset;
			item.y = screenY;
			item.x = 150;
			var margin:Float = 80;
			var isVisible:Bool = (screenY + item.height > -margin && screenY < FlxG.height + margin);
			item.visible = isVisible;
			item.active = isVisible;
			if (!isVisible)
				continue;
			var dist:Float = 0;
			if (screenY < margin)
				dist = (margin - screenY) / margin;
			else if (screenY + item.height > FlxG.height - margin)
				dist = (screenY + item.height - (FlxG.height - margin)) / margin;
			item.alpha = FlxMath.bound(1 - dist, 0, 1);
		}

		var selItem:FlxText = catGrpOptions.members[curSelected];
		if (selItem != null && selItem.visible)
		{
			catSelectorLeft.x = selItem.x - 63;
			catSelectorLeft.y = selItem.y;
			catSelectorRight.x = selItem.x + selItem.width + 15;
			catSelectorRight.y = selItem.y;
			catSelectorLeft.visible = true;
			catSelectorRight.visible = true;
			catSelectorLeft.alpha = selItem.alpha;
			catSelectorRight.alpha = selItem.alpha;
		}
		else
		{
			catSelectorLeft.visible = false;
			catSelectorRight.visible = false;
		}

		if (controls.UI_UP_P)
			changeCategorySelection(-1);
		if (controls.UI_DOWN_P)
			changeCategorySelection(1);
		if (FlxG.mouse.wheel > 0)
			changeCategorySelection(-1);
		else if (FlxG.mouse.wheel < 0)
			changeCategorySelection(1);

		// 每帧统一指针状态 (触屏 tap + 鼠标复用同一套判定)。
		OnlinePointer.poll();

		for (i in 0...catGrpOptions.length)
		{
			var item:FlxText = catGrpOptions.members[i];
			if (item == null || !item.visible)
				continue;
			// 触屏: tap 语义 + ≥40px 命中 (分类项是 50px optionsfont, 命中高基本达标, 拉开一点余量)。
			if (OnlinePointer.tapped(item.x, item.y, item.width, Math.max(item.height, OnlineLayout.TOUCH_MIN_H))
				|| (FlxG.mouse.overlaps(item, FlxG.camera) && FlxG.mouse.justPressed && !OnlinePointer.pressed))
			{
				if (curSelected != i)
					changeCategorySelection(i - curSelected, false);
				openSelectedCategory(catIds[curSelected]);
				break;
			}
			if (FlxG.mouse.overlaps(item, FlxG.camera) && curSelected != i)
			{
				curSelected = i;
				changeCategorySelection(0, false);
			}
		}

		if (controls.ACCEPT)
			openSelectedCategory(catIds[curSelected]);
		if (controls.BACK #if android || FlxG.android.justReleased.BACK #end)
		{
			FlxG.sound.play(Paths.sound('cancelMenu'));
			saveAll();
			close();
		}
	}

	function changeCategorySelection(change:Int = 0, playSound:Bool = true):Void
	{
		curSelected += change;
		if (curSelected < 0)
			curSelected = catIds.length - 1;
		if (curSelected >= catIds.length)
			curSelected = 0;
		targetScrollOffset = -(curSelected * itemSpacing);
		if (change != 0 && playSound)
			FlxG.sound.play(Paths.sound('scrollMenu'), 0.5);
	}

	function destroyCategorySprites():Void
	{
		if (catGrid != null) { remove(catGrid); catGrid.destroy(); catGrid = null; }
		if (catGrpOptions != null) { remove(catGrpOptions); catGrpOptions.destroy(); catGrpOptions = null; }
		if (catSelectorLeft != null) { remove(catSelectorLeft); catSelectorLeft.destroy(); catSelectorLeft = null; }
		if (catSelectorRight != null) { remove(catSelectorRight); catSelectorRight.destroy(); catSelectorRight = null; }
	}

	function openSelectedCategory(id:String):Void
	{
		transitioning = true;
		FlxTween.tween(catGrid, {alpha: 0}, 0.2, {ease: FlxEase.quadIn});
		for (i in 0...catGrpOptions.length)
		{
			var item:FlxText = catGrpOptions.members[i];
			if (item != null)
				FlxTween.tween(item, {x: item.x - FlxG.width, alpha: 0}, 0.3, {ease: FlxEase.cubeIn});
		}
		FlxTween.tween(catSelectorLeft, {x: catSelectorLeft.x - FlxG.width, alpha: 0}, 0.3, {ease: FlxEase.cubeIn});
		FlxTween.tween(catSelectorRight, {x: catSelectorRight.x - FlxG.width, alpha: 0}, 0.3, {
			ease: FlxEase.cubeIn,
			onComplete: function(_) switchToSettings(id)
		});
	}

	// ══════════════ 设置视图 (OptionsState 同款) ══════════════

	function switchToSettings(page:String):Void
	{
		catGrid.visible = false;
		catGrpOptions.visible = false;
		catSelectorLeft.visible = false;
		catSelectorRight.visible = false;
		buildSettingsView(buildOptions(page), catNames[catIds.indexOf(page)]);
		currentMode = MODE_SETTINGS;
		currentPage = page;
		transitioning = false;
	}

	function buildOptions(page:String):Array<Option>
	{
		var out:Array<Option> = [];
		switch (page)
		{
			case 'network':
				out.push(onlineFreeText(UIStyle.t('optServerAddress', '服务器地址'),
					UIStyle.t('optServerAddressDesc', '局域网填房主 IP (ws://IP:2567), 专用服务器填其地址。回车修改。'), 'serverAddress',
					function() return ProfileStore.serverAddress,
					function(v) ProfileStore.setServerAddress(v),
					function() openTextInput(UIStyle.t('optServerAddress', '服务器地址'), ProfileStore.serverAddress, function(t)
					{
						ProfileStore.setServerAddress(t);
						settingsUpdateText(setCurOption);
					})));
				out.push(onlineButton(UIStyle.t('optDeviceId', '设备码 (点击复制)'),
					UIStyle.t('optDeviceIdDesc', '本机唯一身份码。回车复制到剪贴板。'), 'deviceId',
					function() return ProfileStore.deviceId,
					function(v) {},
					function()
					{
						Clipboard.text = ProfileStore.deviceId;
						FlxG.sound.play(Paths.sound('confirmMenu'), 0.6);
					}));
			case 'identity':
				out.push(onlineFreeText(UIStyle.t('optNickname', '昵称'),
					UIStyle.t('optNicknameDesc', '房间内显示的名字。回车修改, 保存后立即生效。'), 'nickname',
					function() return ProfileStore.nickname,
					function(v) {},
					function() openTextInput(UIStyle.t('optNickname', '昵称'), ProfileStore.nickname, function(t)
					{
						pendingAvatar = ProfileStore.avatar;
						ProfileStore.setProfile(t, ProfileStore.avatar);
						settingsUpdateText(setCurOption);
					})));
				out.push(onlineString(UIStyle.t('optAvatar', '头像'),
					UIStyle.t('optAvatarDesc', '原版角色血条图标 (与游戏内血条一致)。左右切换。'), 'avatar',
					avatarOptions(), ProfileStore.avatar,
					function() return ProfileStore.avatar,
					function(v) { pendingAvatar = v; ProfileStore.setProfile(ProfileStore.nickname, v); refreshAvatarPreview(); }));
				out.push(onlineButton(UIStyle.t('optAvatarUpload', '上传头像图片'),
					UIStyle.t('optAvatarUploadDesc', '选择本地 PNG/JPG (≤1MB), 保存后房间内即时生效。'), 'avatarUpload',
					function() return UIStyle.t('optClickToUpload', '点击上传'),
					function(v) {},
					function() pickAvatarImage()));
				out.push(onlineString(UIStyle.t('optSkin', '对局皮肤'),
					UIStyle.t('optSkinDesc', '对局中 BF 使用的皮肤; 跟随谱面 = 不覆盖。房内修改即时广播全员。'), 'skin',
					skinOptions(), ProfileStore.skin.length == 0 ? '跟随谱面' : ProfileStore.skin,
					function() return ProfileStore.skin.length == 0 ? '跟随谱面' : ProfileStore.skin,
					function(v)
					{
						if (v == '跟随谱面')
						{
							pendingSkin = '';
							ProfileStore.setSkinData(null);
						}
						else
						{
							pendingSkin = v;
							var entry:Dynamic = characterEntryByName(v);
							var modDir:String = entry != null ? Std.string(Reflect.field(entry, 'modDir')) : '';
							ProfileStore.setSkinData({char: v, modDir: modDir, suffixLeft: '', suffixRight: ''});
						}
						// 房内即时广播, 其余玩家下一帧重建自己的对手角色。
						if (OnlineSession.active)
							OnlineSession.sendSkinUpdate(ProfileStore.skinData);
					}));
			case 'rules':
				if (inRoomHost)
				{
					out.push(onlineFreeText(UIStyle.t('optRoomName', '房间名'),
						UIStyle.t('optRoomNameDesc', '修改后立即广播给房间内所有玩家。'), 'roomName',
						function() return OnlineSession.active && OnlineSession.settings != null ? OnlineSession.settings.roomName : '',
						function(v) {},
						function()
						{
							openTextInput(UIStyle.t('optRoomName', '房间名'), OnlineSession.roomName, function(t)
							{
								var clean:String = online.shared.OnlineTypes.OnlineConst.sanitizeRoomName(t);
								if (clean.length == 0)
									clean = UIStyle.t('defaultRoomName', '局域网房间');
								OnlineSession.roomName = clean;
								if (OnlineSession.settings != null)
									OnlineSession.settings.roomName = clean;
								broadcastRoomSettings();
								settingsUpdateText(setCurOption);
							});
						}));
					out.push(onlineFreeText(UIStyle.t('optRoomPassword', '房间密码'),
						UIStyle.t('optRoomPasswordDesc', '留空 = 无密码。修改后立即广播。'), 'roomPassword',
						function() return OnlineSession.active && OnlineSession.settings != null ? (OnlineSession.settings.password == null ? '' : OnlineSession.settings.password) : '',
						function(v) {},
						function()
						{
							openTextInput(UIStyle.t('optRoomPassword', '房间密码'),
								OnlineSession.settings != null && OnlineSession.settings.password != null ? OnlineSession.settings.password : '', function(t)
							{
								if (OnlineSession.settings != null)
									OnlineSession.settings.password = t;
								broadcastRoomSettings();
								settingsUpdateText(setCurOption);
							});
						}));
					out.push(onlineBool(UIStyle.t('optRoomDuplicateNames', '允许重名玩家'),
						UIStyle.t('optRoomDuplicateNamesDesc', '关闭后同昵称玩家无法加入房间。修改后立即广播。'), 'allowDuplicateNames',
						OnlineSession.active && OnlineSession.settings != null ? OnlineSession.settings.allowDuplicateNames : true,
						function() return OnlineSession.active && OnlineSession.settings != null ? OnlineSession.settings.allowDuplicateNames : true,
						function(v)
						{
							if (OnlineSession.settings != null)
								OnlineSession.settings.allowDuplicateNames = v;
							broadcastRoomSettings();
						}));
					out.push(onlineString(UIStyle.t('optRoomMode', '房间模式'),
						UIStyle.t('optRoomModeDesc', '实时对战 = 同开同屏并显示对手实时分数; 异步排名 = 各自游玩后提交成绩排名。'), 'roomMode',
						[UIStyle.t('modeRealtime', '实时对战'), UIStyle.t('modeAsync', '异步排名')],
						OnlineSession.mode == online.shared.OnlineTypes.OnlineConst.MODE_ASYNC ? UIStyle.t('modeAsync', '异步排名') : UIStyle.t('modeRealtime', '实时对战'),
						function() return OnlineSession.mode == online.shared.OnlineTypes.OnlineConst.MODE_ASYNC ? UIStyle.t('modeAsync', '异步排名') : UIStyle.t('modeRealtime', '实时对战'),
						function(v)
						{
							var mode:String = v == UIStyle.t('modeAsync', '异步排名')
								? online.shared.OnlineTypes.OnlineConst.MODE_ASYNC
								: online.shared.OnlineTypes.OnlineConst.MODE_REALTIME;
							// 转谱歌曲服务器会拒绝切回实时, 本地也保持一致避免按钮闪烁。
							if (OnlineSession.chart != null && OnlineSession.chart.chartSource == online.shared.OnlineTypes.OnlineConst.CHART_SOURCE_CONVERTED)
								mode = online.shared.OnlineTypes.OnlineConst.MODE_ASYNC;
							OnlineSession.mode = mode;
							if (OnlineSession.settings != null)
								OnlineSession.settings.mode = mode;
							broadcastRoomSettings();
						}));
					out.push(onlineString(UIStyle.t('optRoomMaxPlayers', '房间人数上限'),
						UIStyle.t('optRoomMaxPlayersDesc', '修改后立即广播, 不能低于当前房间人数。'), 'roomMaxPlayers',
						['2', '4', '6', '8', '10', '12'], Std.string(OnlineSession.active && OnlineSession.settings != null ? Std.int(OnlineSession.settings.maxPlayers) : 4),
						function() return OnlineSession.active && OnlineSession.settings != null ? Std.string(Std.int(OnlineSession.settings.maxPlayers)) : '4',
						function(v)
						{
							var n:Int = Std.parseInt(v);
							if (n >= OnlineSession.players.length)
							{
								if (OnlineSession.settings != null)
									OnlineSession.settings.maxPlayers = n;
								broadcastRoomSettings();
							}
						}));
					out.push(onlineString(UIStyle.t('optRoomStage', '房间舞台'),
						UIStyle.t('optRoomStageDesc', '空 = 跟随歌曲舞台。修改后立即广播。'), 'roomStage',
						['跟随歌曲', 'stage', 'spooky', 'philly', 'limo', 'mall', 'mallEvil', 'school', 'schoolEvil', 'tank'],
						OnlineSession.stageName.length == 0 ? '跟随歌曲' : OnlineSession.stageName,
						function() return OnlineSession.stageName.length == 0 ? '跟随歌曲' : OnlineSession.stageName,
						function(v) { OnlineSession.stageName = (v == '跟随歌曲' ? '' : v); broadcastRoomSettings(); }));
				}
				out.push(onlineString((inRoomHost ? UIStyle.t('optRoomCompat', '房间兼容模式') : UIStyle.t('optCompat', '默认兼容模式')),
					UIStyle.t('optCompatDesc', 'Auto / 0.6.3 / 0.7.3 / 1.0.4, 房主修改后即时广播。'), 'compatEngine',
					CompatEngine.VALUES.copy(), ClientPrefs.data.compatEngine,
					function() return ClientPrefs.data.compatEngine,
					function(v) { ClientPrefs.data.compatEngine = v; if (inRoomHost) broadcastRoomSettings(); }));
				var presetList:Array<String> = Ratings.presets.copy();
				if (presetList.indexOf('Custom') < 0)
					presetList.push('Custom');
				out.push(onlineString((inRoomHost ? UIStyle.t('optRoomJudgement', '房间判定') : UIStyle.t('optJudgement', '默认判定')),
					UIStyle.t('optJudgementDesc', '判定窗口预设; 选 Custom 可自定义四档窗口, 房主修改后即时广播。'), 'judgementPreset',
					presetList, ClientPrefs.data.judgementPreset,
					function() return ClientPrefs.data.judgementPreset,
					function(v)
					{
						ClientPrefs.data.judgementPreset = v;
						if (v != 'Custom')
							ClientPrefs.data.judgementTimings = Ratings.returnPreset(v);
						backend.Ratings.syncWindows();
						if (inRoomHost) broadcastRoomSettings();
						// 预设切换后刷新全部行 (窗口值/预设名会变化)
						for (opt in setOptionsArray) settingsUpdateText(opt);
					}));
				out.push(onlineInt(UIStyle.t('optJudgementMarvelous', 'Marvelous 窗口'),
					UIStyle.t('optJudgementMarvelousDesc', '自定义判定: Marvelous 窗口 (ms)。修改后判定类型自动变为 Custom。'), 'judgementMarvelousWindow',
					5, 0, 500, '%vms',
					function() return ClientPrefs.data.judgementTimings != null ? ClientPrefs.data.judgementTimings[0] : 25,
					function(v)
					{
						if (ClientPrefs.data.judgementTimings == null || ClientPrefs.data.judgementTimings.length < 4)
							ClientPrefs.data.judgementTimings = [25, 50, 70, 100];
						ClientPrefs.data.judgementTimings[0] = v;
						ClientPrefs.data.judgementPreset = 'Custom';
						backend.Ratings.syncWindows();
						if (inRoomHost) broadcastRoomSettings();
						refreshJudgementPresetRow();
					}));
				out.push(onlineInt(UIStyle.t('optJudgementSick', 'Sick 窗口'),
					UIStyle.t('optJudgementSickDesc', '自定义判定: Sick 窗口 (ms)。修改后判定类型自动变为 Custom。'), 'judgementSickWindow',
					5, 1, 500, '%vms',
					function() return ClientPrefs.data.judgementTimings != null ? ClientPrefs.data.judgementTimings[1] : 50,
					function(v)
					{
						if (ClientPrefs.data.judgementTimings == null || ClientPrefs.data.judgementTimings.length < 4)
							ClientPrefs.data.judgementTimings = [25, 50, 70, 100];
						ClientPrefs.data.judgementTimings[1] = v;
						ClientPrefs.data.judgementPreset = 'Custom';
						backend.Ratings.syncWindows();
						if (inRoomHost) broadcastRoomSettings();
						refreshJudgementPresetRow();
					}));
				out.push(onlineInt(UIStyle.t('optJudgementGood', 'Good 窗口'),
					UIStyle.t('optJudgementGoodDesc', '自定义判定: Good 窗口 (ms)。修改后判定类型自动变为 Custom。'), 'judgementGoodWindow',
					5, 1, 500, '%vms',
					function() return ClientPrefs.data.judgementTimings != null ? ClientPrefs.data.judgementTimings[2] : 70,
					function(v)
					{
						if (ClientPrefs.data.judgementTimings == null || ClientPrefs.data.judgementTimings.length < 4)
							ClientPrefs.data.judgementTimings = [25, 50, 70, 100];
						ClientPrefs.data.judgementTimings[2] = v;
						ClientPrefs.data.judgementPreset = 'Custom';
						backend.Ratings.syncWindows();
						if (inRoomHost) broadcastRoomSettings();
						refreshJudgementPresetRow();
					}));
				out.push(onlineInt(UIStyle.t('optJudgementBad', 'Bad 窗口'),
					UIStyle.t('optJudgementBadDesc', '自定义判定: Bad 窗口 (ms)。修改后判定类型自动变为 Custom。'), 'judgementBadWindow',
					5, 1, 500, '%vms',
					function() return ClientPrefs.data.judgementTimings != null ? ClientPrefs.data.judgementTimings[3] : 100,
					function(v)
					{
						if (ClientPrefs.data.judgementTimings == null || ClientPrefs.data.judgementTimings.length < 4)
							ClientPrefs.data.judgementTimings = [25, 50, 70, 100];
						ClientPrefs.data.judgementTimings[3] = v;
						ClientPrefs.data.judgementPreset = 'Custom';
						backend.Ratings.syncWindows();
						if (inRoomHost) broadcastRoomSettings();
						refreshJudgementPresetRow();
					}));
				out.push(onlineBool((inRoomHost ? UIStyle.t('optRoomMarvelous', '房间 Marvelous') : UIStyle.t('optMarvelous', '默认 Marvelous')),
					UIStyle.t('optMarvelousDesc', '是否启用 Marvelous 判定; 房主修改后即时广播。'), 'marvelousRatings',
					ClientPrefs.data.marvelousRatings,
					function() return ClientPrefs.data.marvelousRatings,
					function(v) { ClientPrefs.data.marvelousRatings = v; if (inRoomHost) broadcastRoomSettings(); }));
				// osu! 尾判已随引擎离线侧一并移除, 不再作为房间设置。
				if (inRoomHost)
				{
					out.push(onlineString(UIStyle.t('optRoomPause', '房间暂停策略'),
						UIStyle.t('optRoomPauseDesc', '实时对战: 全员可暂停 / 仅房主暂停有效 / 禁止暂停。修改后即时广播。'), 'pausePolicy',
						pausePolicyLabels(), pausePolicyLabel(OnlineSession.pausePolicy),
						function() return pausePolicyLabel(OnlineSession.pausePolicy),
						function(v)
						{
							var p:String = pausePolicyValue(v);
							OnlineSession.pausePolicy = p;
							if (OnlineSession.settings != null)
								OnlineSession.settings.pausePolicy = p;
							broadcastRoomSettings();
						}));
				}
		}
		return out;
	}

	/** 头像选项: 内置角色 + 模组角色 + 已上传的自定义头像。 */
	function avatarOptions():Array<String>
	{
		var base:Array<String> = [];
		for (e in scanModCharacterEntries())
			if (e != null && !base.contains(e.name))
				base.push(e.name);
		if (ProfileStore.avatar != null && ProfileStore.avatar.indexOf('file:') == 0 && !base.contains(ProfileStore.avatar))
			base.push(ProfileStore.avatar);
		return base;
	}

	/** 皮肤选项: "跟随谱面" 必须第一项 + 内置/模组角色 (参考 CharacterEditorState 扫描)。 */
	function skinOptions():Array<String>
	{
		var out:Array<String> = ['跟随谱面'];
		for (e in scanModCharacterEntries())
			if (e != null && !out.contains(e.name))
				out.push(e.name);
		return out;
	}

	/** 角色扫描结果缓存: 模组很多时避免每次进设置页都全量读目录。 */
	static var cachedCharacterEntries:Array<Dynamic> = null;

	/** 模组同步完成后使角色扫描缓存失效, 新接收的模组角色立即可选。 */
	public static function invalidateCharacterCache():Void
	{
		cachedCharacterEntries = null;
	}

	/**
		扫描 characters 定义: Paths.getPreloadPath('characters/') + mods/characters/ + 每个 mods/<mod>/characters/,
		去重。条目为 {name, modDir} (modDir = 角色所在模组目录, 空字符串 = 根/preload),
		联机换肤时随 skinData 上报, 远端玩家才能定位到该模组里的角色。
	**/
	public static function scanModCharacterEntries():Array<Dynamic>
	{
		if (cachedCharacterEntries != null)
			return cachedCharacterEntries;
		var out:Array<Dynamic> = [];
		var seen:Map<String, Bool> = new Map<String, Bool>();
		collectCharacterDir(Paths.getPreloadPath('characters/'), "", out, seen);
		collectCharacterDir(Paths.mods('characters/'), "", out, seen);
		#if sys
		try
		{
			if (sys.FileSystem.exists('mods') && sys.FileSystem.isDirectory('mods'))
			{
				for (entry in sys.FileSystem.readDirectory('mods'))
				{
					if (entry == '.' || entry == '..')
						continue;
					var dir:String = 'mods/' + entry + '/characters';
					if (sys.FileSystem.exists(dir) && sys.FileSystem.isDirectory(dir))
						collectCharacterDir(dir, entry, out, seen);
				}
			}
		}
		catch (e:Dynamic) {}
		#end
		cachedCharacterEntries = out;
		return out;
	}

	static function collectCharacterDir(dir:String, modDir:String, out:Array<Dynamic>, seen:Map<String, Bool>):Void
	{
		#if sys
		try
		{
			if (dir == null || dir.length == 0 || !sys.FileSystem.exists(dir) || !sys.FileSystem.isDirectory(dir))
				return;
			for (file in sys.FileSystem.readDirectory(dir))
			{
				if (!file.endsWith('.json'))
					continue;
				var name:String = file.substr(0, file.length - 5);
				if (name.length == 0 || seen.exists(name))
					continue;
				seen.set(name, true);
				out.push({name: name, modDir: modDir});
			}
		}
		catch (e:Dynamic) {}
		#end
	}

	/** 按角色名查扫描条目 (取 modDir 用)。 */
	public static function characterEntryByName(name:String):Dynamic
	{
		for (e in scanModCharacterEntries())
			if (e != null && e.name == name)
				return e;
		return null;
	}

	function buildSettingsView(optionsArray:Array<Option>, title:String):Void
	{
		destroySettingsSprites();

		setOptionsArray = optionsArray;
		setCurSelected = 0;
		setCurOption = null;
		holdTime = 0;
		holdValue = 0;

		setGrpOptions = new FlxTypedGroup<FlxTextMenuItem>();
		add(setGrpOptions);
		setGrpTexts = new FlxTypedGroup<FlxTextAttached>();
		add(setGrpTexts);
		setCheckboxGroup = new FlxTypedGroup<CheckboxThingie>();
		add(setCheckboxGroup);

		setDescBox = new FlxSprite().makeGraphic(1, 1, FlxColor.BLACK);
		setDescBox.alpha = 0.6;
		add(setDescBox);

		// 标题右移避开左上角 FPS 计数
		setTitleText = new FlxTextMenuItem(190, 56, title, 32);
		setTitleText.alpha = 0.4;
		add(setTitleText);

		// 描述文本宽按屏幕 (原 1180 只对 1280 宽正确), 32px 长描述必须 wordWrap, 否则横向溢出。
		setDescText = new FlxText(50, 600, FlxG.width - 100, "", 32);
		setDescText.setFormat(Paths.optionsfont(), 32, FlxColor.WHITE, CENTER, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		setDescText.wordWrap = true;
		setDescText.scrollFactor.set();
		setDescText.borderSize = 2.4;
		add(setDescText);

		for (i in 0...setOptionsArray.length)
		{
			var optionText:FlxTextMenuItem = new FlxTextMenuItem(290, 260, setOptionsArray[i].name, 48);
			optionText.isMenuItem = true;
			optionText.targetY = i;
			setGrpOptions.add(optionText);

			if (setOptionsArray[i].type == 'button')
			{
				optionText.x -= 10;
				optionText.startPosition.x -= 10;
				// 按钮行右侧实时显示当前值 (不再是固定的 [Press ENTER])。
				var valueText:FlxTextAttached = new FlxTextAttached('' + setOptionsArray[i].getValue(), 36, optionText.width + 80);
				valueText.sprTracker = optionText;
				valueText.copyAlpha = true;
				valueText.ID = i;
				setGrpTexts.add(valueText);
				setOptionsArray[i].setChild(valueText);
			}
			else if (setOptionsArray[i].type == 'bool')
			{
				var checkbox:CheckboxThingie = new CheckboxThingie(optionText.x - 10, optionText.y, setOptionsArray[i].getValue() == true);
				checkbox.sprTracker = optionText;
				checkbox.ID = i;
				setCheckboxGroup.add(checkbox);
			}
			else
			{
				optionText.x -= 10;
				optionText.startPosition.x -= 10;
				var valueText:FlxTextAttached = new FlxTextAttached('' + setOptionsArray[i].getValue(), 48, optionText.width + 80);
				valueText.sprTracker = optionText;
				valueText.copyAlpha = true;
				valueText.ID = i;
				setGrpTexts.add(valueText);
				setOptionsArray[i].setChild(valueText);
			}
			settingsUpdateText(setOptionsArray[i]);
		}

		// 身份页右侧头像预览 (角色立绘, 与设置页 BF 预览同位置)
		if (currentPage == 'identity' || (currentPage.length == 0 && title == '身份'))
		{
			refreshAvatarPreview();
		}

		changeSettingsSelection(0, false);
		settingsReloadCheckboxes();
	}

	function destroySettingsSprites():Void
	{
		if (setGrpOptions != null) { remove(setGrpOptions); setGrpOptions.destroy(); setGrpOptions = null; }
		if (setGrpTexts != null) { remove(setGrpTexts); setGrpTexts.destroy(); setGrpTexts = null; }
		if (setCheckboxGroup != null) { remove(setCheckboxGroup); setCheckboxGroup.destroy(); setCheckboxGroup = null; }
		if (setDescBox != null) { remove(setDescBox); setDescBox.destroy(); setDescBox = null; }
		if (setTitleText != null) { remove(setTitleText); setTitleText.destroy(); setTitleText = null; }
		if (setDescText != null) { remove(setDescText); setDescText.destroy(); setDescText = null; }
		if (avatarPreview != null) { remove(avatarPreview); avatarPreview.destroy(); avatarPreview = null; }
		destroyOverlay();
	}

	function refreshAvatarPreview():Void
	{
		if (avatarPreview != null)
		{
			remove(avatarPreview);
			avatarPreview.destroy();
			avatarPreview = null;
		}
		// 头像预览位置按屏宽右对齐 (原 840 只对 1280 宽正确)。
		avatarPreview = AvatarSprite.make(ProfileStore.avatar, 220);
		avatarPreview.setPosition(Math.max(FlxG.width - 320, 500), 170);
		add(avatarPreview);
	}

	function settingsUpdateText(option:Option):Void
	{
		var text:String = option.displayFormat;
		var val:Dynamic = option.getValue();
		var def:Dynamic = option.defaultValue;
		option.text = text.replace('%v', val).replace('%d', def);
		if (option.child != null)
		{
			var idx:Int = setOptionsArray.indexOf(option);
			if (idx >= 0 && idx < setGrpOptions.length)
			{
				var parentText:FlxTextMenuItem = setGrpOptions.members[idx];
				if (parentText != null)
					option.child.offsetX = parentText.width + 80;
			}
		}
	}

	function changeSettingsSelection(change:Int = 0, playSound:Bool = true):Void
	{
		if (setOptionsArray.length == 0)
			return;
		setCurSelected += change;
		if (setCurSelected < 0)
			setCurSelected = setOptionsArray.length - 1;
		if (setCurSelected >= setOptionsArray.length)
			setCurSelected = 0;

		setDescText.text = setOptionsArray[setCurSelected].description;
		setDescText.screenCenter(Y);
		setDescText.y += 270;

		var bullShit:Int = 0;
		for (item in setGrpOptions.members)
		{
			item.targetY = bullShit - setCurSelected;
			item.alpha = 0.6;
			if (item.targetY == 0)
				item.alpha = 1;
			bullShit++;
		}
		for (text in setGrpTexts)
		{
			text.alpha = 0.6;
			if (text.ID == setCurSelected)
				text.alpha = 1;
		}

		setDescBox.setPosition(setDescText.x - 10, setDescText.y - 10);
		setDescBox.setGraphicSize(Std.int(setDescText.width + 20), Std.int(setDescText.height + 25));
		setDescBox.updateHitbox();

		setCurOption = setOptionsArray[setCurSelected];
		if (playSound)
			FlxG.sound.play(Paths.sound('scrollMenu'));
	}

	function settingsReloadCheckboxes():Void
	{
		for (checkbox in setCheckboxGroup)
			checkbox.daValue = (setOptionsArray[checkbox.ID].getValue() == true);
	}

	// ── 更新 ─────────────────────────────────────────────

	override function update(elapsed:Float)
	{
		super.update(elapsed);
		if (transitioning)
			return;

		if (overlayInput != null)
		{
			updateOverlay();
			return;
		}

		if (currentMode == MODE_CATEGORY)
			updateCategoryView(elapsed);
		else
			updateSettingsView(elapsed);
	}

	function updateSettingsView(elapsed:Float):Void
	{
		var typing:Bool = UIStyle.anyInputFocused();
		if (!typing)
		{
			if (FlxG.mouse.wheel != 0)
			{
				changeSettingsSelection(-FlxG.mouse.wheel);
				FlxG.sound.play(Paths.sound('scrollMenu'));
			}

			// 触屏/鼠标统一 tap 语义 (按下与松开须在同一控件上, 命中 ≥40px;
			// 旧版只有 FlxG.mouse, 安卓上设置页完全点不动 —— UI 重构修复)。
			OnlinePointer.poll();
			var handled:Bool = false;
			if (OnlinePointer.pressed || OnlinePointer.justReleased)
			{
				for (checkbox in setCheckboxGroup)
				{
					if (checkbox != null && checkbox.visible
						&& OnlinePointer.tapped(checkbox.x, checkbox.y, checkbox.width, checkbox.height))
					{
						setCurSelected = checkbox.ID;
						changeSettingsSelection(0, false);
						FlxG.sound.play(Paths.sound('scrollMenu'));
						var opt:Option = setOptionsArray[checkbox.ID];
						opt.setValue(!opt.getValue());
						opt.change();
						settingsReloadCheckboxes();
						handled = true;
						break;
					}
				}
				if (!handled)
				{
					for (text in setGrpTexts)
					{
						if (text != null && text.visible
							&& OnlinePointer.tapped(text.x, text.y, text.width, text.height))
						{
							setCurSelected = text.ID;
							changeSettingsSelection(0, false);
							var clicked:Option = setOptionsArray[text.ID];
							if (clicked.type == 'button')
								clicked.change();
							else if (Std.isOfType(clicked, OnlineOption) && cast(clicked, OnlineOption).freeText)
								clicked.change();
							else
								cycleCurrentOption();
							handled = true;
							break;
						}
					}
				}
				// 行项是 48px FlxTextMenuItem, 点击行体也接受 (旧版只能点右侧附加值)。
				if (!handled)
				{
					for (item in setGrpOptions)
					{
						if (item != null && item.visible
							&& OnlinePointer.tapped(item.x, item.y, item.width, item.height))
						{
							setCurSelected = item.ID;
							changeSettingsSelection(0, false);
							var clicked:Option = setOptionsArray[item.ID];
							if (clicked.type == 'button')
								clicked.change();
							else if (Std.isOfType(clicked, OnlineOption) && cast(clicked, OnlineOption).freeText)
								clicked.change();
							else
								cycleCurrentOption();
							handled = true;
							break;
						}
					}
				}
			}

			if (controls.UI_UP_P)
				changeSettingsSelection(-1);
			if (controls.UI_DOWN_P)
				changeSettingsSelection(1);

			if (setCurOption != null)
			{
				var isFreeText:Bool = Std.isOfType(setCurOption, OnlineOption) && cast(setCurOption, OnlineOption).freeText;
				if (setCurOption.type == 'bool' || setCurOption.type == 'button')
				{
					if (controls.ACCEPT)
					{
						FlxG.sound.play(Paths.sound('scrollMenu'));
						if (setCurOption.type == 'bool')
						{
							setCurOption.setValue(!setCurOption.getValue());
							setCurOption.change();
							settingsReloadCheckboxes();
						}
						else
						{
							setCurOption.change();
						}
					}
				}
				else if (isFreeText)
				{
					// 自由文本行: ACCEPT 打开编辑覆盖层, 左/右不循环。
					if (controls.ACCEPT)
					{
						FlxG.sound.play(Paths.sound('scrollMenu'));
						setCurOption.change();
					}
				}
				else
				{
					if (controls.UI_LEFT_P)
						cycleCurrentOption(-1);
					else if (controls.UI_RIGHT_P)
						cycleCurrentOption(1);
					else if (controls.UI_LEFT || controls.UI_RIGHT)
					{
						holdTime += elapsed;
						if (holdTime > 0.5)
						{
							holdTime = 0;
							cycleCurrentOption(controls.UI_LEFT ? -1 : 1);
						}
					}
					else
						holdTime = 0;
				}
			}

			// ESC 刚取消过输入聚焦时, 这一帧的 BACK 放行 (不退回分类页)。
			if (controls.BACK #if android || FlxG.android.justReleased.BACK #end && !UIStyle.consumedInputEscape())
			{
				FlxG.sound.play(Paths.sound('cancelMenu'));
				saveAll();
				destroySettingsSprites();
				destroyCategorySprites();
				buildCategoryView();
				return;
			}
		}
		else if (FlxG.keys.justPressed.ESCAPE)
		{
			// 打字中按 ESC: 只取消输入聚焦 (Backspace 是退格, 不触发任何导航)。
			UIStyle.releaseInputFocus();
		}
	}

	/** 循环当前选项。dir=-1 左移 (上一个), dir=1 右移 (下一个)。 */
	function cycleCurrentOption(?dir:Int = 1):Void
	{
		var option:Option = setCurOption;
		if (option == null)
			return;
		if (Std.isOfType(option, OnlineOption) && cast(option, OnlineOption).freeText)
			return; // 自由文本行不循环
		if (option.type == 'string' && option.options != null && option.options.length > 0)
		{
			var num:Int = option.curOption + dir;
			if (num < 0)
				num = option.options.length - 1;
			else if (num >= option.options.length)
				num = 0;
			// 房间人数不能低于当前房间内人数, 自动跳过非法值 (双向)。
			if (option.variable == 'roomMaxPlayers')
			{
				var guard:Int = 0;
				while (guard < option.options.length)
				{
					var parsed:Null<Int> = Std.parseInt(option.options[num]);
					if (parsed == null || parsed < OnlineSession.players.length)
					{
						num = (num + dir + option.options.length) % option.options.length;
						guard++;
					}
					else
						break;
				}
			}
			option.curOption = num;
			option.setValue(option.options[num]);
		}
		else if (option.type == 'int')
		{
			var add:Int = Std.int(option.changeValue) * dir;
			var value:Int = option.getValue() + add;
			if (value < option.minValue)
				value = Std.int(option.minValue);
			if (value > option.maxValue)
				value = Std.int(option.maxValue);
			option.setValue(value);
		}
		settingsUpdateText(option);
		option.change();
		FlxG.sound.play(Paths.sound('scrollMenu'));
	}

	// ── 输入覆盖层 (服务器地址 / 昵称) ─────────────────────

	function openTextInput(title:String, initial:String, callback:String->Void):Void
	{
		overlayCallback = callback;
		overlayDim = new FlxSprite().makeGraphic(FlxG.width, FlxG.height, FlxColor.BLACK);
		overlayDim.alpha = 0;
		add(overlayDim);
		FlxTween.tween(overlayDim, {alpha: 0.6}, 0.2);

		// 覆盖层标题/输入按屏高居中 (原 250/310 只对 720 高正确)。
		var overlayY:Float = FlxG.height * 0.33;
		overlayTitle = new FlxText(0, overlayY, FlxG.width, title, 30);
		overlayTitle.setFormat(Paths.optionsfont(), 30, FlxColor.WHITE, CENTER, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		overlayTitle.borderSize = 2.4;
		add(overlayTitle);

		var ovW:Int = Std.int(Math.min(560, FlxG.width - OnlineLayout.PAD * 4));
		overlayInput = new PsychUIInputText(Std.int((FlxG.width - ovW) / 2), overlayY + OnlineLayout.lineHeight(30) + 14, ovW, initial, 22, UIStyle.inputFontKey());
		UIStyle.styleInput(overlayInput, ovW);
		add(overlayInput);
		PsychUIInputText.focusOn = overlayInput;
	}

	function updateOverlay():Void
	{
		if (overlayInput == null)
			return;
		if (controls.ACCEPT || FlxG.keys.justPressed.ENTER)
		{
			var text:String = StringTools.trim(overlayInput.text);
			if (overlayCallback != null && text.length > 0)
				overlayCallback(text);
			FlxG.sound.play(Paths.sound('confirmMenu'), 0.6);
			destroyOverlay();
		}
		// 输入框聚焦时 BACK 放行: Backspace 是退格不是返回; ESC 由输入框先取消聚焦。
		else if (controls.BACK #if android || FlxG.android.justReleased.BACK #end && !UIStyle.anyInputFocused())
		{
			FlxG.sound.play(Paths.sound('cancelMenu'));
			destroyOverlay();
		}
	}

	function destroyOverlay():Void
	{
		if (overlayInput != null)
		{
			if (PsychUIInputText.focusOn == overlayInput)
				PsychUIInputText.focusOn = null;
			remove(overlayInput);
			overlayInput.destroy();
			overlayInput = null;
		}
		if (overlayTitle != null) { remove(overlayTitle); overlayTitle.destroy(); overlayTitle = null; }
		if (overlayDim != null) { remove(overlayDim); overlayDim.destroy(); overlayDim = null; }
		overlayCallback = null;
	}

	// ── 头像上传 ─────────────────────────────────────────

	function pickAvatarImage():Void
	{
		fileDialog.open(null,
			Language.get('online.avatarPick', '选择头像图片 (PNG/JPG, ≤1MB)'),
			[new FileFilter('Images', '*.png;*.jpg;*.jpeg'), new FileFilter('All Files', '*.*')],
			function()
			{
				var path:String = fileDialog.path.split('\\').join('/');
				if (path == null || path.length == 0)
					return;
				var avatar:String = ProfileStore.importAvatarImage(path);
				if (avatar == null)
					return;
				pendingAvatar = avatar;
				ProfileStore.avatar = avatar;
				ProfileStore.save();
				refreshAvatarPreview();
				// 更新头像行显示
				for (i in 0...setOptionsArray.length)
					if (setOptionsArray[i].variable == 'avatar')
					{
						var opt:Option = setOptionsArray[i];
						if (opt.type == 'string' && opt.options != null && !opt.options.contains(avatar))
							opt.options.push(avatar);
						opt.curOption = opt.options.indexOf(avatar);
						opt.setValue(avatar);
						settingsUpdateText(opt);
						break;
					}
			});
	}

	// ── 广播 / 保存 ──────────────────────────────────────

	function broadcastRoomSettings():Void
	{
		var client:GameClient = GameClient.instance;
		if (client == null || client.socket == null || client.state != online.client.GameClient.ClientState.Ready || !OnlineSession.active)
			return;
		var maxPlayers:Int = OnlineSession.active && OnlineSession.settings != null ? Std.int(OnlineSession.settings.maxPlayers) : 4;
		var preset:String = ClientPrefs.data.judgementPreset;
		var timings:Array<Int> = (preset == 'Custom')
			? (ClientPrefs.data.judgementTimings != null ? ClientPrefs.data.judgementTimings.copy() : [25, 50, 70, 100])
			: backend.Ratings.returnPreset(preset);
		client.send(SeiunProtocol.MSG_ROOM_SETTINGS, SeiunProtocol.CHANNEL_ROOM, {
			// 反作弊已移除: 恒为 false。
			antiCheat: false,
			roomName: OnlineSession.settings != null ? OnlineSession.settings.roomName : OnlineSession.roomName,
			password: OnlineSession.settings != null ? OnlineSession.settings.password : "",
			mode: OnlineSession.mode,
			allowDuplicateNames: OnlineSession.settings != null ? OnlineSession.settings.allowDuplicateNames : true,
			judgementPreset: preset,
			judgementTimings: timings,
			marvelousRatings: ClientPrefs.data.marvelousRatings,
			pausePolicy: OnlineSession.pausePolicy,
			compatibilityMode: CompatEngine.compatMode(),
			compatEngine: ClientPrefs.data.compatEngine,
			stageName: OnlineSession.stageName,
			maxPlayers: maxPlayers,
			teamSize: Std.int(Math.max(1, Std.int(maxPlayers / 2)))
		});
	}

	function saveAll():Void
	{
		ProfileStore.setProfile(ProfileStore.nickname, pendingAvatar);
		ProfileStore.setSkin(pendingSkin);
		ProfileStore.save();
		ClientPrefs.saveSettings();

		if (OnlineSession.active)
		{
			var client:GameClient = GameClient.instance;
			if (client != null && client.socket != null && client.state == online.client.GameClient.ClientState.Ready)
			{
				if (ProfileStore.avatar != null && ProfileStore.avatar.indexOf("file:") == 0)
					online.client.AvatarFileClient.upload(ProfileStore.avatar.substr(5));
				client.send(SeiunProtocol.MSG_PROFILE_UPDATE, SeiunProtocol.CHANNEL_ROOM, {
					nickname: ProfileStore.nickname,
					avatar: ProfileStore.avatar,
					skin: ProfileStore.skin
				});
			}
		}
	}

	override function destroy():Void
	{
		destroySettingsSprites();
		destroyCategorySprites();
		super.destroy();
	}

	// ── Option 构造快捷方式 ───────────────────────────────

	static function onlineButton(name:String, desc:String, variable:String, getter:Void->Dynamic, setter:Dynamic->Void, onChange:Void->Void):Option
	{
		var o:OnlineOption = new OnlineOption(name, desc, variable, 'button', '', getter, setter);
		o.onChange = onChange;
		return o;
	}

	/** 自由文本行: string 类型但左/右不循环, ACCEPT 打开输入覆盖层, 右侧实时显示当前值。 */
	static function onlineFreeText(name:String, desc:String, variable:String, getter:Void->Dynamic, setter:Dynamic->Void, onChange:Void->Void):Option
	{
		var o:OnlineOption = new OnlineOption(name, desc, variable, 'string', '', getter, setter, null);
		o.freeText = true;
		o.onChange = onChange;
		return o;
	}

	static function onlineBool(name:String, desc:String, variable:String, defaultValue:Bool, getter:Void->Dynamic, setter:Dynamic->Void):Option
	{
		var o:OnlineOption = new OnlineOption(name, desc, variable, 'bool', defaultValue, getter, setter);
		o.onChange = function()
		{
			// 值已经由 setValue 写入 getter/setter 目标
		};
		return o;
	}

	static function onlineString(name:String, desc:String, variable:String, options:Array<String>, defaultValue:String, getter:Void->Dynamic, setter:Dynamic->Void):Option
	{
		var o:OnlineOption = new OnlineOption(name, desc, variable, 'string', defaultValue, getter, setter, options);
		o.onChange = function() {};
		return o;
	}

	/** 整数选项行 (自定义判定窗口等): 左右循环, 按 changeValue 步进。 */
	static function onlineInt(name:String, desc:String, variable:String, changeValue:Int, minValue:Int, maxValue:Int, displayFormat:String, getter:Void->Dynamic, setter:Dynamic->Void):Option
	{
		var o:OnlineOption = new OnlineOption(name, desc, variable, 'int', minValue, getter, setter);
		o.changeValue = changeValue;
		o.minValue = minValue;
		o.maxValue = maxValue;
		o.displayFormat = displayFormat;
		o.onChange = function() {};
		return o;
	}

	/** 自定义窗口修改后, 判定预设行自动显示 Custom。 */
	function refreshJudgementPresetRow():Void
	{
		if (setOptionsArray == null)
			return;
		for (opt in setOptionsArray)
			if (opt.variable == 'judgementPreset')
				settingsUpdateText(opt);
	}

	/** 暂停策略选项文案 (与 CreateRoomCard.pausePolicyLabel 一致)。 */
	static function pausePolicyLabels():Array<String>
	{
		return [
			UIStyle.t('pauseEveryone', '全员可暂停'),
			UIStyle.t('pauseHostOnly', '仅房主可暂停'),
			UIStyle.t('pauseDisabled', '禁止暂停')
		];
	}

	static function pausePolicyLabel(p:String):String
	{
		return switch (p)
		{
			case online.shared.OnlineTypes.OnlineConst.PAUSE_HOST_ONLY: UIStyle.t('pauseHostOnly', '仅房主可暂停');
			case online.shared.OnlineTypes.OnlineConst.PAUSE_DISABLED: UIStyle.t('pauseDisabled', '禁止暂停');
			default: UIStyle.t('pauseEveryone', '全员可暂停');
		}
	}

	static function pausePolicyValue(label:String):String
	{
		if (label == UIStyle.t('pauseHostOnly', '仅房主可暂停'))
			return online.shared.OnlineTypes.OnlineConst.PAUSE_HOST_ONLY;
		if (label == UIStyle.t('pauseDisabled', '禁止暂停'))
			return online.shared.OnlineTypes.OnlineConst.PAUSE_DISABLED;
		return online.shared.OnlineTypes.OnlineConst.PAUSE_EVERYONE;
	}
}

class OnlineOption extends Option
{
	public var getter:Void->Dynamic;
	public var setter:Dynamic->Void;
	/** 自由文本行: 左/右不循环, ACCEPT 打开输入覆盖层。 */
	public var freeText:Bool = false;

	public function new(name:String, description:String, variable:String, type:String, defaultValue:Dynamic,
			getter:Void->Dynamic, setter:Dynamic->Void, ?options:Array<String> = null)
	{
		this.getter = getter;
		this.setter = setter;
		super(name, description, variable, type, defaultValue, options);
	}

	override public function getValue():Dynamic
	{
		return getter != null ? getter() : null;
	}

	override public function setValue(value:Dynamic)
	{
		if (setter != null)
			setter(value);
		return value;
	}
}
