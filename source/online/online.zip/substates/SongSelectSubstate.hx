package online.substates;

import Alphabet;
import backend.Difficulty;
import backend.MusicBeatSubstate;
import editors.content.FileDialogHandler;
import editors.content.OsuMalodyConvert;
import flash.net.FileFilter;
import flixel.FlxG;
import flixel.FlxSprite;
import flixel.group.FlxGroup.FlxTypedGroup;
import flixel.text.FlxText;
import flixel.tweens.FlxEase;
import flixel.tweens.FlxTween;
import flixel.util.FlxColor;
import HealthIcon;
import Highscore;
import online.client.GameClient;
import online.client.OnlineChartUtil;
import online.client.OnlineSession;
import online.shared.SeiunHash;
import online.shared.SeiunProtocol;
import online.ui.OnlineLayout;
import online.ui.TextButton;
import online.ui.UIStyle;
import Song;
import Song.SwagSong;
import states.StoryMenuState;
import WeekData;
#if sys
import sys.FileSystem;
import sys.io.File;
#end

/**
	联机自由选曲 Substate —— 原版 FreeplayState 界面逐像素复刻:
	menuDesat 背景随歌曲颜色渐变 + 左侧 Alphabet 歌曲列表 + HealthIcon 图标,
	右上 PERSONAL BEST / 难度, 底部操作提示条, 加载失败全屏错误遮罩。
	在此基础上加联机逻辑: 房主确认后广播 MSG_ROOM_SONG_SELECT 并关闭,
	I 键可导入 Malody/osu! 就地转谱, 非房主只读。
**/
class SongSelectSubstate extends MusicBeatSubstate
{
	var songs:Array<String> = [];
	var songColors:Array<Int> = [];
	var songChars:Array<String> = [];
	var songSources:Array<String> = [];
	/** 每首歌所属模组目录 (原版 = 空串): 加载图标/谱面时临时切换, 修复模组图标不加载。 */
	var songFolders:Array<String> = [];

	var selectedSong:Int = 0;
	var selectedDiff:Int = 0;
	var diffs:Array<String> = Difficulty.defaultList.copy();

	var bg:FlxSprite;
	var intendedColor:Int = 0xFFFFFFFF;
	var colorTween:FlxTween;

	var grpSongs:FlxTypedGroup<Alphabet>;
	var iconArray:Array<HealthIcon> = [];
	var scoreBG:FlxSprite;
	var scoreText:FlxText;
	var diffText:FlxText;

	var lerpScore:Int = 0;
	var lerpRating:Float = 0;
	var intendedScore:Int = 0;
	var intendedRating:Float = 0;

	var missingTextBG:FlxSprite;
	var missingText:FlxText;
	var isShowingError:Bool = false;

	var client:GameClient;
	var fileDialog:FileDialogHandler;
	var readOnly:Bool = false;
	var holdTime:Float = 0;
	var mouseOverlapIndex:Int = -1;

	// 导入转换后自动选中
	static var pendingPickSong:String = null;
	static var pendingPickDiff:String = null;

	public function new()
	{
		super();
	}

	override function create()
	{
		super.create();
		readOnly = !OnlineSession.isHost;
		client = GameClient.instance != null ? GameClient.instance : new GameClient();
		fileDialog = new FileDialogHandler();

		FlxG.mouse.visible = true;
		WeekData.reloadWeekFiles(false);

		// 周目歌曲: 颜色/角色与 Freeplay 完全一致
		for (i in 0...WeekData.weeksList.length)
		{
			var weekName:String = WeekData.weeksList[i];
			var week:WeekData = WeekData.weeksLoaded.get(weekName);
			if (week == null || isWeekLocked(week))
				continue;
			for (song in week.songs)
			{
				if (song == null || songs.contains(song[0]))
					continue;
				var colors:Array<Int> = song[2];
				if (colors == null || colors.length < 3)
					colors = [146, 113, 253];
				songs.push(song[0]);
				songColors.push(FlxColor.fromRGB(colors[0], colors[1], colors[2]));
				songChars.push(song[1] == null ? 'bf' : song[1]);
				songSources.push('week');
				songFolders.push(week.folder == null ? "" : week.folder);
			}
		}
		scanConvertedMods();

		if (songs.length == 0)
		{
			songs = ["Bopeebo", "Fresh", "Dad Battle"];
			songColors = [0xFF9271FD, 0xFF9271FD, 0xFF9271FD];
			songChars = ['dad', 'dad', 'dad'];
			songSources = ['week', 'week', 'week'];
			songFolders = ["", "", ""];
		}

		if (pendingPickSong == null)
		{
			// 从联机选歌进入转谱器, 转换完成返回时自动选中刚转换的谱面。
			pendingPickSong = editors.ChartConverterState.lastConvertedSong;
			pendingPickDiff = editors.ChartConverterState.lastConvertedDiff;
			editors.ChartConverterState.lastConvertedSong = null;
			editors.ChartConverterState.lastConvertedDiff = null;
		}
		if (pendingPickSong != null)
		{
			var pickIdx:Int = songs.indexOf(pendingPickSong);
			if (pickIdx >= 0)
				selectedSong = pickIdx;
			if (pendingPickDiff != null)
			{
				var diffIdx:Int = diffs.indexOf(pendingPickDiff);
				if (diffIdx >= 0)
					selectedDiff = diffIdx;
			}
		}
		pendingPickSong = null;
		pendingPickDiff = null;
		if (selectedDiff < 0 || selectedDiff >= diffs.length)
			selectedDiff = 0;

		// 背景 (与 Freeplay 相同: menuDesat + 歌曲颜色)
		bg = new FlxSprite().loadGraphic(Paths.image('menuDesat'));
		bg.antialiasing = ClientPrefs.data.globalAntialiasing;
		bg.screenCenter();
		add(bg);

		grpSongs = new FlxTypedGroup<Alphabet>();
		add(grpSongs);

		rebuildSongItems();

		intendedColor = songColors[selectedSong];
		bg.color = intendedColor;

		// 右上分数/难度 (Freeplay 同款)
		scoreText = new FlxText(FlxG.width * 0.7, 5, 0, "", 32);
		scoreText.setFormat(Paths.languageFont(), 32, FlxColor.WHITE, RIGHT);
		scoreBG = new FlxSprite(scoreText.x - 6, 0).makeGraphic(1, 66, 0xFF000000);
		scoreBG.alpha = 0.6;
		add(scoreBG);
		diffText = new FlxText(scoreText.x, scoreText.y + 36, 0, "", 24);
		diffText.font = Paths.languageFont(); // 难度名走语言包字体 (中文包 vcrcn)
		add(diffText);
		add(scoreText);

		// 底部提示条 (FPS 在左上角, 这条在底部右侧, 绝不重叠)
		var textBG:FlxSprite = new FlxSprite(0, FlxG.height - 26).makeGraphic(FlxG.width, 26, 0xFF000000);
		textBG.alpha = 0.6;
		add(textBG);
		var hint:FlxText = new FlxText(0, textBG.y + 4, FlxG.width,
			readOnly
				? UIStyle.t('songSelectHintReadonly', 'ENTER 确认(仅房主) · ESC 关闭 · I 导入谱面 · 滚轮/↑↓ 选择 · ←→ 难度')
				: UIStyle.t('songSelectHint', 'ENTER 确认选歌并广播 · ESC 关闭 · 右下按钮/I 导入 Malody/osu! 谱面 · 滚轮/↑↓ 选择 · ←→ 难度'), 18);
		hint.setFormat(Paths.languageFont(), 18, FlxColor.WHITE, RIGHT);
		hint.wordWrap = true; // 窄屏长提示不横向溢出
		hint.scrollFactor.set();
		add(hint);

		// 可见的"导入 Malody/osu! 谱面"按钮 (右下角, 底部提示条上方, 不遮挡 FPS)
		// x 按 FlxG.width 右对齐 (原 910 只对 1280 宽正确, 窄屏会溢出屏幕)。
		if (!readOnly)
		{
			var importBtn:TextButton = new TextButton(0, FlxG.height - 66, UIStyle.t('songSelectImportBtn', '导入 Malody/osu! 谱面'), function() pickChartFile(), 16);
			importBtn.alignment = LEFT;
			importBtn.setFormat(Paths.languageFont(), 16, FlxColor.fromRGB(180, 220, 255), LEFT, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
			importBtn.antialiasing = true;
			importBtn.refresh();
			importBtn.x = FlxG.width - importBtn.width - 24;
			add(importBtn);
		}

		// 加载失败遮罩 (Freeplay 同款)
		missingTextBG = new FlxSprite().makeGraphic(FlxG.width, FlxG.height, FlxColor.BLACK);
		missingTextBG.alpha = 0.6;
		missingTextBG.visible = false;
		add(missingTextBG);
		missingText = new FlxText(50, 0, FlxG.width - 100, '', 24);
		missingText.setFormat(Paths.languageFont(), 24, FlxColor.WHITE, CENTER, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		missingText.wordWrap = true; // 错误信息可能很长
		missingText.scrollFactor.set();
		missingText.visible = false;
		add(missingText);

		refreshDiffsForCurrentSong(true);
		changeSelection(0, false);
		changeDiff(0, false);
		playEntranceAnimation();
	}

	function isWeekLocked(week:WeekData):Bool
	{
		return (!week.startUnlocked && week.weekBefore.length > 0
			&& (!StoryMenuState.weekCompleted.exists(week.weekBefore) || !StoryMenuState.weekCompleted.get(week.weekBefore)));
	}

	function rebuildSongItems():Void
	{
		UIStyle.clearAndDestroy(grpSongs);
		for (icon in iconArray)
			icon.destroy();
		iconArray = [];

		for (i in 0...songs.length)
		{
			var item:Alphabet = new Alphabet(90, 325, songs[i], true);
			item.isMenuItem = true;
			item.targetY = i - selectedSong;
			item.snapToPosition();
			if (item.width > 980)
				item.scaleX = 980 / item.width;
			grpSongs.add(item);

			// 修复模组歌曲图标不加载: 与 FreeplayState 相同, 建图标前临时切到该歌所属模组目录。
			var savedModDir:String = Paths.currentModDirectory;
			if (songFolders[i] != null && songFolders[i].length > 0)
				Paths.currentModDirectory = songFolders[i];
			var icon:HealthIcon = new HealthIcon(songChars[i]);
			Paths.currentModDirectory = savedModDir;
			icon.sprTracker = item;
			icon.scale.set(0.85, 0.85);
			icon.updateHitbox();
			add(icon);
			iconArray.push(icon);
		}
	}

	function playEntranceAnimation():Void
	{
		for (i in 0...grpSongs.length)
		{
			var it:Alphabet = grpSongs.members[i];
			var icon:HealthIcon = iconArray[i];
			var targetAlpha:Float = (i == selectedSong) ? 1 : 0.6;
			var delay:Float = Math.min(Math.abs(i - selectedSong) * 0.035, 0.4);
			it.alpha = 0;
			icon.alpha = 0;
			FlxTween.tween(it, {alpha: targetAlpha}, 0.3, {startDelay: delay, ease: FlxEase.sineOut});
			var baseScale:Float = (i == selectedSong) ? 1.2 : 0.85;
			FlxTween.cancelTweensOf(icon.scale);
			icon.scale.set(baseScale * 0.5, baseScale * 0.5);
			FlxTween.tween(icon.scale, {x: baseScale, y: baseScale}, 0.4, {startDelay: delay, ease: FlxEase.backOut});
			FlxTween.tween(icon, {alpha: targetAlpha}, 0.3, {startDelay: delay, ease: FlxEase.sineOut});
		}
	}

	// ── 列表构建 (周目 + mods/data 转换谱面) ──────────────

	function scanConvertedMods():Void
	{
		#if sys
		try
		{
			if (!sys.FileSystem.exists("mods/data") || !sys.FileSystem.isDirectory("mods/data"))
				return;
			for (folder in sys.FileSystem.readDirectory("mods/data"))
			{
				if (folder == "." || folder == "..")
					continue;
				var dir:String = "mods/data/" + folder;
				if (!sys.FileSystem.isDirectory(dir) || songs.contains(folder))
					continue;
				songs.push(folder);
				songColors.push(0xFF9271FD);
				songChars.push('bf');
				// 这里只是普通 mods/data 谱面列表项; 是否"转谱"必须看 song.format,
				// 不能因为它在 mods/data 里就强制异步。
				songSources.push('mod');
				songFolders.push("");
			}
		}
		catch (e:Dynamic) {}
		#end
	}

	function refreshDiffsForCurrentSong(keepIndex:Bool):Void
	{
		var oldDiff:String = diffs.length > selectedDiff && selectedDiff >= 0 ? diffs[selectedDiff] : CoolUtil.defaultDifficulty;
		var name:String = songs[selectedSong];
		var songPath:String = Paths.formatToSongPath(name);
		// 以实际文件为准: 扫描 mods/data/<songPath> 与 assets/preload/data/<songPath>,
		// 导入谱只有哪个难度就只显示哪个难度, 不再凭空注入 Easy/Normal/Hard。
		var found:Array<String> = [];
		scanDirDiffs("mods/data/" + songPath, songPath, found);
		if (selectedSong >= 0 && selectedSong < songFolders.length && songFolders[selectedSong] != null && songFolders[selectedSong].length > 0)
			scanDirDiffs("mods/" + songFolders[selectedSong] + "/data/" + songPath, songPath, found);
		scanDirDiffs(Paths.getPreloadPath("data/") + songPath, songPath, found);
		var ordered:Array<String> = [];
		if (found.length > 0)
		{
			// 标准难度按 defaultList 顺序排在前面, 自定义难度追加在后。
			for (d in Difficulty.defaultList)
				if (found.contains(d))
					ordered.push(d);
			for (d in found)
				if (!ordered.contains(d))
					ordered.push(d);
			diffs = ordered;
		}
		else
			diffs = Difficulty.defaultList.copy();
		var idx:Int = diffs.indexOf(oldDiff);
		selectedDiff = idx >= 0 ? idx : 0;
	}

	static function scanDirDiffs(dir:String, songPath:String, out:Array<String>):Void
	{
		#if sys
		try
		{
			if (dir == null || dir.length == 0 || !sys.FileSystem.exists(dir) || !sys.FileSystem.isDirectory(dir))
				return;
			for (file in sys.FileSystem.readDirectory(dir))
			{
				if (!file.endsWith(".json") || file == "events.json")
					continue;
				var diff:String = OnlineChartUtil.diffNameFromFile(songPath, file);
				if (diff != null && diff.length > 0 && !out.contains(diff))
					out.push(diff);
			}
		}
		catch (e:Dynamic) {}
		#end
	}

	// ── 选择 / 难度 (Freeplay 同款交互) ──────────────────

	function changeSelection(change:Int = 0, playSound:Bool = true)
	{
		if (playSound)
			FlxG.sound.play(Paths.sound('scrollMenu'), 0.4);

		selectedSong += change;
		if (selectedSong < 0)
			selectedSong = songs.length - 1;
		if (selectedSong >= songs.length)
			selectedSong = 0;

		var newColor:Int = songColors[selectedSong];
		if (newColor != intendedColor)
		{
			if (colorTween != null)
				colorTween.cancel();
			intendedColor = newColor;
			colorTween = FlxTween.color(bg, 1, bg.color, intendedColor, {
				onComplete: function(twn:FlxTween) colorTween = null
			});
		}

		missingText.visible = false;
		missingTextBG.visible = false;
		isShowingError = false;

		refreshDiffsForCurrentSong(true);

		for (i in 0...grpSongs.length)
		{
			var item:Alphabet = grpSongs.members[i];
			var icon:HealthIcon = iconArray[i];
			FlxTween.cancelTweensOf(item.scale);
			FlxTween.cancelTweensOf(icon.scale);
			var s:Float = (i == selectedSong) ? 1.2 : 0.85;
			FlxTween.tween(item.scale, {x: s, y: s}, 0.25, {ease: (i == selectedSong) ? FlxEase.backOut : FlxEase.quadOut});
			FlxTween.tween(icon.scale, {x: s, y: s}, 0.25, {ease: (i == selectedSong) ? FlxEase.backOut : FlxEase.quadOut});
		}

		for (i in 0...iconArray.length)
		{
			var isSel:Bool = (i == selectedSong);
			iconArray[i].alpha = isSel ? 1 : 0.6;
			if (iconArray[i].frameCount == 3 && iconArray[i].animation.curAnim != null)
				iconArray[i].animation.curAnim.curFrame = isSel ? 2 : 0;
		}

		var bullShit:Int = 0;
		for (item in grpSongs.members)
		{
			item.targetY = bullShit - selectedSong;
			item.alpha = (item.targetY == 0) ? 1 : 0.6;
			bullShit++;
		}

		updateScoreTargets();
		changeDiff(0, false);
	}

	function changeDiff(change:Int = 0, playSound:Bool = true)
	{
		selectedDiff += change;
		if (selectedDiff < 0)
			selectedDiff = diffs.length - 1;
		if (selectedDiff >= diffs.length)
			selectedDiff = 0;
		if (playSound)
			FlxG.sound.play(Paths.sound('scrollMenu'), 0.4);

		var diffName:String = diffs[selectedDiff];
		diffText.text = (diffs.length <= 1) ? (diffName + ' ') : ('< ' + diffName + ' >');
		positionHighscore();
		updateScoreTargets();
		missingText.visible = false;
		missingTextBG.visible = false;
		isShowingError = false;
	}

	function updateScoreTargets():Void
	{
		#if !switch
		var oldDiffs:Array<String> = CoolUtil.difficulties;
		CoolUtil.difficulties = diffs;
		intendedScore = Highscore.getScore(songs[selectedSong], selectedDiff);
		intendedRating = Highscore.getRating(songs[selectedSong], selectedDiff);
		CoolUtil.difficulties = oldDiffs;
		#end
	}

	function positionHighscore():Void
	{
		scoreText.x = FlxG.width - scoreText.width - 6;
		scoreBG.scale.x = FlxG.width - scoreText.x + 6;
		scoreBG.x = FlxG.width - (scoreBG.scale.x / 2);
		diffText.x = Std.int(scoreBG.x + (scoreBG.width / 2));
		diffText.x -= diffText.width / 2;
	}

	// ── 更新 ─────────────────────────────────────────────

	override function update(elapsed:Float)
	{
		super.update(elapsed);

		lerpScore = Math.floor(FlxMath.lerp(lerpScore, intendedScore, CoolUtil.boundTo(elapsed * 24, 0, 1)));
		lerpRating = FlxMath.lerp(lerpRating, intendedRating, CoolUtil.boundTo(elapsed * 12, 0, 1));
		if (Math.abs(lerpScore - intendedScore) <= 10)
			lerpScore = intendedScore;
		if (Math.abs(lerpRating - intendedRating) <= 0.01)
			lerpRating = intendedRating;
		var ratingSplit:Array<String> = Std.string(Highscore.floorDecimal(lerpRating * 100, 2)).split('.');
		if (ratingSplit.length < 2)
			ratingSplit.push('');
		while (ratingSplit[1].length < 2)
			ratingSplit[1] += '0';
		scoreText.text = Language.get("FreeplayState.scoreText", "PERSONAL BEST:") + lerpScore + ' (' + ratingSplit.join('.') + '%)';
		positionHighscore();

		// 鼠标悬停/点击 (Freeplay 同款, 防止穿透到大厅)。
		// 命中区垂直补到 40px (Alphabet 行高通常 <40, 触屏容易误触/点不中)。
		var hitPadV:Float = Math.max(0, (OnlineLayout.TOUCH_MIN_H - 20) / 2);
		var hitPadH:Float = 14;
		var songHit:Array<{x:Float, y:Float, w:Float, h:Float}> = [];
		var newMouseOverlapIndex:Int = -1;
		for (i in 0...grpSongs.length)
		{
			var song:Alphabet = grpSongs.members[i];
			if (song == null || !song.visible)
				continue;
			var sw:Float = Math.max(song.width, iconArray[i] != null ? iconArray[i].width : 0);
			var sh:Float = Math.max(song.height, 20) + hitPadV * 2;
			var sx:Float = Math.min(song.x, iconArray[i] != null ? iconArray[i].x : song.x) - hitPadH;
			var sy:Float = song.y - hitPadV;
			songHit.push({x: sx, y: sy, w: sw + hitPadH * 2, h: sh});
			if (FlxG.mouse.overlaps(song) || FlxG.mouse.overlaps(iconArray[i]))
			{
				newMouseOverlapIndex = i;
				break;
			}
		}
		mouseOverlapIndex = newMouseOverlapIndex;

		var touchHandled:Bool = false;
		#if (android || mobile)
		// 移动端触屏选歌: 点列表项选中, 再点一次确认 (与鼠标行为一致);
		// 该列表保留原 Freeplay Alphabet 样式, 只把命中区扩到 ≥40px (向上文 songHit 矩形)。
		for (touch in FlxG.touches.list)
		{
			if (touch == null || !touch.justPressed)
				continue;
			var hit:Int = -1;
			for (i in 0...songHit.length)
			{
				var b = songHit[i];
				if (touch.x >= b.x && touch.x <= b.x + b.w && touch.y >= b.y && touch.y <= b.y + b.h)
				{
					hit = i;
					break;
				}
			}
			if (hit < 0)
			{
				// 点右上难度文字 = 循环难度, 保证没有键盘的安卓也能切难度。
				if (diffText != null
					&& touch.x >= diffText.x && touch.x <= diffText.x + diffText.width
					&& touch.y >= diffText.y && touch.y <= diffText.y + diffText.height)
					changeDiff(1);
				continue;
			}
			if (hit != selectedSong)
			{
				selectedSong = hit;
				changeSelection(0, true);
				changeDiff(0, true);
			}
			else
				confirmSong();
			touchHandled = true;
		}
		#end

		if (!touchHandled && FlxG.mouse.justPressed && mouseOverlapIndex >= 0 && mouseOverlapIndex != selectedSong)
		{
			selectedSong = mouseOverlapIndex;
			changeSelection(0, true);
			changeDiff(0, true);
		}
		else if (!touchHandled && FlxG.mouse.justPressed && mouseOverlapIndex == selectedSong)
		{
			confirmSong();
		}

		if (!isShowingError)
		{
			var shiftMult:Int = 1;
			if (FlxG.keys.pressed.SHIFT)
				shiftMult = 3;

			var upP:Bool = controls.UI_UP_P;
			var downP:Bool = controls.UI_DOWN_P;
			if (songs.length > 1)
			{
				if (upP)
					changeSelection(-shiftMult);
				if (downP)
					changeSelection(shiftMult);

				if (controls.UI_DOWN || controls.UI_UP)
				{
					var checkLastHold:Int = Math.floor((holdTime - 0.5) * 10);
					holdTime += elapsed;
					var checkNewHold:Int = Math.floor((holdTime - 0.5) * 10);
					if (holdTime > 0.5 && checkNewHold - checkLastHold > 0)
						changeSelection((checkNewHold - checkLastHold) * (controls.UI_UP ? -shiftMult : shiftMult));
				}
				else
					holdTime = 0;

				if (FlxG.mouse.wheel != 0)
				{
					FlxG.sound.play(Paths.sound('scrollMenu'), 0.2);
					changeSelection(-shiftMult * FlxG.mouse.wheel, false);
				}
			}

			if (controls.UI_LEFT_P)
				changeDiff(-1);
			else if (controls.UI_RIGHT_P)
				changeDiff(1);
		}

		if (FlxG.keys.justPressed.I)
			pickChartFile();

		if (controls.ACCEPT)
			confirmSong();

		if (controls.BACK #if android || FlxG.android.justReleased.BACK #end)
		{
			FlxG.sound.play(Paths.sound('cancelMenu'));
			if (colorTween != null)
				colorTween.cancel();
			close();
		}
	}

	// ── 确认选歌 ─────────────────────────────────────────

	function confirmSong():Void
	{
		if (isShowingError)
		{
			missingText.visible = false;
			missingTextBG.visible = false;
			isShowingError = false;
			return;
		}
		if (readOnly)
		{
			showError(UIStyle.t('songSelectHostOnly', '仅房主可以选择歌曲。'));
			return;
		}
		if (client == null || client.socket == null || client.state != online.client.GameClient.ClientState.Ready)
		{
			showError(UIStyle.t('songSelectDisconnected', '连接已断开，请返回大厅重新连接'));
			return;
		}

		var songName:String = songs[selectedSong];
		// 越界防护: 换歌后难度列表可能变短, 老索引绝不能把 null 难度提交进房间
		// (否则其它端按 null 难度找谱 -> 全房加载失败)。
		if (selectedDiff < 0 || selectedDiff >= diffs.length)
		{
			refreshDiffsForCurrentSong(true);
			changeDiff(0, false);
		}
		var diff:String = diffs.length > 0 ? diffs[selectedDiff] : null;
		if (songName == null || songName.length == 0 || diff == null || diff.length == 0)
		{
			showError(UIStyle.t('songSelectDiffMissing', '未找到可用的谱面难度，请换歌或换难度后再试'));
			return;
		}
		var modFolder:String = (selectedSong >= 0 && selectedSong < songFolders.length) ? songFolders[selectedSong] : "";
		try
		{
			// 与原版 FreeplayState 完全相同的加载方式: songLowercase + Highscore.formatSong。
			var song:SwagSong = OnlineChartUtil.loadChart(songName, diff, modFolder);
			if (song == null)
				throw "Song data is null";
			var hash:String = SeiunHash.ofString(haxe.Json.stringify(song));
			// Malody/osu! 转谱判定: 只看磁盘原始文件的 format 字段 (导入器写入的 psych_v1_convert)。
			// 绝不能用加载归一化后的 song.format —— 那会把原版谱也盖上 psych_v1_convert,
			// 导致"原版谱被误判成转谱、房间被强制异步、暂停策略失效"连锁问题。
			var converted:Bool = OnlineChartUtil.isConvertedChart(songName, diff, modFolder);
			var source:String = converted
				? online.shared.OnlineTypes.OnlineConst.CHART_SOURCE_CONVERTED
				: online.shared.OnlineTypes.OnlineConst.CHART_SOURCE_SONG;
			OnlineSession.setChart({
				songName: songName,
				difficulty: diff,
				chartHash: hash,
				chartSource: source,
				modFolder: modFolder
			});
			// 本地先同步模式, 大厅按钮/文本不用等服务器 ROOM_INFO 往返。
			if (converted && OnlineSession.mode != online.shared.OnlineTypes.OnlineConst.MODE_ASYNC)
			{
				OnlineSession.mode = online.shared.OnlineTypes.OnlineConst.MODE_ASYNC;
				if (OnlineSession.settings != null)
					OnlineSession.settings.mode = online.shared.OnlineTypes.OnlineConst.MODE_ASYNC;
			}
			client.send(SeiunProtocol.MSG_ROOM_SONG_SELECT, SeiunProtocol.CHANNEL_ROOM, {
				songName: songName,
				difficulty: diff,
				chartHash: hash,
				chartSource: source,
				modFolder: modFolder
			});
			FlxG.sound.play(Paths.sound('confirmMenu'), 0.8);
			if (colorTween != null)
				colorTween.cancel();
			close();
		}
		catch (e:Dynamic)
		{
			var err:String = Std.string(e);
			if (err.indexOf('[file_contents,assets/data/') == 0)
				err = 'Missing file: ' + err.substring(34, err.length - 1);
			showError(UIStyle.t('songSelectLoadError', 'ERROR WHILE LOADING CHART:') + "\n" + err);
		}
	}

	function showError(text:String):Void
	{
		missingText.text = text;
		missingText.screenCenter(Y);
		missingText.visible = true;
		missingTextBG.visible = true;
		isShowingError = true;
		FlxG.sound.play(Paths.sound('cancelMenu'));
	}

	// ── 直接导入 Malody/osu! (就地转谱) ──────────────────

	function pickChartFile():Void
	{
		fileDialog.open(null,
			Language.get('online.importChartTitle', '选择 Malody / osu! 谱面 (.mc/.mcz/.osu/.osz)'),
			[new FileFilter('Charts', '*.mc;*.mcz;*.osu;*.osz'), new FileFilter('All Files', '*.*')],
			function()
			{
				var path:String = fileDialog.path.split('\\').join('/');
				if (path == null || path.length == 0)
					return;
				importChart(path);
			});
	}

	function importChart(srcPath:String):Void
	{
		#if sys
		try
		{
			var isPackage:Bool = OsuMalodyConvert.isPackageFile(srcPath);
			var entries:Array<Dynamic> = null;
			var chartList:Array<Dynamic> = [];
			if (isPackage)
			{
				entries = OsuMalodyConvert.readPackageEntries(srcPath);
				chartList = OsuMalodyConvert.packageChartList(entries);
			}
			else
			{
				var content:String = File.getContent(srcPath);
				var lower:String = srcPath.toLowerCase();
				var format:Int = -1;
				if (lower.endsWith(".osu"))
					format = 0;
				else if (lower.endsWith(".mc"))
					format = 1;
				if (format < 0)
				{
					showError(UIStyle.t('importBadType', '不支持的文件类型，请选择 .osu/.osz/.mc/.mcz'));
					return;
				}
				chartList.push({
					format: format,
					content: content,
					audioName: OsuMalodyConvert.chartAudioName(content, format),
					title: OsuMalodyConvert.chartTitle(content, format),
					version: OsuMalodyConvert.chartDifficultyName(content, format)
				});
			}
			if (chartList.length < 1)
			{
				showError(UIStyle.t('importNoCharts', '未找到任何谱面'));
				return;
			}
			var firstFolder:String = "";
			var firstDiff:String = "";
			for (chart in chartList)
			{
				if (chart == null)
					continue;
				var song:SwagSong = (chart.format == 0)
					? OsuMalodyConvert.osuToPsych(chart.content, 0)
					: OsuMalodyConvert.malodyToPsych(chart.content, 0);
				song.format = 'psych_v1_convert';
				var title:String = sanitizeName(chart.title != null && chart.title.length > 0 ? chart.title : (song.song != null ? song.song : 'chart'));
				var version:String = sanitizeName(chart.version != null && chart.version.length > 0 ? chart.version : (song.difficultyName != null ? song.difficultyName : 'FNF'));
				var folder:String = Paths.formatToSongPath(title);
				if (firstFolder.length == 0)
				{
					firstFolder = folder;
					firstDiff = version;
				}
				ensureDirs("mods/data/" + folder);
				ensureDirs("mods/songs/" + folder);
				song.song = title;
				song.difficultyName = version;
				// 与原版一致的布局: mods/data/<songPath>/<songPath>-<diff>.json (默认难度 = <songPath>.json)。
				var diffPath:String = Paths.formatToSongPath(version);
				var fileBase:String = OnlineChartUtil.diffFileBase(folder, diffPath);
				File.saveContent("mods/data/" + folder + "/" + fileBase + ".json", haxe.Json.stringify(song));

				var audioName:String = chart.audioName;
				if (audioName != null && audioName.length > 0)
				{
					if (isPackage)
					{
						var found:Dynamic = OsuMalodyConvert.findPackageAudio(entries, audioName);
						if (found != null && found.data != null)
						{
							var ext:String = StringTools.trim(found.name.substr(found.name.lastIndexOf('.') + 1)).toLowerCase();
							if (ext == "ogg" || ext == "mp3" || ext == "wav" || ext == "m4a")
								File.saveBytes("mods/songs/" + folder + "/Inst." + ext, found.data);
						}
					}
					else
					{
						var adj:String = OsuMalodyConvert.findAdjacentAudio(srcPath, audioName);
						if (adj != null)
						{
							var ext:String = StringTools.trim(adj.substr(adj.lastIndexOf('.') + 1)).toLowerCase();
							if (ext == "ogg" || ext == "mp3" || ext == "wav" || ext == "m4a")
								File.copy(adj, "mods/songs/" + folder + "/Inst." + ext);
						}
					}
				}
			}
			if (!songs.contains(firstFolder))
			{
				songs.push(firstFolder);
				songColors.push(0xFF9271FD);
				songChars.push('bf');
				songSources.push('转换');
				songFolders.push("");
			}
			selectedSong = songs.indexOf(firstFolder);
			UIStyle.clearAndDestroy(grpSongs);
			for (icon in iconArray)
				icon.destroy();
			iconArray = [];
			rebuildSongItems();
			refreshDiffsForCurrentSong(true);
			if (diffs.contains(firstDiff))
				selectedDiff = diffs.indexOf(firstDiff);
			changeSelection(0, false);
			changeDiff(0, false);
			FlxG.sound.play(Paths.sound('confirmMenu'), 0.7);
		}
		catch (e:Dynamic)
		{
			showError(UIStyle.t('importFailed', '导入失败: ') + Std.string(e));
		}
		#else
		showError(UIStyle.t('importUnsupported', '当前平台不支持导入'));
		#end
	}

	static function sanitizeName(name:String):String
	{
		var out:String = name;
		for (c in ['\\', '/', ':', '*', '?', '"', '<', '>', '|', '\n', '\r'])
			out = out.split(c).join('');
		out = StringTools.trim(out);
		return (out.length > 0) ? out : 'chart';
	}

	function ensureDirs(path:String):Void
	{
		#if sys
		if (path == null || path.length == 0 || sys.FileSystem.exists(path))
			return;
		var parent:String = haxe.io.Path.directory(path);
		if (parent != null && parent.length > 0 && parent != path)
			ensureDirs(parent);
		try { sys.FileSystem.createDirectory(path); } catch (e:Dynamic) {}
		#end
	}

	override function destroy():Void
	{
		pendingPickSong = null;
		pendingPickDiff = null;
		if (colorTween != null)
			colorTween.cancel();
		super.destroy();
	}
}
