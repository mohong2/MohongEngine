package online.shared;

import haxe.io.Bytes;

/**
	SeiunEngine 联机协议常量。
	纯 Haxe，无 Flixel/OpenFL 依赖，客户端与无头服务器共享同一份定义。

	隔离设计:
	- 首 8 字节必须是 "SEIUNP01" 魔数, 普通 HTTP/WebSocket/Colyseus 握手不可能产生该前缀;
	- 版本不匹配时双方都必须回 ERROR 并断开, 禁止静默挂起。
**/
class SeiunProtocol
{
	/** 协议魔数, 8 字节。 */
	public static var MAGIC(default, never):String = "SEIUNP01";

	/** 当前协议版本, 主版本变更后不兼容旧实现。 */
	public static inline var PROTOCOL_VERSION:Int = 2;

	/** 引擎指纹, 握手时双端校验。 */
	public static inline var ENGINE_FINGERPRINT:String = "SeiunEngine/0.3.0";

	/** 默认 TCP 端口。 */
	public static inline var DEFAULT_PORT:Int = 2567;

	/** 本地管理面板默认 HTTP 端口。 */
	public static inline var ADMIN_PORT:Int = 2568;

	/** 连接建立后发送 HELLO 的超时时间 (秒)。 */
	public static inline var HELLO_TIMEOUT_SECONDS:Float = 3.0;

	/** 空闲心跳间隔 (秒)。 */
	public static inline var IDLE_HEARTBEAT_SECONDS:Float = 5.0;

	/** 对局中额外心跳间隔 (秒)。 */
	public static inline var GAME_HEARTBEAT_SECONDS:Float = 1.0;

	/** 对局中断线席位保留窗口 (秒)。 */
	public static inline var RECONNECT_WINDOW_SECONDS:Float = 45.0;

	/** 单帧最大控制/房间消息 payload (字节)。 */
	public static inline var MAX_MESSAGE_BYTES:Int = 64 * 1024;

	/** 异步成绩 (含回放 JSON) 单帧上限。 */
	public static inline var MAX_SCORE_BYTES:Int = 4 * 1024 * 1024;

	/** 模组/谱面同步单块大小。 */
	public static inline var FILE_CHUNK_BYTES:Int = 256 * 1024;

	/** 单个同步文件大小上限。 */
	public static inline var MAX_FILE_BYTES:Int = 64 * 1024 * 1024;

	/** 每 5 秒允许的最多消息数 (协议层限流)。 */
	public static inline var RATE_LIMIT_WINDOW_SECONDS:Float = 5.0;

	/** 每个限流窗口允许的消息数。 */
	public static inline var RATE_LIMIT_MESSAGES:Int = 600;

	/** FILE 通道每窗口允许的消息数 (模组同步分块, 放宽且不因超限断连)。 */
	public static inline var RATE_LIMIT_FILE_MESSAGES:Int = 4096;

	/** 判定前允许的服务器/客户端时间偏移 (毫秒)。 */
	public static inline var MAX_CLOCK_OFFSET_MS:Float = 1500.0;

	/** 客户端允许的绝对时钟偏差上限 (毫秒): 局域网机器时钟未同步是常态, 只有离谱偏差才拒绝连接。 */
	public static inline var MAX_CLOCK_SKEW_MS:Float = 60000.0;

	/** 单次对时采样允许的时间跳变 (毫秒)。 */
	public static inline var MAX_CLOCK_JUMP_MS:Float = 300.0;

	// ── 通道 ──────────────────────────────────────────────
	public static inline var CHANNEL_CONTROL:Int = 0;
	public static inline var CHANNEL_ROOM:Int = 1;
	public static inline var CHANNEL_GAME:Int = 2;
	public static inline var CHANNEL_FILE:Int = 3;
	public static inline var CHANNEL_ASYNC:Int = 4;
	public static inline var CHANNEL_ADMIN:Int = 5;
	public static inline var CHANNEL_AUTH:Int = 6;

	// ── 控制消息 ──────────────────────────────────────────
	public static inline var MSG_HELLO:Int = 0x0001;
	public static inline var MSG_WELCOME:Int = 0x0002;
	public static inline var MSG_ERROR:Int = 0x0003;
	public static inline var MSG_PING:Int = 0x0004;
	public static inline var MSG_PONG:Int = 0x0005;
	public static inline var MSG_HEARTBEAT:Int = 0x0006;
	public static inline var MSG_BYE:Int = 0x0007;
	public static inline var MSG_CRASH_SIGNAL:Int = 0x0008;
	public static inline var MSG_DISCONNECT_NOTICE:Int = 0x0009;

	// ── 账号/身份 ─────────────────────────────────────────
	public static inline var MSG_AUTH_REGISTER:Int = 0x0101;
	public static inline var MSG_AUTH_LOGIN:Int = 0x0102;
	public static inline var MSG_AUTH_RESULT:Int = 0x0103;
	public static inline var MSG_PROFILE_UPDATE:Int = 0x0104;
	/** 客户端 → 服务器: 请求某个自定义头像文件 (fileName = mods/avatars 下的文件名)。 */
	public static inline var MSG_AVATAR_REQUEST:Int = 0x0105;

	// ── 房间消息 ──────────────────────────────────────────
	public static inline var MSG_ROOM_LIST:Int = 0x0201;
	public static inline var MSG_ROOM_LIST_RESULT:Int = 0x0202;
	public static inline var MSG_ROOM_CREATE:Int = 0x0203;
	public static inline var MSG_ROOM_JOIN:Int = 0x0204;
	public static inline var MSG_ROOM_JOIN_RESULT:Int = 0x0205;
	public static inline var MSG_ROOM_LEAVE:Int = 0x0206;
	public static inline var MSG_ROOM_INFO:Int = 0x0207;
	public static inline var MSG_ROOM_PLAYER_JOIN:Int = 0x0208;
	public static inline var MSG_ROOM_PLAYER_LEAVE:Int = 0x0209;
	public static inline var MSG_ROOM_READY:Int = 0x020A;
	public static inline var MSG_ROOM_SETTINGS:Int = 0x020B;
	public static inline var MSG_ROOM_CHAT:Int = 0x020C;
	public static inline var MSG_ROOM_ANNOUNCE:Int = 0x020D;
	public static inline var MSG_ROOM_SONG_SELECT:Int = 0x020E;
	public static inline var MSG_ROOM_FORCE_START:Int = 0x020F;
	public static inline var MSG_ROOM_KICK:Int = 0x0210;
	/** 客户端 → 服务器: 请求更换自己的对局皮肤 (payload: skinData)。 */
	public static inline var MSG_ROOM_SET_SKIN:Int = 0x0211;
	/** 服务器 → 房间广播: 某玩家皮肤已更新 (payload: id + skinData)。 */
	public static inline var MSG_ROOM_PLAYER_SKIN:Int = 0x0212;

	// ── 模组/谱面同步 ─────────────────────────────────────
	public static inline var MSG_MOD_MANIFEST:Int = 0x0301;
	public static inline var MSG_MOD_MANIFEST_RESULT:Int = 0x0302;
	public static inline var MSG_MOD_FILE_REQUEST:Int = 0x0303;
	public static inline var MSG_MOD_FILE_CHUNK:Int = 0x0304;
	public static inline var MSG_MOD_FILE_ACK:Int = 0x0305;
	public static inline var MSG_CHART_BUNDLE_ANNOUNCE:Int = 0x0306;

	// ── 实时对局 ──────────────────────────────────────────
	public static inline var MSG_GAME_START:Int = 0x0401;
	public static inline var MSG_GAME_COUNTDOWN:Int = 0x0402;
	public static inline var MSG_GAME_INPUT:Int = 0x0403;
	public static inline var MSG_GAME_JUDGE:Int = 0x0404;
	public static inline var MSG_GAME_HEALTH:Int = 0x0405;
	public static inline var MSG_GAME_PAUSE:Int = 0x0406;
	public static inline var MSG_GAME_RESUME:Int = 0x0407;
	public static inline var MSG_GAME_END:Int = 0x0408;
	public static inline var MSG_GAME_RESULT:Int = 0x0409;
	public static inline var MSG_GAME_RECONNECT:Int = 0x040A;
	public static inline var MSG_GAME_RECONNECT_RESULT:Int = 0x040B;
	/**
		实时对局统一起跑信号。所有真人玩家都上传完谱面时间轴后,
		服务器广播一个服务器时间锚点; 客户端据此把 `startOnTime` 算到
		同一个服务器时刻, 而不是各自按收到 GAME_START 的本地时间起跑。
		(PsychOnline 的 startSong / playerReady 等价物)
	**/
	public static inline var MSG_GAME_SYNC:Int = 0x040C;
	/**
		客户端 → 服务器: 起跑确认 (保留兼容)。服务器当前改为“全员上传完谱面时间轴即自动广播
		MSG_GAME_SYNC”，此消息仅作旧客户端/手动确认兼容, 不影响自动开始。
	**/
	public static inline var MSG_GAME_START_ACK:Int = 0x040D;

	// ── 异步排名模式 ──────────────────────────────────────
	public static inline var MSG_ASYNC_START:Int = 0x0501;
	public static inline var MSG_ASYNC_STATUS:Int = 0x0502;
	public static inline var MSG_ASYNC_SUBMIT:Int = 0x0503;
	public static inline var MSG_ASYNC_RANKING:Int = 0x0504;
	public static inline var MSG_ASYNC_FINALIZE:Int = 0x0505;
	public static inline var MSG_ASYNC_REPLAY_VERIFY:Int = 0x0506;
	/** 客户端请求查看某位玩家的异步回放 (deviceId)。 */
	public static inline var MSG_ASYNC_REPLAY_FETCH:Int = 0x0507;
	/** 服务器返回异步回放 (deviceId/nickname/replayJson)。 */
	public static inline var MSG_ASYNC_REPLAY:Int = 0x0508;
	/** 实时模式结束后客户端上传本局回放 (replayJson, 供他人查看)。 */
	public static inline var MSG_ASYNC_REPLAY_UPLOAD:Int = 0x0509;

	// ── 管理 (仅服主/房主可用) ─────────────────────────────
	public static inline var MSG_ADMIN_COMMAND:Int = 0x0601;
	public static inline var MSG_ADMIN_RESULT:Int = 0x0602;

	// ── 标志位 ────────────────────────────────────────────
	public static inline var FLAG_NONE:Int = 0;
	public static inline var FLAG_ACK_REQUIRED:Int = 1;
	public static inline var FLAG_RAW_BYTES:Int = 2;

	// ── 错误码 ────────────────────────────────────────────
	public static inline var ERR_BAD_MAGIC:Int = 0x1001;
	public static inline var ERR_PROTOCOL_VERSION:Int = 0x1002;
	public static inline var ERR_BAD_FINGERPRINT:Int = 0x1003;
	public static inline var ERR_AUTH_REQUIRED:Int = 0x1004;
	public static inline var ERR_AUTH_FAILED:Int = 0x1005;
	public static inline var ERR_ROOM_NOT_FOUND:Int = 0x1006;
	public static inline var ERR_ROOM_FULL:Int = 0x1007;
	public static inline var ERR_ROOM_PASSWORD:Int = 0x1008;
	public static inline var ERR_CHART_MISMATCH:Int = 0x1009;
	public static inline var ERR_ANTICHEAT_VIOLATION:Int = 0x100A;
	public static inline var ERR_CLOCK_JUMP:Int = 0x100B;
	public static inline var ERR_RATE_LIMIT:Int = 0x100C;
	public static inline var ERR_BAD_PACKET:Int = 0x100D;
	public static inline var ERR_BANNED:Int = 0x100E;
	public static inline var ERR_NOT_AUTHORIZED:Int = 0x100F;
	public static inline var ERR_SERVER_SHUTTING_DOWN:Int = 0x1010;

	// ── 账号细分错误码 (0x1011+) ─────────────────────────
	/** 注册时用户名已存在。 */
	public static inline var ERR_USER_EXISTS:Int = 0x1011;
	/** 登录时用户名不存在。 */
	public static inline var ERR_USER_NOT_FOUND:Int = 0x1012;
	/** 登录时密码错误。 */
	public static inline var ERR_BAD_PASSWORD:Int = 0x1013;
	/** 登录失败次数过多, 账号临时锁定。 */
	public static inline var ERR_ACCOUNT_LOCKED:Int = 0x1014;
	/** 单 IP 注册账号数超限。 */
	public static inline var ERR_TOO_MANY_ACCOUNTS:Int = 0x1015;
	/** 注册太频繁 (IP 冷却)。 */
	public static inline var ERR_REGISTER_COOLDOWN:Int = 0x1016;
	/** 严格模式下账号已绑定其他设备。 */
	public static inline var ERR_DEVICE_BOUND:Int = 0x1017;

	/** 把协议魔数写入 Bytes 偏移 0..8。 */
	public static function writeMagic(out:haxe.io.BytesBuffer):Void
	{
		var b:Bytes = Bytes.ofString(MAGIC);
		out.add(b);
	}

	/** 校验 Bytes 前 8 字节是否为 Seiun 魔数。 */
	public static function hasMagic(b:Bytes, pos:Int = 0):Bool
	{
		if (b.length - pos < 8)
			return false;
		for (i in 0...8)
			if (b.get(pos + i) != MAGIC.charCodeAt(i))
				return false;
		return true;
	}
}
