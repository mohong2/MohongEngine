package online.shared;

import haxe.crypto.Crc32;
import haxe.io.Bytes;
import haxe.io.BytesBuffer;
import haxe.io.BytesInput;
import haxe.io.BytesOutput;
import haxe.io.Error;
import haxe.io.Input;

/**
	Seiun TCP 帧编解码。帧头固定 28 字节、大端序。
	纯 Haxe, 客户端与无头服务器共用。
**/
typedef InboundPacket =
{
	var version:Int;
	var type:Int;
	var channel:Int;
	var flags:Int;
	var sequence:Int;
	var crc:Int;
	var payload:Bytes;
}

class SeiunPacket
{
	public static inline var HEADER_SIZE:Int = 28;

	/** 编码 JSON 消息。 */
	public static function encodeJson(type:Int, channel:Int, sequence:Int, obj:Dynamic, flags:Int = 0):Bytes
	{
		var text:String = haxe.Json.stringify(obj);
		return encodeString(type, channel, sequence, text, flags);
	}

	public static function encodeString(type:Int, channel:Int, sequence:Int, text:String, flags:Int = 0):Bytes
	{
		if (text == null)
			text = "";
		return encodeBytes(type, channel, sequence, Bytes.ofString(text), flags);
	}

	public static function encodeBytes(type:Int, channel:Int, sequence:Int, payload:Bytes, flags:Int = 0):Bytes
	{
		if (payload == null)
			payload = Bytes.alloc(0);

		var crc:Int = 0;
		if (payload.length > 0)
			crc = Crc32.make(payload);

		var out:BytesOutput = new BytesOutput();
		out.bigEndian = true;
		var magic:Bytes = Bytes.ofString(SeiunProtocol.MAGIC);
		out.writeBytes(magic, 0, 8);
		out.writeUInt16(SeiunProtocol.PROTOCOL_VERSION);
		out.writeUInt16(type);
		out.writeUInt16(channel);
		out.writeUInt16(flags);
		out.writeInt32(payload.length);
		out.writeInt32(sequence);
		out.writeInt32(crc);
		if (payload.length > 0)
			out.writeBytes(payload, 0, payload.length);
		var result:Bytes = out.getBytes();
		out.close();
		return result;
	}

	/** 解码单帧 payload 为 Dynamic。 */
	public static function payloadJson(packet:InboundPacket):Dynamic
	{
		if (packet == null || packet.payload == null || packet.payload.length == 0)
			return null;
		return haxe.Json.parse(packet.payload.toString());
	}

	public static function checkCrc(packet:InboundPacket):Bool
	{
		if (packet.crc == 0 || packet.payload.length == 0)
			return true;
		return Crc32.make(packet.payload) == packet.crc;
	}
}

/**
	把 TCP 字节流切成一帧一帧。
	每个连接持有一个实例, 不要跨连接复用。
**/
class PacketFramer
{
	var buffer:BytesBuffer;

	public function new()
	{
		buffer = new BytesBuffer();
	}

	/** 喂入新读取的字节, 返回所有完整帧。 */
	public function push(chunk:Bytes, pos:Int, len:Int):Array<InboundPacket>
	{
		var out:Array<InboundPacket> = [];
		if (chunk == null || len <= 0)
			return out;

		buffer.addBytes(chunk, pos, len);
		var data:Bytes = buffer.getBytes();
		buffer = new BytesBuffer();
		var offset:Int = 0;
		var total:Int = data.length;

		while (total - offset >= SeiunPacket.HEADER_SIZE)
		{
			if (!SeiunProtocol.hasMagic(data, offset))
			{
				// 前 8 字节不是魔数: 这是 HTTP/WebSocket/其它客户端。
				// 保留一个特殊坏包让上层发 ERR_BAD_MAGIC 并断开。
				out.push({
					version: 0,
					type: -1,
					channel: SeiunProtocol.CHANNEL_CONTROL,
					flags: 0,
					sequence: 0,
					crc: 0,
					payload: Bytes.ofString("bad-magic")
				});
				return out;
			}

			var input:BytesInput = new BytesInput(data, offset, total - offset);
			input.bigEndian = true;
			// 魔数已单独校验, 这里要跳过 8 字节魔数再读帧头。
			input.read(8);
			var version:Int = input.readUInt16();
			var type:Int = input.readUInt16();
			var channel:Int = input.readUInt16();
			var flags:Int = input.readUInt16();
			var payloadLen:Int = input.readInt32();
			var sequence:Int = input.readInt32();
			var crc:Int = input.readInt32();
			input.close();

			if (payloadLen < 0 || payloadLen > SeiunProtocol.MAX_FILE_BYTES + SeiunPacket.HEADER_SIZE)
			{
				out.push({
					version: version,
					type: -2,
					channel: channel,
					flags: flags,
					sequence: sequence,
					crc: crc,
					payload: Bytes.alloc(0)
				});
				return out;
			}

			if (total - offset < SeiunPacket.HEADER_SIZE + payloadLen)
				break;

			var payload:Bytes = data.sub(offset + SeiunPacket.HEADER_SIZE, payloadLen);
			out.push({
				version: version,
				type: type,
				channel: channel,
				flags: flags,
				sequence: sequence,
				crc: crc,
				payload: payload
			});
			offset += SeiunPacket.HEADER_SIZE + payloadLen;
		}

		if (offset < total)
			buffer.addBytes(data, offset, total - offset);

		return out;
	}

	/** 连接初始化前读取到的前 8 字节是否为魔数。 */
	public function pendingLooksLikeSeiun():Bool
	{
		// 仅供调试日志使用, 实际判定以 push 的 bad-magic 帧为准。
		return true;
	}
}
