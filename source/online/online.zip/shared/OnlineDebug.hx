package online.shared;

#if sys
import sys.FileSystem;
import sys.io.File;
#end

/**
	联机诊断日志 (纯 Haxe, 无 flixel 依赖):
	写入 <CWD>/online_debug.log, 供真机/无头定位"连接已断开"等运行期问题。
	失败静默, 不影响游戏。
**/
class OnlineDebug
{
	public static function log(tag:String, msg:String):Void
	{
		#if sys
		try
		{
			var path:String = Sys.getCwd() + "/online_debug.log";
			var old:String = FileSystem.exists(path) ? File.getContent(path) : "";
			if (old.length > 256 * 1024)
				old = old.substr(old.length - 128 * 1024);
			File.saveContent(path, old + "[" + Date.now().toString() + "] " + tag + ": " + msg + "\n");
		}
		catch (e:Dynamic) {}
		#end
	}
}
