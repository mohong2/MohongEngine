package online.shared;

#if sys
import sys.FileSystem;
import sys.io.File;
#end

/**
	纯 Haxe 轻量 i18n (无 flixel/Language 依赖):
	供 GameClient / LanDiscovery / ModSyncClient 等"无头可编译"的类使用,
	避免把 ClientPrefs/flixel 拖进 server_build 无头测试。
	UI 层仍走 online.ui.UIStyle.t() (Language.get), 两者键完全一致 (online.*)。
	语言由 UI 层在启动联机界面时 setLocale 注入 (默认 English)。
**/
class OnlineStrings
{
	static var strings:Map<String, String> = null;
	static var locale:String = "";

	/** 由 UI 层调用 (如 UIStyle.installInputEscapeGuard), 传入 ClientPrefs.data.language。 */
	public static function setLocale(lang:String):Void
	{
		if (lang == null || lang.length == 0)
			return;
		if (locale == lang && strings != null)
			return;
		locale = lang;
		load(lang);
	}

	public static function get(key:String, fallback:String):String
	{
		if (strings == null)
			load("English");
		if (strings != null && strings.exists(key))
			return strings.get(key);
		return fallback == null ? '' : fallback;
	}

	static function load(lang:String):Void
	{
		strings = new Map();
		#if sys
		var candidates:Array<String> = [
			"assets/lang/" + lang + "/Online.json",
			"assets/lang/English/Online.json"
		];
		for (path in candidates)
		{
			try
			{
				if (FileSystem.exists(path))
				{
					var json:Dynamic = haxe.Json.parse(File.getContent(path));
					for (f in Reflect.fields(json))
						strings.set(f, Reflect.field(json, f));
					return;
				}
			}
			catch (e:Dynamic) {}
		}
		#end
	}
}
