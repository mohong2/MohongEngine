package online.shared;

import StringTools;

/**
	联机数据结构。所有字段均可 JSON 序列化, 供客户端与服务器共享。
	无 Flixel/OpenFL 依赖。

	Haxe 多类型模块: 所有 typedef 与 OnlineConst 都挂在
	`online.shared.OnlineTypes` 之下, 例如 `OnlineTypes.PlayerIdentity`。
**/
class OnlineTypes
{
	public function new() {}
}

/**
	对局皮肤 (PsychOnline 式四元组的结构化版):
	- char: 角色 JSON 名 (如 "bf"、"pico"); 空 = 跟随谱面;
	- modDir: 角色所在模组目录 (空 = 根目录); 远端加载时切到此目录再取角色资源;
	- suffixLeft / suffixRight: 玩家在左/右两侧时的角色变体后缀
	  (如舞台 car 关的 "-car"), 与引擎 0.6.3 的 player2 重写规则配合;
	  空 = 无变体。
**/
typedef OnlineSkinData =
{
	var char:String;
	@:optional var modDir:String;
	@:optional var suffixLeft:String;
	@:optional var suffixRight:String;
}

/** 把任意动态对象安全转换成 OnlineSkinData; 非法/为空返回 null。 */
class SkinDataUtil
{
	public static function fromDynamic(raw:Dynamic):Null<OnlineSkinData>
	{
		if (raw == null)
			return null;
		var char:String = raw.char == null ? "" : Std.string(raw.char);
		var modDir:String = raw.modDir == null ? "" : Std.string(raw.modDir);
		var sl:String = raw.suffixLeft == null ? "" : Std.string(raw.suffixLeft);
		var sr:String = raw.suffixRight == null ? "" : Std.string(raw.suffixRight);
		if (char.length == 0)
			return null;
		return {char: char, modDir: modDir, suffixLeft: sl, suffixRight: sr};
	}
}

typedef PlayerIdentity =
{
	/** 本地生成的随机 UUID, 身份主键。 */
	var deviceId:String;
	var nickname:String;
	/** 内置头像编号或本地头像相对路径 ("file:xxx")。 */
	var avatar:String;
	/** 对局角色皮肤 (内置角色名, 如 bf/gf/dad/pico)。 */
	@:optional var skin:String;
	/** 结构化皮肤 (PsychOnline 式, 带 modDir/后缀); 与 skin 同时存在时以 skinData 为准。 */
	@:optional var skinData:OnlineSkinData;
	/** 专用服务器登录后写入, 局域网模式为空。 */
	@:optional var accountName:String;
	@:optional var sessionToken:String;
}

typedef PlayerPublicInfo =
{
	var id:String;
	var deviceId:String;
	var nickname:String;
	var avatar:String;
	var isHost:Bool;
	var isReady:Bool;
	@:optional var skin:String;
	/** 结构化皮肤 (PsychOnline 式)。 */
	@:optional var skinData:OnlineSkinData;
	@:optional var team:Int;
	@:optional var pingMs:Float;
	@:optional var accountName:String;
	@:optional var ip:String;
	@:optional var joinedAt:Float;
	/** 观战者: 不占游玩席位, 不参与准备/门闩/开始。 */
	@:optional var isSpectator:Bool;
}

typedef RoomSettings =
{
	var roomName:String;
	/** realtime / async */
	var mode:String;
	var maxPlayers:Int;
	var antiCheat:Bool;
	var password:String;
	var roomCode:String;
	/** Leather Engine / Psych Engine / Kade Engine / Friday Night Funkin' / Custom */
	var judgementPreset:String;
	var judgementTimings:Array<Int>;
	var marvelousRatings:Bool;
	/** 实时对局暂停策略: everyone / hostOnly / disabled (缺省 everyone)。 */
	@:optional var pausePolicy:String;
	var compatibilityMode:Bool;
	var allowDuplicateNames:Bool;
	var teamSize:Int;
	/** 房主指定的房间舞台 (空 = 跟随歌曲)。 */
	@:optional var stageName:String;
	/** 房间统一兼容模式 (backend.CompatEngine 取值: Auto/0.6.3/0.7.3/1.0.4, 空 = Auto)。 */
	@:optional var compatEngine:String;
	@:optional var requireMods:Array<String>;
}

typedef ChartSelection =
{
	var songName:String;
	var difficulty:String;
	var chartHash:String;
	var chartSource:String;
	/** song / converted。converted = 由 Malody/osu! 谱面转换而来, 服务器会强制异步排名。 */
	/** 转谱选歌时携带的源包名, 例如 "chart.mcz"。 */
	@:optional var convertedBundle:String;
	@:optional var songLengthMs:Float;
	/** 模组歌曲所在 mod 子目录 (mods/<modFolder>/data/...), 空串/缺省 = mods/data 根或内置。 */
	@:optional var modFolder:String;
}

typedef RoomPublicInfo =
{
	var roomCode:String;
	var roomName:String;
	var hostId:String;
	var hostNickname:String;
	var mode:String;
	var playerCount:Int;
	var maxPlayers:Int;
	var antiCheat:Bool;
	var hasPassword:Bool;
	var status:String;
	/** 观战者数量 (内置观战支持)。 */
	@:optional var spectatorCount:Int;
	@:optional var chart:ChartSelection;
	@:optional var settings:RoomSettings;
}

typedef JudgeResult =
{
	var deviceId:String;
	var strumTime:Float;
	var lane:Int;
	var rating:String;
	var hitDiff:Float;
	var isSustain:Bool;
	@:optional var score:Int;
	@:optional var health:Float;
	/** PsychOnline 式实时 HUD 需要跟随判定广播的实时统计。 */
	@:optional var misses:Int;
	@:optional var maxCombo:Int;
	@:optional var accuracy:Float;
	@:optional var ratingName:String;
	@:optional var ratingFC:String;
	@:optional var pingMs:Float;
}

typedef ScoreRecord =
{
	var deviceId:String;
	var nickname:String;
	var avatar:String;
	var score:Int;
	var accuracy:Float;
	var maxCombo:Int;
	var misses:Int;
	var marvelous:Int;
	var sick:Int;
	var good:Int;
	var bad:Int;
	var shit:Int;
	var completed:Bool;
	var finishedAt:Float;
	@:optional var nps:Float;
	@:optional var missTimes:Array<Float>;
	@:optional var wrongLaneHits:Array<Float>;
	@:optional var replayJson:String;
	@:optional var replayVerified:Null<Bool>;
}

typedef AsyncPlayerStatus =
{
	var deviceId:String;
	var nickname:String;
	var state:String;
	@:optional var score:ScoreRecord;
	@:optional var startedAt:Float;
	@:optional var updatedAt:Float;
}

typedef ModFileInfo =
{
	var path:String;
	var size:Int;
	var sha256:String;
	@:optional var version:String;
	@:optional var modId:String;
}

typedef ModManifest =
{
	var mods:Array<ModFileInfo>;
	var generatedAt:Float;
	/** 本次清单对应的谱面哈希 (空 = 未选歌/最小清单)。 */
	@:optional var chartHash:String;
	/** song / converted。 */
	@:optional var chartSource:String;
}

typedef OnlineError =
{
	var code:Int;
	var message:String;
	@:optional var detail:String;
}

class OnlineConst
{
	public static inline var MODE_REALTIME:String = "realtime";
	public static inline var MODE_ASYNC:String = "async";

	/** chartSource 取值: 普通歌曲。 */
	public static inline var CHART_SOURCE_SONG:String = "song";
	/** chartSource 取值: Malody/osu! 转谱, 房间强制异步排名。 */
	public static inline var CHART_SOURCE_CONVERTED:String = "converted";

	public static inline var ROOM_STATUS_LOBBY:String = "lobby";
	public static inline var ROOM_STATUS_COUNTDOWN:String = "countdown";
	public static inline var ROOM_STATUS_PLAYING:String = "playing";
	public static inline var ROOM_STATUS_RESULTS:String = "results";

	public static inline var ASYNC_STATE_NOT_STARTED:String = "not_started";
	public static inline var ASYNC_STATE_PLAYING:String = "playing";
	public static inline var ASYNC_STATE_FINISHED:String = "finished";
	public static inline var ASYNC_STATE_WAITING:String = "waiting";

	/** 实时对局暂停策略: 全员可暂停 / 仅房主暂停有效 / 禁止暂停。 */
	public static inline var PAUSE_EVERYONE:String = "everyone";
	public static inline var PAUSE_HOST_ONLY:String = "hostOnly";
	public static inline var PAUSE_DISABLED:String = "disabled";

	public static function sanitizeNickname(value:String):String
	{
		if (value == null)
			return "";
		var out:String = value;
		out = StringTools.replace(out, "\r", " ");
		out = StringTools.replace(out, "\n", " ");
		out = StringTools.replace(out, "\t", " ");
		if (out.length > 24)
			out = out.substr(0, 24);
		return out;
	}

	public static function sanitizeChat(value:String):String
	{
		if (value == null)
			return "";
		var out:String = value;
		out = StringTools.replace(out, "\r", " ");
		out = StringTools.replace(out, "\n", " ");
		if (out.length > 200)
			out = out.substr(0, 200);
		return out;
	}

	public static function sanitizeRoomName(value:String):String
	{
		if (value == null)
			return "";
		var out:String = value;
		out = StringTools.replace(out, "\r", " ");
		out = StringTools.replace(out, "\n", " ");
		if (out.length > 32)
			out = out.substr(0, 32);
		return out;
	}
}
