package online.shared;

/**
	纯 Haxe 判定与输入合法性校验, 供服务器权威计算和异步回放抽检使用。
	注意: 这里只处理与显示无关的数据, 不依赖 Flixel/Note 对象。
**/
typedef ChartNoteEvent =
{
	var timeMs:Float;
	var lane:Int;
	var lengthMs:Float;
}

class JudgeCore
{
	public static inline var RATING_MARVELOUS:String = "marvelous";
	public static inline var RATING_SICK:String = "sick";
	public static inline var RATING_GOOD:String = "good";
	public static inline var RATING_BAD:String = "bad";
	public static inline var RATING_SHIT:String = "shit";

	/** 依据房间判定窗口给评级。 */
	public static function ratingFor(hitDiffMs:Float, timings:Array<Int>, marvelousEnabled:Bool):String
	{
		if (timings == null || timings.length < 4)
			timings = [25, 50, 70, 100];
		var diff:Float = Math.abs(hitDiffMs);
		if (marvelousEnabled && diff <= timings[0])
			return RATING_MARVELOUS;
		if (diff <= timings[1])
			return RATING_SICK;
		if (diff <= timings[2])
			return RATING_GOOD;
		if (diff <= timings[3])
			return RATING_BAD;
		return RATING_SHIT;
	}

	public static function ratingScore(rating:String):Int
	{
		return switch (rating)
		{
			case RATING_MARVELOUS: 400;
			case RATING_SICK: 350;
			case RATING_GOOD: 200;
			case RATING_BAD: 50;
			case RATING_SHIT: -150;
			default: 0;
		}
	}

	/**
		输入合法性: 按键必须落在谱面某 note 的判定窗口内, 否则视为谱面外按键。
		@param notes 按 lane 分组的 note 时间 (毫秒)
		@param pressTimeMs 按键时间 (毫秒, 已换算到谱面时间)
		@param lane 轨道
		@param windowMs 最大窗口 (bad 窗口)
	**/
	public static function isLegalPress(notes:Map<Int, Array<Float>>, pressTimeMs:Float, lane:Int, windowMs:Float):Bool
	{
		if (notes == null)
			return false;
		var laneNotes:Array<Float> = notes.get(lane);
		if (laneNotes == null)
			return false;
		for (t in laneNotes)
			if (Math.abs(pressTimeMs - t) <= windowMs)
				return true;
		return false;
	}

	/** 同 lane 每秒按键数上限; 超过视为超速连点。 */
	public static inline var MAX_HITS_PER_SECOND:Float = 30.0;

	public static function isTooFast(events:Array<Float>, now:Float):Bool
	{
		if (events == null || events.length < 5)
			return false;
		var windowStart:Float = now - 1000.0;
		var count:Int = 0;
		for (t in events)
			if (t >= windowStart && t <= now)
				count++;
		return count > MAX_HITS_PER_SECOND;
	}

	/** 静默自动点击启发式: 连续 hit 间隔方差几乎为 0 且持续 20 次。 */
	public static function looksLikeAutoClicker(events:Array<Float>):Bool
	{
		if (events == null || events.length < 20)
			return false;
		var intervals:Array<Float> = [];
		for (i in 1...events.length)
			intervals.push(events[i] - events[i - 1]);
		var sum:Float = 0;
		for (v in intervals)
			sum += v;
		var mean:Float = sum / intervals.length;
		var variance:Float = 0;
		for (v in intervals)
		{
			var d:Float = v - mean;
			variance += d * d;
		}
		variance /= intervals.length;
		return variance < 0.04 && mean > 0;
	}

	/**
		异步模式回放抽检:
		- replayJson 必须存在;
		- 帧输入不能出现在谱面开始前 5 秒;
		- 判定记录总数不能超过谱面 note 数 * 2 (长条头尾)。
	**/
	public static function verifyAsyncReplay(replayJson:String, noteCount:Int):Bool
	{
		if (replayJson == null || replayJson.length == 0)
			return false;
		try
		{
			var replay:Dynamic = haxe.Json.parse(replayJson);
			var frames:Dynamic = Reflect.field(replay, "frameData");
			if (frames == null && Reflect.hasField(replay, "frames"))
				frames = Reflect.field(replay, "frames");
			if (frames == null || !Std.isOfType(frames, Array))
				return false;
			var judgmentCount:Int = 0;
			var arr:Array<Dynamic> = cast frames;
			for (frame in arr)
			{
				var judgments:Dynamic = Reflect.field(frame, "noteJudgments");
				if (judgments != null && Std.isOfType(judgments, Array))
					judgmentCount += (cast judgments : Array<Dynamic>).length;
			}
			if (noteCount > 0 && judgmentCount > noteCount * 2 + 8)
				return false;
			return true;
		}
		catch (e:Dynamic)
		{
			return false;
		}
	}

	public static function accuracy(marvelous:Int, sick:Int, good:Int, bad:Int, shit:Int):Float
	{
		var total:Int = marvelous + sick + good + bad + shit;
		if (total <= 0)
			return 0;
		var weighted:Float = marvelous * 1.0 + sick * 1.0 + good * 0.75 + bad * 0.25;
		return weighted / total;
	}
}
