package online.shared;

import haxe.crypto.Sha256;
import haxe.io.Bytes;

/**
	SHA-256 工具, 用于谱面/模组一致性校验。
**/
class SeiunHash
{
	public static function ofBytes(data:Bytes):String
	{
		if (data == null)
			data = Bytes.alloc(0);
		return Sha256.make(data).toHex();
	}

	public static function ofString(text:String):String
	{
		return Sha256.encode(text == null ? "" : text);
	}

	#if sys
	public static function ofFile(path:String):String
	{
		if (path == null || !sys.FileSystem.exists(path) || sys.FileSystem.isDirectory(path))
			return "";
		try
		{
			return Sha256.make(sys.io.File.getBytes(path)).toHex();
		}
		catch (e:Dynamic)
		{
			return "";
		}
	}

	public static function fileSize(path:String):Int
	{
		try
		{
			if (path == null || !sys.FileSystem.exists(path) || sys.FileSystem.isDirectory(path))
				return -1;
			return sys.FileSystem.stat(path).size;
		}
		catch (e:Dynamic)
		{
			return -1;
		}
	}
	#end
}
