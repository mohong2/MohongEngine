package online.shared;

/**
	握手后的时钟同步与防加速检测。
	采样三轮 RTT, 拒绝明显时间跳变/speedhack。
**/
class ClockSync
{
	public var offsetMs(default, null):Float = 0;
	public var rttMs(default, null):Float = 0;
	public var stable(default, null):Bool = false;
	public var lastJumpMs(default, null):Float = 0;

	var samples:Array<Float> = [];

	public function new() {}

	/** 客户端发起测量, 记录 t0。 */
	public function beginProbe(localMs:Float):Float
	{
		return localMs;
	}

	/**
		服务器或客户端收到一次往返后计算。
		@param t0 请求发出时的本地时间
		@param t1 对端收到请求时的时间
		@param t2 对端回包时的时间
		@param t3 本地收到回包时的时间
	**/
	public function addSample(t0:Float, t1:Float, t2:Float, t3:Float):Void
	{
		var rtt:Float = (t3 - t0) - (t2 - t1);
		var offset:Float = ((t1 - t0) + (t2 - t3)) * 0.5;
		samples.push(offset);
		if (samples.length > 3)
			samples.shift();

		rttMs = rtt < 0 ? 0 : rtt;
		if (samples.length > 0)
		{
			var sum:Float = 0;
			for (s in samples)
				sum += s;
			offsetMs = sum / samples.length;
		}

		var min:Float = Math.POSITIVE_INFINITY;
		var max:Float = Math.NEGATIVE_INFINITY;
		for (s in samples)
		{
			if (s < min)
				min = s;
			if (s > max)
				max = s;
		}
		lastJumpMs = max - min;
		stable = samples.length >= 3 && lastJumpMs <= SeiunProtocol.MAX_CLOCK_JUMP_MS;
	}

	public function acceptable():Bool
	{
		return Math.abs(offsetMs) <= SeiunProtocol.MAX_CLOCK_OFFSET_MS;
	}

	public static function nowMs():Float
	{
		return Date.now().getTime();
	}
}
