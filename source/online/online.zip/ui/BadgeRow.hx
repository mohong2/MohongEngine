package online.ui;

import flixel.group.FlxSpriteGroup;
import flixel.text.FlxText;
import flixel.util.FlxColor;

/**
	徽标行 (房间设置总览 / 各界面信息条):
	按真实 textWidth 逐枚排布小徽标, 超宽从尾部丢枚并补 "…", 绝不溢出容器。
	取代旧实现"一整行字符串 + 手工截断"的做法。
**/
class BadgeRow extends FlxSpriteGroup
{
	public var maxW:Float;

	public function new(x:Float, y:Float, maxW:Float, ?alignRight:Bool = false)
	{
		super(x, y);
		this.maxW = maxW;
		this.alignRight = alignRight;
	}

	var alignRight:Bool = false;

	/** chips: [{text, ?color}]。 */
	public function setChips(chips:Array<{text:String, ?color:FlxColor}>):Void
	{
		UIStyle.clearAndDestroy(this);
		if (chips == null || chips.length == 0)
			return;
		var gap:Float = 10;
		var dot:Float = 4;
		var widths:Array<Float> = [];
		var texts:FlxText = null;
		// 先测量每枚宽度 (用一个临时文本对象逐个量, 避免提前创建)。
		var measure:FlxText = OnlineLayout.makeText(0, 0, 0, "", OnlineLayout.FS_CHIP);
		var total:Float = 0;
		for (c in chips)
		{
			measure.text = c.text;
			var w:Float = measure.textField.textWidth;
			widths.push(w);
			total += w;
		}
		measure.destroy();
		total += (chips.length - 1) * (gap + dot);

		// 超宽: 从尾部丢枚。
		var visible:Int = chips.length;
		while (visible > 1 && total > maxW)
		{
			total -= widths[visible - 1] + gap + dot;
			visible--;
		}
		var overflowDot:Bool = visible < chips.length;

		var px:Float = 0;
		if (alignRight)
			px = maxW - total;
		for (i in 0...visible)
		{
			var c = chips[i];
			var t:FlxText = OnlineLayout.makeText(px, 0, 0, c.text, OnlineLayout.FS_CHIP,
				c.color == null ? OnlineLayout.C_SUB : c.color);
			t.textField.wordWrap = false;
			add(t);
			px += widths[i] + gap;
			if (i < visible - 1)
			{
				var d:FlxText = OnlineLayout.makeText(px, 0, 0, "·", OnlineLayout.FS_CHIP, 0xFF54648C);
				add(d);
				px += dot + gap;
			}
		}
		if (overflowDot)
		{
			var d:FlxText = OnlineLayout.makeText(px, 0, 0, "…", OnlineLayout.FS_CHIP, 0xFF54648C);
			add(d);
		}
	}
}
