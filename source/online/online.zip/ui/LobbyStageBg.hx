package online.ui;

import BGSprite;
import ClientPrefs;
import flixel.group.FlxSpriteGroup;

/**
	房间大厅舞台背景 (仅布景, 不含固定人物):
	舞台由 LobbyCharacter 组按玩家站位铺设, 镜头由大厅按人数拉远。
	资产与 BaseStage 的 stage 一致, 放大以覆盖拉远镜头 (zoom 0.36~0.62) 的视野。
	人物脚底世界坐标 ≈ 1160~1210, 镜头 scroll=(200,110)。
**/
class LobbyStageBg extends FlxSpriteGroup
{
	public function new()
	{
		super(0, 0);

		// 背景墙: 放大到覆盖最大拉远镜头 (zoom≈0.38 → 可视宽约 3368) 的视野。
		var bg:BGSprite = new BGSprite('stageback', -600, -400, 0.9, 0.9);
		bg.setGraphicSize(Std.int(bg.width * 2.6));
		bg.updateHitbox();
		add(bg);

		// 舞台前沿 (幕布/地板): 上沿正好压在角色脚底 (大厅角色 feet≈1120~1165) 之下,
		// 角色完整可见, 幕布只盖住脚底以下的地板 —— 与原版 PlayState 的层级一致。
		var stageFront:BGSprite = new BGSprite('stagefront', -650, 1180, 0.9, 0.9);
		stageFront.setGraphicSize(Std.int(stageFront.width * 3.0));
		stageFront.updateHitbox();
		add(stageFront);

		if (!ClientPrefs.data.lowQuality)
		{
			var stageLight:BGSprite = new BGSprite('stage_light', 220, -160, 0.9, 0.9);
			stageLight.setGraphicSize(Std.int(stageLight.width * 2.1));
			stageLight.updateHitbox();
			add(stageLight);

			var stageLight2:BGSprite = new BGSprite('stage_light', 2500, -160, 0.9, 0.9);
			stageLight2.setGraphicSize(Std.int(stageLight2.width * 2.1));
			stageLight2.updateHitbox();
			stageLight2.flipX = true;
			add(stageLight2);

			var stageCurtains:BGSprite = new BGSprite('stagecurtains', -900, -520, 1.3, 1.3);
			stageCurtains.setGraphicSize(Std.int(stageCurtains.width * 2.2));
			stageCurtains.updateHitbox();
			add(stageCurtains);
		}
	}
}
