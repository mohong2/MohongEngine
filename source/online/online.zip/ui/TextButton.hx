package online.ui;

import flixel.FlxG;
import flixel.text.FlxText;
import flixel.tweens.FlxEase;
import flixel.tweens.FlxTween;
import flixel.util.FlxColor;

/**
	文本式可点按钮 (PsychOnline 风格, 现代化):
	- 普通状态显示 "选项", 聚焦/悬停显示 "> 选项 <";
	- 键盘导航用 focus, 鼠标悬停即高亮, 点击触发 onClick;
	- hover 有平滑缩放过渡, 不画任何按钮底图, 与玻璃面板搭配。
**/
class TextButton extends FlxText
{
	public var id:Int = 0;
	public var onClick:Void->Void = null;

	/** 附加说明 (底部描述行用)。 */
	public var desc:String = "";

	/** 触屏/鼠标命中区垂直扩展 (px/侧): 保证小字号按钮也有 ≥40px 命中高度。 */
	public var touchPadY:Float = 4;

	/** 标签/焦点变化时自动水平居中。 */
	public var centerOnLabel(default, set):Bool = false;

	/** hover/focus 时的放大倍率 (丝滑过渡)。 */
	public var hoverScale:Float = 1.06;

	var baseLabel:String;
	var _focused:Bool = false;
	var _hovered:Bool = false;

	public function new(x:Float, y:Float, text:String, ?onClick:Void->Void, ?size:Int = 32, ?wrapWidth:Float = 0)
	{
		super(x, y, wrapWidth, text, size);
		this.baseLabel = text;
		this.onClick = onClick;
		setFormat(Paths.languageFont(), size, FlxColor.WHITE, CENTER, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		antialiasing = true;
		alpha = 0.85;
		render();
	}

	function set_centerOnLabel(v:Bool):Bool
	{
		centerOnLabel = v;
		render();
		return v;
	}

	public var focused(default, set):Bool;

	function set_focused(v:Bool):Bool
	{
		_focused = v;
		render();
		return v;
	}

	/** 外部修改显示文字时同步 baseLabel。 */
	public function setLabel(text:String):Void
	{
		baseLabel = text;
		render();
	}

	/** 强制重排文字/居中, 供布局代码在改标签后重新量宽度。 */
	public function refresh():Void
	{
		render();
	}

	function render():Void
	{
		text = (_focused || _hovered) ? "> " + baseLabel + " <" : baseLabel;
		alpha = (_focused || _hovered) ? 1.0 : 0.82;
		if (centerOnLabel)
		{
			// 每次重排, 避免文字宽度测量陈旧导致停留在左侧
			var tw:Float = width > 0 ? width : 0;
			x = (FlxG.width - tw) / 2;
		}
	}

	/** 触屏按压中的 touch id (-1 = 无); tap 语义防误触。 */
	var _pressTouchId:Int = -1;

	var _tween:FlxTween = null;

	function tweenScale(to:Float):Void
	{
		// 取消 hover/focus 缩放: FlxSprite 缩放原点在左上角, 选中时文字会向右下偏移,
		// 用户观感就是"选中后坐标跑了"。焦点态只通过 "> <" 装饰和 alpha 表达。
	}

	override function update(elapsed:Float)
	{
		super.update(elapsed);
		var touchHandled:Bool = false;
		#if (android || mobile)
		// 安卓/移动端: 触屏改为"按下并在本按钮上松开"才触发 (tap 语义)。
		// 之前 justPressed 立即触发, 行距紧 + 手指稍滑就会误触邻行。
		for (touch in FlxG.touches.list)
		{
			if (touch == null)
				continue;
			var over:Bool = touch.x >= x && touch.x <= x + width
				&& touch.y >= y - touchPadY && touch.y <= y + height + touchPadY;
			if (over != _hovered)
			{
				_hovered = over;
				render();
			}
			if (touch.justPressed && over && _pressTouchId < 0)
			{
				_pressTouchId = touch.touchPointID;
			}
			else if (touch.touchPointID == _pressTouchId && touch.justReleased)
			{
				_pressTouchId = -1;
				if (over && onClick != null)
				{
					FlxG.sound.play(Paths.sound('scrollMenu'), 0.7);
					onClick();
					touchHandled = true;
				}
			}
			else if (touch.touchPointID == _pressTouchId && !over)
			{
				// 滑出按钮: 取消本次按压, 不触发。
				_pressTouchId = -1;
			}
		}
		#end
		// 触屏同时模拟鼠标的设备只触发一次; 纯鼠标平台走原逻辑。
		if (!touchHandled && FlxG.mouse.visible)
		{
			var over:Bool = FlxG.mouse.overlaps(this)
				|| (FlxG.mouse.x >= x && FlxG.mouse.x <= x + width
					&& FlxG.mouse.y >= y - touchPadY && FlxG.mouse.y <= y + height + touchPadY);
			if (over != _hovered)
			{
				_hovered = over;
				render();
				if (!_focused)
					tweenScale(over ? hoverScale : 1.0);
			}
			if (over && FlxG.mouse.justPressed && onClick != null)
			{
				FlxG.sound.play(Paths.sound('scrollMenu'), 0.7);
				onClick();
			}
		}
	}
}
