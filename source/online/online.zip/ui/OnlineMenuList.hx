package online.ui;

import flixel.FlxG;
import flixel.group.FlxSpriteGroup;
import flixel.math.FlxMath;
import flixel.math.FlxPoint;
import flixel.text.FlxText;
import flixel.util.FlxColor;

/**
	联机界面通用 Psych 风格菜单列表。

	两种形态:
	- **菜单形态 (默认)**: 大字号 (42px) FlxTextMenuItem, "> 文本 <" 装饰 + targetY 平滑滑动,
	  用于整屏主菜单;
	- **行列表形态 (rowMode = true)**: 紧凑行 (13~15px), ">" 选中标记占独立 marker 列、
	  行文本 x 恒定、选中只换色不位移 (Find/Dedicated 列表的既有观感), 文本按 rowWidth
	  实测截断, 行命中高度按 OnlineLayout.TOUCH_MIN_H 补齐, 点击走 OnlinePointer 的 tap 语义
	  (按下与松开必须在同一行, 滑出即取消), 鼠标与触屏同一套代码。

	键盘: UI_UP/UI_DOWN 选择 + ACCEPT 确认; 输入框聚焦时自动忽略按键 (与 UIStyle 的 ESC 守卫兼容)。
**/
class OnlineMenuList extends FlxSpriteGroup
{
	/** 单个菜单项数据。 */
	public var entries:Array<OnlineMenuEntry> = [];

	/** 当前选中索引 (set 会自动刷新高亮与描述)。 */
	public var curSelected(default, set):Int = 0;

	/** 列表是否接收键盘/指针输入 (Substate 弹出或内联输入时置 false; 避免与 FlxBasic.active 重名)。 */
	public var inputEnabled:Bool = true;

	/** 选中变化回调 (参数: 索引)。 */
	public var onChange:Int->Void = null;

	/** 确认回调 (参数: 索引)。 */
	public var onAccept:Int->Void = null;

	/** 列表首项起始坐标。 */
	public var startPosition:FlxPoint;

	/** 每项间距。 */
	public var spacingY:Float = 92;

	/** 超出 visibleMax 时从两端裁剪显示 (0 = 不裁剪)。 */
	public var visibleMax:Int = 0;

	/** 底部描述文本 (descs 非空时由本组件维护)。 */
	public var descText:FlxText = null;

	// ── 行列表形态 ────────────────────────────────────────

	/** true = 紧凑行列表 (固定锚点 + 只换色不位移 + tap 语义)。 */
	public var rowMode:Bool = false;

	/** 行/菜单项字号。 */
	public var itemSize:Int = 42;

	/** 行文本可用宽度 (rowMode 下按它实测截断; 0 = 不截断)。 */
	public var rowWidth:Float = 0;

	/** ">" 标记列宽 (rowMode)。 */
	public var markerWidth:Float = 22;

	/** 行颜色 (rowMode)。 */
	public var colorSelected:FlxColor = 0xFFFFEB96;

	public var colorNormal:FlxColor = 0xFFDCEBFA;

	/** 鼠标悬停即改选中 (rowMode 下默认开; 触屏不受影响, 触屏只认 tap)。 */
	public var hoverSelects:Bool = true;

	/** 键盘选择是否循环 (rowMode 沿用原实现的循环行为)。 */
	public var wrapSelection:Bool = false;

	var items:Array<FlxTextMenuItem> = [];
	var markers:Array<FlxText> = [];
	var scrollIndex:Int = 0;

	public function new(x:Float, y:Float, spacing:Float = 92)
	{
		super();
		startPosition = FlxPoint.get(x, y);
		spacingY = spacing;
	}

	/** 一步切到行列表形态 (Find/Dedicated 用)。 */
	public function asRowList(width:Float, size:Int = 13, spacing:Float = 30):OnlineMenuList
	{
		rowMode = true;
		rowWidth = width;
		itemSize = size;
		spacingY = Math.max(spacing, OnlineLayout.lineHeight(size));
		wrapSelection = true;
		return this;
	}

	/**
		(重)建菜单项。label/desc 走 Language.get 后传入; onSelect 建议用 function(idx) 闭包。
	**/
	public function setEntries(newEntries:Array<OnlineMenuEntry>):Void
	{
		UIStyle.clearAndDestroy(this);
		entries = newEntries == null ? [] : newEntries;
		items = [];
		markers = [];
		for (i in 0...entries.length)
		{
			if (rowMode)
			{
				var marker:FlxText = OnlineLayout.makeText(startPosition.x, startPosition.y + i * spacingY, markerWidth, " ", itemSize, colorSelected, LEFT);
				markers.push(marker);
				add(marker);
			}
			var item:FlxTextMenuItem = new FlxTextMenuItem(rowMode ? startPosition.x + markerWidth : startPosition.x,
				startPosition.y + (rowMode ? i * spacingY : 0), entries[i].label, rowMode ? itemSize : 42);
			if (rowMode)
			{
				// 固定锚点: 不参与 FlxTextMenuItem 的插值移动, 选中只换色。
				item.isMenuItem = false;
				item.borderSize = 1.5;
				item.fieldWidth = rowWidth > 0 ? rowWidth : item.fieldWidth;
			}
			else
			{
				item.borderSize = 3;
				item.distancePerItem.y = spacingY;
				item.startPosition.y = startPosition.y;
				// 位移由 OnlineMenuList.update 统一按 spacingY 计算, 关闭 FlxTextMenuItem 自带
				// 的 1.3 倍系数移动, 避免双重插值。
				item.changeX = false;
				item.changeY = false;
			}
			items.push(item);
			add(item);
		}
		if (entries.length > 0)
			scrollIndex = 0;
		curSelected = Std.int(Math.min(curSelected, Math.max(0, entries.length - 1)));
		refreshLabels();
	}

	function set_curSelected(v:Int):Int
	{
		if (entries.length == 0)
			return 0;
		v = FlxMath.wrap(v, 0, entries.length - 1);
		if (curSelected != v)
		{
			curSelected = v;
			refreshLabels();
			if (onChange != null)
				onChange(v);
		}
		return curSelected;
	}

	function decorate(label:String, selected:Bool):String
	{
		return selected ? '> ' + label + ' <' : label;
	}

	/** 重刷每项文字/透明度/描述 (标签被外部改动后也调用它)。 */
	public function refreshLabels():Void
	{
		for (i in 0...items.length)
		{
			if (entries[i] == null)
				continue;
			var selected:Bool = i == curSelected;
			if (rowMode)
			{
				// 行文本 x 恒定, 只换色 + 标记列; 超宽按真实宽度截断。
				items[i].color = selected ? colorSelected : colorNormal;
				items[i].alpha = selected ? 1.0 : 0.86;
				if (rowWidth > 0)
					OnlineLayout.truncate(items[i], entries[i].label, rowWidth);
				else
					items[i].text = entries[i].label;
				if (i < markers.length)
					markers[i].text = selected ? ">" : " ";
			}
			else
			{
				items[i].text = decorate(entries[i].label, selected);
				items[i].alpha = selected ? 1.0 : 0.55;
				items[i].targetY = itemTargetY(i);
			}
		}
		if (descText != null)
		{
			var d:String = entries.length > 0 ? entries[curSelected].desc : null;
			descText.text = d == null ? "" : d;
		}
	}

	/** 项 i 相对滚动窗口的目标偏移。 */
	function itemTargetY(i:Int):Int
	{
		return i - scrollIndex;
	}

	/** 外部改 label 后同步 (如开关值拼接进标签)。 */
	public function setLabel(idx:Int, label:String):Void
	{
		if (idx < 0 || idx >= entries.length)
			return;
		entries[idx].label = label;
		refreshLabels();
	}

	/** 列表实际占用高度 (行列表用来给底板/滚动条算尺寸)。 */
	public function contentHeight():Float
	{
		if (items.length == 0)
			return 0;
		return items.length * spacingY;
	}

	override function update(elapsed:Float):Void
	{
		super.update(elapsed);
		if (items.length != entries.length)
			return; // setEntries 进行中

		if (!rowMode)
		{
			for (i in 0...items.length)
			{
				// 与 FlxTextMenuItem.update 相同的缓动, 但按本项目间距排布
				var lerpVal:Float = Math.exp(-elapsed * 9.6);
				items[i].y = FlxMath.lerp(startPosition.y + itemTargetY(i) * spacingY, items[i].y, lerpVal);
				items[i].x = startPosition.x;
			}
		}

		if (!inputEnabled || entries.length == 0)
			return;

		var controls = Controls.instance;
		if (controls != null && !UIStyle.anyInputFocused())
		{
			if (controls.UI_UP_P)
				changeSelection(-1);
			if (controls.UI_DOWN_P)
				changeSelection(1);
			if (controls.ACCEPT && onAccept != null)
			{
				FlxG.sound.play(Paths.sound('confirmMenu'), 0.7);
				onAccept(curSelected);
			}
		}
		if (rowMode)
			handleRowPointer();
		else
			handlePointer();
	}

	function changeSelection(diff:Int):Void
	{
		var next:Int = curSelected + diff;
		if (wrapSelection)
			next = FlxMath.wrap(next, 0, entries.length - 1);
		else
		{
			if (next < 0)
				next = 0;
			if (next > entries.length - 1)
				next = entries.length - 1;
		}
		if (next != curSelected)
		{
			FlxG.sound.play(Paths.sound('scrollMenu'), 0.6);
			curSelected = next;
		}
	}

	/** 行列表指针: tap 语义 + ≥40px 命中 + 鼠标悬停预选。 */
	function handleRowPointer():Void
	{
		OnlinePointer.poll();
		if (OnlinePointer.x < 0)
			return;
		for (i in 0...items.length)
		{
			var it:FlxTextMenuItem = items[i];
			var rx:Float = startPosition.x;
			var rw:Float = markerWidth + (rowWidth > 0 ? rowWidth : it.width);
			if (hoverSelects && FlxG.mouse.visible && !OnlinePointer.pressed
				&& OnlinePointer.over(rx, it.y, rw, it.height) && i != curSelected)
			{
				FlxG.sound.play(Paths.sound('scrollMenu'), 0.4);
				curSelected = i;
			}
			if (OnlinePointer.tapped(rx, it.y, rw, it.height))
			{
				curSelected = i;
				if (onAccept != null)
				{
					FlxG.sound.play(Paths.sound('confirmMenu'), 0.7);
					onAccept(i);
				}
				return;
			}
		}
	}

	function handlePointer():Void
	{
		var pointerX:Float = -1;
		var pointerY:Float = -1;
		var pressed:Bool = false;
		#if (android || mobile)
		for (touch in FlxG.touches.list)
		{
			if (touch == null)
				continue;
			pointerX = touch.x;
			pointerY = touch.y;
			pressed = touch.justPressed;
			break;
		}
		if (pointerX < 0 && FlxG.mouse.visible)
		{
			pointerX = FlxG.mouse.x;
			pointerY = FlxG.mouse.y;
			pressed = FlxG.mouse.justPressed;
		}
		#else
		if (FlxG.mouse.visible)
		{
			pointerX = FlxG.mouse.x;
			pointerY = FlxG.mouse.y;
			pressed = FlxG.mouse.justPressed;
		}
		#end
		if (pointerX < 0)
			return;

		for (i in 0...items.length)
		{
			var it:FlxTextMenuItem = items[i];
			var pad:Float = 14;
			var over:Bool = pointerX >= it.x - pad && pointerX <= it.x + it.width + pad
				&& pointerY >= it.y - pad * 0.5 && pointerY <= it.y + it.height + pad * 0.5;
			if (over && i != curSelected)
			{
				FlxG.sound.play(Paths.sound('scrollMenu'), 0.4);
				curSelected = i;
			}
			if (over && pressed && onAccept != null && i == curSelected)
			{
				FlxG.sound.play(Paths.sound('confirmMenu'), 0.7);
				onAccept(i);
				return;
			}
		}
	}

	override function destroy():Void
	{
		entries = [];
		items = [];
		markers = [];
		super.destroy();
	}
}

/** 菜单项数据: label 显示文本, desc 选中时底部描述, tag 供状态自行区分用途。 */
class OnlineMenuEntry
{
	public var label:String;
	public var desc:String = "";
	public var tag:String = "";

	public function new(label:String, ?desc:String = "", ?tag:String = "")
	{
		this.label = label;
		this.desc = desc == null ? "" : desc;
		this.tag = tag == null ? "" : tag;
	}
}
