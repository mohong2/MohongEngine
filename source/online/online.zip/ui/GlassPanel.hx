package online.ui;

import backend.ui.PsychUIHelper;
import flixel.FlxSprite;
import flixel.group.FlxSpriteGroup;
import flixel.util.FlxColor;

/**
	玻璃风格圆角面板: 半透明深色圆角填充 + 淡色圆角细边框。
	用引擎 PsychUIHelper 的圆角矩形生成, 任何机器都能跑。
**/
class GlassPanel extends FlxSpriteGroup
{
	public var fill:FlxSprite;

	public function new(x:Float, y:Float, w:Float, h:Float,
			?tint:Int = 0xFF0C1322, ?fillAlpha:Float = 0.62, ?borderAlpha:Float = 0.55,
			?radius:Int = 14, ?borderColor:Int = 0xFF9FB8E8)
	{
		super(x, y);
		var W:Int = Std.int(Math.max(2, w));
		var H:Int = Std.int(Math.max(2, h));
		var R:Int = Std.int(Math.max(4, Math.min(radius, Std.int(Math.min(W, H) / 2))));

		// 外框 (圆角, 稍大一圈) 在最底层
		var border:FlxSprite = PsychUIHelper.createRoundedRectSprite(W, H, R);
		border.color = borderColor;
		border.alpha = borderAlpha * 0.5;
		add(border);

		// 内填 (圆角, 缩进 2px 露出边框)
		fill = PsychUIHelper.createRoundedRectSprite(W - 4, H - 4, Std.int(Math.max(2, R - 2)));
		fill.color = tint;
		fill.alpha = fillAlpha;
		fill.setPosition(2, 2);
		add(fill);

		// 顶部高光线 (圆角细条), 增加玻璃质感
		var gloss:FlxSprite = PsychUIHelper.createRoundedRectSprite(W - 12, 2, 1);
		gloss.color = borderColor;
		gloss.alpha = borderAlpha * 0.8;
		gloss.setPosition(6, 5);
		add(gloss);
	}
}
