package online.ui;

import flixel.FlxSprite;
import flixel.group.FlxSpriteGroup;
import flixel.util.FlxColor;

/**
	扁平 Psych 面板 (UI 完全重构: 取代 GlassPanel 的玻璃拟态):
	- 纯深色实底 + 1px 冷灰蓝细边框, 无高光/无圆角渐变, 与 Psych 原版菜单的黑底描边观感一致;
	- 构造签名与 GlassPanel 兼容 (同参数位), 便于逐处替换;
	- 可选顶部标题条底色 (headerH > 0), 给"面板内小标题"一个统一的落脚处。

	为什么不再用圆角: Psych 原版 UI 全是硬边黑底 + 描边字, 圆角+半透明高光是上一轮遗留的
	玻璃拟态风格, 与目标风格冲突, 并且圆角贴图在低端安卓上多一次 BitmapData 生成。
**/
class OnlinePanel extends FlxSpriteGroup
{
	public var fill:FlxSprite;
	public var header:FlxSprite = null;

	public function new(x:Float, y:Float, w:Float, h:Float, ?tint:Int = 0xFF10161F, ?fillAlpha:Float = 0.88, ?borderAlpha:Float = 0.75,
			?headerH:Float = 0, ?borderColor:Int = 0xFF5C7196)
	{
		super(x, y);
		var W:Int = Std.int(Math.max(2, w));
		var H:Int = Std.int(Math.max(2, h));

		// 外框 (实心 1px 描边效果 = 边框色底 + 内缩填充)
		var border:FlxSprite = new FlxSprite().makeGraphic(W, H, FlxColor.WHITE);
		border.color = borderColor;
		border.alpha = borderAlpha;
		add(border);

		fill = new FlxSprite(1, 1).makeGraphic(Std.int(Math.max(1, W - 2)), Std.int(Math.max(1, H - 2)), FlxColor.WHITE);
		fill.color = tint;
		fill.alpha = fillAlpha;
		add(fill);

		if (headerH > 0)
		{
			header = new FlxSprite(1, 1).makeGraphic(Std.int(Math.max(1, W - 2)), Std.int(Math.max(1, headerH)), FlxColor.WHITE);
			header.color = borderColor;
			header.alpha = 0.28;
			add(header);
		}
	}
}
