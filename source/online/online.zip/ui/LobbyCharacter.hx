package online.ui;

import Character;
import flixel.FlxG;
import flixel.FlxSprite;
import flixel.group.FlxSpriteGroup;
import flixel.text.FlxText;
import flixel.util.FlxColor;

/**
	大厅站台角色 (PsychOnline LobbyCharacter 适配):
	一个玩家 = 一个角色立绘 (按玩家 skin, 空 = 跟随谱面 → 大厅默认 BF)
	+ 头顶信息 (昵称 / 房主 / 准备 / 延迟)。
	位置由大厅按人数排布, 这里只负责加载与摆放。
**/
class LobbyCharacter extends FlxSpriteGroup
{
	public var playerId:String = "";
	public var character:Character = null;
	public var label:FlxText;
	public var labelBg:FlxSprite;

	var nickname:String = "";
	var isHost:Bool = false;
	var isReady:Bool = false;
	var pingMs:Float = 0;
	var skinName:String = "";
	var lastLabelSig:String = "";

	public function new(player:Dynamic)
	{
		super(0, 0);
		if (player != null)
		{
			playerId = Std.string(Reflect.field(player, "id"));
			nickname = Std.string(Reflect.field(player, "nickname"));
			isHost = Reflect.field(player, "isHost") == true;
			isReady = Reflect.field(player, "isReady") == true;
			pingMs = Reflect.field(player, "pingMs") == null ? 0 : Std.parseFloat(Std.string(Reflect.field(player, "pingMs")));
			skinName = Reflect.field(player, "skin") == null ? "" : Std.string(Reflect.field(player, "skin"));
		}
		if (nickname == null || nickname.length == 0)
			nickname = online.ui.UIStyle.t('player', '玩家');
		loadCharacter();
		buildLabel();
		updateLabel(true);
	}

	/** 按玩家 skin 加载角色立绘 (失败回退 BF, 绝不崩溃)。 */
	public function loadCharacter():Void
	{
		if (character != null)
		{
			remove(character);
			character.destroy();
			character = null;
		}
		var name:String = skinName == null || skinName.length == 0 ? "bf" : skinName;
		try
		{
			character = new Character(0, 0, name);
		}
		catch (e:Dynamic)
		{
			try
			{
				character = new Character(0, 0, 'bf');
			}
			catch (e2:Dynamic)
			{
				return;
			}
		}
		character.playAnim('idle', true);
		character.antialiasing = true;
		try
		{
			character.dance();
		}
		catch (e:Dynamic) {}
		add(character);
	}

	function buildLabel():Void
	{
		labelBg = new FlxSprite();
		labelBg.makeGraphic(1, 1, FlxColor.BLACK);
		labelBg.alpha = 0.55;
		add(labelBg);
		label = new FlxText(0, 0, 0, "", 13);
		label.setFormat(Paths.languageFont(), 13, FlxColor.WHITE, CENTER, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		add(label);
	}

	/** 以脚底为锚点摆放: centerX = 角色水平中心, feetY = 脚底 y (精灵左上角语义)。 */
	public function reposition(centerX:Float, feetY:Float, scale:Float):Void
	{
		if (character == null)
			return;
		character.setGraphicSize(Std.int(character.width * scale));
		character.updateHitbox();
		character.x = centerX - character.width / 2;
		character.y = feetY - character.height;
		updateLabel(false);
	}

	public function setReady(ready:Bool):Void
	{
		if (isReady == ready)
			return;
		isReady = ready;
		updateLabel(true);
	}

	public function setPing(ping:Float):Void
	{
		pingMs = ping;
		updateLabel(false);
	}

	public function updateLabel(force:Bool):Void
	{
		if (label == null || character == null)
			return;
		var sig:String = nickname + "|" + (isHost ? "1" : "0") + "|" + (isReady ? "1" : "0") + "|" + Std.int(pingMs);
		if (!force && sig == lastLabelSig)
			return;
		lastLabelSig = sig;
		// PsychOnline 式双行标签: 第 1 行 昵称+标记, 第 2 行 延迟+状态。
		var line1:Array<String> = [nickname];
		if (isHost)
			line1.push("[" + online.ui.UIStyle.t('roomHost', '房主') + "]");
		var line2:Array<String> = [];
		if (pingMs > 0)
			line2.push(Std.int(pingMs) + "ms");
		if (isReady)
			line2.push(online.ui.UIStyle.t('roomReady', '准备'));
		var text:String = line1.join(" ");
		if (line2.length > 0)
			text += "\n" + line2.join(" · ");
		label.text = text;
		label.x = character.x + character.width / 2 - label.width / 2;
		label.y = character.y - label.height - 6;
		labelBg.scale.set(label.width + 12, label.height + 4);
		labelBg.updateHitbox();
		labelBg.x = label.x - 6;
		labelBg.y = label.y - 2;
	}

	public function dance():Void
	{
		if (character != null)
		{
			try
			{
				character.dance();
			}
			catch (e:Dynamic) {}
		}
	}

	override function destroy():Void
	{
		if (character != null)
		{
			remove(character);
			character.destroy();
			character = null;
		}
		super.destroy();
	}
}
