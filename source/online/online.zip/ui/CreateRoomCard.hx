package online.ui;

import backend.Ratings;
import backend.ui.PsychUIInputText;
import ClientPrefs;
import flixel.FlxG;
import flixel.group.FlxSpriteGroup;
import flixel.text.FlxText;
import flixel.util.FlxColor;

/**
	建房配置卡 (LAN 托管页 / DEDICATED 页共用):
	房间名/密码输入 + 模式/人数/判定/Custom 窗口/Marvelous/兼容/舞台 循环行。
	所有文字走 UIStyle.t() 本地化; 行文本固定锚点, 选中只换色不位移。
	页面负责把「输入框 + 本卡行 + 页面的主按钮」组成统一焦点链。

	判定行支持自定义: 预设循环到 Custom 时, 窗口值取 ClientPrefs 当前 judgementTimings,
	细调在房间大厅的联机设置里完成 (自定义窗口四个行)。
**/
class CreateRoomCard extends FlxSpriteGroup
{
	public var roomNameInput:PsychUIInputText;
	public var passwordInput:PsychUIInputText;
	public var rows:Array<TextButton> = [];
	/** 输入框在前, 行在后 (供页面组焦点链)。 */
	public var focusables:Array<Dynamic> = [];
	/** 焦点链内的当前索引 (页面键盘导航用)。 */
	public var curFocus:Int = 0;

	var modeRealtime:Bool = true;
	var allowDuplicateNames:Bool = true;
	var maxPlayers:Int = 4;
	var marvelousRatings:Bool = true;
	var pausePolicyIdx:Int = 0;
	var compatEngineIdx:Int = 0;
	var compatEngines:Array<String> = backend.CompatEngine.VALUES.copy();
	var presetNames:Array<String> = [];
	var selectedPreset:Int = 0;
	/** 选中 Custom 时的自定义窗口 (默认取本地当前判定, 可在大厅设置里细调)。 */
	var customTimings:Array<Int> = null;
	var selectedStage:Int = 0;
	var stageList:Array<String> = ["", "stage", "spooky", "philly", "limo", "mall", "mallEvil", "school", "schoolEvil", "tank"];
	/** 卡片宽度 (布局/截断用)。 */
	var cardW:Float = 390;

	/** 实时对局暂停策略选项 (对应 OnlineConst.PAUSE_*)。 */
	public static final PAUSE_POLICY_VALUES:Array<String> = [
		online.shared.OnlineTypes.OnlineConst.PAUSE_EVERYONE,
		online.shared.OnlineTypes.OnlineConst.PAUSE_HOST_ONLY,
		online.shared.OnlineTypes.OnlineConst.PAUSE_DISABLED
	];

	/**
		@param defaultRoomName 非空时作为房间名输入框的默认文本
		(专用服务器传 "昵称的房间", 局域网沿用本地化默认 "局域网房间")。
	**/
	public function new(x:Float, y:Float, w:Float, ?defaultRoomName:String = null)
	{
		super(x, y);
		cardW = w;

		if (Ratings.presets.length == 0)
			Ratings.loadPresets();
		presetNames = Ratings.presets.copy();
		if (presetNames.indexOf('Custom') < 0)
			presetNames.push('Custom');
		// 本地判定类型是 Custom 时, 建房默认直接选中 Custom 并沿用本地窗口。
		var localPreset:String = ClientPrefs.data.judgementPreset;
		var localIdx:Int = presetNames.indexOf(localPreset);
		if (localIdx >= 0)
			selectedPreset = localIdx;
		else if (localPreset == 'Custom')
			selectedPreset = presetNames.length - 1;
		customTimings = validTimings(ClientPrefs.data.judgementTimings);

		var labelW:Float = w - 40;

		var nameLabel:FlxText = makeLabel(20, 0, labelW, UIStyle.t('createRoomName', '房间名'));
		add(nameLabel);
		var defaultName:String = defaultRoomName != null && defaultRoomName.length > 0
			? defaultRoomName : UIStyle.t('defaultRoomName', '局域网房间');
		roomNameInput = new PsychUIInputText(20, 18, Std.int(labelW), defaultName, 14, UIStyle.inputFontKey());
		UIStyle.styleInput(roomNameInput);
		add(roomNameInput);

		var passLabel:FlxText = makeLabel(20, 56, labelW, UIStyle.t('createRoomPassword', '房间密码 (可留空)'));
		add(passLabel);
		passwordInput = new PsychUIInputText(20, 74, Std.int(labelW), "", 14, UIStyle.inputFontKey());
		UIStyle.styleInput(passwordInput, labelW);
		passwordInput.passwordMask = true;
		add(passwordInput);

		var y:Float = 112;
		// 34px 行距: 15px 中文字形 + 黑描边实测高度 ~24px, 30px 行距会贴边/重叠。
		rows.push(makeRow(y, UIStyle.t('createMode', '模式'), cycleMode)); y += 34;
		rows.push(makeRow(y, UIStyle.t('createDuplicateNames', '重名玩家'), cycleDuplicateNames)); y += 34;
		rows.push(makeRow(y, UIStyle.t('createPlayers', '人数'), cyclePlayers)); y += 34;
		rows.push(makeRow(y, UIStyle.t('createJudgement', '判定'), cyclePreset)); y += 34;
		rows.push(makeRow(y, UIStyle.t('createMarvelous', 'Marvelous'), cycleMarvelous)); y += 34;
		rows.push(makeRow(y, UIStyle.t('createPause', '暂停策略'), cyclePause)); y += 34;
		rows.push(makeRow(y, UIStyle.t('createCompat', '兼容模式'), cycleCompat)); y += 34;
		rows.push(makeRow(y, UIStyle.t('createStage', '舞台'), cycleStage)); y += 34;

		focusables = [roomNameInput, passwordInput];
		for (r in rows)
			focusables.push(r);

		refresh();
	}

	function makeLabel(x:Float, y:Float, w:Float, text:String):FlxText
	{
		var t:FlxText = OnlineLayout.makeText(x, y, w, text, 12, 0xFFAABEE6, LEFT);
		return t;
	}

	function makeRow(y:Float, base:String, fn:Void->Void):TextButton
	{
		var row:TextButton = new TextButton(14, y, base, fn, 15);
		row.desc = base;
		row.alignment = LEFT;
		row.setFormat(Paths.languageFont(), 15, FlxColor.WHITE, LEFT, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		row.antialiasing = true;
		OnlineLayout.padTouch(row);
		add(row);
		return row;
	}

	public function cycleMode():Void
	{
		modeRealtime = !modeRealtime;
		refresh();
	}

	public function cycleDuplicateNames():Void
	{
		allowDuplicateNames = !allowDuplicateNames;
		refresh();
	}

	public function cyclePlayers():Void
	{
		maxPlayers = maxPlayers >= 12 ? 2 : maxPlayers + 2;
		refresh();
	}

	public function cycleMarvelous():Void
	{
		marvelousRatings = !marvelousRatings;
		refresh();
	}

	public function cyclePause():Void
	{
		pausePolicyIdx = (pausePolicyIdx + 1) % PAUSE_POLICY_VALUES.length;
		refresh();
	}

	public function cycleCompat():Void
	{
		compatEngineIdx = (compatEngineIdx + 1) % compatEngines.length;
		refresh();
	}

	public function cyclePreset():Void
	{
		if (presetNames.length == 0)
			return;
		selectedPreset = (selectedPreset + 1) % presetNames.length;
		if (presetNames[selectedPreset] == 'Custom' && customTimings == null)
			customTimings = validTimings(ClientPrefs.data.judgementTimings);
		refresh();
	}

	public function cycleStage():Void
	{
		selectedStage = (selectedStage + 1) % stageList.length;
		refresh();
	}

	public function teamText():String
	{
		var ts:Int = Std.int(maxPlayers / 2);
		return ts + "v" + ts + " (" + maxPlayers + ")";
	}

	/** 当前选中预设名 (Custom 也在列表内)。 */
	public function currentPreset():String
	{
		return presetNames.length > 0 ? presetNames[selectedPreset] : "Leather Engine";
	}

	/** 当前选中的判定窗口 (Custom 用本地/自定义窗口)。 */
	public function currentTimings():Array<Int>
	{
		var preset:String = currentPreset();
		if (preset == 'Custom')
			return validTimings(customTimings);
		var t:Array<Int> = Ratings.returnPreset(preset);
		return validTimings(t);
	}

	static function validTimings(t:Array<Int>):Array<Int>
	{
		if (t != null && t.length >= 4)
		{
			var out:Array<Int> = [];
			for (v in t)
				out.push(v < 0 ? 0 : (v > 500 ? 500 : v));
			return out;
		}
		return [25, 50, 70, 100];
	}

	public function currentPausePolicy():String
	{
		return PAUSE_POLICY_VALUES[pausePolicyIdx];
	}

	/** 暂停策略值的显示文案。 */
	public static function pausePolicyLabel(p:String):String
	{
		return switch (p)
		{
			case online.shared.OnlineTypes.OnlineConst.PAUSE_HOST_ONLY: UIStyle.t('pauseHostOnly', '仅房主');
			case online.shared.OnlineTypes.OnlineConst.PAUSE_DISABLED: UIStyle.t('pauseDisabled', '禁止暂停');
			default: UIStyle.t('pauseEveryone', '全员');
		}
	}

	public function refresh():Void
	{
		var preset:String = currentPreset();
		var stageName:String = stageList[selectedStage];
		var compatLabel:String = compatEngines[compatEngineIdx];
		var vals:Array<String> = [
			UIStyle.t('createMode', '模式') + ": " + (modeRealtime ? UIStyle.t('modeRealtime', '实时对战') : UIStyle.t('modeAsync', '异步排名')),
			UIStyle.t('createDuplicateNames', '重名玩家') + ": " + (allowDuplicateNames ? UIStyle.t('allow', '允许') : UIStyle.t('deny', '拒绝')),
			UIStyle.t('createPlayers', '人数') + ": " + teamText(),
			UIStyle.t('createJudgement', '判定') + ": " + preset + " " + currentTimings().join("/") + (marvelousRatings ? " (Marvelous)" : ""),
			"Marvelous: " + (marvelousRatings ? UIStyle.t('on', '开') : UIStyle.t('off', '关')),
			UIStyle.t('createPause', '暂停策略') + ": " + pausePolicyLabel(currentPausePolicy()),
			UIStyle.t('createCompat', '兼容模式') + ": " + compatLabel,
			UIStyle.t('createStage', '舞台') + ": " + (stageName.length == 0 ? UIStyle.t('followSong', '跟随歌曲') : stageName)
		];
		// 行标签按可用宽度实测截断 (长判定串不再溢出卡片右缘)。
		for (i in 0...rows.length)
		{
			// truncate 需要按"行文本真实可用宽"计算: 卡片宽 w 收进字段 (构造时保存)。
			rows[i].setLabel(OnlineLayout.truncate(rows[i], vals[i], cardW - 28));
			rows[i].refresh();
		}
	}

	/** 生成 MSG_ROOM_CREATE 的 payload (与旧 OnlineCreateRoomState 一致 + Custom 窗口)。 */
	public function buildPayload():Dynamic
	{
		return {
			roomName: roomNameInput.text,
			mode: modeRealtime ? online.shared.OnlineTypes.OnlineConst.MODE_REALTIME : online.shared.OnlineTypes.OnlineConst.MODE_ASYNC,
			maxPlayers: maxPlayers,
			// 反作弊已移除: 恒为 false。
			antiCheat: false,
			password: passwordInput.text,
			judgementPreset: currentPreset(),
			judgementTimings: currentTimings(),
			marvelousRatings: marvelousRatings,
			pausePolicy: currentPausePolicy(),
			compatibilityMode: backend.CompatEngine.compatMode(),
			compatEngine: compatEngines[compatEngineIdx],
			allowDuplicateNames: allowDuplicateNames,
			teamSize: Std.int(maxPlayers / 2),
			stageName: stageList[selectedStage]
		};
	}

	public function updateFocus():Void
	{
		UIStyle.updateFocusOutline(roomNameInput);
		UIStyle.updateFocusOutline(passwordInput);
	}

	public function curFocusTextButton():TextButton
	{
		if (focusables.length == 0)
			return null;
		var f:Dynamic = focusables[curFocus];
		if (Std.isOfType(f, TextButton))
			return cast f;
		return null;
	}

	public function focusInput():Void
	{
		var f:Dynamic = focusables[curFocus];
		if (Std.isOfType(f, PsychUIInputText))
			PsychUIInputText.focusOn = cast f;
	}
}
