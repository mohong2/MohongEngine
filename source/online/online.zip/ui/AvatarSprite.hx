package online.ui;

import flixel.FlxSprite;
import flixel.util.FlxColor;
import HealthIcon;
import online.client.AvatarFileClient;
import online.substates.OptionsSubstate;

/**
	联机玩家头像组件:
	- 默认/内置: 用游戏内原版角色血条图标 (HealthIcon, 与 Freeplay/对局血条一致);
	- 自定义图片: avatar = "file:<name>" → mods/avatars/<name>;
	- 自定义图片在本地缺失时 (远端玩家尚未同步到该文件) 回退 BF 图标, 不再显示灰色空块;
	- 模组角色: 自动切到该角色所在模组目录再加载图标, 保证 mod 图标也能显示。
**/
class AvatarSprite
{
	public static inline var AVATAR_DIR:String = "mods/avatars";

	/** 生成头像精灵 (角色名 或 "file:xxx")。 */
	public static function make(avatar:String, size:Int):FlxSprite
	{
		if (avatar != null && avatar.indexOf("file:") == 0)
		{
			var spr:FlxSprite = new FlxSprite();
			spr.antialiasing = true;
			if (loadImageAvatar(spr, avatar, size))
				return spr;
			// 自定义图片不在本地 (通常是远端玩家上传的头像): 先向服务器请求下载,
			// 下载完成前回退原版 BF 图标, 不显示灰色空块。
			AvatarFileClient.request(avatar.substr(5));
			return makeIcon("bf", size);
		}
		return makeIcon((avatar == null || avatar.length == 0) ? "bf" : avatar, size);
	}

	static function makeIcon(name:String, size:Int):FlxSprite
	{
		var savedModDir:String = Paths.currentModDirectory;
		var modDir:String = "";
		try
		{
			var entry:Dynamic = OptionsSubstate.characterEntryByName(name);
			if (entry != null && Reflect.field(entry, "modDir") != null)
				modDir = Std.string(Reflect.field(entry, "modDir"));
		}
		catch (e:Dynamic) {}
		if (modDir.length > 0)
			Paths.currentModDirectory = modDir;
		var result:FlxSprite = null;
		try
		{
			var icon:HealthIcon = new HealthIcon(name);
			var scale:Float = size / Math.max(1, Math.max(icon.width, icon.height));
			icon.setGraphicSize(Std.int(icon.width * scale), Std.int(icon.height * scale));
			icon.updateHitbox();
			icon.antialiasing = true;
			result = icon;
		}
		catch (e:Dynamic)
		{
			try
			{
				var fallback:HealthIcon = new HealthIcon('bf');
				var scale:Float = size / Math.max(1, Math.max(fallback.width, fallback.height));
				fallback.setGraphicSize(Std.int(fallback.width * scale), Std.int(fallback.height * scale));
				fallback.updateHitbox();
				fallback.antialiasing = true;
				result = fallback;
			}
			catch (e2:Dynamic)
			{
				var spr:FlxSprite = new FlxSprite();
				spr.makeGraphic(size, size, FlxColor.GRAY);
				result = spr;
			}
		}
		if (modDir.length > 0)
			Paths.currentModDirectory = savedModDir;
		return result;
	}

	/** 成功加载返回 true; 本地没有该文件返回 false (不再画灰块)。 */
	public static function loadImageAvatar(spr:FlxSprite, avatar:String, size:Int):Bool
	{
		var name:String = avatar == null ? "" : avatar.substr(5);
		#if sys
		if (name.length > 0 && sys.FileSystem.exists(AVATAR_DIR + "/" + name))
		{
			try
			{
				spr.loadGraphic(AVATAR_DIR + "/" + name);
				fit(spr, size);
				return true;
			}
			catch (e:Dynamic) {}
		}
		#end
		return false;
	}

	/** 把图片等比缩放放进 size 方框。 */
	static function fit(spr:FlxSprite, size:Int):Void
	{
		if (spr.width <= 0 || spr.height <= 0)
			return;
		var scale:Float = size / Math.max(spr.width, spr.height);
		spr.setGraphicSize(Std.int(spr.width * scale), Std.int(spr.height * scale));
		spr.updateHitbox();
	}
}
