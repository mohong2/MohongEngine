package online.ui;

import flixel.FlxG;
import flixel.FlxSprite;
import flixel.group.FlxSpriteGroup;
import flixel.text.FlxText;
import flixel.util.FlxColor;

/**
	联机大按钮 (房间底栏等主要操作用, 替代挤在一起的小号文字按钮):
	- Psych 风格实体底 + 细边框 + 居中标签 (languageFont), 高 48px, 命中区充足;
	- kind 决定配色: "primary"=强调底 (准备/开始), "danger"=警示边 (退出), 默认普通;
	- 聚焦/悬停时底色提亮, 触屏 tap 语义 (按下在本按钮上松开才触发);
	- 宽度按标签实测 + 左右内边距, 由外部布局器统一排布。

	坐标注意: FlxSpriteGroup 的子项在 add 时被平移到"组坐标"。
	因此内部始终以 (0,0) 组建子项, 最后才设置组位置; 任何时刻给 label
	定位都必须用 this.x/this.y + 本地偏移, 否则文字会和底板"分家"。
**/
class OnlineBigButton extends FlxSpriteGroup
{
	public static final BTN_H:Float = 48;
	public static inline var PAD_X:Float = 26;
	public static inline var FS:Int = 20;

	public var onClick:Void->Void = null;

	var border:FlxSprite;
	var bg:FlxSprite;
	var label:FlxText;
	var baseLabel:String = "";
	var kind:String = "normal";

	var _focused:Bool = false;
	var _hovered:Bool = false;
	var pressTouchId:Int = -1;
	var pressedMouse:Bool = false;

	public function new(x:Float, y:Float, text:String, kind:String, ?onClick:Void->Void)
	{
		super(0, 0);
		this.kind = kind == null ? "normal" : kind;
		this.onClick = onClick;
		this.baseLabel = text;

		label = OnlineLayout.makeText(0, 0, 0, text, FS, FlxColor.WHITE, CENTER);
		label.textField.wordWrap = false;
		var w:Float = Math.max(150, label.width + PAD_X * 2);

		border = new FlxSprite().makeGraphic(Std.int(w), Std.int(BTN_H), 0xFF3D4C6E);
		add(border);
		bg = new FlxSprite(1, 1).makeGraphic(Std.int(w - 2), Std.int(BTN_H - 2), 0xFF141D33);
		add(bg);
		add(label);
		layoutLabel();
		applyState();

		// 子项已在本地坐标就位, 最后整体移动组 (组 setter 会平移全部子项)。
		this.x = x;
		this.y = y;
	}

	function colors():{border:FlxColor, bg:FlxColor}
	{
		var active:Bool = _focused || _hovered;
		return switch (kind)
		{
			case "primary": {border: active ? 0xFFFFD24A : 0xFF8C6B1E, bg: active ? 0xFF5A4510 : 0xFF3A2E0C};
			case "danger": {border: active ? 0xFFFF7C7C : 0xFF7C3A3A, bg: active ? 0xFF4A1D1D : 0xFF2A1212};
			default: {border: active ? 0xFF7FB4FF : 0xFF3D4C6E, bg: active ? 0xFF22345C : 0xFF141D33};
		}
	}

	function applyState():Void
	{
		var c = colors();
		border.color = c.border;
		bg.color = c.bg;
		label.alpha = (_focused || _hovered) ? 1.0 : 0.92;
	}

	/** 标签在底板内水平/垂直居中 (必须以组当前位置 + 本地偏移计算)。 */
	function layoutLabel():Void
	{
		label.x = this.x + (border.width - label.width) / 2;
		label.y = this.y + (BTN_H - label.height) / 2;
	}

	/** 外部改标签 (准备/取消准备)。底板按新标签实测宽度重建, 行内重新布局。 */
	public function setLabel(text:String):Void
	{
		baseLabel = text;
		label.text = text;
		var w:Float = Math.max(150, label.width + PAD_X * 2);
		border.makeGraphic(Std.int(w), Std.int(BTN_H), border.color);
		bg.makeGraphic(Std.int(w - 2), Std.int(BTN_H - 2), bg.color);
		// makeGraphic 会让子项 frame 重算但保持位置; 确保底板仍钉在组内原位。
		border.x = this.x;
		border.y = this.y;
		bg.x = this.x + 1;
		bg.y = this.y + 1;
		layoutLabel();
	}

	public var focused(default, set):Bool;

	function set_focused(v:Bool):Bool
	{
		_focused = v;
		applyState();
		return v;
	}

	override function update(elapsed:Float):Void
	{
		super.update(elapsed);
		var padY:Float = 6;
		#if (android || mobile)
		for (touch in FlxG.touches.list)
		{
			if (touch == null)
				continue;
			var over:Bool = touch.x >= x && touch.x <= x + width
				&& touch.y >= y - padY && touch.y <= y + height + padY;
			if (touch.justPressed && over && pressTouchId < 0)
				pressTouchId = touch.touchPointID;
			else if (touch.touchPointID == pressTouchId && touch.justReleased)
			{
				pressTouchId = -1;
				if (over)
					fire();
			}
			else if (touch.touchPointID == pressTouchId && !over)
				pressTouchId = -1;
		}
		#end
		if (FlxG.mouse.visible)
		{
			var over:Bool = FlxG.mouse.x >= x && FlxG.mouse.x <= x + width
				&& FlxG.mouse.y >= y - padY && FlxG.mouse.y <= y + height + padY;
			if (over != _hovered)
			{
				_hovered = over;
				applyState();
			}
			if (over && FlxG.mouse.justPressed)
				pressedMouse = true;
			else if (pressedMouse && FlxG.mouse.justReleased)
			{
				pressedMouse = false;
				if (over)
					fire();
			}
			else if (pressedMouse && !over && FlxG.mouse.justReleased)
				pressedMouse = false;
		}
	}

	function fire():Void
	{
		if (onClick != null)
		{
			FlxG.sound.play(Paths.sound('confirmMenu'), 0.7);
			onClick();
		}
	}
}
