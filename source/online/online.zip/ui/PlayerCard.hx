package online.ui;

import flixel.FlxG;
import flixel.FlxSprite;
import flixel.group.FlxSpriteGroup;
import flixel.text.FlxText;
import flixel.util.FlxColor;

/**
	玩家卡片 (房间大厅左栏 / 其它界面复用):
	- Psych 平面深底 + 细边框;
	- 头像 + 昵称 (测量截断) + 徽标行 (房主/准备/观战/队伍) + 彩色 ping;
	- 整卡可点 (tap 语义): 房主对他人卡片两次点击确认踢出 (第一次点亮
	  "再点一次确认踢出!", 3 秒内再点发送, 防误触), 踢出回调 onKickConfirmed;
	  其余卡片走 onTap (资料查看等扩展用)。
**/
class PlayerCard extends FlxSpriteGroup
{
	public static final CARD_H:Float = 56;

	public var playerId:String = "";
	public var isSelf:Bool = false;
	/** 普通点击回调 (资料查看等扩展用)。 */
	public var onTap:PlayerCard->Void = null;
	/** 房主二次确认踢出回调。 */
	public var onKickConfirmed:PlayerCard->Void = null;

	var bg:FlxSprite;
	var border:FlxSprite;
	var avatar:FlxSprite;
	var nameText:FlxText;
	var badgeText:FlxText;
	var pingText:FlxText;
	var armed:Bool = false;
	var armedTimer:Float = 0;
	var nickname:String = "";
	var wasHost:Bool = false;
	var isSpectator:Bool = false;
	var pressTouchId:Int = -1;
	var pressTouchStartX:Float = 0;
	var pressTouchStartY:Float = 0;
	var pressMouseStartX:Float = 0;
	var pressMouseStartY:Float = 0;
	/** 拖动超过该距离视为滚动手势, 不再触发 tap (与房间左栏滚动共存)。 */
	static inline var DRAG_TAP_TOLERANCE:Float = 18;
	var pressedMouse:Bool = false;

	public function new(w:Float, x:Float, y:Float)
	{
		super(x, y);
		border = new FlxSprite().makeGraphic(Std.int(w), Std.int(CARD_H), 0xFF3D4C6E);
		add(border);
		bg = new FlxSprite(1, 1).makeGraphic(Std.int(w - 2), Std.int(CARD_H - 2), 0xF2111828);
		add(bg);
		// 徽标行宽度: 右侧给 ping 留 58px (48 文本 + 10 边距), 避免 "[房主][观战]队1" 与 ping 重叠。
		nameText = OnlineLayout.makeText(58, 8, w - 118, "", OnlineLayout.FS_BODY, OnlineLayout.C_TEXT);
		add(nameText);
		badgeText = OnlineLayout.makeText(58, 8 + OnlineLayout.lineHeight(OnlineLayout.FS_BODY) - 2, w - 116, "", OnlineLayout.FS_SMALL, OnlineLayout.C_SUB);
		add(badgeText);
		pingText = OnlineLayout.makeText(0, 8, 48, "", OnlineLayout.FS_SMALL, OnlineLayout.C_SUB, RIGHT);
		add(pingText);
	}

	/** 用会话玩家数据刷新内容 (p 为 PlayerPublicInfo)。 */
	public function setPlayer(p:Dynamic):Void
	{
		playerId = Std.string(p.id);
		isSelf = playerId == online.client.OnlineSession.selfId;
		nickname = p.nickname == null ? "?" : Std.string(p.nickname);
		wasHost = p.isHost == true;
		isSpectator = Reflect.hasField(p, "isSpectator") && p.isSpectator == true;

		if (avatar != null)
		{
			remove(avatar);
			avatar.destroy();
			avatar = null;
		}
		avatar = AvatarSprite.make(p.avatar == null || p.avatar.length == 0 ? "bf" : Std.string(p.avatar), 20);
		avatar.setPosition(9, 8);
		add(avatar);

		nameText.text = OnlineLayout.truncate(nameText, nickname, nameText.fieldWidth);
		nameText.color = wasHost ? OnlineLayout.C_ACCENT : OnlineLayout.C_TEXT;

		var parts:Array<String> = [];
		if (wasHost)
			parts.push("[" + UIStyle.t('roomHost', '房主') + "]");
		if (isSpectator)
			parts.push("[" + UIStyle.t('roomSpectator', '观战') + "]");
		else if (p.isReady == true)
			parts.push("[" + UIStyle.t('roomReady', '准备') + "]");
		if (p.team != null && p.team >= 0)
			parts.push(UIStyle.t('roomTeam', '队') + (p.team + 1));
		// 徽标串按可用宽度实测截断 (长组合不再压到 ping)。
		badgeText.text = OnlineLayout.truncate(badgeText,
			parts.length > 0 ? parts.join(" ") : UIStyle.t('roomNoBadge', '—'), badgeText.fieldWidth);
		badgeText.color = isSpectator ? OnlineLayout.C_INFO : (p.isReady == true ? OnlineLayout.C_OK : OnlineLayout.C_SUB);

		var ping:Int = p.pingMs == null ? 0 : Std.int(p.pingMs);
		pingText.text = ping > 0 ? ping + "ms" : "";
		// FlxSpriteGroup 子项在 add 后是世界坐标：pingText 必须用 this.x + 面板内右缘偏移。
		pingText.x = this.x + border.width - pingText.width - 10;
		pingText.color = ping <= 0 ? OnlineLayout.C_SUB : (ping < 80 ? OnlineLayout.C_OK : (ping < 180 ? OnlineLayout.C_ACCENT : OnlineLayout.C_WARN));

		refreshBorder();
	}

	function refreshBorder():Void
	{
		border.color = armed ? 0xFFFF5555 : (kickable() ? 0xFF445C8C : 0xFF3D4C6E);
	}

	/** 房主且不是自己且不是房主本人 → 可点击确认踢出。 */
	function kickable():Bool
	{
		return online.client.OnlineSession.isHost && !isSelf && !wasHost;
	}

	override function update(elapsed:Float):Void
	{
		super.update(elapsed);
		if (armed)
		{
			armedTimer -= elapsed;
			if (armedTimer <= 0)
				setArmed(false);
		}

		// 整卡 tap 语义 (与 TextButton 相同: 按下在本卡上松开才触发, 滑出取消)。
		#if (android || mobile)
		for (touch in FlxG.touches.list)
		{
			if (touch == null)
				continue;
			var over:Bool = touch.x >= x && touch.x <= x + width && touch.y >= y && touch.y <= y + height;
			if (touch.justPressed && over && pressTouchId < 0)
			{
				pressTouchId = touch.touchPointID;
				pressTouchStartX = touch.x;
				pressTouchStartY = touch.y;
			}
			else if (touch.touchPointID == pressTouchId && touch.justReleased)
			{
				pressTouchId = -1;
				// 拖动超过容差 = 滚动卡片栏手势, 不是点击 (与 handleRailScroll 共存)。
				if (over && Math.abs(touch.x - pressTouchStartX) < DRAG_TAP_TOLERANCE
					&& Math.abs(touch.y - pressTouchStartY) < DRAG_TAP_TOLERANCE)
					handleTap();
			}
			else if (touch.touchPointID == pressTouchId && !over)
				pressTouchId = -1;
		}
		#end
		if (FlxG.mouse.visible)
		{
			var over:Bool = FlxG.mouse.overlaps(this);
			if (over && FlxG.mouse.justPressed)
			{
				pressedMouse = true;
				pressMouseStartX = FlxG.mouse.x;
				pressMouseStartY = FlxG.mouse.y;
			}
			else if (pressedMouse && FlxG.mouse.justReleased)
			{
				pressedMouse = false;
				if (over && Math.abs(FlxG.mouse.x - pressMouseStartX) < DRAG_TAP_TOLERANCE
					&& Math.abs(FlxG.mouse.y - pressMouseStartY) < DRAG_TAP_TOLERANCE)
					handleTap();
			}
			else if (pressedMouse && !over && FlxG.mouse.justReleased)
				pressedMouse = false;
		}
	}

	function handleTap():Void
	{
		if (armed)
		{
			setArmed(false);
			refreshBorder();
			if (onKickConfirmed != null)
				onKickConfirmed(this);
			return;
		}
		if (kickable())
		{
			setArmed(true);
			return;
		}
		if (onTap != null)
			onTap(this);
	}

	function setArmed(v:Bool):Void
	{
		armed = v;
		armedTimer = v ? 3.0 : 0;
		if (armed)
		{
			nameText.text = OnlineLayout.truncate(nameText, UIStyle.t('roomKickConfirm', '再点一次确认踢出!'), nameText.fieldWidth);
			nameText.color = OnlineLayout.C_WARN;
		}
		else
		{
			nameText.text = OnlineLayout.truncate(nameText, nickname, nameText.fieldWidth);
			nameText.color = wasHost ? OnlineLayout.C_ACCENT : OnlineLayout.C_TEXT;
		}
	}
}
