package online.ui;

import backend.ui.PsychUIInputText;
import flixel.FlxG;
import flixel.FlxSprite;
import flixel.group.FlxSpriteGroup;
import flixel.text.FlxText;
import flixel.util.FlxColor;

/**
	大厅聊天框 (PsychOnline ChatBox 适配, 扁平 Psych 风格):
	历史消息 + 输入框 + 发送按钮; 公告 / 加入离开 / 模组同步进度走同一消息流。
	Enter 发送, ESC 取消聚焦; 聚焦时优先处理键盘, 避免误触大厅快捷键。

	UI 重构要点 (原实现三处溢出):
	- 面板 OnlinePanel (扁平深底) 取代 GlassPanel;
	- 输入框走 styleInput 的容器约束模式 (旧版被无条件抬到 440px, 直接压出 320px 面板);
	- 历史区 wordWrap + 按可用高度丢弃最旧行, 长消息既不横向溢出也不顶穿面板上沿。
**/
class LobbyChatBox extends FlxSpriteGroup
{
	/** 发送回调, 返回 true 表示已处理 (清空输入)。 */
	public var onSend:String->Void = null;

	var history:FlxText;
	var input:PsychUIInputText;
	var sendBtn:TextButton;
	var lines:Array<String> = [];
	static final MAX_LINES:Int = 30;
	static final MAX_CHARS:Int = 2600;

	/** 历史区顶部起点 (提示行下方)。 */
	static inline var HISTORY_TOP:Float = 26;

	/** 历史区可用高度 (面板内, 输入框上沿以上)。 */
	var historyMaxH:Float = 0;

	public var focused(get, never):Bool;

	function get_focused():Bool
	{
		return input != null && PsychUIInputText.focusOn == input;
	}

	public function new(x:Float, y:Float, w:Float, h:Float)
	{
		// FlxSpriteGroup 的 add() 会把子项平移到"组坐标"：
		// 这里先以 (0,0) 创建组、子项全部按本地坐标摆放，最后再一次性移到目标位置，
		// 避免后续对子项的本地坐标赋值被误当成世界坐标（旧版把 history 顶到屏幕顶部、
		// 输入框宽度算到送出发送按钮外面）。
		super(0, 0);
		var panel:OnlinePanel = new OnlinePanel(0, 0, w, h);
		add(panel);

		var hint:FlxText = OnlineLayout.makeText(10, 6, w - 20,
			online.ui.UIStyle.t('chatHint', '聊天 (点击输入 · Enter 发送 · TAB 聚焦 · ESC 取消)'), 11, OnlineLayout.C_SUB, LEFT);
		add(hint);

		history = OnlineLayout.makeText(12, HISTORY_TOP, w - 24, "", 13, 0xFFF0F0E1, LEFT);
		// 长消息按面板宽度换行, 不再横向溢出。
		history.wordWrap = true;
		add(history);

		// 发送按钮先建 (要用它的实测宽度给输入框留位), 命中高度补到 ≥40px。
		sendBtn = new TextButton(0, 0, online.ui.UIStyle.t('chatSend', '发送'), function() send(), 18);
		sendBtn.touchPadY = Math.max(4, (OnlineLayout.TOUCH_MIN_H - sendBtn.height) / 2);
		sendBtn.x = w - 12 - sendBtn.width;
		sendBtn.y = h - 40;
		add(sendBtn);

		// 输入框宽度按容器算 (左内边距 10 + 与发送按钮留 12px 间隙), styleInput 只在上限内钳制。
		var inputW:Int = Std.int(Math.max(120, sendBtn.x - 10 - 12));
		input = new PsychUIInputText(10, h - 42, inputW, "", 16, UIStyle.inputFontKey());
		UIStyle.styleInput(input, inputW);
		add(input);

		historyMaxH = Math.max(OnlineLayout.lineHeight(13), (h - 42) - 8 - HISTORY_TOP);

		this.x = x;
		this.y = y;
	}

	public function addLine(text:String):Void
	{
		if (text == null)
			return;
		lines.push(text);
		while (lines.length > MAX_LINES)
			lines.shift();
		refreshHistory();
	}

	/**
		重排历史区: wordWrap 下的实际高度只能实测, 因此从最新消息往前加行,
		一旦超过可用高度就停 —— 内容永远贴住输入框上沿, 绝不顶穿面板上沿。
	**/
	function refreshHistory():Void
	{
		if (history == null)
			return;
		var shown:Array<String> = [];
		var i:Int = lines.length - 1;
		while (i >= 0)
		{
			shown.unshift(lines[i]);
			var joined:String = shown.join("\n");
			if (joined.length > MAX_CHARS && shown.length > 1)
			{
				shown.shift();
				break;
			}
			history.text = shown.join("\n");
			if (history.height > historyMaxH && shown.length > 1)
			{
				shown.shift();
				break;
			}
			i--;
		}
		history.text = shown.join("\n");
		// 最新一行贴住输入框上沿 (历史短时从顶部开始)。
		// history 是 FlxSpriteGroup 子项，add 后坐标已是世界坐标，必须加回组位置 this.y。
		history.y = this.y + Math.max(HISTORY_TOP, HISTORY_TOP + historyMaxH - history.height);
	}

	function send():Void
	{
		var text:String = StringTools.trim(input.text);
		if (text.length == 0)
			return;
		if (onSend != null)
			onSend(text);
		input.text = "";
	}

	public function focusInput():Void
	{
		if (input != null)
			PsychUIInputText.focusOn = input;
	}

	public function resetChat():Void
	{
		lines = [];
		history.text = "";
		history.y = this.y + HISTORY_TOP;
	}

	override function update(elapsed:Float)
	{
		super.update(elapsed);
		if (input == null)
			return;
		var isFocused:Bool = PsychUIInputText.focusOn == input;
		if (isFocused && FlxG.keys.justPressed.ENTER)
			send();
		if (isFocused && FlxG.keys.justPressed.ESCAPE)
			PsychUIInputText.focusOn = null;
	}
}
