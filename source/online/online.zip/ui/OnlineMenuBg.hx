package online.ui;

import backend.seiun.ui.MenuFX;
import ClientPrefs;
import flixel.FlxG;
import flixel.FlxSprite;
import flixel.FlxState;
import flixel.group.FlxSpriteGroup;
import flixel.util.FlxColor;

/**
	联机页面主菜单风格背景 (与主界面 MainMenuState 一致):
	- menuBG 底图 + 可选 Seiun aurora 漂移光晕 (MenuFX);
	- 叠加可调透明度的黑色遮罩, 保证前景文字可读;
	- 供联机结算 / 登录页等使用 (替换原先的游戏舞台 OnlineStageBg)。
**/
class OnlineMenuBg extends FlxSpriteGroup
{
	var glowA:FlxSprite = null;
	var glowB:FlxSprite = null;

	public static function attach(target:FlxState, ?dim:Float = 0.55):OnlineMenuBg
	{
		var bg:OnlineMenuBg = new OnlineMenuBg();
		target.add(bg);
		var overlay:FlxSprite = new FlxSprite().makeGraphic(FlxG.width, FlxG.height, FlxColor.BLACK);
		overlay.alpha = dim;
		overlay.scrollFactor.set();
		target.add(overlay);
		return bg;
	}

	public function new()
	{
		super(0, 0);

		// 与 MainMenuState 相同的底图构图
		var bg:FlxSprite = new FlxSprite(-80).loadGraphic(Paths.image('menuBG'));
		bg.scrollFactor.set(0, 0);
		bg.setGraphicSize(Std.int(bg.width * 1.175));
		bg.updateHitbox();
		bg.screenCenter();
		bg.antialiasing = ClientPrefs.data.globalAntialiasing;
		add(bg);

		if (MenuFX.enabled())
		{
			glowA = MenuFX.makeGlow(920, 0xFFFD719B, 0.3);
			glowA.blend = ADD;
			glowA.scrollFactor.set(0, 0);
			glowA.screenCenter();
			add(glowA);

			glowB = MenuFX.makeGlow(760, 0xFF8A5CFF, 0.24);
			glowB.blend = ADD;
			glowB.scrollFactor.set(0, 0);
			glowB.screenCenter();
			add(glowB);
		}
	}

	override function update(elapsed:Float)
	{
		super.update(elapsed);
		if (glowA != null)
			MenuFX.driftGlow(glowA, MenuFX.time, FlxG.width * 0.28, FlxG.height * 0.42,
				90, 46, 0.21, 0.17, 0.0, 1.3, 0.32, 0.1, 0.5, 2.1, 0xFFFD719B, 0.06);
		if (glowB != null)
			MenuFX.driftGlow(glowB, MenuFX.time, FlxG.width * 0.72, FlxG.height * 0.55,
				110, 60, 0.17, 0.13, 2.1, 0.4, 0.26, 0.08, 1.7, 0.0, 0xFF8A5CFF, 0.05);
	}
}
