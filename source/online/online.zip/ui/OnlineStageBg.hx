package online.ui;

import BGSprite;
import Character;
import ClientPrefs;
import flixel.FlxG;
import flixel.FlxSprite;
import flixel.FlxState;
import flixel.group.FlxSpriteGroup;
import flixel.tweens.FlxEase;
import flixel.tweens.FlxTween;
import flixel.util.FlxColor;

/**
	联机菜单背景: 真实游戏舞台 (默认 stage) + BF/GF/老爹 三人 idle 舞蹈。
	人物按菜单构图站位 (老爹左 / 女友中 / BF 右), 放大贴底 + 轻微上下浮动。
	与 BaseStage 的资产一致, 但不依赖 PlayState, 可挂到任意联机状态。
**/
class OnlineStageBg extends FlxSpriteGroup
{
	public static function attach(target:FlxState, ?dim:Float = 0.62):OnlineStageBg
	{
		var bg:OnlineStageBg = new OnlineStageBg();
		target.add(bg);
		var overlay:FlxSprite = new FlxSprite().makeGraphic(FlxG.width, FlxG.height, FlxColor.BLACK);
		overlay.alpha = dim;
		target.add(overlay);
		return bg;
	}

	var bf:Character;
	var gf:Character;
	var dad:Character;
	var beatTimer:Float = 0;
	var beatInterval:Float = 0.5;

	public function new()
	{
		super(0, 0);

		// 背景铺满 (与 BaseStage.create() 相同的资产)
		var bg:BGSprite = new BGSprite('stageback', -600, -200, 0.9, 0.9);
		bg.setGraphicSize(Std.int(bg.width * 1.15));
		bg.updateHitbox();
		add(bg);

		var stageFront:BGSprite = new BGSprite('stagefront', -650, 600, 0.9, 0.9);
		stageFront.setGraphicSize(Std.int(stageFront.width * 1.1));
		stageFront.updateHitbox();
		add(stageFront);

		if (!ClientPrefs.data.lowQuality)
		{
			var stageLight:BGSprite = new BGSprite('stage_light', -125, -100, 0.9, 0.9);
			stageLight.setGraphicSize(Std.int(stageLight.width * 1.1));
			stageLight.updateHitbox();
			add(stageLight);

			var stageLight2:BGSprite = new BGSprite('stage_light', 1225, -100, 0.9, 0.9);
			stageLight2.setGraphicSize(Std.int(stageLight2.width * 1.1));
			stageLight2.updateHitbox();
			stageLight2.flipX = true;
			add(stageLight2);

			var stageCurtains:BGSprite = new BGSprite('stagecurtains', -500, -300, 1.3, 1.3);
			stageCurtains.setGraphicSize(Std.int(stageCurtains.width * 0.9));
			stageCurtains.updateHitbox();
			add(stageCurtains);
		}

		// 三人组: 菜单构图站位 (左 Dad / 中 GF / 右 BF), 放大贴底
		dad = new Character(0, 0, 'dad');
		placeCharacter(dad, 150, 1.12);
		add(dad);
		gf = new Character(0, 0, 'gf');
		placeCharacter(gf, 600, 0.82);
		add(gf);
		bf = new Character(0, 0, 'bf');
		placeCharacter(bf, 1030, 1.12);
		add(bf);

		gf.dance();
		dad.dance();
		bf.dance();

		floatCharacter(dad, 0.0);
		floatCharacter(gf, 0.7);
		floatCharacter(bf, 1.4);
	}

	/** 以脚底为锚点放置人物: x 为角色中心, 脚底贴屏幕底部 (y 是精灵左上角)。 */
	function placeCharacter(c:Character, centerX:Float, scale:Float):Void
	{
		c.setGraphicSize(Std.int(c.width * scale));
		c.updateHitbox();
		c.x = centerX - c.width / 2;
		c.y = FlxG.height - c.height - 15;
	}

	/** 轻微上下浮动, 让背景更生动。 */
	function floatCharacter(c:Character, phase:Float):Void
	{
		var baseY:Float = c.y;
		FlxTween.tween(c, {y: baseY - 8}, 1.1 + phase * 0.3, {
			ease: FlxEase.sineInOut,
			type: FlxTweenType.PINGPONG,
			startDelay: phase
		});
	}

	override function update(elapsed:Float)
	{
		super.update(elapsed);
		beatTimer += elapsed;
		if (beatTimer >= beatInterval)
		{
			beatTimer = 0;
			gf.dance();
			dad.dance();
			bf.dance();
		}
	}
}
