package online.ui;

import flixel.FlxG;
import flixel.FlxObject;

/**
	统一指针 (鼠标 + 触屏) tap 语义助手 —— UI 重构新增。

	为什么需要它: 联机各页原来遍地是 `FlxG.mouse.justPressed && FlxG.mouse.overlaps(txt)`,
	三个问题:
	1. 安卓完全没有 FlxG.touches 分支 (设置页/资料页/列表页在手机上点不动);
	2. justPressed 立即触发 = 按下即生效, 手指稍滑就误触邻行;
	3. 命中区就是文字自身高度 (12~16px), 远低于 40px 触屏标准。

	用法 (每个 State/Substate 的 update 开头调用一次 poll, 之后随便问几次 tapped):
	```haxe
	OnlinePointer.poll();
	if (OnlinePointer.tapped(row.x, row.y, row.width, row.height)) select(i);
	```

	tap 判定: 按下点与松开点都必须落在同一矩形内 (滑出即取消), 与 TextButton 的语义一致。
**/
class OnlinePointer
{
	/** 本帧指针坐标 (无指针时为 -1)。 */
	public static var x:Float = -1;

	public static var y:Float = -1;

	public static var pressed:Bool = false;
	public static var justPressed:Bool = false;
	public static var justReleased:Bool = false;

	/** 本帧是否已有人消费掉这次 tap (避免一次点击同时命中多个控件)。 */
	static var consumedTick:Int = -1;

	static var pressX:Float = -1;
	static var pressY:Float = -1;
	static var polledTick:Int = -1;

	/** 每帧调用一次 (重复调用同一帧无副作用)。 */
	public static function poll():Void
	{
		if (polledTick == FlxG.game.ticks)
			return;
		polledTick = FlxG.game.ticks;
		x = -1;
		y = -1;
		pressed = false;
		justPressed = false;
		justReleased = false;

		#if (android || mobile)
		for (touch in FlxG.touches.list)
		{
			if (touch == null)
				continue;
			// 只认第一根还在活动 (按下/持续/刚松开) 的手指。
			if (!touch.pressed && !touch.justPressed && !touch.justReleased)
				continue;
			x = touch.x;
			y = touch.y;
			pressed = touch.pressed;
			justPressed = touch.justPressed;
			justReleased = touch.justReleased;
			break;
		}
		#end
		if (x < 0 && FlxG.mouse != null)
		{
			x = FlxG.mouse.x;
			y = FlxG.mouse.y;
			pressed = FlxG.mouse.pressed;
			justPressed = FlxG.mouse.justPressed;
			justReleased = FlxG.mouse.justReleased;
		}

		if (justPressed)
		{
			pressX = x;
			pressY = y;
		}
	}

	/** 指针是否悬停在矩形上 (命中高度不足 minH 时上下对称补足)。 */
	public static function over(rx:Float, ry:Float, rw:Float, rh:Float, ?minH:Float = 0):Bool
	{
		if (x < 0)
			return false;
		if (minH <= 0)
			minH = OnlineLayout.TOUCH_MIN_H;
		var pad:Float = Math.max(0, (minH - rh) / 2);
		return x >= rx && x <= rx + rw && y >= ry - pad && y <= ry + rh + pad;
	}

	static function inRect(px:Float, py:Float, rx:Float, ry:Float, rw:Float, rh:Float, minH:Float):Bool
	{
		if (px < 0)
			return false;
		var pad:Float = Math.max(0, (minH - rh) / 2);
		return px >= rx && px <= rx + rw && py >= ry - pad && py <= ry + rh + pad;
	}

	/**
		tap 判定: 本帧松开, 且按下点与松开点都在该矩形内 (含 ≥minH 命中补偿)。
		一帧内只有第一个命中者拿到 true, 后续调用返回 false (防止重叠控件双触发)。
	**/
	public static function tapped(rx:Float, ry:Float, rw:Float, rh:Float, ?minH:Float = 0):Bool
	{
		if (!justReleased || consumedTick == FlxG.game.ticks)
			return false;
		if (minH <= 0)
			minH = OnlineLayout.TOUCH_MIN_H;
		if (!inRect(x, y, rx, ry, rw, rh, minH))
			return false;
		if (!inRect(pressX, pressY, rx, ry, rw, rh, minH))
			return false; // 按下点在别处 = 滑进来的, 不算 tap
		consumedTick = FlxG.game.ticks;
		return true;
	}

	/** FlxObject 便捷重载 (用对象自身的 x/y/width/height)。 */
	public static function tappedOn(obj:FlxObject, ?minH:Float = 0):Bool
	{
		if (obj == null || !obj.visible)
			return false;
		return tapped(obj.x, obj.y, obj.width, obj.height, minH);
	}

	/** 悬停便捷重载。 */
	public static function overOn(obj:FlxObject, ?minH:Float = 0):Bool
	{
		if (obj == null || !obj.visible)
			return false;
		return over(obj.x, obj.y, obj.width, obj.height, minH);
	}
}
