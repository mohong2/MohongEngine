package online.ui;

import flixel.FlxG;
import flixel.text.FlxText;
import flixel.text.FlxText.FlxTextAlign;
import flixel.util.FlxColor;

/**
	联机 UI 布局标准 (重构新增, 全部界面共用):
	- 字号/行高/间距常量: 中文字形按 1.5× 字号行高, 杜绝"按字符数估宽"的旧算法;
	- 测量后布局: 任何会溢出的文本必须经过 truncate() 按真实 textWidth 截断;
	- 统一文本工厂: 全部走 Paths.languageFont() + 黑描边, 各界面不再各写一套 setFormat。

	坐标约定: 以 FlxG.width/height 为准 (不假定 1280x720), 界面 create 时用局部常量
	计算区域 (顶栏 / 左栏 / 舞台 / 右栏 / 底栏), 窄屏 (width < 1000) 走降级布局。
**/
class OnlineLayout
{
	// ── 尺寸标准 ──────────────────────────────────────────

	/** 中文字形行高系数 (实测 15px 字号 + 描边需 ~22px)。 */
	public static inline var LINE_RATIO:Float = 1.5;

	/** 触屏最小命中高度 (px)。 */
	public static inline var TOUCH_MIN_H:Float = 40;

	/** 页面统一内边距。 */
	public static inline var PAD:Float = 16;

	/** 窄屏阈值: 低于此宽度启用降级布局 (左右栏折叠)。 */
	public static inline var NARROW_W:Float = 1000;

	// 字号标准
	public static inline var FS_TITLE:Int = 26;
	public static inline var FS_SECTION:Int = 16;
	public static inline var FS_BODY:Int = 14;
	public static inline var FS_SMALL:Int = 12;
	public static inline var FS_CHIP:Int = 12;

	public static function lineHeight(size:Float):Float
	{
		return Math.ceil(size * LINE_RATIO);
	}

	// ── 统一色板 (Psych 深底 + 少量个性强调色) ────────────

	public static var C_TEXT:FlxColor = 0xFFEFF4FF;
	public static var C_SUB:FlxColor = 0xFFAABEE6;
	public static var C_ACCENT:FlxColor = 0xFFFFD24A;   // 房主/强调
	public static var C_OK:FlxColor = 0xFF7CFF9B;       // 已准备/正常
	public static var C_INFO:FlxColor = 0xFF9BC8FF;     // 观战/信息
	public static var C_WARN:FlxColor = 0xFFFF7C7C;     // 高延迟/警示

	// ── 工厂 ─────────────────────────────────────────────

	/** 标准文本: languageFont + 黑描边, 描边粗细随字号。 */
	public static function makeText(x:Float, y:Float, w:Float, str:String, size:Int, ?color:FlxColor = 0xFFFFFFFF, ?align:FlxTextAlign = LEFT):FlxText
	{
		var t:FlxText = new FlxText(x, y, w, str, size);
		t.setFormat(Paths.languageFont(), size, color, align, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		t.borderSize = Math.max(1, size / 14);
		return t;
	}

	/**
		测量截断: 按真实 textWidth 逐字截断到 maxW (中英文/表情同样可靠)。
		ft 必须已 setFormat; 返回最终显示串。
	**/
	public static function truncate(ft:FlxText, raw:String, maxW:Float):String
	{
		if (raw == null)
			raw = "";
		ft.text = raw;
		if (ft.textField.textWidth <= maxW)
			return raw;
		var cut:Int = raw.length;
		while (cut > 1)
		{
			ft.text = raw.substr(0, cut) + "…";
			if (ft.textField.textWidth <= maxW)
				break;
			cut--;
		}
		return ft.text;
	}

	/** 按钮行布局: 实测宽度均匀排布在 [x, x+maxW] 内, 不再互相挤爆。 */
	public static function layoutButtonRow(buttons:Array<TextButton>, x:Float, y:Float, maxW:Float):Void
	{
		if (buttons == null || buttons.length == 0)
			return;
		var total:Float = 0;
		for (b in buttons)
		{
			b.refresh();
			total += b.width;
		}
		var gap:Float = buttons.length > 1
			? Math.min(40, (maxW - total) / (buttons.length + 1))
			: (maxW - total) / 2;
		if (gap < 6)
			gap = 6;
		var px:Float = x + gap;
		var overflow:Float = total + gap * (buttons.length + 1) - maxW;
		if (overflow > 0)
			px -= overflow / 2;
		for (b in buttons)
		{
			b.x = px;
			b.y = y;
			px += b.width + gap;
		}
	}

	/**
		水平居中的多列起始 x: 传各列宽度与列间距, 返回每列的 x。
		用来干掉各页写死的 190/660/690 这类"只在 1280 宽下正确"的列坐标。
	**/
	public static function centeredColumns(widths:Array<Float>, gap:Float):Array<Float>
	{
		var total:Float = 0;
		for (w in widths)
			total += w;
		total += gap * Math.max(0, widths.length - 1);
		var x:Float = Math.max(PAD, (FlxG.width - total) / 2);
		var out:Array<Float> = [];
		for (w in widths)
		{
			out.push(x);
			x += w + gap;
		}
		return out;
	}

	/** 把按钮的触屏命中高度补到 TOUCH_MIN_H (小字号按钮必调)。 */
	public static function padTouch(btn:TextButton):Void
	{
		if (btn == null)
			return;
		btn.refresh();
		btn.touchPadY = Math.max(4, (TOUCH_MIN_H - btn.height) / 2);
	}

	/** 一次给多个按钮补命中高度。 */
	public static function padTouchAll(btns:Array<TextButton>):Void
	{
		for (b in btns)
			padTouch(b);
	}

	/** 底部安全区: 带虚拟按键的平台把底栏抬高。 */
	public static function bottomSafeY():Float
	{
		#if android
		return FlxG.height - 8;
		#else
		return FlxG.height - 8;
		#end
	}
}
