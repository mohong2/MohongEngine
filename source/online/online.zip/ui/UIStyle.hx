package online.ui;

import backend.ui.PsychUIInputText;
import flixel.FlxBasic;
import flixel.FlxG;
import flixel.text.FlxText;
import flixel.util.FlxColor;
import online.shared.SeiunProtocol;
import openfl.events.KeyboardEvent;

/**
	联机 UI 统一风格工具 (原 OnlineOptionsState.styleInput 迁出):
	玻璃输入框 / 标题 / 徽标 / i18n / 错误码本地化, 供大厅与各 Substate 复用。
**/
class UIStyle
{
	// ── i18n ──────────────────────────────────────────────

	/** 联机文本统一入口: `Language.get('online.' + key, fallback)`。客户端 UI 禁止写死中文。 */
	public static function t(key:String, fallback:String):String
	{
		return Language.get('online.' + key, fallback);
	}

	/** 已知协议错误码 → 本地化文本; 未知错误码回退服务器原文 (服务器公告保持原文)。 */
	public static function errText(code:Dynamic, fallback:String):String
	{
		var c:Int = -1;
		if (code != null)
		{
			if (Std.isOfType(code, Int))
				c = cast code;
			else
			{
				var parsed:Null<Int> = Std.parseInt(Std.string(code));
				if (parsed != null)
					c = parsed;
			}
		}
		var key:String = switch (c)
		{
			case SeiunProtocol.ERR_BAD_MAGIC: 'errBadMagic';
			case SeiunProtocol.ERR_PROTOCOL_VERSION: 'errProtocolVersion';
			case SeiunProtocol.ERR_BAD_FINGERPRINT: 'errBadFingerprint';
			case SeiunProtocol.ERR_AUTH_REQUIRED: 'errAuthRequired';
			case SeiunProtocol.ERR_AUTH_FAILED: 'errAuthFailed';
			case SeiunProtocol.ERR_ROOM_NOT_FOUND: 'errRoomNotFound';
			case SeiunProtocol.ERR_ROOM_FULL: 'errRoomFull';
			case SeiunProtocol.ERR_ROOM_PASSWORD: 'errRoomPassword';
			case SeiunProtocol.ERR_CHART_MISMATCH: 'errChartMismatch';
			case SeiunProtocol.ERR_ANTICHEAT_VIOLATION: 'errAnticheat';
			case SeiunProtocol.ERR_CLOCK_JUMP: 'errClockJump';
			case SeiunProtocol.ERR_RATE_LIMIT: 'errRateLimit';
			case SeiunProtocol.ERR_BAD_PACKET: 'errBadPacket';
			case SeiunProtocol.ERR_BANNED: 'errBanned';
			case SeiunProtocol.ERR_NOT_AUTHORIZED: 'errNotAuthorized';
			case SeiunProtocol.ERR_SERVER_SHUTTING_DOWN: 'errShuttingDown';
			default: null;
		}
		if (key == null)
			return fallback == null ? '' : fallback;
		return t(key, fallback);
	}

	// ── 输入框 ────────────────────────────────────────────

	/**
		PsychUIInputText 构造用的字体 key (注意它内部走 Paths.font(key), 只能传裸 key,
		不能传 Paths.languageFont() 那种完整路径, 否则会拼成 assets/fonts/assets/fonts/...)。
		随语言包切换: 中文包 vcrcn, 英文包 vcr。
	**/
	public static function inputFontKey():String
	{
		return Language.get("ttf", "vcr") + ".ttf";
	}

	/**
		统一输入框样式: 中文字体 + 暗色底 + 亮色文字 + 文字垂直/水平居中。

		宽度规则 (旧版无条件抬到 440 是"聊天框/昵称框/地址框压出面板"的共同根因):
		- 不传 maxWidth: 保持历史行为 (表单主输入框下限 440);
		- 传 maxWidth (容器可用宽度): 尊重调用方宽度, 只在 [120, maxWidth] 内钳制, 绝不越过容器右缘。
	**/
	public static function styleInput(input:PsychUIInputText, ?maxWidth:Float = 0):Void
	{
		input.textObj.font = Paths.languageFont();
		input.textObj.color = 0xFFE8F0FF;
		input.behindText.color = 0xFF16203A;
		input.caret.color = 0xFFE8F0FF;
		if (maxWidth > 0)
		{
			// 容器约束模式: 输入框底板会比 fieldWidth 宽 2px, 这里预留出来。
			var cap:Int = Std.int(Math.max(120, maxWidth - 2));
			if (input.fieldWidth > cap)
				input.fieldWidth = cap;
			if (input.fieldWidth < 120)
				input.fieldWidth = Std.int(Math.min(120, cap));
		}
		else if (input.fieldWidth < 440)
			input.fieldWidth = 440;
		// 重新按新字体重排, 刷新边界数据。
		input.text = input.text;
		// 按字号确定性计算行高与框高: 中文字形约 1.4~1.5× 字号,
		// 不能依赖 FlxText.height (字体切换后度量可能仍是旧的), 否则文字溢出框外。
		var size:Float = input.textObj.size;
		var lineH:Float = Math.ceil(size * 1.5);
		var needH:Int = Std.int(Math.max(lineH + 10, 30));
		input.setGraphicSize(input.fieldWidth + 2, needH);
		input.updateHitbox();
		// 左右留 6px 内边距, 垂直方向按行高在框内居中 —— 修"文字顶在框上/偏上"的对不齐问题。
		// 注意: FlxSpriteGroup 的子对象是"世界坐标" (add 时已按组位置平移), 直接写 textObj.x=6
		// 会把所有输入框的文字钉到屏幕左上角; 这里只设"相对输入框的偏移", 由 PsychUIInputText
		// 的 set_x/set_y 在组移动时自动重贴, alignText() 立即生效。
		input.textOffsetX = 6;
		input.textOffsetY = Math.max(1, Math.floor((needH - 2 - lineH) / 2));
		input.alignText();
		// 失焦时用暗色描边, 聚焦时 updateFocusOutline 会刷成高亮蓝。
		if (input.bg != null)
			input.bg.color = 0xFF1A2233;
	}

	/** 输入框聚焦描边: 含输入框的页面在 update() 中每帧调用。 */
	public static function updateFocusOutline(input:PsychUIInputText):Void
	{
		if (input == null || input.bg == null)
			return;
		var focused:Bool = PsychUIInputText.focusOn == input;
		var target:Int = focused ? 0xFF66B8FF : 0xFF1A2233;
		if (input.bg.color != target)
			input.bg.color = target;
	}

	/** 统一的标题文本。 */
	public static function makeTitle(text:String, size:Int = 30):FlxText
	{
		var t:FlxText = new FlxText(0, 24, FlxG.width, text, size);
		t.setFormat(Paths.languageFont(), size, FlxColor.WHITE, CENTER, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		return t;
	}

	/** 小徽标文本 (房间设置总览行用)。 */
	public static function makeChip(text:String, ?color:Int = 0xFFD8E4FF):FlxText
	{
		var t:FlxText = new FlxText(0, 0, 0, text, 13);
		t.setFormat(Paths.languageFont(), 13, color, CENTER, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		t.alpha = 0.92;
		return t;
	}

	/** 提示文本 (灰蓝色, 面板内小标题)。 */
	public static function makeHint(text:String, w:Float, size:Int = 14):FlxText
	{
		var t:FlxText = new FlxText(0, 0, w, text, size);
		t.setFormat(Paths.languageFont(), size, FlxColor.fromRGB(170, 190, 230), LEFT);
		return t;
	}

	/** 是否有输入框正在聚焦 (状态/Substate 用它避免 Enter/ESC 与打字冲突)。 */
	public static function anyInputFocused():Bool
	{
		return PsychUIInputText.focusOn != null;
	}

	/** 第一次 ESC 只取消输入框聚焦, 不关闭页面。 */
	public static function releaseInputFocus():Void
	{
		if (PsychUIInputText.focusOn != null)
			PsychUIInputText.focusOn = null;
	}

	// ── ESC 守卫: 输入框自己会在 KEY_DOWN 里清掉 focusOn, 等 update 时已无从判断 ──
	// 因此在 stage 监听器里抢在输入框之前记下"这次 ESC 是取消聚焦", 状态据此不关闭页面。
	static var escGuardTick:Int = -1;
	static var escGuardInstalled:Bool = false;

	static function onStageEscape(e:KeyboardEvent):Void
	{
		if (e.keyCode == 27 && PsychUIInputText.focusOn != null)
			escGuardTick = FlxG.game.ticks;
	}

	/** 在包含 PsychUIInputText 的 State/Substate 的 create() 开头调用。 */
	public static function installInputEscapeGuard():Void
	{
		// 让无头可编译的 OnlineStrings (GameClient 等) 跟随当前语言。
		online.shared.OnlineStrings.setLocale(ClientPrefs.data.language);
		if (!escGuardInstalled)
		{
			escGuardInstalled = true;
			try
			{
				FlxG.stage.addEventListener(KeyboardEvent.KEY_DOWN, onStageEscape);
			}
			catch (e:Dynamic) {}
		}
	}

	/** 本帧刚用 ESC 取消过输入焦点时返回 true (BACK 应放行一次, 不关闭页面)。 */
	public static function consumedInputEscape():Bool
	{
		return escGuardTick == FlxG.game.ticks;
	}

	/**
		清空并销毁组内所有成员。
		FlxTypedGroup.clear() 只解绑不 destroy, 直接 clear 会泄漏角色/头像
		(每个 Character 都带大量动画帧), 大厅反复刷新会越用越卡。
	**/
	public static function clearAndDestroy(group:Dynamic):Void
	{
		if (group == null)
			return;
		try
		{
			var members:Array<Dynamic> = cast group.members;
			if (members != null)
			{
				for (m in members)
				{
					if (m != null && Std.isOfType(m, FlxBasic))
						cast(m, FlxBasic).destroy();
				}
			}
		}
		catch (e:Dynamic) {}
		try
		{
			group.clear();
		}
		catch (e:Dynamic) {}
	}
}
