package options;

import backend.MusicBeatState;
import flixel.addons.display.FlxBackdrop;
import states.MainMenuState;
#if cpp
import Discord.DiscordClient;
#end
import flash.text.TextField;
import flixel.addons.display.FlxGridOverlay;
import lime.utils.Assets;
import flixel.FlxSubState;
import flash.text.TextField;
 
import flixel.util.FlxSave;
import haxe.Json;
import flixel.input.keyboard.FlxKey;
import flixel.graphics.FlxGraphic;
import Controls;

using StringTools;

class OptionsState extends MusicBeatState
{	
	private var mouseOverOption:Int = -1;

	var optionIds:Array<String> = ['notecolor', 'controls', 'adjust', 'graphics', 'visuals', 'gameplay', 'extra_settings'];
	
	var optionTexts:Array<String> = [
		Language.get("option.notecolor", "Note Colors"),
		Language.get("option.controls", "Controls"),
		Language.get("option.adjust", "Adjust Delay and Combo"),
		Language.get("option.graphics", "Graphics"),
		Language.get("option.visuals", "Visuals and UI"),
		Language.get("option.gameplay", "Gameplay"),
		Language.get("option.extra_settings", "Extra setting")
	];
	
	private var grpOptions:FlxTypedGroup<FlxText>;
	private static var curSelected:Int = 0;
	public static var menuBG:FlxSprite;
	public static var onPlayState:Bool = false;

	function openSelectedSubstate(id:String) {
		switch(id) {
			case 'notecolor':
				#if android
				removeVirtualPad();
				#end
				openSubState(new options.NotesSubState());
			case 'controls':
				#if android
				removeVirtualPad();
				#end
				openSubState(new options.ControlsSubState());
			case 'graphics':
				#if android
				removeVirtualPad();
				#end
				openSubState(new options.GraphicsSettingsSubState());
			case 'visuals':
				#if android
				removeVirtualPad();
				#end
				openSubState(new options.VisualsUISubState());
			case 'gameplay':
				#if android
				removeVirtualPad();
				#end
				openSubState(new options.GameplaySettingsSubState());
			case 'extra_settings':
				#if android
				removeVirtualPad();
				#end
				openSubState(new options.Extrasettings());
			case 'adjust':
				LoadingState.loadAndSwitchState(new options.NoteOffsetState());
		}
	}

	private var selectorLeft:FlxText; 
	private var selectorRight:FlxText;

	override function create() {
		#if desktop
		DiscordClient.changePresence("Options Menu", null);
		#end

		var bg:FlxSprite = new FlxSprite().loadGraphic(Paths.image('menuDesat'));
		bg.color = 0xff17719b;
		bg.screenCenter();
		bg.antialiasing = ClientPrefs.data.globalAntialiasing;
		add(bg);
		
		var grid:FlxBackdrop = new FlxBackdrop(FlxGridOverlay.createGrid(80, 80, 160, 160, true, 0x33FFFFFF, 0x0));
		grid.velocity.set(40, 40);
		grid.alpha = 0;
		FlxTween.tween(grid, {alpha: 1}, 0.5, {ease: FlxEase.quadOut});
		add(grid);
		
		grpOptions = new FlxTypedGroup<FlxText>();
		add(grpOptions);
		

		for (i in 0...optionIds.length)
		{
			var optionText:FlxText = new FlxText(150, 0, 0, optionTexts[i], 32);
			 optionText.setFormat(
            Paths.optionsfont(),   
            50,                
            FlxColor.WHITE,           
            LEFT,                     
            FlxTextBorderStyle.OUTLINE, 
            FlxColor.BLACK            
        );
			optionText.borderSize = 2.5;
			optionText.screenCenter(Y);
			optionText.y += (100 * (i - (optionIds.length / 2))) + 50;
			grpOptions.add(optionText);
		}
		selectorLeft = new FlxText(0, 0, 0, ">", 32);
		selectorLeft.setFormat(Paths.optionsfont(), 50, FlxColor.WHITE, LEFT, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		selectorLeft.borderSize = 2.5;
		add(selectorLeft);
		

		selectorRight = new FlxText(0, 0, 0, "<", 32);
		selectorRight.setFormat(Paths.optionsfont(), 50, FlxColor.WHITE, LEFT, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		selectorRight.borderSize = 2.5;
		add(selectorRight);
		
		#if android
		var tipText:FlxText = new FlxText(10, FlxG.height - 24, 0, 'Press C to customize your mobile controls', 16);
		tipText.setFormat(Paths.optionsfont(), 16, FlxColor.WHITE, LEFT, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		tipText.borderSize = 2.4;
		tipText.scrollFactor.set();
		add(tipText);
		#end

		changeSelection();
		ClientPrefs.saveSettings();
		#if android
		addVirtualPad(UP_DOWN, A_B_C);
		#end
		super.create();
	}
	
	override function closeSubState() {
		super.closeSubState();
		ClientPrefs.saveSettings();
	}

	override function update(elapsed:Float) {
		super.update(elapsed);
		var mouseOverChanged = false;
		for (i in 0...grpOptions.length) {
			if (FlxG.mouse.overlaps(grpOptions.members[i])) {
				if (mouseOverOption != i) {
					mouseOverOption = i;
					mouseOverChanged = true;
				}
				break;
			}
		}
		
		if (mouseOverChanged && mouseOverOption != curSelected) {
			curSelected = mouseOverOption;
			changeSelection(0);
		}
		
		if (FlxG.mouse.justPressed) {
			for (i in 0...grpOptions.length) {
				if (FlxG.mouse.overlaps(grpOptions.members[i])) {
					curSelected = i;
					changeSelection(0);
					openSelectedSubstate(optionIds[curSelected]);
					break;
				}
			}
		}
		
		if (controls.UI_UP_P) {
			changeSelection(-1);
		}
		if (controls.UI_DOWN_P) {
			changeSelection(1);
		}
		if(FlxG.mouse.wheel != 0)
			{
				FlxG.sound.play(Paths.sound('scrollMenu'), 0.2);
				changeSelection(-FlxG.mouse.wheel);
			}
		if (controls.BACK) {
			FlxG.sound.play(Paths.sound('cancelMenu'));
			if(onPlayState)
			{
				StageData.loadDirectory(PlayState.SONG);
				LoadingState.loadAndSwitchState(new PlayState());
				FlxG.sound.music.volume = 0;
			}
			else MusicBeatState.switchState(new MainMenuState());
		}
		if(controls.ACCEPT)
			openSelectedSubstate(optionIds[curSelected]);
		#if android
		if (virtualPad.buttonC.justPressed) {
			persistentUpdate = false;
			openSubState(new android.AndroidControlsSubState());
		}
		#end
	}
	
	function changeSelection(change:Int = 0) {
		curSelected += change;
		if (curSelected < 0)
			curSelected = optionIds.length - 1;
		if (curSelected >= optionIds.length)
			curSelected = 0;

		var bullShit:Int = 0;

		for (item in grpOptions.members) {
			item.alpha = 0.6;
			if (bullShit == curSelected) {
				item.alpha = 1;

				selectorLeft.x = item.x - 63;
				selectorLeft.y = item.y;
				selectorRight.x = item.x + item.width + 15;
				selectorRight.y = item.y;
			}
			bullShit++;
		}
		FlxG.sound.play(Paths.sound('scrollMenu'));
	}
}
	