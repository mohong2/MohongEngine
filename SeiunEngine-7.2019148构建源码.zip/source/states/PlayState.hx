package states;

import substates.PauseSubState;
import substates.OldPauseSubState;
import substates.GameOverSubstate;
import substates.PlayStateResultsSubstate;
import script.hscript.HScript;
import haxe.display.Display.GotoDefinitionResult;
import flixel.graphics.FlxGraphic;
#if cpp
import Discord.DiscordClient;
#end

import Section.SwagSection;
import Song.SwagSong;
import WiggleEffect.WiggleEffectType;
import flixel.FlxBasic;
import flixel.FlxGame;
import flixel.FlxObject;
import flixel.FlxState;
import flixel.FlxSubState;
import flixel.addons.display.FlxGridOverlay;
import flixel.addons.effects.FlxTrail;
import flixel.addons.effects.FlxTrailArea;
import flixel.addons.effects.chainable.FlxEffectSprite;
import flixel.addons.effects.chainable.FlxWaveEffect;
import flixel.addons.transition.FlxTransitionableState;
import flixel.graphics.atlas.FlxAtlas;
import flixel.graphics.frames.FlxAtlasFrames;
import flixel.math.FlxRect;
import flixel.system.FlxSound;
import flixel.ui.FlxBar;
import flixel.util.FlxCollision;
import flixel.util.FlxSort;
import flixel.util.FlxStringUtil;
import haxe.Json;
import lime.utils.Assets;
import openfl.Lib;
import openfl.display.BlendMode;
import openfl.display.StageQuality;
import openfl.filters.BitmapFilter;
import openfl.utils.Assets as OpenFlAssets;
import editors.ChartingState;
import editors.CharacterEditorState;
 
import flixel.input.keyboard.FlxKey;
import Note.EventNote;
import Note.PreloadedChartNote;
import openfl.events.KeyboardEvent;
import flixel.effects.particles.FlxEmitter;
import flixel.effects.particles.FlxParticle;
import flixel.util.FlxSave;
import flixel.animation.FlxAnimationController;
import animateatlas.AtlasFrameMaker;
import Achievements;
import StageData;
import script.lua.FunkinLua;
import script.lua.DebugLuaText;
import DialogueBoxPsych;
import Conductor.Rating;
import mohong.TraceManager;
import mohong.MemoryMonitor;
import mohong.RenderOptimizer;
import popup.RatingPopup;
#if !flash 
import flixel.addons.display.FlxRuntimeShader;
import openfl.filters.ShaderFilter;
#end

#if sys
import sys.FileSystem;
import sys.io.File;
#end

#if VIDEOS_ALLOWED
#if (hxCodec >= "3.0.0") import hxcodec.flixel.FlxVideo as VideoHandler;
#elseif (hxCodec >= "2.6.1") import hxcodec.VideoHandler as VideoHandler;
#elseif (hxCodec == "2.6.0") import VideoHandler;
#else import vlc.MP4Handler as VideoHandler; #end
#end

using StringTools;

// Stage backdrop system
import states.stages.StageBackdrop;
import states.stages.BaseStage;
import states.stages.SpookyStage;
import states.stages.PhillyStage;
import states.stages.LimoStage;
import states.stages.MallStage;
import states.stages.MallEvilStage;
import states.stages.SchoolStage;
import states.stages.SchoolEvilStage;
import states.stages.TankStage;

@:allow(Replay)
class PlayState extends MusicBeatState
{

	public static var STRUM_X = 42;
	public static var STRUM_X_MIDDLESCROLL = -278;

	public static var ratingStuff:Array<Dynamic> = [
		['F', 0.2], //From 0% to 19%
		['D', 0.4], //From 20% to 39%
		['C-', 0.5], //From 40% to 49%
		['C', 0.6], //From 50% to 59%
		['B', 0.69], //From 60% to 68%
		['A', 0.7], //69%
		['AA', 0.8], //From 70% to 79%
		['AAA', 0.9], //From 80% to 89%
		['AAAA', 1], //From 90% to 99%
		['AAAAA', 1] //The value on this one isn't used actually, since Perfect is always "1"
	]; 

	//public static var ratingStuff:Array<Dynamic> = [
	//	['You Suck!', 0.2], //From 0% to 19%
	//	['Shit', 0.4], //From 20% to 39%
	//	['Bad', 0.5], //From 40% to 49%
	//	['Bruh', 0.6], //From 50% to 59%
	//	['Meh', 0.69], //From 60% to 68%
	//	['Nice', 0.7], //69%
	//	['Good', 0.8], //From 70% to 79%
	//	['Great', 0.9], //From 80% to 89%
	//	['Sick!', 1], //From 90% to 99%
	//	['Perfect!!', 1] //The value on this one isn't used actually, since Perfect is always "1"
	//];

	//event variables
	private var isCameraOnForcedPos:Bool = false;

	var msTxtKade:FlxText;
	var msTween:FlxTween;
	var atkText:FlxText;


	#if (haxe >= "4.0.0")
	public var boyfriendMap:Map<String, Boyfriend> = new Map();
	public var dadMap:Map<String, Character> = new Map();
	public var gfMap:Map<String, Character> = new Map();
	#else
	public var boyfriendMap:Map<String, Boyfriend> = new Map<String, Boyfriend>();
	public var dadMap:Map<String, Character> = new Map<String, Character>();
	public var gfMap:Map<String, Character> = new Map<String, Character>();
	#end

	public var BF_X:Float = 770;
	public var BF_Y:Float = 100;
	public var DAD_X:Float = 100;
	public var DAD_Y:Float = 100;
	public var GF_X:Float = 400;
	public var GF_Y:Float = 130;

	public var songSpeedTween:FlxTween;
	public var songSpeed(default, set):Float = 1;
	public var songSpeedType:String = "multiplicative";
	public var noteKillOffset:Float = 350;

	public var playbackRate(default, set):Float = 1;

	public var boyfriendGroup:FlxSpriteGroup;
	public var dadGroup:FlxSpriteGroup;
	public var gfGroup:FlxSpriteGroup;
	public static var curStage:String = '';
	public static var isPixelStage:Bool = false;
	public static var SONG:SwagSong = null;

	/** Stage backdrop handler — manages background sprites, anims, and stage-specific logic. */
	public var stageBackdrop:StageBackdrop;
	public static var isStoryMode:Bool = false;
	public static var storyWeek:Int = 0;
	public static var storyPlaylist:Array<String> = [];
	public static var storyDifficulty:Int = 1;

	public var spawnTime:Float = 2000;

	public var vocals:FlxSound;
	public var vocalsPlayer:FlxSound;
	public var vocalsOpponent:FlxSound;


	public var dad:Character = null;
	public var gf:Character = null;
	public var boyfriend:Boyfriend = null;

	public var notes:FlxTypedGroup<Note>;
	public var sustainNotes:FlxTypedGroup<Note>; // Kept for Lua compatibility (empty)
	public var unspawnNotes:Array<Note> = [];
	public var eventNotes:Array<EventNote> = [];

	public var notesAddedCount:Int = 0;
	public var limitNC:Int = 0;
	public var noteLimit:Int = 1000;

	private var strumLine:FlxSprite;

	//Handles the new epic mega sexy cam code that i've done
	public var camFollow:FlxPoint;
	public var camFollowPos:FlxObject;
	private static var prevCamFollow:FlxPoint;
	private static var prevCamFollowPos:FlxObject;

	public var strumLineNotes:FlxTypedGroup<StrumNote>;
	public var opponentStrums:FlxTypedGroup<StrumNote>;
	public var playerStrums:FlxTypedGroup<StrumNote>;
	public var grpNoteSplashes:FlxTypedGroup<NoteSplash>;

	public var camZooming:Bool = false;
	public var camZoomingMult:Float = 1;
	public var camZoomingDecay:Float = 1;
	private var curSong:String = "";

	public var gfSpeed:Int = 1;
	public var health:Float = 1;
	// Displayed health used for smooth healthbar transitions
	public var displayHealth:Float = 1;
	public var combo:Int = 0;

	public var healthBarBG:AttachedSprite;
	public var healthBar:Dynamic;
	var songPercent:Float = 0;

	public var timeBarBG:AttachedSprite; //草你妈的LUA
	public var timeBar:FlxBar;


	public var keyboardDisplay:KeyboardDisplay;

	public var ratingsData:Array<Rating> = [];
	public var sicks:Int = 0;
	public var goods:Int = 0;
	public var bads:Int = 0;
	public var shits:Int = 0;

	public var sustainNotescore:Int = 0;
	private var sideHUDVisible:Bool = false;
	private var notehitlol:Int = 0;
	private var tnh:FlxText;
	private var cm:FlxText;
	private var sick:FlxText;
	private var good:FlxText;
	private var bad:FlxText;
	private var shit:FlxText;
	private var miss:FlxText;
	private static final tnhx:Int = -10;
	private static final cmoffset:Int = -4;
	private static final cmy:Int = 20;

	private var generatedMusic:Bool = false;
	public var endingSong:Bool = false;
	public var startingSong:Bool = false;
	private var updateTime:Bool = true;
	public static var changedDifficulty:Bool = false;
	public static var chartingMode:Bool = false;

	public var guitarHeroSustains:Bool = false;

	//Gameplay settings
	public var healthGain:Float = 1;
	public var healthLoss:Float = 1;
	public var instakillOnMiss:Bool = false;
	public var cpuControlled(default, set):Bool = false;
	inline function set_cpuControlled(value:Bool):Bool {
		cpuControlled = value;
		if (botplayTxt != null)
			botplayTxt.visible = (!ClientPrefs.data.hideHud) ? cpuControlled : false;
		return cpuControlled;
	}
	public var playOpponent:Bool = false;
	public var reverseNoteHit:Bool = false;
	public var practiceMode:Bool = false;

	public static var replayMode:Bool = false;

	public var botplaySine:Float = 0;
	public var botplayTxt:FlxText;
	public var replaySine:Float = 0;
	public var replayTxt:FlxText;
	var botplayUsed:Bool = false;
	var strumsHit:Array<Bool> = [false, false, false, false, false, false, false, false];
	var _suppressNoteAnim:Bool = false;
	/** 新 NF 风格 Replay 实例 (录制/回放) */
	public var replayExam:Replay;
	/** 回放模式按键状态数组 (由 replayApplyInput 设置) */
	private var _hold:Array<Bool> = [];
	private var _press:Array<Bool> = [];
	private var _release:Array<Bool> = [];


	public var iconP1:HealthIcon;
	public var iconP2:HealthIcon;
	public var camHUD:FlxCamera;
	public var camGame:FlxCamera;
	public var camOther:FlxCamera;
	public var cameraSpeed:Float = 1;

	var dialogue:Array<String> = ['blah blah blah', 'coolswag'];
	var dialogueJson:DialogueFile = null;

	public var dadbattleBlack:BGSprite;
	public var dadbattleLight:BGSprite;
	public var dadbattleSmokes:FlxSpriteGroup;

	public var halloweenBG:BGSprite;
	public var halloweenWhite:BGSprite;

	public var phillyLightsColors:Array<FlxColor>;
	public var phillyWindow:BGSprite;
	public var phillyStreet:BGSprite;
	public var phillyTrain:BGSprite;
	public var blammedLightsBlack:FlxSprite;
	public var phillyWindowEvent:BGSprite;
	public var trainSound:FlxSound;

	public var phillyGlowGradient:PhillyGlow.PhillyGlowGradient;
	public var phillyGlowParticles:FlxTypedGroup<PhillyGlow.PhillyGlowParticle>;

	public var limoKillingState:Int = 0;
	public var limo:BGSprite;
	public var limoMetalPole:BGSprite;
	public var limoLight:BGSprite;
	public var limoCorpse:BGSprite;
	public var limoCorpseTwo:BGSprite;
	public var bgLimo:BGSprite;
	public var grpLimoParticles:FlxTypedGroup<BGSprite>;
	public var grpLimoDancers:FlxTypedGroup<BackgroundDancer>;
	public var fastCar:BGSprite;

	public var upperBoppers:BGSprite;
	public var bottomBoppers:BGSprite;
	public var santa:BGSprite;
	public var heyTimer:Float;

	public var bgGirls:BackgroundGirls;
	public var wiggleShit:WiggleEffect = new WiggleEffect();
	public var bgGhouls:BGSprite;

    public var trackBackground:FlxSprite;
    public var trackColor:String = '000000';
    public var trackAlpha:Float = 0.3;
    public var scaleFactor:Float = 0.3;

	public var tankWatchtower:BGSprite;
	public var tankGround:BGSprite;
	public var tankmanRun:FlxTypedGroup<TankmenBG>;
	public var foregroundSprites:FlxTypedGroup<BGSprite>;

	public var songScore:Int = 0;
	public var songHits:Int = 0;
	public var songMisses:Int = 0;
	public var scoreTxt:FlxText;
	public var timeTxt:FlxText;
	public var scoreTxtTween:FlxTween;

	public static var campaignScore:Int = 0;
	public static var campaignMisses:Int = 0;
	public static var seenCutscene:Bool = false;
	public static var deathCounter:Int = 0;

	public var defaultCamZoom:Float = 1.05;

	// how big to stretch the pixel art assets
	public static var daPixelZoom:Float = 6;
	private var singAnimations:Array<String> = ['singLEFT', 'singDOWN', 'singUP', 'singRIGHT'];

	public var inCutscene:Bool = false;
	public var skipCountdown:Bool = false;
	public var songLength:Float = 0;

	public var boyfriendCameraOffset:Array<Float> = null;
	public var opponentCameraOffset:Array<Float> = null;
	public var girlfriendCameraOffset:Array<Float> = null;

	#if cpp
	// Discord RPC variables
	var storyDifficultyText:String = "";
	var detailsText:String = "";
	var detailsPausedText:String = "";
	#end

	//Achievement shit
	var keysPressed:Array<Bool> = [];
	var boyfriendIdleTime:Float = 0.0;
	var boyfriendIdled:Bool = false;

	// Lua shit
	public static var instance:PlayState;
	public var introSoundsSuffix:String = '';

	// Debug buttons
	private var debugKeysChart:Array<FlxKey>;
	private var debugKeysCharacter:Array<FlxKey>;

	// Less laggy controls
	public var keysArray:Array<Dynamic>;
	public var controlArray:Array<String>;
	//
	public var score:Int = 0;
	public var maxcombo:Int = 0;
	//
	public var precacheList:Map<String, String> = new Map<String, String>();
	
	// stores the last judgement object
	public static var lastRating:FlxSprite;
	// stores the last combo sprite object
	public static var lastCombo:FlxSprite;
	// stores the last combo score objects in an array
	public static var lastScore:Array<FlxSprite> = [];

	/** 评级弹窗对象池 */
	var ratingPopup:RatingPopup;

	public var NoteMs:Array<Float> = [];
	public var NoteTime:Array<Float> = [];

	/** Frame counter for batched note cleanup — every N frames instead of every frame. */
	var _noteCleanupFrameCounter:Int = 0;
	/** Interval for batched note cleanup (in frames). Soft-coded for tuning. */
	static final NOTE_CLEANUP_INTERVAL:Int = 3;

	/**
	 * Create the appropriate StageBackdrop for the current stage.
	 * Public fields on PlayState (halloweenBG, phillyWindow, etc.)
	 * are assigned inside each stage handler's create().
	 */
	function createStageHandler(stage:String):StageBackdrop
	{
		return switch (stage)
		{
			case 'stage':    new BaseStage(this);
			case 'spooky':   new SpookyStage(this);
			case 'philly':   new PhillyStage(this);
			case 'limo':     new LimoStage(this);
			case 'mall':     new MallStage(this);
			case 'mallEvil': new MallEvilStage(this);
			case 'school':   new SchoolStage(this);
			case 'schoolEvil': new SchoolEvilStage(this);
			case 'tank':     new TankStage(this);
			default:         new BaseStage(this);
		}
	}


	override public function create()
	{
		// Initialize memory tracking for this state
		MemoryMonitor.initialize();
		MemoryMonitor.onStateSwitch();
		 
		//trace('Playback Rate: ' + playbackRate);
		Paths.clearStoredMemory();
		// for lua
		instance = this;
		debugKeysChart = ClientPrefs.copyKey(ClientPrefs.keyBinds.get('debug_1'));
		debugKeysCharacter = ClientPrefs.copyKey(ClientPrefs.keyBinds.get('debug_2'));
		PauseSubState.songName = null; //Reset to default
		playbackRate = ClientPrefs.getGameplaySetting('songspeed', 1);
		// replay 模式下 playbackRate 将在 replayExam.loadFromFile() 时从 StateRecord 恢复
		

		keysArray = [
			ClientPrefs.copyKey(ClientPrefs.keyBinds.get('note_left')),
			ClientPrefs.copyKey(ClientPrefs.keyBinds.get('note_down')),
			ClientPrefs.copyKey(ClientPrefs.keyBinds.get('note_up')),
			ClientPrefs.copyKey(ClientPrefs.keyBinds.get('note_right'))
		];

		controlArray = [
			'NOTE_LEFT',
			'NOTE_DOWN',
			'NOTE_UP',
			'NOTE_RIGHT'
		];

		//Ratings
		ratingsData.push(new Rating('sick')); //default rating


		var rating:Rating = new Rating('good');
		rating.ratingMod = 0.7;
		rating.score = 200;
		rating.noteSplash = false;
		ratingsData.push(rating);

		var rating:Rating = new Rating('bad');
		rating.ratingMod = 0.4;
		rating.score = 0;
		rating.noteSplash = false;
		ratingsData.push(rating);

		var rating:Rating = new Rating('shit');
		rating.ratingMod = 0;
		rating.score = 0;
		rating.noteSplash = false;
		ratingsData.push(rating);

		// For the "Just the Two of Us" achievement
		for (i in 0...keysArray.length)
		{
			keysPressed.push(false);
		}

		if (FlxG.sound.music != null)
			FlxG.sound.music.stop();

		// Gameplay settings
		healthGain = ClientPrefs.getGameplaySetting('healthgain', 1);
		healthLoss = ClientPrefs.getGameplaySetting('healthloss', 1);
		instakillOnMiss = ClientPrefs.getGameplaySetting('instakill', false);
		practiceMode = ClientPrefs.getGameplaySetting('practice', false);
		cpuControlled = ClientPrefs.getGameplaySetting('botplay', false);
        playOpponent = ClientPrefs.getGameplaySetting('playOpponent', false);
        reverseNoteHit = ClientPrefs.getGameplaySetting('reverseNoteHit', false);
		guitarHeroSustains = ClientPrefs.data.guitarHeroSustains;
    	        if (cpuControlled) playOpponent = false;
                guitarHeroSustains = ClientPrefs.data.guitarHeroSustains;
                // 初始化 NF 风格 Replay 实例
                replayExam = new Replay();
                add(replayExam);
                if (replayMode) {
                        replayExam.loadFromFile(Replay.preparedPath);
			// 回放模式下强制关闭 botplay/practice 防止冲突
			cpuControlled = false;
			practiceMode = false;
                } else if(!playOpponent && ClientPrefs.data.saveReplayData) {
                        replayExam.startRecording();
                }


		// var gameCam:FlxCamera = FlxG.camera;
		camGame = new FlxCamera();
		camHUD = new FlxCamera();
		camOther = new FlxCamera();
		camHUD.bgColor.alpha = 0;
		camOther.bgColor.alpha = 0;

		FlxG.cameras.reset(camGame);
		FlxG.cameras.add(camHUD, false);
		FlxG.cameras.add(camOther, false);
		grpNoteSplashes = new FlxTypedGroup<NoteSplash>();

		FlxG.cameras.setDefaultDrawTarget(camGame, true);
		CustomFadeTransition.nextCamera = camOther;

		persistentUpdate = true;
		persistentDraw = true;

		if (SONG == null)
			SONG = Song.loadFromJson('tutorial');

		Conductor.mapBPMChanges(SONG);
		Conductor.changeBPM(SONG.bpm);

		#if desktop
		storyDifficultyText = CoolUtil.difficulties[storyDifficulty];

		// String that contains the mode defined here so it isn't necessary to call changePresence for each mode
		if (isStoryMode)
		{
			detailsText = "Story Mode: " + WeekData.getCurrentWeek().weekName;
		}
		else
		{
			detailsText = "Freeplay";
		}

		// String for when the game is paused
		detailsPausedText = "Paused - " + detailsText;
		#end

		GameOverSubstate.resetVariables();
		var songName:String = Paths.formatToSongPath(SONG.song);

		curStage = SONG.stage;
		//trace('stage is: ' + curStage);
		if(SONG.stage == null || SONG.stage.length < 1) {
			switch (songName)
			{
				case 'spookeez' | 'south' | 'monster':
					curStage = 'spooky';
				case 'pico' | 'blammed' | 'philly' | 'philly-nice':
					curStage = 'philly';
				case 'milf' | 'satin-panties' | 'high':
					curStage = 'limo';
				case 'cocoa' | 'eggnog':
					curStage = 'mall';
				case 'winter-horrorland':
					curStage = 'mallEvil';
				case 'senpai' | 'roses':
					curStage = 'school';
				case 'thorns':
					curStage = 'schoolEvil';
				case 'ugh' | 'guns' | 'stress':
					curStage = 'tank';
				default:
					curStage = 'stage';
			}
		}
		SONG.stage = curStage;

		var stageData:StageFile = StageData.getStageFile(curStage);
		if(stageData == null) { //Stage couldn't be found, create a dummy stage for preventing a crash
			stageData = {
				directory: "",
				defaultZoom: 0.9,
				isPixelStage: false,

				boyfriend: [770, 100],
				girlfriend: [400, 130],
				opponent: [100, 100],
				hide_girlfriend: false,

				camera_boyfriend: [0, 0],
				camera_opponent: [0, 0],
				camera_girlfriend: [0, 0],
				camera_speed: 1
			};
		}

		defaultCamZoom = stageData.defaultZoom;
		isPixelStage = stageData.isPixelStage;
		BF_X = stageData.boyfriend[0];
		BF_Y = stageData.boyfriend[1];
		GF_X = stageData.girlfriend[0];
		GF_Y = stageData.girlfriend[1];
		DAD_X = stageData.opponent[0];
		DAD_Y = stageData.opponent[1];

		if(stageData.camera_speed != null)
			cameraSpeed = stageData.camera_speed;

		boyfriendCameraOffset = stageData.camera_boyfriend;
		if(boyfriendCameraOffset == null) //Fucks sake should have done it since the start :rolling_eyes:
			boyfriendCameraOffset = [0, 0];

		opponentCameraOffset = stageData.camera_opponent;
		if(opponentCameraOffset == null)
			opponentCameraOffset = [0, 0];

		girlfriendCameraOffset = stageData.camera_girlfriend;
		if(girlfriendCameraOffset == null)
			girlfriendCameraOffset = [0, 0];

		boyfriendGroup = new FlxSpriteGroup(BF_X, BF_Y);
		dadGroup = new FlxSpriteGroup(DAD_X, DAD_Y);
		gfGroup = new FlxSpriteGroup(GF_X, GF_Y);

		keyboardDisplay = new KeyboardDisplay(ClientPrefs.data.comboOffset[4], ClientPrefs.data.comboOffset[5]);
		keyboardDisplay.antialiasing = ClientPrefs.data.globalAntialiasing;
		keyboardDisplay.visible = ClientPrefs.data.keyboardDisplay;
		add(keyboardDisplay);
		keyboardDisplay.cameras = [camOther];

		// Create stage backdrop handler and build background sprites
		stageBackdrop = createStageHandler(curStage);
		stageBackdrop.create();

		switch(Paths.formatToSongPath(SONG.song))
		{
			case 'stress':
				GameOverSubstate.characterName = 'bf-holding-gf-dead';
		}

		if(isPixelStage) {
			introSoundsSuffix = '-pixel';
		}

		add(gfGroup); //Needed for blammed lights

		// Shitty layering but whatev it works LOL
		if (curStage == 'limo')
			add(limo);

		add(dadGroup);
		add(boyfriendGroup);

		switch(curStage)
		{
			case 'spooky':
				add(halloweenWhite);
			case 'tank':
				add(foregroundSprites);
		}

		#if LUA_ALLOWED
		luaDebugGroup = new FlxTypedGroup<DebugLuaText>();
		luaDebugGroup.cameras = [camOther];
		add(luaDebugGroup);
		#end

		// ---- GLOBAL SCRIPTS (single pass over folders for both Lua & HScript) ----
		var filesPushed:Array<String> = [];
		var scriptFolders:Array<String> = [];

		#if (LUA_ALLOWED || HSCRIPT_ALLOWED)
		scriptFolders.push(Paths.getPreloadPath('scripts/'));
		#end

		#if MODS_ALLOWED
		scriptFolders.push(Paths.mods('scripts/'));
		if(Paths.currentModDirectory != null && Paths.currentModDirectory.length > 0)
			scriptFolders.push(Paths.mods(Paths.currentModDirectory + '/scripts/'));

		for(mod in Paths.getGlobalMods())
			scriptFolders.push(Paths.mods(mod + '/scripts/'));
		#end

		for (folder in scriptFolders)
		{
			#if (LUA_ALLOWED || HSCRIPT_ALLOWED || sys)
			if (!FileSystem.exists(folder)) continue;
			var dirContents:Array<String> = FileSystem.readDirectory(folder);
			#end

			#if LUA_ALLOWED
			for (file in dirContents)
			{
				if(file.endsWith('.lua') && !filesPushed.contains(file))
				{
					luaArray.push(new FunkinLua(folder + file));
					filesPushed.push(file);
				}
			}
			#end

			#if HSCRIPT_ALLOWED
			for (file in dirContents)
			{
				if(HScript.isHscriptFile(file) && !filesPushed.contains(file))
				{
					try {
						var script = new HScript(folder + file);
						if(script != null) {
							hscriptArray.push(script);
							filesPushed.push(file);
						}
					} catch (e:Dynamic) {
						TraceManager.error('trace.playState.hscriptFailed', 'Failed to load hscript: {} - {}', [file, e]);
					}
				}
			}
			#end
		}

		// ---- STAGE-SPECIFIC SCRIPTS ----
		#if LUA_ALLOWED
		(function() {
			var luaFile:String = 'stages/' + curStage + '.lua';
			#if MODS_ALLOWED
			if(FileSystem.exists(Paths.modFolders(luaFile)))
				luaFile = Paths.modFolders(luaFile);
			else
				luaFile = Paths.getPreloadPath(luaFile);
			#else
			luaFile = Paths.getPreloadPath(luaFile);
			#end
			#if sys
			if(FileSystem.exists(luaFile))
				luaArray.push(new FunkinLua(luaFile));
			#end
		})();
		#end
		
		#if HSCRIPT_ALLOWED
		(function() {
			var hscriptFile:String = 'stages/' + curStage + '.hx';
			#if MODS_ALLOWED
			if(FileSystem.exists(Paths.modFolders(hscriptFile)))
				hscriptFile = Paths.modFolders(hscriptFile);
			else
				hscriptFile = Paths.getPreloadPath(hscriptFile);
			#else
			hscriptFile = Paths.getPreloadPath(hscriptFile);
			#end
			if(FileSystem.exists(hscriptFile)) {
				try {
					hscriptArray.push(new HScript(hscriptFile));
				} catch (e:Dynamic) {
					TraceManager.error('trace.playState.hscriptStageFailed', 'Failed to load stage hscript: {} - {}', [hscriptFile, e]);
				}
			}
		})();
		#end


		var gfVersion:String = SONG.gfVersion;
		if(gfVersion == null || gfVersion.length < 1)
		{
			switch (curStage)
			{
				case 'limo':
					gfVersion = 'gf-car';
				case 'mall' | 'mallEvil':
					gfVersion = 'gf-christmas';
				case 'school' | 'schoolEvil':
					gfVersion = 'gf-pixel';
				case 'tank':
					gfVersion = 'gf-tankmen';
				default:
					gfVersion = 'gf';
			}

			switch(Paths.formatToSongPath(SONG.song))
			{
				case 'stress':
					gfVersion = 'pico-speaker';
			}
			SONG.gfVersion = gfVersion; //Fix for the Chart Editor
		}

		if (!stageData.hide_girlfriend)
		{
			gf = new Character(0, 0, gfVersion);
			startCharacterPos(gf);
			gf.scrollFactor.set(0.95, 0.95);
			gfGroup.add(gf);
			startCharacterLua(gf.curCharacter);

			if(gfVersion == 'pico-speaker')
			{
				if(!ClientPrefs.data.lowQuality)
				{
					var firstTank:TankmenBG = new TankmenBG(20, 500, true);
					firstTank.resetShit(20, 600, true);
					firstTank.strumTime = 10;
					tankmanRun.add(firstTank);

					for (i in 0...TankmenBG.animationNotes.length)
					{
						if(FlxG.random.bool(16)) {
							var tankBih = tankmanRun.recycle(TankmenBG);
							tankBih.strumTime = TankmenBG.animationNotes[i][0];
							tankBih.resetShit(500, 200 + FlxG.random.int(50, 100), TankmenBG.animationNotes[i][1] < 2);
							tankmanRun.add(tankBih);
						}
					}
				}
			}
		}

		dad = new Character(0, 0, SONG.player2);
		startCharacterPos(dad, true);
		dadGroup.add(dad);
		startCharacterLua(dad.curCharacter);

		boyfriend = new Boyfriend(0, 0, SONG.player1);
		startCharacterPos(boyfriend);
		boyfriendGroup.add(boyfriend);
		startCharacterLua(boyfriend.curCharacter);

		var camPos:FlxPoint = new FlxPoint(girlfriendCameraOffset[0], girlfriendCameraOffset[1]);
		if(gf != null)
		{
			camPos.x += gf.getGraphicMidpoint().x + gf.cameraPosition[0];
			camPos.y += gf.getGraphicMidpoint().y + gf.cameraPosition[1];
		}

		if(dad.curCharacter.startsWith('gf')) {
			dad.setPosition(GF_X, GF_Y);
			if(gf != null)
				gf.visible = false;
		}

		switch(curStage)
		{
			case 'limo':
				if (fastCar != null) {
					if (stageBackdrop is LimoStage)
						cast(stageBackdrop, LimoStage).resetFastCar();
					addBehindGF(fastCar);
				}
			case 'schoolEvil':
				if (stageBackdrop is SchoolEvilStage)
					cast(stageBackdrop, SchoolEvilStage).addEvilTrail();
		}

		var file:String = Paths.json(songName + '/dialogue'); //Checks for json/Psych Engine dialogue
		if (OpenFlAssets.exists(file)) {
			dialogueJson = DialogueBoxPsych.parseDialogue(file);
		}

		var file:String = Paths.txt(songName + '/' + songName + 'Dialogue'); //Checks for vanilla/Senpai dialogue
		if (OpenFlAssets.exists(file)) {
			dialogue = CoolUtil.coolTextFile(file);
		}
		var doof:DialogueBox = new DialogueBox(false, dialogue);
		// doof.x += 70;
		// doof.y = FlxG.height * 0.5;
		doof.scrollFactor.set();
		doof.finishThing = startCountdown;
		doof.nextDialogueThing = startNextDialogue;
		doof.skipDialogueThing = skipDialogue;
		if (ClientPrefs.data.compatibility_mode) {
			comboGroup = new FlxSpriteGroup();
			add(comboGroup);
			noteGroup = new FlxTypedGroup<FlxBasic>();
			add(noteGroup);
			uiGroup = new FlxSpriteGroup();
			add(uiGroup);
		}

		Conductor.songPosition = -5000;

		strumLine = new FlxSprite(ClientPrefs.data.middleScroll ? STRUM_X_MIDDLESCROLL : STRUM_X, 50).makeGraphic(FlxG.width, 10);
		if(ClientPrefs.data.downScroll) strumLine.y = FlxG.height - 150;
		strumLine.scrollFactor.set();

		var showTime:Bool = (ClientPrefs.data.timeBarType != 'Disabled');
		timeTxt = new FlxText(STRUM_X + (FlxG.width / 2) - 248, 18, 400, "", 32);
		timeTxt.setFormat(Paths.font("vcr.ttf"), 20, FlxColor.WHITE, CENTER, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		timeTxt.scrollFactor.set();
		timeTxt.alpha = 0;
		timeTxt.borderSize = 2;
		timeTxt.visible = showTime;
		if(ClientPrefs.data.downScroll) timeTxt.y = FlxG.height - 44;

		if(ClientPrefs.data.timeBarType == 'Song Name')
		{
			timeTxt.text = SONG.song;
		}
		updateTime = showTime;

		timeBarBG = new AttachedSprite('timeBar');
		timeBarBG.x = timeTxt.x;
		timeBarBG.y = timeTxt.y + (timeTxt.height / 4);
		timeBarBG.scrollFactor.set();
		timeBarBG.alpha = 0;
		timeBarBG.visible = showTime;
		timeBarBG.color = FlxColor.BLACK;
		timeBarBG.xAdd = -4;
		timeBarBG.yAdd = -4;
		if (ClientPrefs.data.compatibility_mode)
			uiGroup.add(timeBarBG);
		else
			add(timeBarBG);

		timeBar = new FlxBar(timeBarBG.x + 4, timeBarBG.y + 4, LEFT_TO_RIGHT, Std.int(timeBarBG.width - 8), Std.int(timeBarBG.height - 8), this,
			'songPercent', 0, 1);
		timeBar.scrollFactor.set();
		timeBar.createFilledBar(0xFF000000, 0xFFFFFFFF);
		timeBar.numDivisions = 800; //How much lag this causes?? Should i tone it down to idk, 400 or 200?
		timeBar.alpha = 0;
		timeBar.visible = showTime;
		if (ClientPrefs.data.compatibility_mode) {
			uiGroup.add(timeBar);
			uiGroup.add(timeTxt);
		} else {
			add(timeBar);
			add(timeTxt);
		}
		timeBarBG.sprTracker = timeBar;

		strumLineNotes = new FlxTypedGroup<StrumNote>();
		if (ClientPrefs.data.compatibility_mode) {
			noteGroup.add(strumLineNotes);
		} else {
			add(strumLineNotes);
			add(grpNoteSplashes);
		}

		if(ClientPrefs.data.timeBarType == 'Song Name')
		{
			timeTxt.size = 24;
			timeTxt.y += 3;
		}

		var splash:NoteSplash = new NoteSplash(100, 100, 0);
		grpNoteSplashes.add(splash);
		splash.alpha = 0.0;

		opponentStrums = new FlxTypedGroup<StrumNote>();
		playerStrums = new FlxTypedGroup<StrumNote>();

		// 评级弹窗对象池 — 预分配精灵复用，替换 popUpScore 中频繁 new/destroy 的开销
		ratingPopup = new RatingPopup();
		ratingPopup.targetCameras = [camHUD];
		ratingPopup.antialiasing = isPixelStage ? false : ClientPrefs.data.globalAntialiasing;
		ratingPopup.isPixel = isPixelStage;
		ratingPopup.daPixelZoom = daPixelZoom;
		if (ClientPrefs.data.compatibility_mode)
		{
			// 兼容模式: container 指向 comboGroup
			// 用 Std.int() + 类型检查避免 cast 返回 null
			ratingPopup.container = comboGroup;
			add(ratingPopup.container);
		}
		else
		{
			insert(members.indexOf(strumLineNotes), ratingPopup.container);
		}

		// startCountdown();
		#if android
		addAndroidControls();
		#end
		generateSong(SONG.song);

		if (ClientPrefs.data.compatibility_mode) {
			noteGroup.add(grpNoteSplashes);
		}

		// After all characters being loaded, it makes then invisible 0.01s later so that the player won't freeze when you change characters
		// add(strumLine);

		camFollow = new FlxPoint();
		camFollowPos = new FlxObject(0, 0, 1, 1);

		snapCamFollowToPos(camPos.x, camPos.y);
		if (prevCamFollow != null)
		{
			camFollow = prevCamFollow;
			prevCamFollow = null;
		}
		if (prevCamFollowPos != null)
		{
			camFollowPos = prevCamFollowPos;
			prevCamFollowPos = null;
		}
		add(camFollowPos);

		FlxG.camera.follow(camFollowPos, LOCKON, 1);
		// FlxG.camera.setScrollBounds(0, FlxG.width, 0, FlxG.height);
		FlxG.camera.zoom = defaultCamZoom;
		FlxG.camera.focusOn(camFollow);

		FlxG.worldBounds.set(0, 0, FlxG.width, FlxG.height);

		FlxG.fixedTimestep = false;
		moveCameraSection();

		// 兼容模式使用 0.7.3 Bar 类，非兼容模式使用原始 FlxBar
		if (ClientPrefs.data.compatibility_mode) {
			var barY:Float = FlxG.height * (!ClientPrefs.data.downScroll ? 0.89 : 0.11);
			var compatBar:objects.Bar = new objects.Bar(0, barY, 'healthBar', function() return displayHealth, 0, 2);
			compatBar.scrollFactor.set();
			compatBar.screenCenter(X);
			compatBar.visible = !ClientPrefs.data.hideHud;
			compatBar.alpha = ClientPrefs.data.healthBarAlpha;
			compatBar.leftToRight = false;
			healthBar = compatBar;
			healthBarBG = null;
		} else {
			healthBarBG = new AttachedSprite('healthBar');
			healthBarBG.y = FlxG.height * 0.89;
			healthBarBG.screenCenter(X);
			healthBarBG.scrollFactor.set();
			healthBarBG.visible = !ClientPrefs.data.hideHud;
			healthBarBG.xAdd = -4;
			healthBarBG.yAdd = -4;
			add(healthBarBG);
			if(ClientPrefs.data.downScroll) healthBarBG.y = 0.11 * FlxG.height;

			healthBar = new FlxBar(healthBarBG.x + 4, healthBarBG.y + 4, RIGHT_TO_LEFT, Std.int(healthBarBG.width - 8), Std.int(healthBarBG.height - 8), this,
				'displayHealth', 0, 2);
			healthBar.scrollFactor.set();
			healthBar.visible = !ClientPrefs.data.hideHud;
			healthBar.alpha = ClientPrefs.data.healthBarAlpha;
			Reflect.setProperty(healthBar, 'numDivisions', 10000);
			add(healthBar);
			healthBarBG.sprTracker = healthBar;
		}

		if (ClientPrefs.data.compatibility_mode)
			uiGroup.add(healthBar);

		iconP1 = new HealthIcon(boyfriend.healthIcon, false);
		iconP1.flipX = true;
		iconP1.y = healthBar.y - 75;
		iconP1.x = healthBar.x + healthBar.width + 12;
		iconP1.visible = !ClientPrefs.data.hideHud;
		iconP1.alpha = ClientPrefs.data.healthBarAlpha;
		if (ClientPrefs.data.compatibility_mode)
			uiGroup.add(iconP1);
		else
			add(iconP1);

		iconP2 = new HealthIcon(dad.healthIcon, false);
		iconP2.y = healthBar.y - 75;
		iconP2.x = healthBar.x - 150;
		iconP2.visible = !ClientPrefs.data.hideHud;
		iconP2.alpha = ClientPrefs.data.healthBarAlpha;
		if (ClientPrefs.data.compatibility_mode)
			uiGroup.add(iconP2);
		else
			add(iconP2);
		reloadHealthBarColors();

		var scoreY:Float = (healthBarBG != null) ? (healthBarBG.y + 36) : (healthBar.y + 40);
		scoreTxt = new FlxText(0, scoreY, FlxG.width, "", 20);
		scoreTxt.setFormat(Paths.languageFont(), 20, FlxColor.WHITE, CENTER, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		scoreTxt.scrollFactor.set();
		scoreTxt.borderSize = 2;
		scoreTxt.visible = !ClientPrefs.data.hideHud;
		if (ClientPrefs.data.compatibility_mode)
			uiGroup.add(scoreTxt);
		else
			add(scoreTxt);

		botplayTxt = new FlxText(400, timeBarBG.y + 55, FlxG.width - 800, "BOTPLAY", 32);
		botplayTxt.setFormat(Paths.font("vcr.ttf"), 32, FlxColor.WHITE, CENTER, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		botplayTxt.scrollFactor.set();
		botplayTxt.borderSize = 2;
		botplayTxt.visible = cpuControlled && !ClientPrefs.data.hideHud;
		if (!cpuControlled && practiceMode) {
			botplayTxt.text = 'Practice Mode';
			botplayTxt.visible = !ClientPrefs.data.hideHud;
		}
		if (ClientPrefs.data.compatibility_mode)
			uiGroup.add(botplayTxt);
		else
			add(botplayTxt);
		if(ClientPrefs.data.downScroll) {
			botplayTxt.y = timeBarBG.y - 78;
		}

		replayTxt = new FlxText(400, timeBarBG.y + 55, FlxG.width - 800, "REPLAY", 32);
		replayTxt.setFormat(Paths.font("vcr.ttf"), 32, FlxColor.WHITE, CENTER, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		replayTxt.scrollFactor.set();
		replayTxt.borderSize = 2;
		replayTxt.visible = replayMode;
		if (ClientPrefs.data.compatibility_mode)
			uiGroup.add(replayTxt);
		else
			add(replayTxt);
		if(ClientPrefs.data.downScroll) {
			replayTxt.y = timeBarBG.y - 78;
		}
		

		if (ClientPrefs.data.compatibility_mode) {
			comboGroup.cameras = [camHUD];
			noteGroup.cameras = [camHUD];
			uiGroup.cameras = [camHUD];
		} else {
			strumLineNotes.cameras = [camHUD];
			grpNoteSplashes.cameras = [camHUD];
			notes.cameras = [camHUD];
			Reflect.setProperty(healthBar, "cameras", [camHUD]);
			healthBarBG.cameras = [camHUD];
			iconP1.cameras = [camHUD];
			iconP2.cameras = [camHUD];
			scoreTxt.cameras = [camHUD];
			botplayTxt.cameras = [camHUD];
			replayTxt.cameras = [camHUD];
			timeBar.cameras = [camHUD];
			timeBarBG.cameras = [camHUD];
			timeTxt.cameras = [camHUD];
		}
		doof.cameras = [camHUD];

		// if (SONG.song == 'South')
		// FlxG.camera.alpha = 0.7;
		// UI_camera.zoom = 1;

		// cameras = [FlxG.cameras.list[1]];
		startingSong = true;
		
		#if LUA_ALLOWED
		for (notetype in noteTypeMap.keys())
		{
			#if MODS_ALLOWED
			var luaToLoad:String = Paths.modFolders('custom_notetypes/' + notetype + '.lua');
			if(FileSystem.exists(luaToLoad))
			{
				luaArray.push(new FunkinLua(luaToLoad));
			}
			else
			{
				luaToLoad = Paths.getPreloadPath('custom_notetypes/' + notetype + '.lua');
				if(FileSystem.exists(luaToLoad))
				{
					luaArray.push(new FunkinLua(luaToLoad));
				}
			}
			#elseif sys
			var luaToLoad:String = Paths.getPreloadPath('custom_notetypes/' + notetype + '.lua');
			if(OpenFlAssets.exists(luaToLoad))
			{
				luaArray.push(new FunkinLua(luaToLoad));
			}
			#end
		}
		
		for (event in eventPushedMap.keys())
		{
			#if MODS_ALLOWED
			var luaToLoad:String = Paths.modFolders('custom_events/' + event + '.lua');
			if(FileSystem.exists(luaToLoad))
			{
				luaArray.push(new FunkinLua(luaToLoad));
			}
			else
			{
				luaToLoad = Paths.getPreloadPath('custom_events/' + event + '.lua');
				if(FileSystem.exists(luaToLoad))
				{
					luaArray.push(new FunkinLua(luaToLoad));
				}
			}
			#elseif sys
			var luaToLoad:String = Paths.getPreloadPath('custom_events/' + event + '.lua');
			if(OpenFlAssets.exists(luaToLoad))
			{
				luaArray.push(new FunkinLua(luaToLoad));
			}
			#end
		}
		#end

#if HSCRIPT_ALLOWED
		for (notetype in noteTypeMap.keys())
		{
			try {
			#if MODS_ALLOWED
			var hscriptToLoad:String = Paths.modFolders('custom_notetypes/' + notetype + '.hx');
			if(FileSystem.exists(hscriptToLoad))
			{
				hscriptArray.push(new HScript(hscriptToLoad));
			}
			else
			{
				hscriptToLoad = Paths.getPreloadPath('custom_notetypes/' + notetype + '.hx');
				if(FileSystem.exists(hscriptToLoad))
				{
					hscriptArray.push(new HScript(hscriptToLoad));
				}
			}
			#elseif sys
			var hscriptToLoad:String = Paths.getPreloadPath('custom_notetypes/' + notetype + '.hx');
			if(OpenFlAssets.exists(hscriptToLoad))
			{
				hscriptArray.push(new HScript(hscriptToLoad));
			}
			#end
			} catch (e:Dynamic) {
				TraceManager.error('trace.playState.notetypeHscriptFailed', 'Failed to load notetype hscript {}: {}', [notetype, e]);
			}
		}
		
		for (event in eventPushedMap.keys())
		{
			try {
			#if MODS_ALLOWED
			var hscriptToLoad:String = Paths.modFolders('custom_events/' + event + '.hx');
			if(FileSystem.exists(hscriptToLoad))
			{
				hscriptArray.push(new HScript(hscriptToLoad));
			}
			else
			{
				hscriptToLoad = Paths.getPreloadPath('custom_events/' + event + '.hx');
				if(FileSystem.exists(hscriptToLoad))
				{
					hscriptArray.push(new HScript(hscriptToLoad));
				}
			}
			#elseif sys
			var hscriptToLoad:String = Paths.getPreloadPath('custom_events/' + event + '.hx');
			if(OpenFlAssets.exists(hscriptToLoad))
			{
				hscriptArray.push(new HScript(hscriptToLoad));
			}
			#end
			} catch (e:Dynamic) {
				TraceManager.error('trace.playState.eventHscriptFailed', 'Failed to load event hscript {}: {}', [event, e]);
			}
		}
		#end


		noteTypeMap.clear();
		noteTypeMap = null;
		eventPushedMap.clear();
		eventPushedMap = null;

		// SONG SPECIFIC SCRIPTS
		#if LUA_ALLOWED
		var filesPushed:Array<String> = [];
		var foldersToCheck:Array<String> = [Paths.getPreloadPath('data/' + Paths.formatToSongPath(SONG.song) + '/')];

		#if MODS_ALLOWED
		foldersToCheck.insert(0, Paths.mods('data/' + Paths.formatToSongPath(SONG.song) + '/'));
		if(Paths.currentModDirectory != null && Paths.currentModDirectory.length > 0)
			foldersToCheck.insert(0, Paths.mods(Paths.currentModDirectory + '/data/' + Paths.formatToSongPath(SONG.song) + '/'));

		for(mod in Paths.getGlobalMods())
			foldersToCheck.insert(0, Paths.mods(mod + '/data/' + Paths.formatToSongPath(SONG.song) + '/' ));// using push instead of insert because these should run after everything else
		#end

		for (folder in foldersToCheck)
		{
			if(FileSystem.exists(folder))
			{
				for (file in FileSystem.readDirectory(folder))
				{
					if(file.endsWith('.lua') && !filesPushed.contains(file))
					{
						luaArray.push(new FunkinLua(folder + file));
						filesPushed.push(file);
					}
				}
			}
		}
		#end

		// SONG SPECIFIC HSCRIPTS
		#if HSCRIPT_ALLOWED
		var hscriptSongFilesPushed:Array<String> = [];
		var hscriptSongFolders:Array<String> = [Paths.getPreloadPath('data/' + Paths.formatToSongPath(SONG.song) + '/')];

		#if MODS_ALLOWED
		hscriptSongFolders.insert(0, Paths.mods('data/' + Paths.formatToSongPath(SONG.song) + '/'));
		if(Paths.currentModDirectory != null && Paths.currentModDirectory.length > 0)
			hscriptSongFolders.insert(0, Paths.mods(Paths.currentModDirectory + '/data/' + Paths.formatToSongPath(SONG.song) + '/'));

		for(mod in Paths.getGlobalMods())
			hscriptSongFolders.insert(0, Paths.mods(mod + '/data/' + Paths.formatToSongPath(SONG.song) + '/'));
		#end

		for (folder in hscriptSongFolders)
		{
			if(FileSystem.exists(folder))
			{
				for (file in FileSystem.readDirectory(folder))
				{
					if(HScript.isHscriptFile(file) && !hscriptSongFilesPushed.contains(file))
					{
						try {
							var hscript = new HScript(folder + file);
							if(hscript != null) {
								hscriptArray.push(hscript);
								hscriptSongFilesPushed.push(file);
							}
						} catch (e:Dynamic) {
							TraceManager.error('trace.playState.songHscriptFailed', 'Failed to load song hscript: {} - {}', [file, e]);
						}
					}
				}
			}
		}
		#end

		var daSong:String = Paths.formatToSongPath(curSong);
		if (isStoryMode && !seenCutscene)
		{
			switch (daSong)
			{
				case "monster":
					var whiteScreen:FlxSprite = new FlxSprite(0, 0).makeGraphic(Std.int(FlxG.width * 2), Std.int(FlxG.height * 2), FlxColor.WHITE);
					add(whiteScreen);
					whiteScreen.scrollFactor.set();
					whiteScreen.blend = ADD;
					camHUD.visible = false;
					snapCamFollowToPos(dad.getMidpoint().x + 150, dad.getMidpoint().y - 100);
					inCutscene = true;

					FlxTween.tween(whiteScreen, {alpha: 0}, 1, {
						startDelay: 0.1,
						ease: FlxEase.linear,
						onComplete: function(twn:FlxTween)
						{
							camHUD.visible = true;
							remove(whiteScreen);
							startCountdown();
						}
					});
					FlxG.sound.play(Paths.soundRandom('thunder_', 1, 2));
					if(gf != null) gf.playAnim('scared', true);
					boyfriend.playAnim('scared', true);

				case "winter-horrorland":
					var blackScreen:FlxSprite = new FlxSprite().makeGraphic(Std.int(FlxG.width * 2), Std.int(FlxG.height * 2), FlxColor.BLACK);
					add(blackScreen);
					blackScreen.scrollFactor.set();
					camHUD.visible = false;
					inCutscene = true;

					FlxTween.tween(blackScreen, {alpha: 0}, 0.7, {
						ease: FlxEase.linear,
						onComplete: function(twn:FlxTween) {
							remove(blackScreen);
						}
					});
					FlxG.sound.play(Paths.sound('Lights_Turn_On'));
					snapCamFollowToPos(400, -2050);
					FlxG.camera.focusOn(camFollow);
					FlxG.camera.zoom = 1.5;

					new FlxTimer().start(0.8, function(tmr:FlxTimer)
					{
						camHUD.visible = true;
						remove(blackScreen);
						FlxTween.tween(FlxG.camera, {zoom: defaultCamZoom}, 2.5, {
							ease: FlxEase.quadInOut,
							onComplete: function(twn:FlxTween)
							{
								startCountdown();
							}
						});
					});
				case 'senpai' | 'roses' | 'thorns':
					if(daSong == 'roses') FlxG.sound.play(Paths.sound('ANGRY'));
					schoolIntro(doof);

				case 'ugh' | 'guns' | 'stress':
					tankIntro();

				default:
					startCountdown();
			}
			seenCutscene = true;
		}
		else
		{
			startCountdown();
		}
		RecalculateRating();
			if (ClientPrefs.data.sidehud) {
			var totalNotesText = Language.get("totalNotesText", "Total Notes Hit: 0") + "0",
			combosText = Language.get("combosText", "Combos: 0")+ "0",
			sicksText = Language.get("sicksText", "Sicks: 0") + "0",
			goodsText = Language.get("goodsText", "Goods: 0") + "0",
			badsText = Language.get("badsText", "Bads: 0") + "0",
			shitsText = Language.get("shitsText", "Shits: 0") + "0",
			missesText = Language.get("missesText", "Misses: 0") + "0";


			tnh = new FlxText(tnhx + 10, 259, 250, totalNotesText, 20);
			tnh.setFormat(20, FlxColor.WHITE, LEFT, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
			tnh.cameras = [camOther];
			tnh.font = Paths.languageFont(); 
			tnh.borderSize = 2;
			add(tnh);

			cm = new FlxText(-tnh.x + cmoffset, tnh.y + cmy, 200, combosText, 20);
			cm.setFormat(20, FlxColor.WHITE, LEFT, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
			cm.cameras = [camOther];
			cm.font = Paths.languageFont(); 
			cm.borderSize = 2;
			add(cm);

			sick = new FlxText(cm.x, cm.y + 30, 200, sicksText, 20);
			sick.setFormat(20, FlxColor.WHITE, LEFT, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
			sick.cameras = [camOther];
			sick.font = Paths.languageFont(); 
			sick.borderSize = 2;
			add(sick);

			good = new FlxText(cm.x, sick.y + 30, 200, goodsText, 20);
			good.setFormat(20, FlxColor.WHITE, LEFT, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
			good.cameras = [camOther];
			good.font = Paths.languageFont(); 
			good.borderSize = 2;
			add(good);

			bad = new FlxText(cm.x, good.y + 30, 200, badsText, 20);
			bad.setFormat(20, FlxColor.WHITE, LEFT, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
			bad.cameras = [camOther];
			bad.font = Paths.languageFont(); 
			bad.borderSize = 2;
			add(bad);

			shit = new FlxText(cm.x, bad.y + 30, 200, shitsText, 20);
			shit.setFormat(20, FlxColor.WHITE, LEFT, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
			shit.cameras = [camOther];
			shit.font = Paths.languageFont(); 
			shit.borderSize = 2;
			add(shit);

			miss = new FlxText(cm.x, shit.y + 30, 200, missesText, 20);
			miss.setFormat(20, FlxColor.RED, LEFT, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
			miss.cameras = [camOther];
			miss.font = Paths.languageFont(); 
			miss.borderSize = 2;
			add(miss);
			}


		msTxtKade = new FlxText(ClientPrefs.data.comboOffset[6], ClientPrefs.data.comboOffset[7], 0, "", 19);
		msTxtKade.alpha = 0;
		msTxtKade.scrollFactor.set();
		msTxtKade.cameras = [camHUD];
		msTxtKade.visible = !ClientPrefs.data.hideHud;
		msTxtKade.setFormat(19, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		msTxtKade.borderSize = 2;
		msTxtKade.font = Paths.font("kadems.ttf"); 
		add(msTxtKade);

		var songName:String = PlayState.SONG.song; 
		var difficultyName:String = CoolUtil.difficultyString();
		var seiunEngineVersion:String = MainMenuState.seiunengineVersion;
		var psychEngineVersion:String = MainMenuState.psychEngineVersion;

        var versionText:String = 'SE $seiunEngineVersion + PE $psychEngineVersion';
		atkText = new FlxText(0, 700, 600, "", 15);
       atkText.text = '$songName $difficultyName - $versionText';
        atkText.cameras = [camHUD];
		atkText.borderSize = 2;
		atkText.setFormat(15, FlxTextBorderStyle.OUTLINE, FlxColor.BLACK);
		atkText.font = Paths.font("vcr.ttf"); 
        add(atkText);
		if(replayMode)
			atkText.text += '(Replay)';

		//PRECACHING MISS SOUNDS BECAUSE I THINK THEY CAN LAG PEOPLE AND FUCK THEM UP IDK HOW HAXE WORKS
		if(ClientPrefs.data.hitsoundVolume > 0) precacheList.set('hitsound', 'sound');
		precacheList.set('missnote1', 'sound');
		precacheList.set('missnote2', 'sound');
		precacheList.set('missnote3', 'sound');

		if (PauseSubState.songName != null) {
			precacheList.set(PauseSubState.songName, 'music');
		} else if(ClientPrefs.data.pauseMusic != 'None') {
			precacheList.set(Paths.formatToSongPath(ClientPrefs.data.pauseMusic), 'music');
		}

		precacheList.set('alphabet', 'image');
	
		#if cpp
		// Updating Discord Rich Presence.
		if(iconP2 != null) DiscordClient.changePresence(detailsText, SONG.song + " (" + storyDifficultyText + ")", iconP2.getCharacter());
		#end

		// Track background — lazy small initial allocation, resized in update()
		trackAlpha = ClientPrefs.data.trackAlpha;
		trackBackground = new FlxSprite(0, -50).makeGraphic(64, 64, FlxColor.fromString('#' + trackColor));
		trackBackground.alpha = trackAlpha;
		trackBackground.cameras = [camHUD];
		trackBackground.scrollFactor.set();
		trackBackground.visible = (trackAlpha > 0);
		super.create();
		if (ClientPrefs.data.compatibility_mode)
			insert(members.indexOf(noteGroup), trackBackground);
		else
			insert(members.indexOf(strumLineNotes), trackBackground);

		callOnScripts('onCreatePost', []);

		cacheCountdown();
		cachePopUpScore();

		// Batch-precache: iterate once, skip already-loaded assets
		for (key => type in precacheList)
		{
			switch(type)
			{
				case 'image': Paths.image(key);
				case 'sound': Paths.sound(key);
				case 'music': Paths.music(key);
			}
		}

		Paths.clearUnusedMemory();
		CustomFadeTransition.nextCamera = camOther;
		
	}
	/** Cached reflect property getters for Dynamic healthBar. */
	var _healthBarWidth(get, never):Float;
	inline function get__healthBarWidth():Float return Reflect.getProperty(healthBar, "width");
	var _healthBarPercent(get, never):Float;
	inline function get__healthBarPercent():Float return Reflect.getProperty(healthBar, "percent");

	public dynamic function updateIconsPosition(elapsed:Float)
	{
		// Smoothly move icons towards target positions computed from the healthbar's displayed percent
		var iconOffset:Int = 26;
		var barWidth:Float = _healthBarWidth;
		var barPercent:Float = _healthBarPercent;
		var targetBase:Float = healthBar.x + (barWidth * (FlxMath.remapToRange(barPercent, 0, 100, 100, 0) * 0.01));
		var target1:Float = targetBase + (150 * iconP1.scale.x - 150) / 2 - iconOffset;
		var target2:Float = targetBase - (150 * iconP2.scale.x) / 2 - iconOffset * 2;
		// Interpolation factor (higher = faster)
		var t:Float = Math.min(1, elapsed * 10);
		var lerpX1:Float = (target1 - iconP1.x) * t;
		var lerpX2:Float = (target2 - iconP2.x) * t;
		iconP1.x += lerpX1;
		iconP2.x += lerpX2;
		// Also smoothly follow vertical changes of the healthbar
		var targetY:Float = healthBar.y - 75;
		iconP1.y += (targetY - iconP1.y) * t;
		iconP2.y += (targetY - iconP2.y) * t;
	}

	function set_songSpeed(value:Float):Float
	{
		if(generatedMusic)
		{
			// 直接按新 songSpeed 重算长条 scale.y，避免乘法累积导致的浮点误差和极端值渲染异常
			for (note in notes) if(note != null && note.exists) note.recalcSustainScale(value);
			for (note in unspawnNotes) if(note != null && note.exists) note.recalcSustainScale(value);
		}
		songSpeed = value;
		noteKillOffset = 350 / songSpeed;
		return value;
	}

	function set_playbackRate(value:Float):Float
	{
		if(generatedMusic)
		{
			if(vocals != null) vocals.pitch = value;
			if(vocalsPlayer != null) vocalsPlayer.pitch = value;
			if(vocalsOpponent != null) vocalsOpponent.pitch = value;
			FlxG.sound.music.pitch = value;
		}
		playbackRate = value;
		FlxAnimationController.globalSpeed = value;
		TraceManager.debug('trace.playState.animSpeed', 'Anim speed: {}', [FlxAnimationController.globalSpeed]);
		Conductor.safeZoneOffset = (ClientPrefs.data.safeFrames / 60) * 1000 * value;
		setOnScripts('playbackRate', playbackRate);
		return value;
	}

	override public function addTextToDebug(text:String, color:FlxColor) {
		#if LUA_ALLOWED
		luaDebugGroup.forEachAlive(function(spr:DebugLuaText) {
			spr.y += 20;
		});

		if(luaDebugGroup.members.length > 34) {
			var blah = luaDebugGroup.members[34];
			blah.destroy();
			luaDebugGroup.remove(blah);
		}
		luaDebugGroup.insert(0, new DebugLuaText(text, luaDebugGroup, color));
		#end
	}

	public function reloadHealthBarColors() {
		if (ClientPrefs.data.compatibility_mode) {
			// Bar.setColors
			healthBar.setColors(
				FlxColor.fromRGB(dad.healthColorArray[0], dad.healthColorArray[1], dad.healthColorArray[2]),
				FlxColor.fromRGB(boyfriend.healthColorArray[0], boyfriend.healthColorArray[1], boyfriend.healthColorArray[2])
			);
		} else {
			healthBar.createFilledBar(FlxColor.fromRGB(dad.healthColorArray[0], dad.healthColorArray[1], dad.healthColorArray[2]),
				FlxColor.fromRGB(boyfriend.healthColorArray[0], boyfriend.healthColorArray[1], boyfriend.healthColorArray[2]));
			healthBar.updateBar();
		}
	}

	public function addCharacterToList(newCharacter:String, type:Int) {
		switch(type) {
			case 0:
				if(!boyfriendMap.exists(newCharacter)) {
					var newBoyfriend:Boyfriend = new Boyfriend(0, 0, newCharacter);
					boyfriendMap.set(newCharacter, newBoyfriend);
					boyfriendGroup.add(newBoyfriend);
					startCharacterPos(newBoyfriend);
					newBoyfriend.alpha = 0.00001;
					startCharacterLua(newBoyfriend.curCharacter);
				}

			case 1:
				if(!dadMap.exists(newCharacter)) {
					var newDad:Character = new Character(0, 0, newCharacter);
					dadMap.set(newCharacter, newDad);
					dadGroup.add(newDad);
					startCharacterPos(newDad, true);
					newDad.alpha = 0.00001;
					startCharacterLua(newDad.curCharacter);
				}

			case 2:
				if(gf != null && !gfMap.exists(newCharacter)) {
					var newGf:Character = new Character(0, 0, newCharacter);
					newGf.scrollFactor.set(0.95, 0.95);
					gfMap.set(newCharacter, newGf);
					gfGroup.add(newGf);
					startCharacterPos(newGf);
					newGf.alpha = 0.00001;
					startCharacterLua(newGf.curCharacter);
				}
		}
	}

	function startCharacterLua(name:String)
	{
		#if LUA_ALLOWED
		var doPush:Bool = false;
		var luaFile:String = 'characters/' + name + '.lua';
		#if MODS_ALLOWED
		if(FileSystem.exists(Paths.modFolders(luaFile))) {
			luaFile = Paths.modFolders(luaFile);
			doPush = true;
		} else {
			luaFile = Paths.getPreloadPath(luaFile);
			if(FileSystem.exists(luaFile)) {
				doPush = true;
			}
		}
		#else
		luaFile = Paths.getPreloadPath(luaFile);
		if(Assets.exists(luaFile)) {
			doPush = true;
		}
		#end

		if(doPush)
		{
			for (script in luaArray)
			{
				if(script.scriptName == luaFile) return;
			}
			luaArray.push(new FunkinLua(luaFile));
		}
		#end
	}

	function startCharacterPos(char:Character, ?gfCheck:Bool = false) {
		if(gfCheck && char.curCharacter.startsWith('gf')) { //IF DAD IS GIRLFRIEND, HE GOES TO HER POSITION
			char.setPosition(GF_X, GF_Y);
			char.scrollFactor.set(0.95, 0.95);
			char.danceEveryNumBeats = 2;
		}
		char.x += char.positionArray[0];
		char.y += char.positionArray[1];
	}
	#if VIDEOS_ALLOWED
	var video:VideoHandler = null;
	var videoPlaying:Bool = false;
	#end
	public function startVideo(name:String)
	{
		#if VIDEOS_ALLOWED
		inCutscene = true;
		videoPlaying = true;

		var filepath:String = Paths.video(name);
		#if sys
		if(!FileSystem.exists(filepath))
		#else
		if(!OpenFlAssets.exists(filepath))
		#end
		{
			FlxG.log.warn('Couldnt find video file: ' + name);
			startAndEnd();
			return;
		}

			video = new VideoHandler();
			#if (hxCodec >= "3.0.0")
			// Recent versions
			video.play(filepath);
			video.onEndReached.add(function()
			{
				video.dispose();
				videoPlaying = false;
				startAndEnd();
				return;
			}, true);
			#else
			// Older versions
			video.playVideo(filepath);
			video.finishCallback = function()
			{
				videoPlaying = false;
				startAndEnd();
				return;
			}
			#end
		#else
		FlxG.log.warn('Platform not supported!');
		startAndEnd();
		return;
		#end
	}

	function startAndEnd()
	{
		#if VIDEOS_ALLOWED
		videoPlaying = false;
		#end
		if(endingSong)
			endSong();
		else
			startCountdown();
	}

	var dialogueCount:Int = 0;
	public var psychDialogue:DialogueBoxPsych;
	//You don't have to add a song, just saying. You can just do "startDialogue(dialogueJson);" and it should work
	public function startDialogue(dialogueFile:DialogueFile, ?song:String = null):Void
	{
		// TO DO: Make this more flexible, maybe?
		if(psychDialogue != null) return;

		if(dialogueFile.dialogue.length > 0) {
			inCutscene = true;
			precacheList.set('dialogue', 'sound');
			precacheList.set('dialogueClose', 'sound');
			psychDialogue = new DialogueBoxPsych(dialogueFile, song);
			psychDialogue.scrollFactor.set();
			if(endingSong) {
				psychDialogue.finishThing = function() {
					psychDialogue = null;
					endSong();
				}
			} else {
				psychDialogue.finishThing = function() {
					psychDialogue = null;
					startCountdown();
				}
			}
			psychDialogue.nextDialogueThing = startNextDialogue;
			psychDialogue.skipDialogueThing = skipDialogue;
			psychDialogue.cameras = [camHUD];
			add(psychDialogue);
		} else {
			FlxG.log.warn('Your dialogue file is badly formatted!');
			if(endingSong) {
				endSong();
			} else {
				startCountdown();
			}
		}
	}

	function schoolIntro(?dialogueBox:DialogueBox):Void
	{
		inCutscene = true;
		var black:FlxSprite = new FlxSprite(-100, -100).makeGraphic(FlxG.width * 2, FlxG.height * 2, FlxColor.BLACK);
		black.scrollFactor.set();
		add(black);

		var red:FlxSprite = new FlxSprite(-100, -100).makeGraphic(FlxG.width * 2, FlxG.height * 2, 0xFFff1b31);
		red.scrollFactor.set();

		var senpaiEvil:FlxSprite = new FlxSprite();
		senpaiEvil.frames = Paths.getSparrowAtlas('weeb/senpaiCrazy');
		senpaiEvil.animation.addByPrefix('idle', 'Senpai Pre Explosion', 24, false);
		senpaiEvil.setGraphicSize(Std.int(senpaiEvil.width * 6));
		senpaiEvil.scrollFactor.set();
		senpaiEvil.updateHitbox();
		senpaiEvil.screenCenter();
		senpaiEvil.x += 300;

		var songName:String = Paths.formatToSongPath(SONG.song);
		if (songName == 'roses' || songName == 'thorns')
		{
			remove(black);

			if (songName == 'thorns')
			{
				add(red);
				camHUD.visible = false;
			}
		}

		new FlxTimer().start(0.3, function(tmr:FlxTimer)
		{
			black.alpha -= 0.15;

			if (black.alpha > 0)
			{
				tmr.reset(0.3);
			}
			else
			{
				if (dialogueBox != null)
				{
					if (Paths.formatToSongPath(SONG.song) == 'thorns')
					{
						add(senpaiEvil);
						senpaiEvil.alpha = 0;
						new FlxTimer().start(0.3, function(swagTimer:FlxTimer)
						{
							senpaiEvil.alpha += 0.15;
							if (senpaiEvil.alpha < 1)
							{
								swagTimer.reset();
							}
							else
							{
								senpaiEvil.animation.play('idle');
								FlxG.sound.play(Paths.sound('Senpai_Dies'), 1, false, null, true, function()
								{
									remove(senpaiEvil);
									remove(red);
									FlxG.camera.fade(FlxColor.WHITE, 0.01, true, function()
									{
										add(dialogueBox);
										camHUD.visible = true;
									}, true);
								});
								new FlxTimer().start(3.2, function(deadTime:FlxTimer)
								{
									FlxG.camera.fade(FlxColor.WHITE, 1.6, false);
								});
							}
						});
					}
					else
					{
						add(dialogueBox);
					}
				}
				else
					startCountdown();

				remove(black);
			}
		});
	}

	function tankIntro()
	{
		var cutsceneHandler:CutsceneHandler = new CutsceneHandler();

		var songName:String = Paths.formatToSongPath(SONG.song);
		dadGroup.alpha = 0.00001;
		camHUD.visible = false;
		//inCutscene = true; //this would stop the camera movement, oops

		var tankman:FlxSprite = new FlxSprite(-20, 320);
		tankman.frames = Paths.getSparrowAtlas('cutscenes/' + songName);
		tankman.antialiasing = ClientPrefs.data.globalAntialiasing;
		addBehindDad(tankman);
		cutsceneHandler.push(tankman);

		var tankman2:FlxSprite = new FlxSprite(16, 312);
		tankman2.antialiasing = ClientPrefs.data.globalAntialiasing;
		tankman2.alpha = 0.000001;
		cutsceneHandler.push(tankman2);
		var gfDance:FlxSprite = new FlxSprite(gf.x - 107, gf.y + 140);
		gfDance.antialiasing = ClientPrefs.data.globalAntialiasing;
		cutsceneHandler.push(gfDance);
		var gfCutscene:FlxSprite = new FlxSprite(gf.x - 104, gf.y + 122);
		gfCutscene.antialiasing = ClientPrefs.data.globalAntialiasing;
		cutsceneHandler.push(gfCutscene);
		var picoCutscene:FlxSprite = new FlxSprite(gf.x - 849, gf.y - 264);
		picoCutscene.antialiasing = ClientPrefs.data.globalAntialiasing;
		cutsceneHandler.push(picoCutscene);
		var boyfriendCutscene:FlxSprite = new FlxSprite(boyfriend.x + 5, boyfriend.y + 20);
		boyfriendCutscene.antialiasing = ClientPrefs.data.globalAntialiasing;
		cutsceneHandler.push(boyfriendCutscene);

		cutsceneHandler.finishCallback = function()
		{
			var timeForStuff:Float = Conductor.crochet / 1000 * 4.5;
			FlxG.sound.music.fadeOut(timeForStuff);
			FlxTween.tween(FlxG.camera, {zoom: defaultCamZoom}, timeForStuff, {ease: FlxEase.quadInOut});
			moveCamera(true);
			startCountdown();

			dadGroup.alpha = 1;
			camHUD.visible = true;
			boyfriend.animation.finishCallback = null;
			gf.animation.finishCallback = null;
			gf.dance();
		};

		camFollow.set(dad.x + 280, dad.y + 170);
		switch(songName)
		{
			case 'ugh':
				cutsceneHandler.endTime = 12;
				cutsceneHandler.music = 'DISTORTO';
				precacheList.set('wellWellWell', 'sound');
				precacheList.set('killYou', 'sound');
				precacheList.set('bfBeep', 'sound');

				var wellWellWell:FlxSound = new FlxSound().loadEmbedded(Paths.sound('wellWellWell'));
				FlxG.sound.list.add(wellWellWell);

				tankman.animation.addByPrefix('wellWell', 'TANK TALK 1 P1', 24, false);
				tankman.animation.addByPrefix('killYou', 'TANK TALK 1 P2', 24, false);
				tankman.animation.play('wellWell', true);
				FlxG.camera.zoom *= 1.2;

				// Well well well, what do we got here?
				cutsceneHandler.timer(0.1, function()
				{
					wellWellWell.play(true);
				});

				// Move camera to BF
				cutsceneHandler.timer(3, function()
				{
					camFollow.x += 750;
					camFollow.y += 100;
				});

				// Beep!
				cutsceneHandler.timer(4.5, function()
				{
					boyfriend.playAnim('singUP', true);
					boyfriend.specialAnim = true;
					FlxG.sound.play(Paths.sound('bfBeep'));
				});

				// Move camera to Tankman
				cutsceneHandler.timer(6, function()
				{
					camFollow.x -= 750;
					camFollow.y -= 100;

					// We should just kill you but... what the hell, it's been a boring day... let's see what you've got!
					tankman.animation.play('killYou', true);
					FlxG.sound.play(Paths.sound('killYou'));
				});

			case 'guns':
				cutsceneHandler.endTime = 11.5;
				cutsceneHandler.music = 'DISTORTO';
				tankman.x += 40;
				tankman.y += 10;
				precacheList.set('tankSong2', 'sound');

				var tightBars:FlxSound = new FlxSound().loadEmbedded(Paths.sound('tankSong2'));
				FlxG.sound.list.add(tightBars);

				tankman.animation.addByPrefix('tightBars', 'TANK TALK 2', 24, false);
				tankman.animation.play('tightBars', true);
				boyfriend.animation.curAnim.finish();

				cutsceneHandler.onStart = function()
				{
					tightBars.play(true);
					FlxTween.tween(FlxG.camera, {zoom: defaultCamZoom * 1.2}, 4, {ease: FlxEase.quadInOut});
					FlxTween.tween(FlxG.camera, {zoom: defaultCamZoom * 1.2 * 1.2}, 0.5, {ease: FlxEase.quadInOut, startDelay: 4});
					FlxTween.tween(FlxG.camera, {zoom: defaultCamZoom * 1.2}, 1, {ease: FlxEase.quadInOut, startDelay: 4.5});
				};

				cutsceneHandler.timer(4, function()
				{
					gf.playAnim('sad', true);
					gf.animation.finishCallback = function(name:String)
					{
						gf.playAnim('sad', true);
					};
				});

			case 'stress':
				cutsceneHandler.endTime = 35.5;
				tankman.x -= 54;
				tankman.y -= 14;
				gfGroup.alpha = 0.00001;
				boyfriendGroup.alpha = 0.00001;
				camFollow.set(dad.x + 400, dad.y + 170);
				FlxTween.tween(FlxG.camera, {zoom: 0.9 * 1.2}, 1, {ease: FlxEase.quadInOut});
				foregroundSprites.forEach(function(spr:BGSprite)
				{
					spr.y += 100;
				});
				precacheList.set('stressCutscene', 'sound');

				tankman2.frames = Paths.getSparrowAtlas('cutscenes/stress2');
				addBehindDad(tankman2);

				if (!ClientPrefs.data.lowQuality)
				{
					gfDance.frames = Paths.getSparrowAtlas('characters/gfTankmen');
					gfDance.animation.addByPrefix('dance', 'GF Dancing at Gunpoint', 24, true);
					gfDance.animation.play('dance', true);
					addBehindGF(gfDance);
				}

				gfCutscene.frames = Paths.getSparrowAtlas('cutscenes/stressGF');
				gfCutscene.animation.addByPrefix('dieBitch', 'GF STARTS TO TURN PART 1', 24, false);
				gfCutscene.animation.addByPrefix('getRektLmao', 'GF STARTS TO TURN PART 2', 24, false);
				gfCutscene.animation.play('dieBitch', true);
				gfCutscene.animation.pause();
				addBehindGF(gfCutscene);
				if (!ClientPrefs.data.lowQuality)
				{
					gfCutscene.alpha = 0.00001;
				}

				picoCutscene.frames = AtlasFrameMaker.construct('cutscenes/stressPico');
				picoCutscene.animation.addByPrefix('anim', 'Pico Badass', 24, false);
				addBehindGF(picoCutscene);
				picoCutscene.alpha = 0.00001;

				boyfriendCutscene.frames = Paths.getSparrowAtlas('characters/BOYFRIEND');
				boyfriendCutscene.animation.addByPrefix('idle', 'BF idle dance', 24, false);
				boyfriendCutscene.animation.play('idle', true);
				boyfriendCutscene.animation.curAnim.finish();
				addBehindBF(boyfriendCutscene);

				var cutsceneSnd:FlxSound = new FlxSound().loadEmbedded(Paths.sound('stressCutscene'));
				FlxG.sound.list.add(cutsceneSnd);

				tankman.animation.addByPrefix('godEffingDamnIt', 'TANK TALK 3', 24, false);
				tankman.animation.play('godEffingDamnIt', true);

				var calledTimes:Int = 0;
				var zoomBack:Void->Void = function()
				{
					var camPosX:Float = 630;
					var camPosY:Float = 425;
					camFollow.set(camPosX, camPosY);
					camFollowPos.setPosition(camPosX, camPosY);
					FlxG.camera.zoom = 0.8;
					cameraSpeed = 1;

					calledTimes++;
					if (calledTimes > 1)
					{
						foregroundSprites.forEach(function(spr:BGSprite)
						{
							spr.y -= 100;
						});
					}
				}

				cutsceneHandler.onStart = function()
				{
					cutsceneSnd.play(true);
				};

				cutsceneHandler.timer(15.2, function()
				{
					FlxTween.tween(camFollow, {x: 650, y: 300}, 1, {ease: FlxEase.sineOut});
					FlxTween.tween(FlxG.camera, {zoom: 0.9 * 1.2 * 1.2}, 2.25, {ease: FlxEase.quadInOut});

					gfDance.visible = false;
					gfCutscene.alpha = 1;
					gfCutscene.animation.play('dieBitch', true);
					gfCutscene.animation.finishCallback = function(name:String)
					{
						if(name == 'dieBitch') //Next part
						{
							gfCutscene.animation.play('getRektLmao', true);
							gfCutscene.offset.set(224, 445);
						}
						else
						{
							gfCutscene.visible = false;
							picoCutscene.alpha = 1;
							picoCutscene.animation.play('anim', true);

							boyfriendGroup.alpha = 1;
							boyfriendCutscene.visible = false;
							boyfriend.playAnim('bfCatch', true);
							boyfriend.animation.finishCallback = function(name:String)
							{
								if(name != 'idle')
								{
									boyfriend.playAnim('idle', true);
									boyfriend.animation.curAnim.finish(); //Instantly goes to last frame
								}
							};

							picoCutscene.animation.finishCallback = function(name:String)
							{
								picoCutscene.visible = false;
								gfGroup.alpha = 1;
								picoCutscene.animation.finishCallback = null;
							};
							gfCutscene.animation.finishCallback = null;
						}
					};
				});

				cutsceneHandler.timer(17.5, function()
				{
					zoomBack();
				});

				cutsceneHandler.timer(19.5, function()
				{
					tankman2.animation.addByPrefix('lookWhoItIs', 'TANK TALK 3', 24, false);
					tankman2.animation.play('lookWhoItIs', true);
					tankman2.alpha = 1;
					tankman.visible = false;
				});

				cutsceneHandler.timer(20, function()
				{
					camFollow.set(dad.x + 500, dad.y + 170);
				});

				cutsceneHandler.timer(31.2, function()
				{
					boyfriend.playAnim('singUPmiss', true);
					boyfriend.animation.finishCallback = function(name:String)
					{
						if (name == 'singUPmiss')
						{
							boyfriend.playAnim('idle', true);
							boyfriend.animation.curAnim.finish(); //Instantly goes to last frame
						}
					};

					camFollow.set(boyfriend.x + 280, boyfriend.y + 200);
					cameraSpeed = 12;
					FlxTween.tween(FlxG.camera, {zoom: 0.9 * 1.2 * 1.2}, 0.25, {ease: FlxEase.elasticOut});
				});

				cutsceneHandler.timer(32.2, function()
				{
					zoomBack();
				});
		}
	}

	var startTimer:FlxTimer;
	var finishTimer:FlxTimer = null;

	// For being able to mess with the sprites on Lua
	public var countdownReady:FlxSprite;
	public var countdownSet:FlxSprite;
	public var countdownGo:FlxSprite;
	public static var startOnTime:Float = 0;

	function cacheCountdown()
	{
		var introAssets:Map<String, Array<String>> = new Map<String, Array<String>>();
		introAssets.set('default', ['ready', 'set', 'go']);
		introAssets.set('pixel', ['pixelUI/ready-pixel', 'pixelUI/set-pixel', 'pixelUI/date-pixel']);

		var introAlts:Array<String> = introAssets.get('default');
		if (isPixelStage) introAlts = introAssets.get('pixel');
		
		for (asset in introAlts)
			Paths.image(asset);
		
		Paths.sound('intro3' + introSoundsSuffix);
		Paths.sound('intro2' + introSoundsSuffix);
		Paths.sound('intro1' + introSoundsSuffix);
		Paths.sound('introGo' + introSoundsSuffix);
	}

	public function startCountdown():Void
	{
		if(startedCountdown) {
			callOnScripts('onStartCountdown', []);
			return;
		}

		inCutscene = false;
		var ret:Dynamic = callOnScripts('onStartCountdown', [], false);
		if(ret != FunkinLua.Function_Stop) {
			if (skipCountdown || startOnTime > 0) skipArrowStartTween = true;
			#if android androidControls.visible = true; #end
			generateStaticArrows(0);
			generateStaticArrows(1);
			                        // If the player is controlling the opponent side, swap the static arrow
                        // positions/properties so arrows match the active side.
            if (playOpponent) {
                var maxSwap:Int = Std.int(Math.min(playerStrums.length, opponentStrums.length));
                for (i in 0...maxSwap) {
                    var p:StrumNote = playerStrums.members[i];
                    var o:StrumNote = opponentStrums.members[i];
					if (!ClientPrefs.data.middleScroll) {
					var tmpX:Float = p.x;
					p.x = o.x;
					o.x = tmpX;

					var tmpY:Float = p.y;
					p.y = o.y;
					o.y = tmpY;
					}
									

                    var tmpAngle:Float = p.angle;
                    p.angle = o.angle;
                    o.angle = tmpAngle;

                	var tmpDir:Float = p.direction;
                    p.direction = o.direction;
                     o.direction = tmpDir;

                    var tmpAlpha:Float = p.alpha;
                    p.alpha = o.alpha;
                    o.alpha = tmpAlpha;

                    var tmpDown:Bool = p.downScroll;
                    p.downScroll = o.downScroll;
                    o.downScroll = tmpDown;
					var tmpSustain:Bool = p.sustainReduce;
                    p.sustainReduce = o.sustainReduce;
                    o.sustainReduce = tmpSustain;

                    p.updateHitbox();
                    o.updateHitbox();
                }
            }
			for (i in 0...playerStrums.length) {
				setOnScripts('defaultPlayerStrumX' + i, playerStrums.members[i].x);
				setOnScripts('defaultPlayerStrumY' + i, playerStrums.members[i].y);
			}
			for (i in 0...opponentStrums.length) {
				setOnScripts('defaultOpponentStrumX' + i, opponentStrums.members[i].x);
				setOnScripts('defaultOpponentStrumY' + i, opponentStrums.members[i].y);
				//if(ClientPrefs.data.middleScroll) opponentStrums.members[i].visible = false;
			}

			startedCountdown = true;
			Conductor.songPosition = -Conductor.crochet * 5;
			setOnScripts('startedCountdown', true);
			callOnScripts('onCountdownStarted', []);

			var swagCounter:Int = 0;

			if(startOnTime < 0) startOnTime = 0;

			if (startOnTime > 0) {
				clearNotesBefore(startOnTime);
				setSongTime(startOnTime - 350);
				return;
			}
			else if (skipCountdown)
			{
				setSongTime(0);
				return;
			}

			startTimer = new FlxTimer().start(Conductor.crochet / 1000 / playbackRate, function(tmr:FlxTimer)
			{
				if (gf != null && tmr.loopsLeft % Math.round(gfSpeed * gf.danceEveryNumBeats) == 0 && gf.animation.curAnim != null && !gf.animation.curAnim.name.startsWith("sing") && !gf.stunned)
				{
					gf.dance();
				}
				if (tmr.loopsLeft % boyfriend.danceEveryNumBeats == 0 && boyfriend.animation.curAnim != null && !boyfriend.animation.curAnim.name.startsWith('sing') && !boyfriend.stunned)
				{
					boyfriend.dance();
				}
				if (tmr.loopsLeft % dad.danceEveryNumBeats == 0 && dad.animation.curAnim != null && !dad.animation.curAnim.name.startsWith('sing') && !dad.stunned)
				{
					dad.dance();
				}

				var introAssets:Map<String, Array<String>> = new Map<String, Array<String>>();
				introAssets.set('default', ['ready', 'set', 'go']);
				introAssets.set('pixel', ['pixelUI/ready-pixel', 'pixelUI/set-pixel', 'pixelUI/date-pixel']);

				var introAlts:Array<String> = introAssets.get('default');
				var antialias:Bool = ClientPrefs.data.globalAntialiasing;
				if(isPixelStage) {
					introAlts = introAssets.get('pixel');
					antialias = false;
				}

				// head bopping for bg characters on Mall
				if(curStage == 'mall') {
					if(!ClientPrefs.data.lowQuality)
						upperBoppers.dance(true);

					bottomBoppers.dance(true);
					santa.dance(true);
				}

				switch (swagCounter)
				{
					case 0:
						FlxG.sound.play(Paths.sound('intro3' + introSoundsSuffix), 0.6);
					case 1:
						countdownReady = new FlxSprite().loadGraphic(Paths.image(introAlts[0]));
						countdownReady.cameras = [camHUD];
						countdownReady.scrollFactor.set();
						countdownReady.updateHitbox();

						if (PlayState.isPixelStage)
							countdownReady.setGraphicSize(Std.int(countdownReady.width * daPixelZoom));

						countdownReady.screenCenter();
						countdownReady.antialiasing = antialias;
						insert(ClientPrefs.data.compatibility_mode ? members.indexOf(noteGroup) : members.indexOf(notes), countdownReady);
						FlxTween.tween(countdownReady, {/*y: countdownReady.y + 100,*/ alpha: 0}, Conductor.crochet / 1000, {
							ease: FlxEase.cubeInOut,
							onComplete: function(twn:FlxTween)
							{
								remove(countdownReady);
								countdownReady.destroy();
							}
						});
						FlxG.sound.play(Paths.sound('intro2' + introSoundsSuffix), 0.6);
					case 2:
						countdownSet = new FlxSprite().loadGraphic(Paths.image(introAlts[1]));
						countdownSet.cameras = [camHUD];
						countdownSet.scrollFactor.set();

						if (PlayState.isPixelStage)
							countdownSet.setGraphicSize(Std.int(countdownSet.width * daPixelZoom));

						countdownSet.screenCenter();
						countdownSet.antialiasing = antialias;
						insert(ClientPrefs.data.compatibility_mode ? members.indexOf(noteGroup) : members.indexOf(notes), countdownSet);
						FlxTween.tween(countdownSet, {/*y: countdownSet.y + 100,*/ alpha: 0}, Conductor.crochet / 1000, {
							ease: FlxEase.cubeInOut,
							onComplete: function(twn:FlxTween)
							{
								remove(countdownSet);
								countdownSet.destroy();
							}
						});
						FlxG.sound.play(Paths.sound('intro1' + introSoundsSuffix), 0.6);
					case 3:
						countdownGo = new FlxSprite().loadGraphic(Paths.image(introAlts[2]));
						countdownGo.cameras = [camHUD];
						countdownGo.scrollFactor.set();

						if (PlayState.isPixelStage)
							countdownGo.setGraphicSize(Std.int(countdownGo.width * daPixelZoom));

						countdownGo.updateHitbox();

						countdownGo.screenCenter();
						countdownGo.antialiasing = antialias;
						insert(ClientPrefs.data.compatibility_mode ? members.indexOf(noteGroup) : members.indexOf(notes), countdownGo);
						FlxTween.tween(countdownGo, {/*y: countdownGo.y + 100,*/ alpha: 0}, Conductor.crochet / 1000, {
							ease: FlxEase.cubeInOut,
							onComplete: function(twn:FlxTween)
							{
								remove(countdownGo);
								countdownGo.destroy();
							}
						});
						FlxG.sound.play(Paths.sound('introGo' + introSoundsSuffix), 0.6);
					case 4:
				}

				notes.forEachAlive(function(note:Note) {
					if(ClientPrefs.data.opponentStrums || note.mustPress)
					{
						note.copyAlpha = false;
						note.alpha = note.multAlpha;
						if(ClientPrefs.data.middleScroll && !note.mustPress) {
							note.alpha *= 0.35;
						}
					}
				});
				callOnScripts('onCountdownTick', [swagCounter]);

				swagCounter += 1;
				// generateSong('fresh');
			}, 5);
		}
	}

	public function addBehindGF(obj:FlxObject)
	{
		insert(members.indexOf(gfGroup), obj);
	}
	public function addBehindBF(obj:FlxObject)
	{
		insert(members.indexOf(boyfriendGroup), obj);
	}
	public function addBehindDad(obj:FlxObject)
	{
		insert(members.indexOf(dadGroup), obj);
	}

	public function clearNotesBefore(time:Float)
	{
		var i:Int = unspawnNotes.length - 1;
		while (i >= 0) {
			var daNote:Note = unspawnNotes[i];
			if(daNote.strumTime - 350 < time)
			{
				daNote.wasHit = true;
			}
			--i;
		}

		i = notes.length - 1;
		while (i >= 0) {
			var daNote:Note = notes.members[i];
			if(daNote.strumTime - 350 < time)
			{
				daNote.active = false;
				daNote.visible = false;
				daNote.ignoreNote = true;
				daNote.kill();
			}
			--i;
		}


	}
	//var lerpSongScore:Float = 0;
	public function updateScore(miss:Bool = false)
	{
		/*
		scoreTxt.text = Language.get("scorelangtxt", "Score") + ': ${Math.floor(lerpSongScore)}'
		+ " | " + Language.get("combobtxt", "Combo Breaks") + ': $songMisses'
		+  " | " + Language.get("acclangtxt", "Accuracy") + ':' + (ratingName != '?' ? ' ${Highscore.floorDecimal(ratingPercent * 100, 2)}% | $ratingFC ' : '') + '($ratingName)';
		*/
		scoreTxt.text = Language.get("scorelangtxt", "Score") + ': $songScore'
		+ " | " + Language.get("combobtxt", "Combo Breaks") + ': $songMisses'
		+  " | " + Language.get("acclangtxt", "Accuracy") + ':' + (ratingName != '?' ? ' ${Highscore.floorDecimal(ratingPercent * 100, 2)}% | $ratingFC ' : '') + '($ratingName)';

		if(ClientPrefs.data.scoreZoom && !miss && !cpuControlled)
		{
			if(scoreTxtTween != null) {
				scoreTxtTween.cancel();
			}
			scoreTxt.scale.x = 1.075;
			scoreTxt.scale.y = 1.075;
			scoreTxtTween = FlxTween.tween(scoreTxt.scale, {x: 1, y: 1}, 0.2, {
				onComplete: function(twn:FlxTween) {
					scoreTxtTween = null;
				}
			});
		}
		callOnScripts('onUpdateScore', [miss]);
	}

	public function setSongTime(time:Float)
	{
		if(time < 0) time = 0;

		FlxG.sound.music.pause();
		vocals.pause();
		vocalsPlayer.pause();
		vocalsOpponent.pause();

		FlxG.sound.music.time = time;
		FlxG.sound.music.pitch = playbackRate;
		FlxG.sound.music.play();

		if (Conductor.songPosition <= vocals.length)
		{
			vocals.time = time;
			vocals.pitch = playbackRate;
		}
		
		if (Conductor.songPosition <= vocalsOpponent.length)
		{
			vocalsOpponent.time = time;
			vocalsOpponent.pitch = playbackRate;
		}
		
		if (Conductor.songPosition <= vocalsPlayer.length)
		{
			vocalsPlayer.time = time;
			vocalsPlayer.pitch = playbackRate;
		}
		vocals.play();
		vocalsPlayer.play();
		vocalsOpponent.play();

		Conductor.songPosition = time;
		songTime = time;
	}

	function startNextDialogue() {
		dialogueCount++;
		callOnScripts('onNextDialogue', [dialogueCount]);
	}

	function skipDialogue() {
		callOnScripts('onSkipDialogue', [dialogueCount]);
	}

	var previousFrameTime:Int = 0;
	var lastReportedPlayheadPosition:Int = 0;
	var songTime:Float = 0;

	function startSong():Void
	{
		startingSong = false;

		previousFrameTime = FlxG.game.ticks;
		lastReportedPlayheadPosition = 0;

		FlxG.sound.playMusic(Paths.inst(PlayState.SONG.song), 1, false);
		FlxG.sound.music.pitch = playbackRate;
		FlxG.sound.music.onComplete = finishSong.bind();
		vocals.play();
		vocalsPlayer.play();
		vocalsOpponent.play();

		if(startOnTime > 0)
		{
			setSongTime(startOnTime - 500);
		}
		startOnTime = 0;

		if(paused) {
			//trace('Oopsie doopsie! Paused sound');
			FlxG.sound.music.pause();
		vocals.pause();
		vocalsPlayer.pause();
		vocalsOpponent.pause();
		}

		// Song duration in a float, useful for the time left feature
		songLength = FlxG.sound.music.length;
		FlxTween.tween(timeBar, {alpha: 1}, 0.5, {ease: FlxEase.circOut});
		FlxTween.tween(timeTxt, {alpha: 1}, 0.5, {ease: FlxEase.circOut});

		if (stageBackdrop != null)
			stageBackdrop.songStart();

		#if cpp
		// Updating Discord Rich Presence (with Time Left)
		if(iconP2 != null) DiscordClient.changePresence(detailsText, SONG.song + " (" + storyDifficultyText + ")", iconP2.getCharacter(), true, songLength);
		#end
		setOnScripts('songLength', songLength);
		callOnScripts('onSongStart', []);
	}

	var debugNum:Int = 0;
	private var noteTypeMap:Map<String, Bool> = new Map<String, Bool>();
	private var eventPushedMap:Map<String, Bool> = new Map<String, Bool>();

	/** Pre-allocated reusable fields for Note creation to reduce GC pressure. */
	static var NOTE_HIT_HEALTH:Float = 0.023;
	private function generateSong(dataPath:String):Void
	{
		songSpeedType = ClientPrefs.getGameplaySetting('scrolltype','multiplicative');
		if (!(replayMode && replayExam != null)) {
			switch(songSpeedType) {
				case "multiplicative":
					songSpeed = SONG.speed * ClientPrefs.getGameplaySetting('scrollspeed', 1);
				case "constant":
					songSpeed = ClientPrefs.getGameplaySetting('scrollspeed', 1);
			}
		}

		var songData = SONG;
		Conductor.changeBPM(songData.bpm);
		curSong = songData.song;

		// Load vocals
		if (SONG.needsVoices) {
			vocals = new FlxSound().loadEmbedded(Paths.voices(PlayState.SONG.song));
			vocalsPlayer = new FlxSound().loadEmbedded(Paths.playervoices(PlayState.SONG.song));
			vocalsOpponent = new FlxSound().loadEmbedded(Paths.opponentvoices(PlayState.SONG.song));
		} else {
			vocals = new FlxSound();
			vocalsPlayer = new FlxSound();
			vocalsOpponent = new FlxSound();
		}
		vocals.pitch = playbackRate;
		vocalsPlayer.pitch = playbackRate;
		vocalsOpponent.pitch = playbackRate;
		FlxG.sound.list.add(vocals);
		FlxG.sound.list.add(vocalsPlayer);
		FlxG.sound.list.add(vocalsOpponent);
		FlxG.sound.list.add(new FlxSound().loadEmbedded(Paths.inst(PlayState.SONG.song)));

		notes = new FlxTypedGroup<Note>();
		sustainNotes = new FlxTypedGroup<Note>(); // Empty group for Lua compatibility
		if (ClientPrefs.data.compatibility_mode)
			noteGroup.add(notes);
		else
			add(notes);

		notesAddedCount = 0;
		limitNC = 0;

		var preloadedNotes:Array<PreloadedChartNote> = [];
		var noteData:Array<SwagSection> = songData.notes;
		var songName:String = Paths.formatToSongPath(SONG.song);

		// Load event notes from events.json
		var file:String = Paths.json(songName + '/events');
		#if MODS_ALLOWED
		if (FileSystem.exists(Paths.modsJson(songName + '/events')) || FileSystem.exists(file)) {
		#else
		if (OpenFlAssets.exists(file)) {
		#end
			var eventsData:Array<Dynamic> = Song.loadFromJson('events', songName).events;
			for (event in eventsData)
			{
				for (i in 0...event[1].length)
				{
					var subEvent:EventNote = {
						strumTime: event[0] + ClientPrefs.data.noteOffset,
						event: event[1][i][0],
						value1: event[1][i][1],
						value2: event[1][i][2]
					};
					subEvent.strumTime -= eventNoteEarlyTrigger(subEvent);
					eventNotes.push(subEvent);
					eventPushed(subEvent);
				}
			}
		}

		var stepCrochet:Float = Conductor.stepCrochet;
		var isNewVer:Bool = Song.isNewVersion;

		for (section in noteData)
		{
			if (section.changeBPM)
			{
				Conductor.changeBPM(section.bpm);
				stepCrochet = Conductor.stepCrochet;
			}

			var mustHit:Bool = section.mustHitSection;
			var gfSec:Bool = section.gfSection;

			for (songNotes in section.sectionNotes)
			{
				var rawStrum:Float = songNotes[0];
				var rawData:Int = Std.int(songNotes[1]);
				var noteDataIdx:Int = rawData % 4;

				var gottaHitNote:Bool = isNewVer ? (rawData < 4) : (rawData > 3 ? !mustHit : mustHit);
				if (playOpponent) gottaHitNote = !gottaHitNote;

				var noteType:String = songNotes[3];
				if (!Std.isOfType(songNotes[3], String))
					noteType = Note.defaultNoteTypes[Std.int(songNotes[3])];

				if (!noteTypeMap.exists(noteType))
					noteTypeMap.set(noteType, true);

				var isAlt:Bool = (noteType == 'Alt Animation');
				var isHurt:Bool = (noteType == 'Hurt Note');
				var isGF:Bool = gfSec && (rawData < 4) || noteType == 'GF Sing';
				var isNoAnim:Bool = (noteType == 'No Animation');
				var isAltSuffix:String = isAlt ? '-alt' : '';

				// Build PreloadedChartNote (lightweight data transfer object)
				var swagNote:PreloadedChartNote = {
					strumTime: rawStrum,
					noteData: noteDataIdx,
					mustPress: gottaHitNote,
					oppNote: playOpponent ? gottaHitNote : !gottaHitNote,
					noteType: noteType,
					animSuffix: isAltSuffix,
					gfNote: isGF,
					noAnimation: isNoAnim,
					noMissAnimation: isNoAnim,
					isSustainNote: false,
					isSustainEnd: false,
					sustainLength: songNotes[2],
					hitHealth: 0.023,
					missHealth: isHurt ? 0.3 : 0.0475,
					hitCausesMiss: isHurt,
					ignoreNote: isHurt && gottaHitNote,
					multSpeed: 1,
					multAlpha: 1,
					noteDensity: 1,
					noteskin: '',
					texture: '',
					blockHit: false,
					lowPriority: false,
					wasHit: false,
					offsetX: 0,
					offsetY: 0,
					parentST: 0,
					parentSL: 0,
					noteSplashDisabled: false,
					hitsoundDisabled: false
				};
				preloadedNotes.push(swagNote);

				var susLen:Float = swagNote.sustainLength;
				if (susLen < 1) continue;

				var roundSus:Int = Math.round(susLen / stepCrochet);
				if (roundSus < 1) continue;

				var susBaseOffset:Float = stepCrochet / FlxMath.roundDecimal(songSpeed, 2);
				for (susNote in 0...roundSus + 1)
				{
					var sustainNote:PreloadedChartNote = {
						strumTime: rawStrum + (stepCrochet * susNote) + susBaseOffset,
						noteData: noteDataIdx,
						mustPress: gottaHitNote,
						oppNote: swagNote.oppNote,
						noteType: noteType,
						animSuffix: isAltSuffix,
						gfNote: isGF,
						noAnimation: isNoAnim,
						noMissAnimation: isNoAnim,
						isSustainNote: true,
						isSustainEnd: (susNote == roundSus),
						sustainLength: susLen,
						parentST: rawStrum,
						parentSL: susLen,
						hitHealth: 0.023,
						missHealth: isHurt ? 0.1 : 0.0475,
						hitCausesMiss: isHurt,
						ignoreNote: isHurt && gottaHitNote,
						multSpeed: 1,
						multAlpha: 1,
						noteDensity: 1,
						noteskin: '',
						texture: '',
						blockHit: false,
						lowPriority: false,
						wasHit: false,
						offsetX: 0,
						offsetY: 0,
						noteSplashDisabled: false,
						hitsoundDisabled: false
					};
					preloadedNotes.push(sustainNote);
				}
			}
		}

		// Load song events (legacy format)
		for (event in songData.events)
		{
			for (i in 0...event[1].length)
			{
				var subEvent:EventNote = {
					strumTime: event[0] + ClientPrefs.data.noteOffset,
					event: event[1][i][0],
					value1: event[1][i][1],
					value2: event[1][i][2]
				};
				subEvent.strumTime -= eventNoteEarlyTrigger(subEvent);
				eventNotes.push(subEvent);
				eventPushed(subEvent);
			}
		}

		// Sort preloaded notes by time
		preloadedNotes.sort(function(a, b) return FlxSort.byValues(FlxSort.ASCENDING, a.strumTime, b.strumTime));

		// Convert to Note objects via setupNoteData + inline prevNote linking
		unspawnNotes = [];
		var lastNotePerData:Map<Int, Note> = new Map<Int, Note>();
		for (pNote in preloadedNotes)
		{
			var newNote:Note = new Note(pNote.strumTime, pNote.noteData, null, pNote.isSustainNote, false);
			newNote.setupNoteData(pNote);
			unspawnNotes.push(newNote);

			// Inline prevNote/nextNote linking (avoids a second pass)
			var prev:Note = lastNotePerData.get(newNote.noteData);
			if (prev != null) {
				newNote.prevNote = prev;
				prev.nextNote = newNote;
			}
			lastNotePerData.set(newNote.noteData, newNote);
		}

		if (eventNotes.length > 1)
			eventNotes.sort(sortByTime);

		checkEventNote();
		generatedMusic = true;
	}

	function eventPushed(event:EventNote) {
		switch(event.event) {
			case 'Change Character':
				var charType:Int = 0;
				switch(event.value1.toLowerCase()) {
					case 'gf' | 'girlfriend' | '1':
						charType = 2;
					case 'dad' | 'opponent' | '0':
						charType = 1;
					default:
						charType = Std.parseInt(event.value1);
						if(Math.isNaN(charType)) charType = 0;
				}

				var newCharacter:String = event.value2;
				addCharacterToList(newCharacter, charType);

			case 'Dadbattle Spotlight':
				dadbattleBlack = new BGSprite(null, -800, -400, 0, 0);
				dadbattleBlack.makeGraphic(Std.int(FlxG.width * 2), Std.int(FlxG.height * 2), FlxColor.BLACK);
				dadbattleBlack.alpha = 0.25;
				dadbattleBlack.visible = false;
				add(dadbattleBlack);

				dadbattleLight = new BGSprite('spotlight', 400, -400);
				dadbattleLight.alpha = 0.375;
				dadbattleLight.blend = ADD;
				dadbattleLight.visible = false;

				dadbattleSmokes.alpha = 0.7;
				dadbattleSmokes.blend = ADD;
				dadbattleSmokes.visible = false;
				add(dadbattleLight);
				add(dadbattleSmokes);

				var offsetX = 200;
				var smoke:BGSprite = new BGSprite('smoke', -1550 + offsetX, 660 + FlxG.random.float(-20, 20), 1.2, 1.05);
				smoke.setGraphicSize(Std.int(smoke.width * FlxG.random.float(1.1, 1.22)));
				smoke.updateHitbox();
				smoke.velocity.x = FlxG.random.float(15, 22);
				smoke.active = true;
				dadbattleSmokes.add(smoke);
				var smoke:BGSprite = new BGSprite('smoke', 1550 + offsetX, 660 + FlxG.random.float(-20, 20), 1.2, 1.05);
				smoke.setGraphicSize(Std.int(smoke.width * FlxG.random.float(1.1, 1.22)));
				smoke.updateHitbox();
				smoke.velocity.x = FlxG.random.float(-15, -22);
				smoke.active = true;
				smoke.flipX = true;
				dadbattleSmokes.add(smoke);


			case 'Philly Glow':
				blammedLightsBlack = new FlxSprite(FlxG.width * -0.5, FlxG.height * -0.5).makeGraphic(Std.int(FlxG.width * 2), Std.int(FlxG.height * 2), FlxColor.BLACK);
				blammedLightsBlack.visible = false;
				insert(members.indexOf(phillyStreet), blammedLightsBlack);

				phillyWindowEvent = new BGSprite('philly/window', phillyWindow.x, phillyWindow.y, 0.3, 0.3);
				phillyWindowEvent.setGraphicSize(Std.int(phillyWindowEvent.width * 0.85));
				phillyWindowEvent.updateHitbox();
				phillyWindowEvent.visible = false;
				insert(members.indexOf(blammedLightsBlack) + 1, phillyWindowEvent);


				phillyGlowGradient = new PhillyGlow.PhillyGlowGradient(-400, 225); //This shit was refusing to properly load FlxGradient so fuck it
				phillyGlowGradient.visible = false;
				insert(members.indexOf(blammedLightsBlack) + 1, phillyGlowGradient);
				if(!ClientPrefs.data.flashing) phillyGlowGradient.intendedAlpha = 0.7;

				precacheList.set('philly/particle', 'image'); //precache particle image
				phillyGlowParticles = new FlxTypedGroup<PhillyGlow.PhillyGlowParticle>();
				phillyGlowParticles.visible = false;
				insert(members.indexOf(phillyGlowGradient) + 1, phillyGlowParticles);
		}

		if(!eventPushedMap.exists(event.event)) {
			eventPushedMap.set(event.event, true);
		}
	}

	function eventNoteEarlyTrigger(event:EventNote):Float {
		var returnedValue:Float = callOnScripts('eventEarlyTrigger', [event.event]);
		if(returnedValue != 0) {
			return returnedValue;
		}

		switch(event.event) {
			case 'Kill Henchmen': //Better timing so that the kill sound matches the beat intended
				return 280; //Plays 280ms before the actual position
		}
		return 0;
	}

	function sortByShit(Obj1:Note, Obj2:Note):Int
	{
		return FlxSort.byValues(FlxSort.ASCENDING, Obj1.strumTime, Obj2.strumTime);
	}

	public static function sortByTime(Obj1:Dynamic, Obj2:Dynamic):Int
	{
		return FlxSort.byValues(FlxSort.ASCENDING, Obj1.strumTime, Obj2.strumTime);
	}

	public var skipArrowStartTween:Bool = false; //for lua
	private function generateStaticArrows(player:Int):Void
	{
		for (i in 0...4)
		{
			// FlxG.log.add(i);
			var targetAlpha:Float = 1;
			if (player < 1)
			{
				if(!ClientPrefs.data.opponentStrums) targetAlpha = 0;
				else if(ClientPrefs.data.middleScroll) targetAlpha = 0.35;
			}

			var babyArrow:StrumNote = new StrumNote(ClientPrefs.data.middleScroll ? STRUM_X_MIDDLESCROLL : STRUM_X, strumLine.y, i, player);
			babyArrow.downScroll = ClientPrefs.data.downScroll;
			if (!isStoryMode && !skipArrowStartTween)
			{
				//babyArrow.y -= 10;
				babyArrow.alpha = 0;
				FlxTween.tween(babyArrow, {/*y: babyArrow.y + 10,*/ alpha: targetAlpha}, 1, {ease: FlxEase.circOut, startDelay: 0.5 + (0.2 * i)});
			}
			else
			{
				babyArrow.alpha = targetAlpha;
			}

			if (player == 1)
			{
				playerStrums.add(babyArrow);
			}
			else
			{
				if(ClientPrefs.data.middleScroll)
				{
					babyArrow.x += 310;
					if(i > 1) { //Up and Right
						babyArrow.x += FlxG.width / 2 + 25;
					}
				}
				opponentStrums.add(babyArrow);
			}

			strumLineNotes.add(babyArrow);
			babyArrow.postAddedToGroup();
		}
	}

	override function openSubState(SubState:FlxSubState)
	{
		if (paused)
		{
			if (FlxG.sound.music != null)
			{
				FlxG.sound.music.pause();
			vocals.pause();
			vocalsPlayer.pause();
			vocalsOpponent.pause();
			}

			if (startTimer != null && !startTimer.finished)
				startTimer.active = false;
			if (finishTimer != null && !finishTimer.finished)
				finishTimer.active = false;
			if (songSpeedTween != null)
				songSpeedTween.active = false;

			if (limoStage != null && limoStage.carTimer != null) limoStage.carTimer.active = false;

			var chars:Array<Character> = [boyfriend, gf, dad];
			for (char in chars) {
				if(char != null && char.colorTween != null) {
					char.colorTween.active = false;
				}
			}

			for (tween in modchartTweens) {
				tween.active = false;
			}
			for (timer in modchartTimers) {
				timer.active = false;
			}
		}

		super.openSubState(SubState);
	}

	override function closeSubState()
	{
		if (paused)
		{
			if (FlxG.sound.music != null && !startingSong)
			{
				resyncVocals();
			}

			if (startTimer != null && !startTimer.finished)
				startTimer.active = true;
			if (finishTimer != null && !finishTimer.finished)
				finishTimer.active = true;
			if (songSpeedTween != null)
				songSpeedTween.active = true;

			if (limoStage != null && limoStage.carTimer != null) limoStage.carTimer.active = true;

			var chars:Array<Character> = [boyfriend, gf, dad];
			for (char in chars) {
				if(char != null && char.colorTween != null) {
					char.colorTween.active = true;
				}
			}

			for (tween in modchartTweens) {
				tween.active = true;
			}
			for (timer in modchartTimers) {
				timer.active = true;
			}
			paused = false;
			callOnScripts('onResume', []);

			#if desktop
			if (startTimer != null && startTimer.finished)
			{
				if(iconP2 != null) DiscordClient.changePresence(detailsText, SONG.song + " (" + storyDifficultyText + ")", iconP2.getCharacter(), true, songLength - Conductor.songPosition - ClientPrefs.data.noteOffset);
			}
			else
			{
				if(iconP2 != null) DiscordClient.changePresence(detailsText, SONG.song + " (" + storyDifficultyText + ")", iconP2.getCharacter());
			}
			#end
		}

		super.closeSubState();
	}

	override public function onFocus():Void
	{
		#if desktop
		if (health > 0 && !paused && iconP2 != null)
		{
			if (Conductor.songPosition > 0.0)
			{
				DiscordClient.changePresence(detailsText, SONG.song + " (" + storyDifficultyText + ")", iconP2.getCharacter(), true, songLength - Conductor.songPosition - ClientPrefs.data.noteOffset);
			}
			else
			{
				DiscordClient.changePresence(detailsText, SONG.song + " (" + storyDifficultyText + ")", iconP2.getCharacter());
			}
		}
		#end

		super.onFocus();
	}

	override public function onFocusLost():Void
	{
		#if desktop
		if (health > 0 && !paused && iconP2 != null)
		{
			DiscordClient.changePresence(detailsPausedText, SONG.song + " (" + storyDifficultyText + ")", iconP2.getCharacter());
		}
		#end

		super.onFocusLost();
	}

	function resyncVocals():Void
	{
		if(finishTimer != null || startingSong || FlxG.sound.music == null) return;

		vocals.pause();
		vocalsPlayer.pause();
		vocalsOpponent.pause();

		FlxG.sound.music.play();
		FlxG.sound.music.pitch = playbackRate;
		Conductor.songPosition = FlxG.sound.music.time;
		if (Conductor.songPosition <= vocals.length)
		{
			vocals.time = Conductor.songPosition;
			vocals.pitch = playbackRate;
		}
		if (Conductor.songPosition <= vocalsPlayer.length)
		{
			vocalsPlayer.time = Conductor.songPosition;
			vocalsPlayer.pitch = playbackRate;
		}
		if (Conductor.songPosition <= vocalsOpponent.length)
		{
			vocalsOpponent.time = Conductor.songPosition;
			vocalsOpponent.pitch = playbackRate;
		}
		vocals.play();
		vocalsPlayer.play();
		vocalsOpponent.play();
	}

	public var paused:Bool = false;
	public var canReset:Bool = true;
	var startedCountdown:Bool = false;
	var canPause:Bool = true;

	override public function update(elapsed:Float)
	{
		/*if (FlxG.keys.justPressed.NINE)
		{
			iconP1.swapOldIcon();
		}*/
		callOnScripts('onUpdate', [elapsed]);
		keyboardDisplay.dataUpdate(elapsed);
		/*
		lerpSongScore = FlxMath.lerp(lerpSongScore, songScore, CoolUtil.boundTo(elapsed * 10, 0, 1));
   		if (Math.abs(lerpSongScore - songScore) <= 10) lerpSongScore = songScore;
		scoreTxt.text = Language.get("scorelangtxt", "Score") + ': ${Math.floor(lerpSongScore)}'
		+ " | " + Language.get("combobtxt", "Combo Breaks") + ': $songMisses'
		+  " | " + Language.get("acclangtxt", "Accuracy") + ':' + (ratingName != '?' ? ' ${Highscore.floorDecimal(ratingPercent * 100, 2)}% | $ratingFC ' : '') + '($ratingName)';
		*/

		// Delegate per-frame stage update to the backdrop handler
		if (stageBackdrop != null)
			stageBackdrop.update(elapsed);

		if(!inCutscene) {
			var lerpVal:Float = CoolUtil.boundTo(elapsed * 2.4 * cameraSpeed * playbackRate, 0, 1);
			camFollowPos.setPosition(FlxMath.lerp(camFollowPos.x, camFollow.x, lerpVal), FlxMath.lerp(camFollowPos.y, camFollow.y, lerpVal));
			if(!startingSong && !endingSong && boyfriend.animation.curAnim != null && boyfriend.animation.curAnim.name.startsWith('idle')) {
				boyfriendIdleTime += elapsed;
				if(boyfriendIdleTime >= 0.15) { // Kind of a mercy thing for making the achievement easier to get as it's apparently frustrating to some playerss
					boyfriendIdled = true;
				}
			} else {
				boyfriendIdleTime = 0;
			}
		}
		if (combo > maxcombo){
		maxcombo = combo;
		}
		super.update(elapsed);


		// Track background: reposition and resize to follow player strum lanes
		if (playerStrums != null && playerStrums.length >= 4 && trackBackground != null)
		{
			var s0:Float = playerStrums.members[0].x;
			var s1:Float = playerStrums.members[1].x;
			var s2:Float = playerStrums.members[2].x;
			var s3:Float = playerStrums.members[3].x;
			var minX:Float = Math.min(Math.min(s0, s1), Math.min(s2, s3));
			var maxX:Float = Math.max(Math.max(s0, s1), Math.max(s2, s3));
			var extraWidth:Float = scaleFactor * 15;
			trackBackground.x = minX - extraWidth;
			var newWidth:Float = (maxX + 112) - minX + (extraWidth * 2);
			if (Math.abs(trackBackground.width - newWidth) > 1)
				trackBackground.makeGraphic(Std.int(newWidth), 820, FlxColor.fromString('#' + trackColor));

			// Ensure track bg is behind notes
			if (strumLineNotes != null) {
				var bgIdx:Int = members.indexOf(trackBackground);
				var notesIdx:Int = ClientPrefs.data.compatibility_mode
					? members.indexOf(noteGroup)
					: members.indexOf(strumLineNotes);
				if (bgIdx > notesIdx) {
					remove(trackBackground, true);
					insert(notesIdx, trackBackground);
				}
			}
		}


		if (ClientPrefs.data.sidehud) {
			tnh.text = Language.get("totalNotesText", "Total Notes Hit:") + notehitlol;
			cm.text = Language.get("combosText", "Combos") + combo + '($maxcombo)';
			sick.text = Language.get("sicksText", "Sicks:") + sicks;
			good.text = Language.get("goodsText", "Goods:") + goods;
			bad.text = Language.get("badsText", "Bads:") + bads;
			shit.text = Language.get("shitsText", "Shits:") + shits;
			miss.text = Language.get("missesText", "Misses:") + songMisses;
		}

		setOnScripts('curDecStep', curDecStep);
		setOnScripts('curDecBeat', curDecBeat);

		if(botplayTxt.visible) {
			botplaySine += 180 * elapsed;
			botplayTxt.alpha = 1 - Math.sin((Math.PI * botplaySine) / 180 * playbackRate);
		}
		if(botplayTxt != null && cpuControlled && !botplayUsed) botplayUsed = true;
		if(replayTxt.visible) {
			replaySine += 180 * elapsed;
			replayTxt.alpha = 1 - Math.sin((Math.PI * replaySine) / 180);
		}


		if (controls.PAUSE	#if android || FlxG.android.justReleased.BACK #end && startedCountdown && canPause)
		{
			var ret:Dynamic = callOnScripts('onPause', [], false);
			if(ret != FunkinLua.Function_Stop#if VIDEOS_ALLOWED && !videoPlaying #end)  {
				openPauseMenu();
			}
		}

		if (FlxG.keys.anyJustPressed(debugKeysChart) && !endingSong && !inCutscene)
		{
			openChartEditor();
		}


		if (cpuControlled && (songScore != 0 || songHits != 0)) {
			songScore = 0;
			songHits = 0;
			RecalculateRating();
			updateScore();
		}

		// Clamp health
		if (health > 2) health = 2;

		// Update health icon frames based on bar percent (use cached getter)
		var hpPercent:Float = _healthBarPercent;
		var p1frame:Int = iconP1.animation.curAnim.curFrame;
		var p2frame:Int = iconP2.animation.curAnim.curFrame;
		if (hpPercent < 20) {
			if (p1frame != 1) iconP1.animation.curAnim.curFrame = 1;
			if (p2frame != 2) iconP2.animation.curAnim.curFrame = 2;
		} else if (hpPercent > 80) {
			if (p1frame != 2) iconP1.animation.curAnim.curFrame = 2;
			if (p2frame != 1) iconP2.animation.curAnim.curFrame = 1;
		} else {
			if (p1frame != 0) iconP1.animation.curAnim.curFrame = 0;
			if (p2frame != 0) iconP2.animation.curAnim.curFrame = 0;
		}

		if (FlxG.keys.anyJustPressed(debugKeysCharacter) && !endingSong && !inCutscene) {
			persistentUpdate = false;
			paused = true;
			cancelMusicFadeTween();
			MusicBeatState.switchState(new CharacterEditorState(SONG.player2));
		}
		
		if (startedCountdown)
		{
			Conductor.songPosition += FlxG.elapsed * 1000 * playbackRate;
		}
		
		updateIconsScale(elapsed);
		// Smoothly interpolate displayed health towards actual health for a smooth bar transition
		var smoothSpeed:Float = 8; // tweakable smoothing speed
		displayHealth += (health - displayHealth) * Math.min(1, elapsed * smoothSpeed);
		healthBar.updateBar();
		// Update icon positions smoothly
		updateIconsPosition(elapsed);

		if (startingSong)
		{
			if (startedCountdown && Conductor.songPosition >= 0)
				startSong();
			else if(!startedCountdown)
				Conductor.songPosition = -Conductor.crochet * 5;
		}
		else
		{
			if (!paused)
			{
				songTime += FlxG.game.ticks - previousFrameTime;
				previousFrameTime = FlxG.game.ticks;

				// Interpolation type beat
				if (Conductor.lastSongPos != Conductor.songPosition)
				{
					songTime = (songTime + Conductor.songPosition) / 2;
					Conductor.lastSongPos = Conductor.songPosition;
					// Conductor.songPosition += FlxG.elapsed * 1000;
					// trace('MISSED FRAME');
				}

				if(updateTime) {
					var curTime:Float = Conductor.songPosition - ClientPrefs.data.noteOffset;
					if(curTime < 0) curTime = 0;
					songPercent = (curTime / songLength);

					var songCalc:Float = (ClientPrefs.data.timeBarType == 'Time Elapsed') ? curTime : (songLength - curTime);
					var secondsTotal:Int = Math.floor(songCalc / 1000);
					if(secondsTotal < 0) secondsTotal = 0;

					if(ClientPrefs.data.timeBarType != 'Song Name')
						timeTxt.text = FlxStringUtil.formatTime(secondsTotal, false);
				}
			}

			// Conductor.lastSongPos = FlxG.sound.music.time;
		}

		if (camZooming)
		{
			FlxG.camera.zoom = FlxMath.lerp(defaultCamZoom, FlxG.camera.zoom, CoolUtil.boundTo(1 - (elapsed * 3.125 * camZoomingDecay * playbackRate), 0, 1));
			camHUD.zoom = FlxMath.lerp(1, camHUD.zoom, CoolUtil.boundTo(1 - (elapsed * 3.125 * camZoomingDecay * playbackRate), 0, 1));
		}

		FlxG.watch.addQuick("secShit", curSection);
		FlxG.watch.addQuick("beatShit", curBeat);
		FlxG.watch.addQuick("stepShit", curStep);

		// RESET = Quick Game Over Screen
		if (!ClientPrefs.data.noReset && controls.RESET && canReset && !inCutscene && startedCountdown && !endingSong)
		{
			health = 0;
			TraceManager.debug('trace.playState.resetTrue', 'RESET = True');
		}
		doDeathCheck();

		if (notesAddedCount < unspawnNotes.length)
		{
			var time:Float = spawnTime;
			if(songSpeed < 1) time /= songSpeed;
			if(unspawnNotes[notesAddedCount].multSpeed < 1) time /= unspawnNotes[notesAddedCount].multSpeed;

			var targetNote:Note = unspawnNotes[notesAddedCount];
			limitNC = notes.countLiving();

			while (limitNC < noteLimit && targetNote != null && targetNote.strumTime - Conductor.songPosition < time)
			{
				if (targetNote.wasHit)
				{
					notesAddedCount++;
					if (notesAddedCount < unspawnNotes.length)
						targetNote = unspawnNotes[notesAddedCount];
					else
						break;
					continue;
				}

				targetNote.spawned = true;
				notes.add(targetNote);
				if (ClientPrefs.data.compatibility_mode) {
					callOnScripts('onSpawnNote', [
						notes.members.indexOf(targetNote),
						targetNote.noteData,
						targetNote.noteType,
						targetNote.isSustainNote,
						targetNote.strumTime
					]);
				} else {
					callOnScripts('onSpawnNote', [
						notes.members.indexOf(targetNote),
						targetNote.noteData,
						targetNote.noteType,
						targetNote.isSustainNote
					]);
				}

				notesAddedCount++;
				limitNC++;
				if (notesAddedCount < unspawnNotes.length)
					targetNote = unspawnNotes[notesAddedCount];
				else
					break;
			}
		}

		if (generatedMusic && !inCutscene)
		{
			// 回放模式: 由 replayExam.replayUpdate() 处理按键; 非回放模式: 由 keysCheck() 处理
			if (replayMode) {
				if (replayExam != null) replayExam.replayUpdate(elapsed);
			} else if(!cpuControlled) {
				keysCheck();
			} else if(boyfriend.animation.curAnim != null && boyfriend.holdTimer > Conductor.stepCrochet * (0.0011 / FlxG.sound.music.pitch) * boyfriend.singDuration && boyfriend.animation.curAnim.name.startsWith('sing') && !boyfriend.animation.curAnim.name.endsWith('miss')) {
				boyfriend.dance();
			}

			if(startedCountdown)
			{
				strumsHit = [false, false, false, false, false, false, false, false];
				var fakeCrochet:Float = (60 / SONG.bpm) * 1000;

				function updateDaNote(daNote:Note):Void
				{
					if (daNote == null || !daNote.exists) return;

					// Auto-hit opponent notes
					if (!daNote.mustPress && !daNote.hitByOpponent && !daNote.ignoreNote && daNote.strumTime <= Conductor.songPosition)
						opponentNoteHit(daNote);

					// CPU auto-hit player notes
					if (daNote.mustPress && cpuControlled && !daNote.wasGoodHit && daNote.strumTime <= Conductor.songPosition && !daNote.ignoreNote && !daNote.blockHit)
						goodNoteHit(daNote);

					if (!daNote.exists) return;

					var strumGroup:FlxTypedGroup<StrumNote> = daNote.mustPress ? playerStrums : opponentStrums;
					var strum:StrumNote = strumGroup.members[daNote.noteData];
					if (strum == null) return;

					var strumX:Float = strum.x + daNote.offsetX;
					var strumY:Float = strum.y + daNote.offsetY;
					var strumAngle:Float = strum.angle + daNote.offsetAngle;
					var strumDirection:Float = strum.direction;
					var strumAlpha:Float = strum.alpha * daNote.multAlpha;
					var strumScroll:Bool = strum.downScroll;

					if (strumScroll)
						daNote.distance = (0.45 * (Conductor.songPosition - daNote.strumTime) * songSpeed * daNote.multSpeed);
					else
						daNote.distance = (-0.45 * (Conductor.songPosition - daNote.strumTime) * songSpeed * daNote.multSpeed);

					var angleDir:Float = strumDirection * Math.PI / 180;

					if (daNote.copyAngle)
						daNote.angle = strumDirection - 90 + strumAngle;

					if (daNote.copyAlpha)
						daNote.alpha = strumAlpha;

					// Sustain body scale stretch — must span pixel gap between pieces.
					// Pixel gap = 0.45 * stepCrochet * songSpeed.
					// Rendered height = frameHeight * scale.y.
					// So: scale.y = (0.45 * stepCrochet * songSpeed * multSpeed) / frameHeight
					/*
					if (daNote.isSustainNote && !daNote.animation.curAnim.name.endsWith('end'))
					{
						daNote.scale.y = (0.45 * Conductor.stepCrochet * songSpeed * daNote.multSpeed) / daNote.frameHeight;
						if (PlayState.isPixelStage)
						{
							daNote.scale.y *= PlayState.daPixelZoom * 1.20;
							daNote.scale.x *= PlayState.daPixelZoom;
						}
						daNote.scale.x = 0.7;
						daNote.updateHitbox();
					}
					*/

					if (daNote.copyX)
						daNote.x = strumX + Math.cos(angleDir) * daNote.distance;

					if (daNote.copyY)
					{
						daNote.y = strumY + Math.sin(angleDir) * daNote.distance;

						if (strumScroll && daNote.isSustainNote)
						{
							if (daNote.animation.curAnim.name.endsWith('end'))
							{
								daNote.y += 10.5 * (fakeCrochet / 400) * 1.5 * songSpeed + (46 * (songSpeed - 1));
								daNote.y -= 46 * (1 - (fakeCrochet / 600)) * songSpeed;
								if (PlayState.isPixelStage)
									daNote.y += 8 + (6 - daNote.originalHeightForCalcs) * PlayState.daPixelZoom;
								else
									daNote.y -= 19;
							}
							daNote.y += (Note.swagWidth / 2) - (60.5 * (songSpeed - 1));
							daNote.y += 27.5 * ((SONG.bpm / 100) - 1) * (songSpeed - 1);
						}
					}

					var center:Float = strumY + Note.swagWidth / 2;
					if (strum.sustainReduce && daNote.isSustainNote
						&& (!daNote.mustPress || daNote.wasGoodHit || daNote.ignoreNote))
					{
						if (strumScroll)
						{
							if (daNote.y - daNote.offset.y * daNote.scale.y + daNote.height >= center)
							{
								var swagRect:FlxRect = new FlxRect(0, 0, daNote.frameWidth, daNote.frameHeight);
								swagRect.height = (center - daNote.y) / daNote.scale.y;
								swagRect.y = daNote.frameHeight - swagRect.height;
								daNote.clipRect = swagRect;
							}
						}
						else
						{
							if (daNote.y + daNote.offset.y * daNote.scale.y <= center)
							{
								var swagRect:FlxRect = new FlxRect(0, 0, daNote.width / daNote.scale.x, daNote.height / daNote.scale.y);
								swagRect.y = (center - daNote.y) / daNote.scale.y;
								swagRect.height -= swagRect.y;
								daNote.clipRect = swagRect;
							}
						}
					}

					// Kill late notes
					if (Conductor.songPosition > noteKillOffset + daNote.strumTime)
					{
						if (daNote.mustPress && !cpuControlled && !daNote.ignoreNote && !endingSong && !daNote.wasGoodHit)
							noteMiss(daNote);

						invalidateNote(daNote);
					}
				}

				notes.forEachAlive(updateDaNote);

				// Batched cleanup: only purge dead notes every N frames to reduce GC pressure
				_noteCleanupFrameCounter++;
				if (_noteCleanupFrameCounter >= NOTE_CLEANUP_INTERVAL)
				{
					_noteCleanupFrameCounter = 0;
					var i:Int = notes.members.length - 1;
					while (i >= 0) {
						var note:Note = notes.members[i];
						if (note != null && !note.exists) {
							notes.remove(note, true);
							note.destroy();
						}
						i--;
					}
				}

				// Sort for correct draw order (closer to strum on top)
				var sortOrder:Int = ClientPrefs.data.downScroll ? FlxSort.ASCENDING : FlxSort.DESCENDING;
				notes.sort(FlxSort.byY, sortOrder);
			}
			else
			{
				function resetNote(daNote:Note):Void
				{
					daNote.canBeHit = false;
					daNote.wasGoodHit = false;
				}
				notes.forEachAlive(resetNote);
				// Always clean up dead notes here (no batching needed before countdown starts)
				var i:Int = notes.members.length - 1;
				while (i >= 0) {
					var note:Note = notes.members[i];
					if (note != null && !note.exists) {
						notes.remove(note, true);
						note.destroy();
					}
					i--;
				}
			}
		}
		checkEventNote();

		#if debug
		if(!endingSong && !startingSong) {
			if (FlxG.keys.justPressed.ONE) {
				KillNotes();
				FlxG.sound.music.onComplete();
			}
			if(FlxG.keys.justPressed.TWO) { //Go 10 seconds into the future :O
				setSongTime(Conductor.songPosition + 10000);
				clearNotesBefore(Conductor.songPosition);
			}
		}
		#end

		setOnScripts('cameraX', camFollowPos.x);
		setOnScripts('cameraY', camFollowPos.y);
		setOnScripts('botPlay', cpuControlled);
		callOnScripts('onUpdatePost', [elapsed]);
	}
	// Health icon updaters(like 073?)
	public dynamic function updateIconsScale(elapsed:Float){
		var mult:Float = FlxMath.lerp(1, iconP1.scale.x, CoolUtil.boundTo(1 - (elapsed * 9 * playbackRate), 0, 1));
		iconP1.scale.set(mult, mult);
		iconP1.updateHitbox();

		var mult:Float = FlxMath.lerp(1, iconP2.scale.x, CoolUtil.boundTo(1 - (elapsed * 9 * playbackRate), 0, 1));
		iconP2.scale.set(mult, mult);
		iconP2.updateHitbox();
	}


	function openPauseMenu()
	{
		persistentUpdate = false;
		persistentDraw = true;
		paused = true;

		keyboardDisplay.save();
		for (i in 0...4)
			keyboardDisplay.released(i);


		// 1 / 1000 chance for Gitaroo Man easter egg
		/*if (FlxG.random.bool(0.1))
		{
			// gitaroo man easter egg
			cancelMusicFadeTween();
			MusicBeatState.switchState(new GitarooPause());
		}
		else {*/
		if(FlxG.sound.music != null) {
			FlxG.sound.music.pause();
			vocals.pause();
			vocalsPlayer.pause();
			vocalsOpponent.pause();
		}
		#if HSCRIPT_ALLOWED
		var usePause = (Main.useOldPause != null) ? Main.useOldPause : ClientPrefs.data.oldPauseMenu;
		if (usePause)
			openSubState(new OldPauseSubState(boyfriend.getScreenPosition().x, boyfriend.getScreenPosition().y));
		else
			openSubState(new PauseSubState(boyfriend.getScreenPosition().x, boyfriend.getScreenPosition().y));
		#else
		openSubState(new PauseSubState(boyfriend.getScreenPosition().x, boyfriend.getScreenPosition().y));
		#end
		//}

		#if desktop
		if(iconP2 != null) DiscordClient.changePresence(detailsPausedText, SONG.song + " (" + storyDifficultyText + ")", iconP2.getCharacter());
		#end
	}

	public function openChartEditor()
	{
		persistentUpdate = false;
		paused = true;
		cancelMusicFadeTween();
        if(ClientPrefs.data.newchartingstate)
            MusicBeatState.switchState(new editors.NewChartingState());
                        else
            MusicBeatState.switchState(new editors.ChartingState());
		chartingMode = true;

		#if desktop
		DiscordClient.changePresence("Chart Editor", null, null, true);
		#end
	}

	public var isDead:Bool = false; //Don't mess with this on Lua!!!
	function doDeathCheck(?skipHealthCheck:Bool = false) {
		if (((skipHealthCheck && instakillOnMiss) || (playOpponent ? health >= 2 : health <= 0)) && !practiceMode && !isDead && !replayMode)
		{
			var ret:Dynamic = callOnScripts('onGameOver', [], false);
			if(ret != FunkinLua.Function_Stop) {
				boyfriend.stunned = true;
				deathCounter++;

				paused = true;

				vocals.stop();
				vocalsPlayer.stop();
				vocalsOpponent.stop();
				FlxG.sound.music.stop();
				
				persistentUpdate = false;
				persistentDraw = false;
				for (tween in modchartTweens) {
					tween.active = true;
				}
				for (timer in modchartTimers) {
					timer.active = true;
				}
				openSubState(new GameOverSubstate(boyfriend.getScreenPosition().x - boyfriend.positionArray[0], boyfriend.getScreenPosition().y - boyfriend.positionArray[1], camFollowPos.x, camFollowPos.y));

				// MusicBeatState.switchState(new GameOverState(boyfriend.getScreenPosition().x, boyfriend.getScreenPosition().y));

				#if desktop
				// Game Over doesn't get his own variable because it's only used here
				if(iconP2 != null) DiscordClient.changePresence("Game Over - " + detailsText, SONG.song + " (" + storyDifficultyText + ")", iconP2.getCharacter());
				#end
				isDead = true;
				return true;
			}
		}
		return false;
	}

	public function checkEventNote() {
		while(eventNotes.length > 0) {
			var leStrumTime:Float = eventNotes[0].strumTime;
			if(Conductor.songPosition < leStrumTime) {
				break;
			}

			var value1:String = '';
			if(eventNotes[0].value1 != null)
				value1 = eventNotes[0].value1;

			var value2:String = '';
			if(eventNotes[0].value2 != null)
				value2 = eventNotes[0].value2;

			triggerEventNote(eventNotes[0].event, value1, value2, leStrumTime);
			eventNotes.shift();
		}
	}

	public function getControl(key:String) {
		var pressed:Bool = Reflect.getProperty(controls, key);
		//trace('Control result: ' + pressed);
		return pressed;
	}

	public function triggerEventNote(eventName:String, value1:String, value2:String, ?strumTime:Float = 0) {
		switch(eventName) {
			case 'Dadbattle Spotlight':
				var val:Null<Int> = Std.parseInt(value1);
				if(val == null) val = 0;

				switch(Std.parseInt(value1))
				{
					case 1, 2, 3: //enable and target dad
						if(val == 1) //enable
						{
							dadbattleBlack.visible = true;
							dadbattleLight.visible = true;
							dadbattleSmokes.visible = true;
							defaultCamZoom += 0.12;
						}

						var who:Character = dad;
						if(val > 2) who = boyfriend;
						//2 only targets dad
						dadbattleLight.alpha = 0;
						new FlxTimer().start(0.12, function(tmr:FlxTimer) {
							dadbattleLight.alpha = 0.375;
						});
						dadbattleLight.setPosition(who.getGraphicMidpoint().x - dadbattleLight.width / 2, who.y + who.height - dadbattleLight.height + 50);

					default:
						dadbattleBlack.visible = false;
						dadbattleLight.visible = false;
						defaultCamZoom -= 0.12;
						FlxTween.tween(dadbattleSmokes, {alpha: 0}, 1, {onComplete: function(twn:FlxTween)
						{
							dadbattleSmokes.visible = false;
						}});
				}

			case 'Hey!':
				var value:Int = 2;
				switch(value1.toLowerCase().trim()) {
					case 'bf' | 'boyfriend' | '0':
						value = 0;
					case 'gf' | 'girlfriend' | '1':
						value = 1;
				}

				var time:Float = Std.parseFloat(value2);
				if(Math.isNaN(time) || time <= 0) time = 0.6;

				if(value != 0) {
					if(dad.curCharacter.startsWith('gf')) { //Tutorial GF is actually Dad! The GF is an imposter!! ding ding ding ding ding ding ding, dindinding, end my suffering
						dad.playAnim('cheer', true);
						dad.specialAnim = true;
						dad.heyTimer = time;
					} else if (gf != null) {
						gf.playAnim('cheer', true);
						gf.specialAnim = true;
						gf.heyTimer = time;
					}

					if(curStage == 'mall') {
						bottomBoppers.animation.play('hey', true);
						heyTimer = time;
					}
				}
				if(value != 1) {
					boyfriend.playAnim('hey', true);
					boyfriend.specialAnim = true;
					boyfriend.heyTimer = time;
				}

			case 'Set GF Speed':
				var value:Int = Std.parseInt(value1);
				if(Math.isNaN(value) || value < 1) value = 1;
				gfSpeed = value;

			case 'Philly Glow':
				if (stageBackdrop != null) stageBackdrop.eventTrigger(eventName, value1, value2);

			case 'Kill Henchmen':
				if (stageBackdrop != null) stageBackdrop.eventTrigger(eventName, value1, value2);

			case 'Add Camera Zoom':
				if(ClientPrefs.data.camZooms && FlxG.camera.zoom < 1.35) {
					var camZoom:Float = Std.parseFloat(value1);
					var hudZoom:Float = Std.parseFloat(value2);
					if(Math.isNaN(camZoom)) camZoom = 0.015;
					if(Math.isNaN(hudZoom)) hudZoom = 0.03;

					FlxG.camera.zoom += camZoom;
					camHUD.zoom += hudZoom;
				}

			case 'Trigger BG Ghouls':
				if(curStage == 'schoolEvil' && !ClientPrefs.data.lowQuality) {
					bgGhouls.dance(true);
					bgGhouls.visible = true;
				}

			case 'Play Animation':
				//trace('Anim to play: ' + value1);
				var char:Character = dad;
				switch(value2.toLowerCase().trim()) {
					case 'bf' | 'boyfriend':
						char = boyfriend;
					case 'gf' | 'girlfriend':
						char = gf;
					default:
						var val2:Int = Std.parseInt(value2);
						if(Math.isNaN(val2)) val2 = 0;

						switch(val2) {
							case 1: char = boyfriend;
							case 2: char = gf;
						}
				}

				if (char != null)
				{
					char.playAnim(value1, true);
					char.specialAnim = true;
				}

			case 'Camera Follow Pos':
				if(camFollow != null)
				{
					var val1:Float = Std.parseFloat(value1);
					var val2:Float = Std.parseFloat(value2);
					if(Math.isNaN(val1)) val1 = 0;
					if(Math.isNaN(val2)) val2 = 0;

					isCameraOnForcedPos = false;
					if(!Math.isNaN(Std.parseFloat(value1)) || !Math.isNaN(Std.parseFloat(value2))) {
						camFollow.x = val1;
						camFollow.y = val2;
						isCameraOnForcedPos = true;
					}
				}

			case 'Alt Idle Animation':
				var char:Character = dad;
				switch(value1.toLowerCase().trim()) {
					case 'gf' | 'girlfriend':
						char = gf;
					case 'boyfriend' | 'bf':
						char = boyfriend;
					default:
						var val:Int = Std.parseInt(value1);
						if(Math.isNaN(val)) val = 0;

						switch(val) {
							case 1: char = boyfriend;
							case 2: char = gf;
						}
				}

				if (char != null)
				{
					char.idleSuffix = value2;
					char.recalculateDanceIdle();
				}

			case 'Screen Shake':
				var valuesArray:Array<String> = [value1, value2];
				var targetsArray:Array<FlxCamera> = [camGame, camHUD];
				for (i in 0...targetsArray.length) {
					var split:Array<String> = valuesArray[i].split(',');
					var duration:Float = 0;
					var intensity:Float = 0;
					if(split[0] != null) duration = Std.parseFloat(split[0].trim());
					if(split[1] != null) intensity = Std.parseFloat(split[1].trim());
					if(Math.isNaN(duration)) duration = 0;
					if(Math.isNaN(intensity)) intensity = 0;

					if(duration > 0 && intensity != 0) {
						targetsArray[i].shake(intensity, duration);
					}
				}


			case 'Change Character':
				var charType:Int = 0;
				switch(value1.toLowerCase().trim()) {
					case 'gf' | 'girlfriend':
						charType = 2;
					case 'dad' | 'opponent':
						charType = 1;
					default:
						charType = Std.parseInt(value1);
						if(Math.isNaN(charType)) charType = 0;
				}

				switch(charType) {
					case 0:
						if(boyfriend.curCharacter != value2) {
							if(!boyfriendMap.exists(value2)) {
								addCharacterToList(value2, charType);
							}

							var lastAlpha:Float = boyfriend.alpha;
							boyfriend.alpha = 0.00001;
							boyfriend = boyfriendMap.get(value2);
							boyfriend.alpha = lastAlpha;
							iconP1.changeIcon(boyfriend.healthIcon);
						}
						setOnScripts('boyfriendName', boyfriend.curCharacter);

					case 1:
						if(dad.curCharacter != value2) {
							if(!dadMap.exists(value2)) {
								addCharacterToList(value2, charType);
							}

							var wasGf:Bool = dad.curCharacter.startsWith('gf');
							var lastAlpha:Float = dad.alpha;
							dad.alpha = 0.00001;
							dad = dadMap.get(value2);
							if(!dad.curCharacter.startsWith('gf')) {
								if(wasGf && gf != null) {
									gf.visible = true;
								}
							} else if(gf != null) {
								gf.visible = false;
							}
							dad.alpha = lastAlpha;
							iconP2.changeIcon(dad.healthIcon);
						}
						setOnScripts('dadName', dad.curCharacter);

					case 2:
						if(gf != null)
						{
							if(gf.curCharacter != value2)
							{
								if(!gfMap.exists(value2))
								{
									addCharacterToList(value2, charType);
								}

								var lastAlpha:Float = gf.alpha;
								gf.alpha = 0.00001;
								gf = gfMap.get(value2);
								gf.alpha = lastAlpha;
							}
							setOnScripts('gfName', gf.curCharacter);
						}
				}
				reloadHealthBarColors();

			case 'BG Freaks Expression':
				if(bgGirls != null) bgGirls.swapDanceType();

			case 'Change Scroll Speed':
				if (songSpeedType == "constant")
					return;
				var val1:Float = Std.parseFloat(value1);
				var val2:Float = Std.parseFloat(value2);
				if(Math.isNaN(val1)) val1 = 1;
				if(Math.isNaN(val2)) val2 = 0;

				var newValue:Float = SONG.speed * ClientPrefs.getGameplaySetting('scrollspeed', 1) * val1;

				if(val2 <= 0)
				{
					songSpeed = newValue;
				}
				else
				{
					songSpeedTween = FlxTween.tween(this, {songSpeed: newValue}, val2 / playbackRate, {ease: FlxEase.linear, onComplete:
						function (twn:FlxTween)
						{
							songSpeedTween = null;
						}
					});
				}

			case 'Set Property':
				var killMe:Array<String> = value1.split('.');
				if(killMe.length > 1) {
					FunkinLua.setVarInArray(FunkinLua.getPropertyLoopThingWhatever(killMe, true, true), killMe[killMe.length-1], value2);
				} else {
					FunkinLua.setVarInArray(this, value1, value2);
				}
			case 'Play Sound':
				var val2:Float = Std.parseFloat(value2);
				if(Math.isNaN(val2)) val2 = 1;
				FlxG.sound.play(Paths.sound(value1), val2);

		}
		if (ClientPrefs.data.compatibility_mode) {
			callOnScripts('onEvent', [eventName, value1, value2, strumTime]);
		} else {
			callOnScripts('onEvent', [eventName, value1, value2]);
		}
	}

	function moveCameraSection():Void {
		if(SONG.notes[curSection] == null) return;

		if (gf != null && SONG.notes[curSection].gfSection)
		{
			camFollow.set(gf.getMidpoint().x, gf.getMidpoint().y);
			camFollow.x += gf.cameraPosition[0] + girlfriendCameraOffset[0];
			camFollow.y += gf.cameraPosition[1] + girlfriendCameraOffset[1];
			tweenCamIn();
			callOnScripts('onMoveCamera', ['gf']);
			return;
		}

		if (!SONG.notes[curSection].mustHitSection)
		{
			moveCamera(true);
			callOnScripts('onMoveCamera', ['dad']);
		}
		else
		{
			moveCamera(false);
			callOnScripts('onMoveCamera', ['boyfriend']);
		}
	}

	var cameraTwn:FlxTween;
	public function moveCamera(isDad:Bool)
	{
		if(isDad)
		{
			camFollow.set(dad.getMidpoint().x + 150, dad.getMidpoint().y - 100);
			camFollow.x += dad.cameraPosition[0] + opponentCameraOffset[0];
			camFollow.y += dad.cameraPosition[1] + opponentCameraOffset[1];
			tweenCamIn();
		}
		else
		{
			camFollow.set(boyfriend.getMidpoint().x - 100, boyfriend.getMidpoint().y - 100);
			camFollow.x -= boyfriend.cameraPosition[0] - boyfriendCameraOffset[0];
			camFollow.y += boyfriend.cameraPosition[1] + boyfriendCameraOffset[1];

			if (Paths.formatToSongPath(SONG.song) == 'tutorial' && cameraTwn == null && FlxG.camera.zoom != 1)
			{
				cameraTwn = FlxTween.tween(FlxG.camera, {zoom: 1}, (Conductor.stepCrochet * 4 / 1000), {ease: FlxEase.elasticInOut, onComplete:
					function (twn:FlxTween)
					{
						cameraTwn = null;
					}
				});
			}
		}
	}

	function tweenCamIn() {
		if (Paths.formatToSongPath(SONG.song) == 'tutorial' && cameraTwn == null && FlxG.camera.zoom != 1.3) {
			cameraTwn = FlxTween.tween(FlxG.camera, {zoom: 1.3}, (Conductor.stepCrochet * 4 / 1000), {ease: FlxEase.elasticInOut, onComplete:
				function (twn:FlxTween) {
					cameraTwn = null;
				}
			});
		}
	}

	function snapCamFollowToPos(x:Float, y:Float) {
		camFollow.set(x, y);
		camFollowPos.setPosition(x, y);
	}

	public function finishSong(?ignoreNoteOffset:Bool = false):Void
	{
		var finishCallback:Void->Void = endSong; //In case you want to change it in a specific song.

		updateTime = false;
		FlxG.sound.music.volume = 0;
		vocals.volume = 0;
		vocalsPlayer.volume = 0;
		vocalsOpponent.volume = 0;
		vocals.pause();
		vocalsPlayer.pause();
		vocalsOpponent.pause();
		if(ClientPrefs.data.noteOffset <= 0 || ignoreNoteOffset) {
			finishCallback();
		} else {
			finishTimer = new FlxTimer().start(ClientPrefs.data.noteOffset / 1000, function(tmr:FlxTimer) {
				finishCallback();
			});
		}
	}


	public var transitioning = false;
	public function endSong():Void
	{
		//Should kill you if you tried to cheat
		if(!startingSong) {
			function drainHealth(daNote:Note):Void {
				if(daNote.strumTime < songLength - Conductor.safeZoneOffset) {
					if (playOpponent)
						health += 0.05 * healthLoss;
					else
						health -= 0.05 * healthLoss;
				}
			}
			notes.forEachAlive(drainHealth);

			// Only drain truly unspawned notes (past notesAddedCount cursor)
			var i:Int = notesAddedCount;
			while (i < unspawnNotes.length) {
				var dn = unspawnNotes[i];
				if(dn.strumTime < songLength - Conductor.safeZoneOffset) {
					if (playOpponent)
						health += 0.05 * healthLoss;
					else
						health -= 0.05 * healthLoss;
				}
				i++;
			}

			if(doDeathCheck()) {
				return;
			}
		}
		keyboardDisplay.save();
		#if android
		androidControls.visible = true;
		#end
		timeBarBG.visible = false;
		timeBar.visible = false;
		timeTxt.visible = false;

		canPause = false;
		endingSong = true;
		camZooming = false;
		inCutscene = false;
		updateTime = false;

		deathCounter = 0;
		seenCutscene = false;

		#if ACHIEVEMENTS_ALLOWED
		if(achievementObj != null) {
			return;
		} else {
			var achieve:String = checkForAchievement(['week1_nomiss', 'week2_nomiss', 'week3_nomiss', 'week4_nomiss',
				'week5_nomiss', 'week6_nomiss', 'week7_nomiss', 'ur_bad',
				'ur_good', 'line_blue','hype', 'two_keys', 'toastie', 'debugger']);

			if(achieve != null) {
				startAchievement(achieve);
				return;
			}
		}
		#end

		var ret:Dynamic = callOnScripts('onEndSong', [], false);
		trace(SONG.validScore);
		if(ret != FunkinLua.Function_Stop && !transitioning) {
			if (SONG.validScore || SONG.validScore == null)
			{
				#if !switch
				var percent:Float = ratingPercent;
				if(Math.isNaN(percent)) percent = 0;
				if (!replayMode && !practiceMode && !cpuControlled && !chartingMode)
				{
				// 准备回放帧数据 (转为 Dynamic 以存入 Allscore)
				var replayFrameData:Array<Dynamic> = (replayExam != null && ClientPrefs.data.saveReplayData)
					? Replay.framesToDynamic(replayExam.getFrameData()) : null;

				var details:Array<Dynamic> = [
					Paths.formatToSongPath(SONG.song),
					songScore,
					songLength,
					songHits,
					songMisses,
					ratingPercent,
					ratingFC,
					ratingName,
					maxcombo,
					NoteTime,
					NoteMs,
					songSpeed,
					playbackRate,
					healthGain,
					healthLoss,
					cpuControlled,
					practiceMode,
					instakillOnMiss,
					Date.now().toString(),
					songSpeedType,
					ClientPrefs.data.sickWindow,
					ClientPrefs.data.goodWindow,
					ClientPrefs.data.badWindow,
					ClientPrefs.data.safeFrames
				];
				Highscore.saveScore(SONG.song, songScore, storyDifficulty, percent,sicks, goods, bads, shits, songMisses, maxcombo);
				Allscore.addEntry(
				SONG.song, storyDifficulty, 
				percent, ratingFC, ratingName,
				songScore,
				sicks, goods, bads, shits, songMisses, maxcombo,
				replayFrameData,
				details,    
				null,
    			songSpeed, playbackRate, songSpeedType
			);
				#end
				}
			}
			if (chartingMode)
			{
				openChartEditor();
				return;
			}

			prevCamFollow = camFollow;
			prevCamFollowPos = camFollowPos;

			openSubState(new PlayStateResultsSubstate());
			transitioning = true;
		}
	}

	#if ACHIEVEMENTS_ALLOWED
	var achievementObj:AchievementObject = null;
	public function startAchievement(achieve:String) {
		achievementObj = new AchievementObject(achieve, camOther);
		achievementObj.onFinish = achievementEnd;
		add(achievementObj);
		TraceManager.info('trace.playState.givingAchievement', 'Giving achievement {}', [achieve]);
	}
	function achievementEnd():Void
	{
		achievementObj = null;
		if(endingSong && !inCutscene) {
			endSong();
		}
	}
	#end

	public function KillNotes() {
		while(notes.length > 0) {
			var daNote:Note = notes.members[0];
			daNote.active = false;
			daNote.visible = false;
			daNote.kill();
		}

		unspawnNotes = [];
		notesAddedCount = 0;
		limitNC = 0;
		eventNotes = [];
	}

	public var totalPlayed:Int = 0;
	public var totalNotesHit:Float = 0.0;

	public var showCombo:Bool = false;
	public var showComboNum:Bool = true;
	public var showRating:Bool = true;

	// Stores Ratings and Combo Sprites in a group(Psych 0.7.3 compat)
	public var comboGroup:FlxSpriteGroup;
	// Stores Note Objects in a Group (Psych 0.7.3 compat)
	public var noteGroup:FlxTypedGroup<FlxBasic>;
	// Stores HUD Objects in a Group (Psych 0.7.3 compat)
	public var uiGroup:FlxSpriteGroup;


	private function cachePopUpScore()
	{
		var pixelShitPart1:String = '';
		var pixelShitPart2:String = '';
		if (isPixelStage)
		{
			pixelShitPart1 = 'pixelUI/';
			pixelShitPart2 = '-pixel';
		}

		Paths.image(pixelShitPart1 + "sick" + pixelShitPart2);
		Paths.image(pixelShitPart1 + "good" + pixelShitPart2);
		Paths.image(pixelShitPart1 + "bad" + pixelShitPart2);
		Paths.image(pixelShitPart1 + "shit" + pixelShitPart2);
		Paths.image(pixelShitPart1 + "combo" + pixelShitPart2);
		
		for (i in 0...10) {
			Paths.image(pixelShitPart1 + 'num' + i + pixelShitPart2);
		}
	}

	private function popUpScore(note:Note = null, ?time:Float = -999999):Void
	{
		var noteDiff:Float = 0;
		if (!cpuControlled) {
			noteDiff = Math.abs(note.strumTime - Conductor.songPosition + ClientPrefs.data.ratingOffset);
			NoteMs.push(noteDiff / playbackRate);
			NoteTime.push(note.strumTime);
		} 

		// boyfriend.playAnim('hey');
		vocals.volume = 1;
		vocalsPlayer.volume = 1;
		vocalsOpponent.volume = 1;

		var score:Int = 350;
		var daRating:Rating = Conductor.judgeNote(note, noteDiff / playbackRate);
		//tryna do MS based judgment due to popular demand


		totalNotesHit += daRating.ratingMod;
		note.ratingMod = daRating.ratingMod;
		if(!note.ratingDisabled) daRating.increase();
		note.rating = daRating.name;
		score = daRating.score;
		if(daRating.noteSplash && !note.noteSplashDisabled)
		{
			spawnNoteSplashOnNote(note);
		}

		if(!practiceMode && !cpuControlled) {
			songScore += score;
			if(!note.ratingDisabled)
			{
				songHits++;
			}
		}
		if(!note.ratingDisabled) {
			totalPlayed++;
			RecalculateRating(false);
		}

		// ---- display rating/combo/number sprites ----
		showComboNum = (combo >= 10);
		ratingPopup.show(daRating.image, combo, playbackRate, FlxG.width * 0.35,
			ClientPrefs.data.hideHud, showRating, showCombo, showComboNum,
			[for (v in ClientPrefs.data.comboOffset) Std.int(v)], Conductor.crochet,
			ClientPrefs.data.comboStacking);
	}

	public var strumsBlocked:Array<Bool> = [];
		private function onKeyPress(event:KeyboardEvent):Void
		{
			if (replayMode)
				return;
			var eventKey:FlxKey = event.keyCode;
			var key:Int = getKeyFromEvent(eventKey);
			if (!cpuControlled && startedCountdown && !paused && key > -1 && (FlxG.keys.checkStatus(eventKey, JUST_PRESSED) || ClientPrefs.data.controllerMode))
			{
				keyPressed(key);
			}
		}

		private function keyPressed(key:Int, ?time:Float = -999999):Void
		{
			if (cpuControlled || paused || key < 0)
				return;

			if (!generatedMusic || endingSong || boyfriend.stunned)
				return;

			keyboardDisplay.pressed(key);
			

			callOnScripts('preKeyPress', [key]);
		if(!boyfriend.stunned && generatedMusic && !endingSong)
			{
				//more accurate hit time for the ratings?
				var lastTime:Float = Conductor.songPosition;
				Conductor.songPosition = FlxG.sound.music.time;

				var canMiss:Bool = !ClientPrefs.data.ghostTapping;

				// heavily based on my own code LOL if it aint broke dont fix it
				var pressNotes:Array<Note> = [];
				//var notesDatas:Array<Int> = [];
				var notesStopped:Bool = false;
			var sortedNotesList:Array<Note> = [];
			notes.forEachAlive(function(daNote:Note)
				{
					if (strumsBlocked[daNote.noteData] != true && daNote.canBeHit && daNote.mustPress && !daNote.tooLate && !daNote.wasGoodHit && !daNote.isSustainNote && !daNote.blockHit)
					{
						if(daNote.noteData == key)
						{
							sortedNotesList.push(daNote);
							//notesDatas.push(daNote.noteData);
						}
						canMiss = true;
					}
				});
				sortedNotesList.sort(sortHitNotes);

				if (sortedNotesList.length > 0) {
					for (epicNote in sortedNotesList)
					{
						for (doubleNote in pressNotes) {
							if (Math.abs(doubleNote.strumTime - epicNote.strumTime) < 1) {
								doubleNote.kill();
								notes.remove(doubleNote, true);
								doubleNote.destroy();
							} else
								notesStopped = true;
						}

						// eee jack detection before was not super good
						if (!notesStopped) {
							goodNoteHit(epicNote);
							pressNotes.push(epicNote);
						}

					}
				}
				else{
					callOnScripts('onGhostTap', [key]);
					if (canMiss) {
						noteMissPress(key);
					}
				}

				// I dunno what you need this for but here you go
				//									- Shubs

				// Shubs, this is for the "Just the Two of Us" achievement lol
				//									- Shadow Mario
				keysPressed[key] = true;

				//more accurate hit time for the ratings? part 2 (Now that the calculations are done, go back to the time it was before for not causing a note stutter)
				Conductor.songPosition = lastTime;
			}
			

			var spr:StrumNote = playerStrums.members[key];
			if(strumsBlocked[key] != true && spr != null && spr.animation.curAnim.name != 'confirm')
			{
				spr.playAnim('pressed');
				spr.resetAnim = 0;
			}
			callOnScripts('onKeyPress', [key]);
			}
		


		function sortHitNotes(a:Note, b:Note):Int
		{
			if (a.lowPriority && !b.lowPriority)
				return 1;
			else if (!a.lowPriority && b.lowPriority)
				return -1;

			return FlxSort.byValues(FlxSort.ASCENDING, a.strumTime, b.strumTime);
		}

		private function onKeyRelease(event:KeyboardEvent):Void
		{
			if (replayMode)
				return;
			var eventKey:FlxKey = event.keyCode;
			var key:Int = getKeyFromEvent(eventKey);
			if (key > -1)
				keyReleased(key);
		}

		public function keyReleased(key:Int):Void
		{
			if (cpuControlled || !startedCountdown || paused)
				return;
			keyboardDisplay.released(key);

			var spr:StrumNote = playerStrums.members[key];
			if (spr != null)
			{
				spr.playAnim('static');
				spr.resetAnim = 0;
			}
			callOnScripts('onKeyRelease', [key]);
		}

	/**
	 * NF 风格: 由 replayExam.replayUpdate() 每帧调用，模拟按键输入
	 * @param frameTime 当前帧对应的歌曲时间
	 * @param pressLanes 按下的轨道列表
	 * @param releaseLanes 释放的轨道列表
	 * @param heldLanes 保持按下的轨道数组
	 */
	public function replayApplyInput(frameTime:Float, pressLanes:Array<Int>, releaseLanes:Array<Int>, heldLanes:Array<Bool>):Void
	{
		var laneCount:Int = keysArray.length;
		for (i in 0...laneCount)
		{
			_hold[i] = (heldLanes != null && i < heldLanes.length) ? heldLanes[i] : false;
			_press[i] = false;
			_release[i] = false;
		}
		if (pressLanes != null)
		{
			for (lane in pressLanes)
			{
				if (lane >= 0 && lane < laneCount) _press[lane] = true;
			}
		}
		if (releaseLanes != null)
		{
			for (lane in releaseLanes)
			{
				if (lane >= 0 && lane < laneCount) _release[lane] = true;
			}
		}

		// 处理按下
		if (_press.contains(true))
		{
			for (i in 0..._press.length)
			{
				if (_press[i] && strumsBlocked[i] != true)
					keyPressed(i, frameTime);
			}
		}

		// 处理长条 (hold)
		if (startedCountdown && !boyfriend.stunned && generatedMusic && !endingSong)
		{
			if (notes.length > 0)
			{
				notes.forEachAlive(function(daNote:Note)
				{
					if (strumsBlocked[daNote.noteData] != true
						&& daNote.isSustainNote
						&& _hold[daNote.noteData]
						&& daNote.canBeHit
						&& daNote.mustPress
						&& !daNote.tooLate
						&& !daNote.wasGoodHit
						&& !daNote.blockHit)
						goodNoteHit(daNote);
				});
			}
		}

		// 角色空闲动画
		if (!_hold.contains(true) && !endingSong && generatedMusic)
		{
			var danceChar:Character = playOpponent ? dad : boyfriend;
			if (danceChar.animation.curAnim != null
				&& danceChar.holdTimer > Conductor.stepCrochet * (0.0011 / FlxG.sound.music.pitch) * danceChar.singDuration
				&& danceChar.animation.curAnim.name.startsWith('sing')
				&& !danceChar.animation.curAnim.name.endsWith('miss'))
				danceChar.dance();
		}

		// 处理释放
		if (_release.contains(true))
		{
			for (i in 0..._release.length)
			{
				if (_release[i] || strumsBlocked[i] == true)
					keyReleased(i);
			}
		}
	}


		private function getKeyFromEvent(key:FlxKey):Int
		{
			if(key != NONE)
			{
				for (i in 0...keysArray.length)
				{
					for (j in 0...keysArray[i].length)
					{
						if(key == keysArray[i][j])
						{
							return i;
						}
					}
				}
			}
			return -1;
		}

		// Hold notes
		public function keysCheck(?keyCount:Int, time:Float = -999999):Void
		{
			var holdArray:Array<Bool> = [];
			var pressArray:Array<Bool> = [];
			var releaseArray:Array<Bool> = [];

			// 非回放模式: 从 controls 读取按键状态
			for (i in 0...controlArray.length)
			{
				holdArray.push(Reflect.getProperty(controls, controlArray[i]));          // NOTE_LEFT, NOTE_DOWN, etc.
				pressArray.push(Reflect.getProperty(controls, controlArray[i] + '_P')); // NOTE_LEFT_P, etc.
				releaseArray.push(Reflect.getProperty(controls, controlArray[i] + '_R')); // NOTE_LEFT_R, etc.
			}

			if (!cpuControlled && startedCountdown && !paused && !endingSong && !boyfriend.stunned && generatedMusic && !replayMode)
			{
				if (ClientPrefs.data.lastNoteAnimation)
				{
					var lastPressedKey:Int = -1;
					for (i in 0...4)
						if (pressArray[i] && strumsBlocked[i] != true)
							lastPressedKey = i;

					for (i in 0...4)
					{
						if (pressArray[i] && strumsBlocked[i] != true)
						{
							_suppressNoteAnim = (i != lastPressedKey);
							keyPressed(i, time);
							_suppressNoteAnim = false;
						}
					}
				}
				else
				{
					for (i in 0...4)
					{
						if (pressArray[i] && strumsBlocked[i] != true)
						{
							keyPressed(i, time);
						}
					}
				}

				notes.forEachAlive(function(daNote:Note)
				{
					if (strumsBlocked[daNote.noteData] != true && daNote.isSustainNote && holdArray[daNote.noteData] && daNote.canBeHit
						&& daNote.mustPress && !daNote.tooLate && !daNote.wasGoodHit && !daNote.blockHit)
						goodNoteHit(daNote, time);
				});
			}

			if (!holdArray.contains(true) && !endingSong && generatedMusic)
			{
				var danceChar:Character = playOpponent ? dad : boyfriend;
				if (danceChar.animation.curAnim != null && danceChar.holdTimer > Conductor.stepCrochet * (0.0011 / FlxG.sound.music.pitch) * danceChar.singDuration && danceChar.animation.curAnim.name.startsWith('sing') && !danceChar.animation.curAnim.name.endsWith('miss'))
					danceChar.dance();
				if (playOpponent && boyfriend.animation.curAnim != null && boyfriend.holdTimer > Conductor.stepCrochet * (0.0011 / FlxG.sound.music.pitch) * boyfriend.singDuration && boyfriend.animation.curAnim.name.startsWith('sing') && !boyfriend.animation.curAnim.name.endsWith('miss'))
					boyfriend.dance();
			}
			for (i in 0...controlArray.length)
			{
				if (releaseArray[i] || strumsBlocked[i] == true)
				{
					var spr:StrumNote = playerStrums.members[i];
					if (spr != null)
					{
						spr.playAnim('static');
						spr.resetAnim = 0;
					}
					keyboardDisplay.released(i);
				}
			}
	}


	private function parseKeys(?suffix:String = ''):Array<Bool>
	{
		var ret:Array<Bool> = [];
		for (i in 0...controlArray.length)
		{
			ret[i] = Reflect.getProperty(controls, controlArray[i] + suffix);
		}
		return ret;
	}

	function noteMiss(daNote:Note):Void { //You didn't hit the key and let it go offscreen, also used by Hurt Notes
			//Dupe note remove
		if (guitarHeroSustains) {
			if (daNote.parent == null) {

				if (daNote.missed) return;
				if (daNote.tail.length > 0) {
					for (childNote in daNote.tail) {
						childNote.alpha = daNote.alpha;
						childNote.missed = true;
						childNote.canBeHit = false;
						childNote.ignoreNote = true;
						childNote.tooLate = true;
						childNote.multAlpha = 0.3;
						childNote.alpha = 0.3;
					}
					daNote.missed = true;
					daNote.canBeHit = false;
				}
			} else if (daNote.parent != null && daNote.isSustainNote) {
				if (daNote.missed) return;
				var parentNote:Note = daNote.parent;
				if (parentNote.tail.length > 0) {
					for (child in parentNote.tail) {
						if (child != daNote) {
							child.missed = true;
							child.canBeHit = false;
							child.ignoreNote = true;
							child.tooLate = true;
							child.multAlpha = 0.3;
							child.alpha = 0.3;
						}
					}
					if (daNote == parentNote.tail[0]) {
						return; 
					}
				}
			}
		}
		NoteMs.push(167);
		NoteTime.push(daNote.strumTime);
		notes.forEachAlive(function(note:Note) {
				if (daNote != note && daNote.mustPress && daNote.noteData == note.noteData && daNote.isSustainNote == note.isSustainNote && Math.abs(daNote.strumTime - note.strumTime) < 1) {
					note.kill();
					notes.remove(note, true);
					note.destroy();
				}
			});
			combo = 0;
			if (playOpponent)
				health += daNote.missHealth * healthLoss;
			else
				health -= daNote.missHealth * healthLoss;
			msTxtKade.color = 0xFF0000;
			msTxtKade.text = 'Miss';
			msTxtKade.alpha = 1;
		if (msTween != null) msTween.cancel();
		msTween = FlxTween.tween(msTxtKade, {alpha: 0}, 0.5, {ease: FlxEase.quintIn});
			if(instakillOnMiss)
			{
				vocals.volume = 0;
				vocalsPlayer.volume = 0;
				doDeathCheck(true);
			}

			if (daNote != null && !daNote.isSustainNote)
			{
				NoteMs.push(167);
				NoteTime.push(daNote.strumTime);
			}
		//For testing purposes
		//trace(daNote.missHealth);
		songMisses++;
		if (!replayMode && replayExam != null)
			replayExam.recordJudgment(daNote.strumTime, daNote.noteData, 0, 'miss', daNote.isSustainNote);
		vocals.volume = 0;
		vocalsPlayer.volume = 0;
		if(!practiceMode) songScore -= 0;

		totalPlayed++;
		RecalculateRating(true);

		var char:Character = playOpponent ? dad : boyfriend;
		if(daNote.gfNote) {
			char = gf;
		}

		if(char != null && !daNote.noMissAnimation && char.hasMissAnimations)
		{
			var animToPlay:String = singAnimations[Std.int(Math.abs(daNote.noteData))] + 'miss' + daNote.animSuffix;
			char.playAnim(animToPlay, true);
		}

		callOnScripts('noteMiss', [notes.members.indexOf(daNote), daNote.noteData, daNote.noteType, daNote.isSustainNote]);
	}

	function noteMissPress(direction:Int = 1):Void //You pressed a key when there was no notes to press for this key
	{
		if(ClientPrefs.data.ghostTapping) return; //fuck it

		if (!boyfriend.stunned)
		{
			if (playOpponent)
				health += 0.05 * healthLoss;
			else
				health -= 0.05 * healthLoss;
			if(instakillOnMiss)
			{
				vocals.volume = 0;
				vocalsPlayer.volume = 0;
				doDeathCheck(true);
			}

			if (combo > 5 && gf != null && gf.animOffsets.exists('sad'))
			{
				gf.playAnim('sad');
			}
			combo = 0;

			if(!practiceMode) songScore -= 0;
			if(!endingSong) {
				songMisses++;
			}
			totalPlayed++;
			RecalculateRating(true);

			FlxG.sound.play(Paths.soundRandom('missnote', 1, 3), FlxG.random.float(0.1, 0.2));
			// FlxG.sound.play(Paths.sound('missnote1'), 1, false);
			// FlxG.log.add('played imss note');

			/*boyfriend.stunned = true;

			// get stunned for 1/60 of a second, makes you able to
			new FlxTimer().start(1 / 60, function(tmr:FlxTimer)
			{
				boyfriend.stunned = false;
			});*/

            var missChar:Character = playOpponent ? dad : boyfriend;
            if(missChar.hasMissAnimations) {
                     missChar.playAnim(singAnimations[Std.int(Math.abs(direction))] + 'miss', true);
            }
			vocals.volume = 0;
			vocalsPlayer.volume = 0;
		}
		callOnScripts('noteMissPress', [direction]);
	}

	function opponentNoteHit(note:Note):Void
	{


		if (Paths.formatToSongPath(SONG.song) != 'tutorial')
			camZooming = true;

        if(note.noteType == 'Hey!' && dad.animOffsets.exists('hey') && !playOpponent) {
            dad.playAnim('hey', true);
            dad.specialAnim = true;
            dad.heyTimer = 0.6;
		    } else if(note.noteType == 'Hey!' && boyfriend.animOffsets.exists('hey') && playOpponent) {
                boyfriend.playAnim('hey', true);
                boyfriend.specialAnim = true;
                boyfriend.heyTimer = 0.6;
                } else if(!note.noAnimation) {
                var altAnim:String = note.animSuffix;

                 if (SONG.notes[curSection] != null)
				 {
                    if (SONG.notes[curSection].altAnim && !SONG.notes[curSection].gfSection) {
                                        altAnim = '-alt';
                        }
                    }

            var char:Character = playOpponent ? boyfriend : dad;
            var animToPlay:String = singAnimations[Std.int(Math.abs(note.noteData))] + altAnim;
            if(note.gfNote) {
                    char = gf;
        	}

            if(char != null)
            {
                char.playAnim(animToPlay, true);
                char.holdTimer = 0;
                    }
            }
	
		if (SONG.needsVoices)
			vocals.volume = 1;
			vocalsPlayer.volume = 1;
			vocalsOpponent.volume = 1;
		var time:Float = 0.15;
		if(note.isSustainNote && !note.animation.curAnim.name.endsWith('end')) {
			time += 0.15;
		}
		StrumPlayAnim(true, Std.int(Math.abs(note.noteData)), time);
		note.hitByOpponent = true;

		var scriptName:String = reverseNoteHit ? 'goodNoteHit' : 'opponentNoteHit';
		var result:Dynamic;
		if (ClientPrefs.data.compatibility_mode) {
			// 0.7.3 格式: 与 opponentNoteHit 一致使用 Math.abs
			result = callOnLuas(scriptName, [notes.members.indexOf(note), Math.abs(note.noteData), note.noteType, note.isSustainNote]);
		} else if (reverseNoteHit) {
			// 0.6.3 格式, 但因 reverseNoteHit 实际调用了 goodNoteHit, 需传原始 noteData
			result = callOnLuas(scriptName, [notes.members.indexOf(note), note.noteData, note.noteType, note.isSustainNote]);
		} else {
			// 0.6.3 opponentNoteHit 本身使用 Math.abs
			result = callOnLuas(scriptName, [notes.members.indexOf(note), Math.abs(note.noteData), note.noteType, note.isSustainNote]);
		}
		if(result != FunkinLua.Function_Stop && result != FunkinLua.Function_StopHScript && result != FunkinLua.Function_StopAll) callOnHScript(scriptName, [note]);
		if (!note.isSustainNote)
		{
			note.kill();
			notes.remove(note, true);
			note.destroy();
		}
		if (!ClientPrefs.data.opponentfe) {
		for (i in 0...4) {
		setOpponentStrumStatic(i);
		}
	}
}
	function invalidateNote(daNote:Note):Void
	{
		daNote.active = false;
		daNote.visible = false;
		daNote.kill();
	}

public function setOpponentStrumStatic(direction:Int) {
    var strum = opponentStrums.members[direction];
    if (strum != null) {
        strum.playAnim('static', true);
        strum.resetAnim = 0;
    }
}
public function setgoodnoteStrumStatic(direction:Int) {
    var strum = playerStrums.members[direction];
    if (strum != null) {
        strum.playAnim('static', true);
        strum.resetAnim = 0;
    }
}


var msScaleTween:FlxTween;

function goodNoteHit(note:Note, ?time:Float = -999999):Void
{
if (note.isSustainNote) {
sustainNotescore += 10;
}
 var rating:String = 'sick';

if (!note.isSustainNote && !(note.ignoreNote || note.hitCausesMiss))  {
notehitlol++;
if (!cpuControlled) {
	var noteDiff:Float = Math.abs(note.strumTime - Conductor.songPosition + ClientPrefs.data.ratingOffset);
	sustainNotescore = 0;
	if (noteDiff <= ClientPrefs.data.badWindow && noteDiff > ClientPrefs.data.goodWindow) {
	    rating = 'bad';
	} else if (noteDiff <= ClientPrefs.data.goodWindow && noteDiff > ClientPrefs.data.sickWindow) {
	    rating = 'good';
	} else if (noteDiff <= ClientPrefs.data.sickWindow) {
	    rating = 'sick';
	} else if (noteDiff > ClientPrefs.data.badWindow) {
	    rating = 'shit';
	}

	if (rating == 'sick') {
		msTxtKade.color = 0x00FFFF;
	} else if (rating == 'good') {
		msTxtKade.color  = 0x006400;
	} else if (rating == 'bad') {
		msTxtKade.color = 0xEEFF00;
	} else if (rating == 'shit') {
		msTxtKade.color = 0xFF0000;
	}

	if (!replayMode && replayExam != null)
	{
		var signedDiff:Float = note.strumTime - Conductor.songPosition + ClientPrefs.data.ratingOffset;
		replayExam.recordJudgment(note.strumTime, note.noteData, signedDiff, rating, note.isSustainNote);
	}

	var strumTime:Float = note.strumTime;
	var songPos:Float = Conductor.songPosition;
	var rOffset:Float = ClientPrefs.data.ratingOffset;
	var diff:Float = strumTime - songPos + rOffset;

	msTxtKade.text = Std.string(FlxMath.roundDecimal(-diff, 3)) + "ms";
	msTxtKade.alpha = 1;
	if (msScaleTween != null) msScaleTween.cancel();
	msTxtKade.scale.set(1.15, 1.15);
	msScaleTween = FlxTween.tween(msTxtKade.scale, {x: 1, y: 1}, 0.15, {ease: FlxEase.backOut});

	if (msTween != null) msTween.cancel();
	msTween = FlxTween.tween(msTxtKade, {alpha: 0}, 0.5, {ease: FlxEase.quintIn});
} else {
	sustainNotescore = 0;
}
	}

		if (!note.wasGoodHit)
		{
			if(cpuControlled && (note.ignoreNote || note.hitCausesMiss)) return;

			if (!cpuControlled && ClientPrefs.data.hitsoundVolume > 0 && !note.hitsoundDisabled)
			{
				FlxG.sound.play(Paths.sound('hitsound'), ClientPrefs.data.hitsoundVolume);
			}

			if(note.hitCausesMiss) {
				noteMiss(note);
				if(!note.noteSplashDisabled && !note.isSustainNote) {
					spawnNoteSplashOnNote(note);
				}

			if(!note.noMissAnimation)
			{
                switch(note.noteType) {
                case 'Hurt Note': //Hurt note
                var hurtChar:Character = playOpponent ? dad : boyfriend;
                if(hurtChar.animation.getByName('hurt') != null) {
                hurtChar.playAnim('hurt', true);
                hurtChar.specialAnim = true;
                	}
            	}
        	}

				note.wasGoodHit = true;
				if (!note.isSustainNote)
				{
					note.kill();
					notes.remove(note, true);
					note.destroy();
				}
				return;
			}
			if (!note.isSustainNote)
			{
				combo += 1;
				popUpScore(note, time);
			} 
			if (note.isSustainEnd && !cpuControlled && !practiceMode) {
			songScore += sustainNotescore;
			updateScore();
			sustainNotescore = 0;
			if(ClientPrefs.data.noteSplashes && note != null && !cpuControlled) {
			var strum:StrumNote = playerStrums.members[note.noteData];
			if(strum != null) {
				spawnNoteSplash(strum.x, strum.y, note.noteData, note);
			}
		}

			}
			var gainHealth:Bool = true;
			if (guitarHeroSustains && note.isSustainNote)
				gainHealth = false;
			if (gainHealth) {
				if (playOpponent)
					health -= note.hitHealth * healthGain;
				else
					health += note.hitHealth * healthGain;
			}

			if(!note.noAnimation && !_suppressNoteAnim) {
				var animToPlay:String = singAnimations[Std.int(Math.abs(note.noteData))];

				if(note.gfNote)
				{
					if(gf != null)
					{
						gf.playAnim(animToPlay + note.animSuffix, true);
						gf.holdTimer = 0;
					}
				}
                else
                    {
                        var playChar:Character = playOpponent ? dad : boyfriend;
                        playChar.playAnim(animToPlay + note.animSuffix, true);
                        playChar.holdTimer = 0;
                    }

                    if(note.noteType == 'Hey!') {
                    var heyChar:Character = playOpponent ? dad : boyfriend;
                    if(heyChar.animOffsets.exists('hey')) {
                    heyChar.playAnim('hey', true);
                    heyChar.specialAnim = true;
                    heyChar.heyTimer = 0.6;
                }

					if(gf != null && gf.animOffsets.exists('cheer')) {
						gf.playAnim('cheer', true);
						gf.specialAnim = true;
						gf.heyTimer = 0.6;
					}
				}
			}

			if(cpuControlled) {
				if (!strumsHit[(note.noteData % 4) + 4]) {
					strumsHit[(note.noteData % 4) + 4] = true;
					var time:Float = calculateResetTime();
					if(note.isSustainNote && !note.animation.curAnim.name.endsWith('end')) {
						time += 0.15;
					}
					StrumPlayAnim(false, Std.int(Math.abs(note.noteData)), time);
				}
			} else {
				var spr = playerStrums.members[note.noteData];
				if(spr != null)
				{
					spr.playAnim('confirm', true);
				}
			}
			note.wasGoodHit = true;
			vocals.volume = 1;
			vocalsPlayer.volume = 1;
			vocalsOpponent.volume = 1;

			if (!cpuControlled) {
				var scriptName:String = reverseNoteHit ? 'opponentNoteHit' : 'goodNoteHit';
				var result:Dynamic;
				if (ClientPrefs.data.compatibility_mode) {
					// 0.7.3 格式: 传递 Math.round(Math.abs(noteData))
					var isSus:Bool = note.isSustainNote;
					var leData:Int = Math.round(Math.abs(note.noteData));
					var leType:String = note.noteType;
					result = callOnLuas(scriptName, [notes.members.indexOf(note), leData, leType, isSus]);
				} else {
					// 0.6.3 格式: 传递原始 noteData (可能为负数)
					result = callOnLuas(scriptName, [notes.members.indexOf(note), note.noteData, note.noteType, note.isSustainNote]);
				}
				if(result != FunkinLua.Function_Stop && result != FunkinLua.Function_StopHScript && result != FunkinLua.Function_StopAll) callOnHScript(scriptName, [note]);
			}

			if (!note.isSustainNote)
			{
				note.kill();
				notes.remove(note, true);
				note.destroy();
			}
		}
		if (cpuControlled && !ClientPrefs.data.opponentfe) {
			setgoodnoteStrumStatic(Std.int(Math.abs(note.noteData)));
		}
}

	public function spawnNoteSplashOnNote(note:Note) {
		if(ClientPrefs.data.noteSplashes && note != null && !cpuControlled) {
			var strum:StrumNote = playerStrums.members[note.noteData];
			if(strum != null) {
				spawnNoteSplash(strum.x, strum.y, note.noteData, note);
			}
		}
	}

	public function spawnNoteSplash(x:Float, y:Float, data:Int, ?note:Note = null) {
		var skin:String = 'noteSplashes';
		if(PlayState.SONG.splashSkin != null && PlayState.SONG.splashSkin.length > 0) skin = PlayState.SONG.splashSkin;

		var hue:Float = 0;
		var sat:Float = 0;
		var brt:Float = 0;
		if (data > -1 && data < ClientPrefs.data.arrowHSV.length)
		{
			hue = ClientPrefs.data.arrowHSV[data][0] / 360;
			sat = ClientPrefs.data.arrowHSV[data][1] / 100;
			brt = ClientPrefs.data.arrowHSV[data][2] / 100;
			if(note != null) {
				skin = note.noteSplashTexture;
				hue = note.noteSplashHue;
				sat = note.noteSplashSat;
				brt = note.noteSplashBrt;
			}
		}

		var splash:NoteSplash = grpNoteSplashes.recycle(NoteSplash);
		splash.setupNoteSplash(x, y, data, skin, hue, sat, brt);
		grpNoteSplashes.add(splash);
	}

	// Stage-specific private methods moved to stage/*.hx handlers.

	/** @return the stage handler cast to LimoStage, or null. */
	var limoStage(get, never):LimoStage;
	inline function get_limoStage():LimoStage
		return (stageBackdrop is LimoStage) ? cast stageBackdrop : null;

	override function destroy() {
		for (lua in luaArray) {
			lua.call('onDestroy', []);
			lua.stop();
		}
		luaArray = [];

		#if HSCRIPT_ALLOWED
		if(FunkinLua.hscript != null) FunkinLua.hscript = null;
		#end

		#if HSCRIPT_ALLOWED
		if (hscriptArray != null) {
			for (script in hscriptArray) {
				script.stop();
			}
			hscriptArray = null;
		}
		#end
		FlxAnimationController.globalSpeed = 1;
		if (FlxG.sound.music != null) FlxG.sound.music.pitch = 1;
		if (ratingPopup != null) ratingPopup.destroyAll();

		// Clear NoteMs/NoteTime arrays to free memory
		if (NoteMs != null) NoteMs = [];
		if (NoteTime != null) NoteTime = [];
		if (unspawnNotes != null) unspawnNotes = [];
		if (eventNotes != null) eventNotes = [];

		// Destroy stage backdrop
		if (stageBackdrop != null)
		{
			stageBackdrop.destroy();
			stageBackdrop = null;
		}

		// Trigger GC on state destruction to prevent memory accumulation
		MemoryMonitor.triggerGarbageCollection('playStateDestroy');

		instance = null;
		super.destroy();
	}

	public static function cancelMusicFadeTween() {
		if(FlxG.sound.music.fadeTween != null) {
			FlxG.sound.music.fadeTween.cancel();
		}
		FlxG.sound.music.fadeTween = null;
	}

	var lastStepHit:Int = -1;
	override function stepHit()
	{
		super.stepHit();
		if (!startingSong && FlxG.sound.music != null
			&& (Math.abs(FlxG.sound.music.time - (Conductor.songPosition - Conductor.offset)) > (20 * playbackRate)
			|| (SONG.needsVoices && Math.abs(vocals.time - (Conductor.songPosition - Conductor.offset)) > (20 * playbackRate))))
		{
			resyncVocals();
		}

		if(curStep == lastStepHit) {
			return;
		}

		lastStepHit = curStep;
		setOnScripts('curStep', curStep);
		callOnScripts('onStepHit', []);
	}

	var lastBeatHit:Int = -1;

	override function beatHit()
	{
		super.beatHit();

		if(lastBeatHit >= curBeat) {
			//trace('BEAT HIT: ' + curBeat + ', LAST HIT: ' + lastBeatHit);
			return;
		}

		if (generatedMusic)
		{
			notes.sort(FlxSort.byY, ClientPrefs.data.downScroll ? FlxSort.ASCENDING : FlxSort.DESCENDING);
		}

		iconP1.scale.set(1.2, 1.2);
		iconP2.scale.set(1.2, 1.2);

		iconP1.updateHitbox();
		iconP2.updateHitbox();

		if (gf != null && curBeat % Math.round(gfSpeed * gf.danceEveryNumBeats) == 0 && gf.animation.curAnim != null && !gf.animation.curAnim.name.startsWith("sing") && !gf.stunned)
		{
			gf.dance();
		}
		if (curBeat % boyfriend.danceEveryNumBeats == 0 && boyfriend.animation.curAnim != null && !boyfriend.animation.curAnim.name.startsWith('sing') && !boyfriend.stunned)
		{
			boyfriend.dance();
		}
		if (curBeat % dad.danceEveryNumBeats == 0 && dad.animation.curAnim != null && !dad.animation.curAnim.name.startsWith('sing') && !dad.stunned)
		{
			dad.dance();
		}

		// Delegate per-beat stage animation
		if (stageBackdrop != null)
			stageBackdrop.beatHit();
		lastBeatHit = curBeat;

		setOnScripts('curBeat', curBeat); //DAWGG?????
		callOnScripts('onBeatHit', []);
	}

	override function sectionHit()
	{
		super.sectionHit();

		if (SONG.notes[curSection] != null)
		{
			if (generatedMusic && !endingSong && !isCameraOnForcedPos)
			{
				moveCameraSection();
			}

			if (camZooming && FlxG.camera.zoom < 1.35 && ClientPrefs.data.camZooms)
			{
				FlxG.camera.zoom += 0.015 * camZoomingMult;
				camHUD.zoom += 0.03 * camZoomingMult;
			}

			if (SONG.notes[curSection].changeBPM)
			{
				Conductor.changeBPM(SONG.notes[curSection].bpm);
				setOnScripts('curBpm', Conductor.bpm);
				setOnScripts('crochet', Conductor.crochet);
				setOnScripts('stepCrochet', Conductor.stepCrochet);
			}
			setOnScripts('mustHitSection', SONG.notes[curSection].mustHitSection);
			setOnScripts('altAnim', SONG.notes[curSection].altAnim);
			setOnScripts('gfSection', SONG.notes[curSection].gfSection);
		}
		
		setOnScripts('curSection', curSection);
		callOnScripts('onSectionHit', []);
	}
	public function callOnScripts(funcToCall:String, args:Array<Dynamic> = null, ignoreStops = false, exclusions:Array<String> = null, excludeValues:Array<Dynamic> = null):Dynamic {
		var returnVal:Dynamic = FunkinLua.Function_Continue;
		if(args == null) args = [];
		if(exclusions == null) exclusions = [];
		if(excludeValues == null) excludeValues = [FunkinLua.Function_Continue];

		var result:Dynamic = callOnLuas(funcToCall, args, ignoreStops, exclusions, excludeValues);
		if(result == null || excludeValues.contains(result)) result = callOnHScript(funcToCall, args, ignoreStops, exclusions, excludeValues);
		return result;
	}

	#if HSCRIPT_ALLOWED
	/**
	 * MusicBeatState.initHScripts() 现已使用 concat 追加而非重置数组，
	 * 因此 PlayState 在 create() 中手动加载的 scripts/ 脚本得以保留。
	 * data/states/PlayState/ 与 hscripts/PlayState/ 的脚本由父类补充加载。
	 */
	override function initHScripts():Void {
		super.initHScripts();
	}
	#end

	public function callOnHScript(funcToCall:String, args:Array<Dynamic> = null, ?ignoreStops:Bool = false, exclusions:Array<String> = null, excludeValues:Array<Dynamic> = null):Dynamic {
		var returnVal:Dynamic = FunkinLua.Function_Continue;

	#if HSCRIPT_ALLOWED
		if(exclusions == null) exclusions = new Array();
		if(excludeValues == null) excludeValues = new Array();
		excludeValues.push(FunkinLua.Function_Continue);

		var len:Int = hscriptArray.length;
		if (len < 1)
			return returnVal;
		for(i in 0...len) {
			var script:HScript = hscriptArray[i];
			if(script == null || script.closed || !script.exists(funcToCall))
				continue;

			var myValue:Dynamic = null;
			try {
				myValue = script.call(funcToCall, args);
				if(myValue == FunkinLua.Function_StopHScript || myValue == FunkinLua.Function_StopAll)
				{
					if(!excludeValues.contains(myValue) && !ignoreStops)
					{
						returnVal = myValue;
						break;
					}
				}
				else if(myValue != null && !excludeValues.contains(myValue))
				{
					returnVal = myValue;
				}
			} catch (e:Dynamic) {
				TraceManager.error('trace.playState.hscriptCallFailed', 'HScript call "{}" failed on {}: {}', [funcToCall, script.scriptName, e]);
			}
		}
		#end
		return returnVal;
	}

	public function setOnScripts(variable:String, arg:Dynamic, exclusions:Array<String> = null) {
		if(exclusions == null) exclusions = [];
		setOnLuas(variable, arg, exclusions);
		setOnHScript(variable, arg, exclusions);
	}

	override public function setOnLuas(variable:String, arg:Dynamic, exclusions:Array<String> = null) {
		#if LUA_ALLOWED
		if(exclusions == null) exclusions = [];
		for (script in luaArray) {
			if(exclusions.contains(script.scriptName))
				continue;

			script.set(variable, arg);
		}
		#end
	}

	public function setOnHScript(variable:String, arg:Dynamic, exclusions:Array<String> = null) {
		#if HSCRIPT_ALLOWED
		if(exclusions == null) exclusions = [];
		HScript.setOnGlobalScript(variable, arg);
		for (script in hscriptArray) {
			if (!script.closed) {
				script.set(variable, arg);
			}
		}
		#end
	}


	override public function callOnLuas(funcToCall:String, args:Array<Dynamic> = null, ignoreStops = false, exclusions:Array<String> = null, excludeValues:Array<Dynamic> = null):Dynamic {
		var returnVal:Dynamic = FunkinLua.Function_Continue;
		#if LUA_ALLOWED
		if(args == null) args = [];
		if(exclusions == null) exclusions = [];
		if(excludeValues == null) excludeValues = [FunkinLua.Function_Continue];

		var arr:Array<FunkinLua> = [];
		for (script in luaArray)
		{
			if(script.closed)
			{
				arr.push(script);
				continue;
			}

			if(exclusions.contains(script.scriptName))
				continue;

			var myValue:Dynamic = script.call(funcToCall, args);
			if((myValue == FunkinLua.Function_StopLua || myValue == FunkinLua.Function_StopAll) && !excludeValues.contains(myValue) && !ignoreStops)
			{
				returnVal = myValue;
				break;
			}

			if(myValue != null && !excludeValues.contains(myValue))
				returnVal = myValue;

			if(script.closed) arr.push(script);
		}

		if(arr.length > 0)
			for (script in arr)
				luaArray.remove(script);
		#end
		return returnVal;
	}



	function calculateResetTime():Float {
		return (Conductor.stepCrochet * 1.5 / 1000) / playbackRate;
	}

	function StrumPlayAnim(isDad:Bool, id:Int, time:Float) {
		var spr:StrumNote = null;
		if(isDad) {
			spr = strumLineNotes.members[id];
		} else {
			spr = playerStrums.members[id];
		}
		if(spr != null) {
			spr.playAnim('confirm', true);
			spr.resetAnim = time;
		}
	}

	public var ratingName:String = '?';
	public var ratingPercent:Float;
	public var ratingFC:String;
	public function RecalculateRating(badHit:Bool = false) {
		setOnScripts('score', songScore);
		setOnScripts('misses', songMisses);
		setOnScripts('hits', songHits);
		setOnScripts('combo', combo);

		var ret:Dynamic = callOnScripts('onRecalculateRating', [], false);
		if(ret != FunkinLua.Function_Stop)
		{
			if(totalPlayed < 1) //Prevent divide by 0
				ratingName = '?';
			else
			{
				// Rating Percent
				ratingPercent = Math.min(1, Math.max(0, totalNotesHit / totalPlayed));
				//trace((totalNotesHit / totalPlayed) + ', Total: ' + totalPlayed + ', notes hit: ' + totalNotesHit);

				// Botplay forces perfect accuracy
				if(cpuControlled) ratingPercent = 1;

				// Rating Name
				if(ratingPercent >= 1)
				{
					ratingName = ratingStuff[ratingStuff.length-1][0]; //Uses last string
				}
				else
				{
					for (i in 0...ratingStuff.length-1)
					{
						if(ratingPercent < ratingStuff[i][1])
						{
							ratingName = ratingStuff[i][0];
							break;
						}
					}
				}
			}

			// Rating FC
			ratingFC = "";
			if (sicks > 0) ratingFC = "SFC";
			if (goods > 0) ratingFC = "GFC";
			if (bads > 0 || shits > 0) ratingFC = "FC";
			if (songMisses > 0 && songMisses < 10) ratingFC = "SDCB";
			else if (songMisses >= 10) ratingFC = "Clear";
		}
		updateScore(badHit); // score will only update after rating is calculated, if it's a badHit, it shouldn't bounce -Ghost
		setOnScripts('rating', ratingPercent);
		setOnScripts('ratingName', ratingName);
		setOnScripts('ratingFC', ratingFC);
	}

	#if ACHIEVEMENTS_ALLOWED
	public function checkForAchievement(achievesToCheck:Array<String> = null):String
	{
		if(chartingMode) return null;

		var usedPractice:Bool = (ClientPrefs.getGameplaySetting('practice', false) || ClientPrefs.getGameplaySetting('botplay', false));
		for (i in 0...achievesToCheck.length) {
			var achievementName:String = achievesToCheck[i];
			if(!Achievements.isAchievementUnlocked(achievementName) && !cpuControlled) {
				var unlock:Bool = false;
				switch(achievementName)
				{
					case 'week1_nomiss' | 'week2_nomiss' | 'week3_nomiss' | 'week4_nomiss' | 'week5_nomiss' | 'week6_nomiss' | 'week7_nomiss':
						if(isStoryMode && campaignMisses + songMisses < 1 && CoolUtil.difficultyString() == 'HARD' && storyPlaylist.length <= 1 && !changedDifficulty && !usedPractice)
						{
							var weekName:String = WeekData.getWeekFileName();
							switch(weekName) //I know this is a lot of duplicated code, but it's easier readable and you can add weeks with different names than the achievement tag
							{
								case 'week1':
									if(achievementName == 'week1_nomiss') unlock = true;
								case 'week2':
									if(achievementName == 'week2_nomiss') unlock = true;
								case 'week3':
									if(achievementName == 'week3_nomiss') unlock = true;
								case 'week4':
									if(achievementName == 'week4_nomiss') unlock = true;
								case 'week5':
									if(achievementName == 'week5_nomiss') unlock = true;
								case 'week6':
									if(achievementName == 'week6_nomiss') unlock = true;
								case 'week7':
									if(achievementName == 'week7_nomiss') unlock = true;
							}
						}
					case 'ur_bad':
						if(ratingPercent < 0.2 && !practiceMode) {
							unlock = true;
						}
					case 'line_blue':
						if(goods == 1 && bads == 0 && shits == 0 && songMisses == 0 && sicks > 0 && !usedPractice){
							unlock = true;
						}
					case 'ur_good':
						if(ratingPercent >= 1 && !usedPractice) {
							unlock = true;
						}
					case 'roadkill_enthusiast':
						if(Achievements.henchmenDeath >= 100) {
							unlock = true;
						}
					case 'oversinging':
						if(boyfriend.holdTimer >= 10 && !usedPractice) {
							unlock = true;
						}
					case 'hype':
						if(!boyfriendIdled && !usedPractice) {
							unlock = true;
						}
					case 'two_keys':
						if(!usedPractice) {
							var howManyPresses:Int = 0;
							for (j in 0...keysPressed.length) {
								if(keysPressed[j]) howManyPresses++;
							}

							if(howManyPresses <= 2) {
								unlock = true;
							}
						}
					case 'toastie':
						if(/*ClientPrefs.data.framerate <= 60 && !ClientPrefs.data.cacheOnGPU &&*/!ClientPrefs.data.shaders && ClientPrefs.data.lowQuality && !ClientPrefs.data.globalAntialiasing) {
							unlock = true;
						}
					case 'debugger':
						if(Paths.formatToSongPath(SONG.song) == 'test' && !usedPractice) {
							unlock = true;
						}
				}

				if(unlock) {
					Achievements.unlockAchievement(achievementName);
					return achievementName;
				}
			}
		}
		return null;
	}
	#end

public var curLight:Int = -1;
        public var curLightEvent:Int = -1;
	}
